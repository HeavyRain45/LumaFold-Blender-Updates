from __future__ import annotations

"""Strict input ownership boundary for the Embedded LumaFold Host.

0.8.56 routes pointer events into ImGui only when the pointer is over the actual
LumaFold surface, or when a LumaFold gesture already owns the pointer. High-rate
Blender-space mouse/tablet traffic therefore bypasses the Host completely.

Secondary ImGui popups can extend beyond the primary rectangle, so the boundary
temporarily widens to the bound View3D while one of those popups is actually open.
"""

import time


_POINTER_BUTTONS = {"LEFTMOUSE", "RIGHTMOUSE", "MIDDLEMOUSE"}
_POINTER_MOTION = {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}
_POINTER_WHEEL = {"WHEELUPMOUSE", "WHEELDOWNMOUSE", "WHEELINMOUSE", "WHEELOUTMOUSE"}
_POINTER_EVENTS = _POINTER_BUTTONS | _POINTER_MOTION | _POINTER_WHEEL
_IDLE_TIMER_INTERVAL = 1.00

_INSTALLED = False
_ORIGINAL_MODAL = None
_OPERATORS = None


def configure(operators_module):
    global _OPERATORS
    _OPERATORS = operators_module


def _bound_view3d(operator):
    host = getattr(operator, "_host", None)
    if host is None or _OPERATORS is None:
        return None, None, None
    try:
        window, area, _rebound = _OPERATORS._ensure_host_binding(host)
    except Exception:
        window = None
        area = None
    if area is None:
        return host, window, None
    return host, window, area


def _point_in_region(region, mx, my):
    try:
        return bool(
            float(region.x) <= mx < float(region.x + region.width)
            and float(region.y) <= my < float(region.y + region.height)
        )
    except Exception:
        return False


def _bound_window_region(operator, context, event):
    host, window, area = _bound_view3d(operator)
    if host is None or area is None:
        return host, None
    try:
        event_window = getattr(context, "window", None)
        if event_window is None:
            return host, None
        if int(event_window.as_pointer()) != int(getattr(host, "window_pointer", 0) or 0):
            return host, None
        if window is not None and int(event_window.as_pointer()) != int(window.as_pointer()):
            return host, None
        mx = float(event.mouse_x)
        my = float(event.mouse_y)
    except Exception:
        return host, None
    try:
        regions = tuple(getattr(area, "regions", ()) or ())
    except Exception:
        regions = ()
    window_region = next((r for r in regions if getattr(r, "type", "") == "WINDOW"), None)
    if window_region is None or not _point_in_region(window_region, mx, my):
        return host, None
    for region in regions:
        if str(getattr(region, "type", "") or "") == "WINDOW":
            continue
        try:
            if int(getattr(region, "width", 0) or 0) <= 0 or int(getattr(region, "height", 0) or 0) <= 0:
                continue
        except Exception:
            continue
        if _point_in_region(region, mx, my):
            return host, None
    return host, window_region


def _pointer_inside_lumafold_surface(operator, context, event):
    """Return True only for the actual Embedded surface rectangle."""
    host, region = _bound_window_region(operator, context, event)
    if host is None or region is None:
        return False
    state = getattr(host, "state", {}) or {}
    if bool(state.get("_secondary_surface_open", False)):
        return True
    try:
        local_x = float(event.mouse_x) - float(region.x)
        local_y = float(region.height - 1) - (float(event.mouse_y) - float(region.y))
        scale = max(0.01, float(state.get("ui_scale", state.get("style_scale", 1.25)) or 1.25))
        width = max(1.0, float(state.get("compact_surface_w", 264.0) or 264.0) * scale)
        height = max(1.0, float(state.get("compact_surface_h", 338.0) or 338.0) * scale)
        x0 = state.get("embedded_window_pos_x")
        y0 = state.get("embedded_window_pos_y")
        if x0 is None or y0 is None:
            # First frame only: keep startup clickable until ImGui reports its rect.
            if int(state.get("_embedded_surface_boot_frame", 0) or 0) < 1:
                return True
            x0 = state.get("embedded_last_valid_pos_x", 0.0)
            y0 = state.get("embedded_last_valid_pos_y", 0.0)
        x0 = float(x0)
        y0 = float(y0)
    except Exception:
        return False
    margin = 3.0
    return bool(
        (x0 - margin) <= local_x < (x0 + width + margin)
        and (y0 - margin) <= local_y < (y0 + height + margin)
    )


def _host_owns_pointer(operator):
    host = getattr(operator, "_host", None)
    if host is None:
        return False
    try:
        owned = getattr(host, "_mouse_owned", None)
        if isinstance(owned, dict):
            return bool(any(bool(value) for value in owned.values()))
    except Exception:
        pass
    return False


def _reset_host_transient_input(operator):
    host = getattr(operator, "_host", None)
    if host is None:
        return
    try:
        host._reset_transient_input()
    except Exception:
        try:
            host._release_owned_input()
        except Exception:
            pass
    try:
        host._mark_dirty()
    except Exception:
        pass


def _host_interactive(operator) -> bool:
    host = getattr(operator, "_host", None)
    if host is None or bool(getattr(host, "closed", False)):
        return False
    try:
        owned = getattr(host, "_mouse_owned", None)
        if isinstance(owned, dict) and any(bool(value) for value in owned.values()):
            return True
    except Exception:
        pass
    try:
        io = getattr(host, "io", None)
        if io is not None and (
            bool(getattr(io, "want_capture_mouse", False))
            or bool(getattr(io, "want_capture_keyboard", False))
            or bool(getattr(io, "want_text_input", False))
        ):
            return True
    except Exception:
        pass
    return False


def _admit_idle_timer(operator) -> bool:
    """Keep only a low-rate lifecycle/context watchdog."""
    now = time.perf_counter()
    last = float(getattr(operator, "_lumafold_idle_timer_at", 0.0) or 0.0)
    if last > 0.0 and (now - last) < _IDLE_TIMER_INTERVAL:
        return False
    operator._lumafold_idle_timer_at = now
    return True


def install():
    global _INSTALLED, _ORIGINAL_MODAL
    if _INSTALLED or _OPERATORS is None:
        return
    cls = getattr(_OPERATORS, "LUMAFOLD_OT_toggle_p0", None)
    original = getattr(cls, "modal", None) if cls is not None else None
    if not callable(original):
        return
    _ORIGINAL_MODAL = original

    def modal_with_blender_ui_boundary(self, context, event):
        event_type = str(getattr(event, "type", "") or "")
        event_value = str(getattr(event, "value", "") or "").upper()

        if event_type == "TIMER":
            if not _admit_idle_timer(self):
                return {"RUNNING_MODAL"}
            return original(self, context, event)

        if event_type == "WINDOW_DEACTIVATE":
            return original(self, context, event)

        if event_type in _POINTER_EVENTS:
            inside = _pointer_inside_lumafold_surface(self, context, event)
            host_owns_pointer = _host_owns_pointer(self)
            if inside:
                self._lumafold_pointer_inside = True
                return original(self, context, event)
            if host_owns_pointer:
                return original(self, context, event)

            # Only the first crossing out of the product needs ImGui cleanup.
            if bool(getattr(self, "_lumafold_pointer_inside", False)):
                _reset_host_transient_input(self)
                self._lumafold_pointer_inside = False
            elif event_type in _POINTER_BUTTONS and event_value == "PRESS":
                _reset_host_transient_input(self)
            return {"PASS_THROUGH"}

        # Product hotkeys are Blender keymaps. The Host modal only sees keyboard
        # traffic while an ImGui control owns keyboard/text focus.
        if not _host_interactive(self):
            return {"PASS_THROUGH"}
        return original(self, context, event)

    cls.modal = modal_with_blender_ui_boundary
    _INSTALLED = True


def uninstall():
    global _INSTALLED, _ORIGINAL_MODAL, _OPERATORS
    if _OPERATORS is not None and callable(_ORIGINAL_MODAL):
        cls = getattr(_OPERATORS, "LUMAFOLD_OT_toggle_p0", None)
        if cls is not None:
            try:
                cls.modal = _ORIGINAL_MODAL
            except Exception:
                pass
    _ORIGINAL_MODAL = None
    _OPERATORS = None
    _INSTALLED = False
