import traceback
import time

import bpy

from .core.diagnostics import write_report
from .core.app import APP
from .core.state import STATE
from .core.host_control import HOST_CONTROL, EMBEDDED, DETACHING, SATELLITE, ATTACHING
from .runtime.bootstrap import begin_install_runtime_async, try_import, is_installing
from .ui.host import UIHost
from .ui.win32_window import view3d_region_screen_rect, imgui_local_to_screen
from .desktop.bridge_server import BRIDGE
from .desktop.launcher import launch_desktop_host, launch_satellite_host

_ACTIVE_OPERATOR = None
_RETURN_EMBEDDED_TARGET = None
_EXTERNAL_SATELLITE_HANDOFF_RUNNING = False
_EXTERNAL_SATELLITE_WATCHDOG_RUNNING = False
_MIGRATION_IN_PROGRESS = False
_RUNTIME_AUTOLAUNCH_PENDING = False
_RUNTIME_AUTOLAUNCH_TARGET = None


def _find_host_area(host):
    """Resolve the View3D area owned by a UIHost even when Blender's current
    event context is an Outliner/Properties/other editor.

    A modal operator receives TIMER events in whichever editor currently owns
    the event context.  Looking only at ``context.area`` therefore starves the
    LumaFold View3D of redraw/context updates after the user clicks another
    editor (most visibly the Outliner).
    """
    if host is None:
        return None, None
    try:
        windows = tuple(bpy.context.window_manager.windows)
    except Exception:
        return None, None
    for window in windows:
        try:
            if window.as_pointer() != host.window_pointer:
                continue
        except Exception:
            continue
        screen = getattr(window, "screen", None)
        if screen is None:
            continue
        for area in screen.areas:
            try:
                if area.as_pointer() == host.area_pointer:
                    return window, area
            except Exception:
                continue
    return None, None


def _window_by_pointer(pointer):
    try:
        windows = tuple(bpy.context.window_manager.windows)
    except Exception:
        return None
    for window in windows:
        try:
            if window.as_pointer() == int(pointer or 0):
                return window
        except Exception:
            continue
    return None


def _best_view3d_area(window):
    """Choose the primary View3D in the window's *current* Workspace/Screen.

    Embedded Host ownership is window-stable, but Blender Workspace switches
    replace the Screen/Area objects.  Prefer the current View3D when possible,
    otherwise bind to the largest View3D in the new Screen.
    """
    if window is None or getattr(window, "screen", None) is None:
        return None, None
    current_area = getattr(bpy.context, "area", None)
    current_window = getattr(bpy.context, "window", None)
    try:
        if (current_window is not None and current_window.as_pointer() == window.as_pointer()
                and current_area is not None and current_area.type == 'VIEW_3D'):
            region = next((r for r in current_area.regions if r.type == 'WINDOW'), None)
            if region is not None:
                return current_area, region
    except Exception:
        pass
    candidates = []
    for area in tuple(window.screen.areas):
        if getattr(area, "type", "") != 'VIEW_3D':
            continue
        region = next((r for r in area.regions if r.type == 'WINDOW'), None)
        if region is None:
            continue
        score = int(getattr(area, "width", 0) or 0) * int(getattr(area, "height", 0) or 0)
        candidates.append((score, area, region))
    if not candidates:
        return None, None
    candidates.sort(key=lambda item: item[0], reverse=True)
    _score, area, region = candidates[0]
    return area, region


def _workspace_name(window):
    try:
        return str(getattr(getattr(window, "workspace", None), "name", "") or "")
    except Exception:
        return ""


def _ensure_host_binding(host):
    """Rebind Embedded UIHost when Blender swaps Workspace/Screen/Area objects."""
    if host is None or getattr(host, "closed", False):
        return None, None, False
    window, area = _find_host_area(host)
    region = None
    if area is not None:
        region = next((r for r in area.regions if r.type == 'WINDOW'), None)
    # Workspace switch: the old Area pointer no longer exists in window.screen.
    if window is None:
        window = _window_by_pointer(getattr(host, "window_pointer", 0))
    if window is None:
        window = getattr(bpy.context, "window", None)
    needs_rebind = area is None or region is None
    if needs_rebind:
        area, region = _best_view3d_area(window)
        if area is not None and region is not None:
            try:
                host.rebind_view3d(window, area, region, workspace_name=_workspace_name(window))
                return window, area, True
            except Exception:
                return window, None, False
        return window, None, False
    # Same Area, but still pulse workspace/mode identity to clear transient input
    # on Mode changes that can consume a release event before LumaFold sees it.
    try:
        host.context_transition_pulse(workspace_name=_workspace_name(window), mode=str(getattr(bpy.context, "mode", "UNKNOWN")))
    except Exception:
        pass
    return window, area, False


def _request_embedded_first_frame(host, *, operator=None, max_attempts=24):
    """Commit the first Embedded WINDOW frame after the Header invoke returns.

    This bounded startup latch exists only until the first successful Host frame.
    It never becomes an idle heartbeat and never consumes WindowManager TIMER events.
    """
    attempts = {"count": 0}

    def _tick():
        if host is None or not bool(getattr(STATE, "running", False)):
            return None
        if int(getattr(STATE, "frames", 0) or 0) > 0:
            return None
        if bool(getattr(host, "closed", False)):
            if operator is not None:
                try:
                    lines = [line.strip() for line in str(getattr(STATE, "last_error", "") or "").splitlines() if line.strip()]
                    detail = lines[-1] if lines else str(getattr(STATE, "status", "") or "unknown draw error")
                    operator.report({'ERROR'}, "LumaFold first frame failed: " + detail)
                except Exception:
                    pass
            return None

        attempts["count"] += 1
        try:
            window, area = _find_host_area(host)
            if area is not None:
                region = next(
                    (
                        item for item in tuple(getattr(area, "regions", ()) or ())
                        if getattr(item, "type", "") == "WINDOW"
                        and int(item.as_pointer()) == int(getattr(host, "region_pointer", 0) or 0)
                    ),
                    None,
                )
                if region is not None:
                    try:
                        region.tag_redraw()
                    except Exception:
                        pass
                area.tag_redraw()
        except Exception:
            pass

        if attempts["count"] >= max(1, int(max_attempts)):
            STATE.status = "LumaFold first frame did not commit"
            if operator is not None:
                try:
                    operator.report({'ERROR'}, "LumaFold first frame did not commit")
                except Exception:
                    pass
            return None
        return 0.025

    try:
        bpy.app.timers.register(_tick, first_interval=0.0, persistent=False)
    except Exception:
        try:
            _tick()
        except Exception:
            pass


def _context_pulse(operator, host, host_id):
    """Low-rate lifecycle watchdog; refresh Core only when context truth changes."""
    if host is None:
        return
    state = getattr(host, "state", {}) or {}
    before_mode = str(state.get("blender_mode") or "")
    before_workspace = str(state.get("blender_workspace") or "")
    _window, _area, rebound = _ensure_host_binding(host)
    after_mode = str(state.get("blender_mode") or "")
    after_workspace = str(state.get("blender_workspace") or "")

    if rebound or after_mode != before_mode or after_workspace != before_workspace:
        try:
            APP.refresh_context(host_id=host_id)
        except Exception:
            # Context polling must never kill the UI runtime. Any actual draw
            # failure is still reported by UIHost._draw.
            pass
    if rebound:
        STATE.status = "Embedded Host rebound to current Workspace"

def _external_satellite_alive():
    proc = getattr(BRIDGE, "satellite_process", None)
    return bool(proc is not None and proc.poll() is None)


def _request_return_from_external_satellite():
    global _RETURN_EMBEDDED_TARGET, _MIGRATION_IN_PROGRESS, _EXTERNAL_SATELLITE_WATCHDOG_RUNNING
    target = dict(_RETURN_EMBEDDED_TARGET or {})
    _MIGRATION_IN_PROGRESS = True
    try:
        if HOST_CONTROL.lease.state in {SATELLITE, DETACHING}:
            HOST_CONTROL.begin_attach()
    except Exception:
        pass
    # Retire the watchdog before terminating the process so it cannot race a
    # second restore against this explicit Host migration.
    _EXTERNAL_SATELLITE_WATCHDOG_RUNNING = False
    try:
        BRIDGE.satellite_active = False
        BRIDGE.satellite_closing = True
        BRIDGE.stop_satellite_process()
    except Exception:
        pass
    STATE.running = False
    STATE.host = None
    STATE.host_mode = "embedded"
    STATE.status = "Returning to Embedded host"
    _RETURN_EMBEDDED_TARGET = None
    if target:
        def _restore():
            global _MIGRATION_IN_PROGRESS
            _restore_embedded_after_satellite(target)
            _MIGRATION_IN_PROGRESS = False
            return None
        bpy.app.timers.register(_restore, first_interval=0.03)
    else:
        _MIGRATION_IN_PROGRESS = False
    return None


def _external_satellite_handoff_tick():
    global _EXTERNAL_SATELLITE_HANDOFF_RUNNING, _MIGRATION_IN_PROGRESS
    proc = getattr(BRIDGE, "satellite_process", None)
    if proc is None or proc.poll() is not None:
        _EXTERNAL_SATELLITE_HANDOFF_RUNNING = False
        _MIGRATION_IN_PROGRESS = False
        try:
            if HOST_CONTROL.lease.state == DETACHING:
                HOST_CONTROL.cancel_detach()
        except Exception:
            pass
        STATE.status = "Satellite launch failed · Embedded retained"
        return None
    if bool(getattr(BRIDGE, "satellite_ready", False)):
        expected = int(getattr(BRIDGE, "satellite_expected_generation", 0) or 0)
        if HOST_CONTROL.lease.state != DETACHING or int(HOST_CONTROL.lease.generation) != expected:
            BRIDGE.stop_satellite_process()
            HOST_CONTROL.recover_embedded()
            _EXTERNAL_SATELLITE_HANDOFF_RUNNING = False
            _MIGRATION_IN_PROGRESS = False
            STATE.status = "Satellite lease rejected · Embedded retained"
            return None
        # Embedded remains the only valid renderer until this point. Shut it down
        # first, then atomically grant a new generation to Satellite.
        shutdown_active_runtime()
        HOST_CONTROL.grant_satellite(expected)
        BRIDGE.satellite_active = True
        STATE.running = True
        STATE.host = None
        STATE.host_mode = "satellite"
        STATE.status = "Satellite running · Lease owner"
        _EXTERNAL_SATELLITE_HANDOFF_RUNNING = False
        _MIGRATION_IN_PROGRESS = False
        _ensure_external_satellite_watchdog()
        return None
    return 0.02


def _external_satellite_watchdog():
    global _EXTERNAL_SATELLITE_WATCHDOG_RUNNING, _RETURN_EMBEDDED_TARGET, _MIGRATION_IN_PROGRESS
    if not _EXTERNAL_SATELLITE_WATCHDOG_RUNNING:
        return None
    proc = getattr(BRIDGE, "satellite_process", None)
    dead = proc is None or proc.poll() is not None
    closing = bool(getattr(BRIDGE, "satellite_closing", False))
    if dead or closing:
        target = dict(_RETURN_EMBEDDED_TARGET or {})
        BRIDGE.satellite_active = False
        BRIDGE.satellite_ready = False
        BRIDGE.satellite_closing = False
        BRIDGE.satellite_process = None
        STATE.running = False
        STATE.host = None
        STATE.host_mode = "embedded"
        STATE.status = "Satellite closed · returning to Blender"
        _RETURN_EMBEDDED_TARGET = None
        _EXTERNAL_SATELLITE_WATCHDOG_RUNNING = False
        _MIGRATION_IN_PROGRESS = True
        try:
            if HOST_CONTROL.lease.state in {SATELLITE, DETACHING}:
                HOST_CONTROL.begin_attach()
        except Exception:
            pass
        if target:
            def _restore():
                global _MIGRATION_IN_PROGRESS
                _restore_embedded_after_satellite(target)
                _MIGRATION_IN_PROGRESS = False
                return None
            bpy.app.timers.register(_restore, first_interval=0.03)
        else:
            _MIGRATION_IN_PROGRESS = False
        return None
    return 0.10


def _ensure_external_satellite_watchdog():
    global _EXTERNAL_SATELLITE_WATCHDOG_RUNNING
    if _EXTERNAL_SATELLITE_WATCHDOG_RUNNING:
        return
    _EXTERNAL_SATELLITE_WATCHDOG_RUNNING = True
    bpy.app.timers.register(_external_satellite_watchdog, first_interval=0.10)


def shutdown_all():
    shutdown_active_runtime()
    BRIDGE.stop()


def shutdown_active_runtime():
    global _ACTIVE_OPERATOR
    if _ACTIVE_OPERATOR is not None:
        try:
            _ACTIVE_OPERATOR._finish(bpy.context)
        except Exception:
            pass
        _ACTIVE_OPERATOR = None
    elif STATE.host is not None:
        try:
            STATE.host.shutdown()
        except Exception:
            pass


def _schedule_runtime_autolaunch(context):
    global _RUNTIME_AUTOLAUNCH_PENDING, _RUNTIME_AUTOLAUNCH_TARGET
    try:
        _RUNTIME_AUTOLAUNCH_TARGET = {
            "window_pointer": int(context.window.as_pointer()) if context.window is not None else 0,
            "area_pointer": int(context.area.as_pointer()) if context.area is not None else 0,
        }
    except Exception:
        _RUNTIME_AUTOLAUNCH_TARGET = {"window_pointer": 0, "area_pointer": 0}
    if _RUNTIME_AUTOLAUNCH_PENDING:
        return
    _RUNTIME_AUTOLAUNCH_PENDING = True
    bpy.app.timers.register(_runtime_autolaunch_tick, first_interval=0.12)


def _runtime_autolaunch_tick():
    global _RUNTIME_AUTOLAUNCH_PENDING, _RUNTIME_AUTOLAUNCH_TARGET
    if is_installing():
        return 0.12

    if try_import() is None:
        _RUNTIME_AUTOLAUNCH_PENDING = False
        _RUNTIME_AUTOLAUNCH_TARGET = None
        return None

    target = dict(_RUNTIME_AUTOLAUNCH_TARGET or {})
    _RUNTIME_AUTOLAUNCH_PENDING = False
    _RUNTIME_AUTOLAUNCH_TARGET = None

    try:
        wm = bpy.context.window_manager
        windows = tuple(getattr(wm, "windows", ()) or ())
        window_pointer = int(target.get("window_pointer", 0) or 0)
        area_pointer = int(target.get("area_pointer", 0) or 0)

        window = next(
            (item for item in windows if int(item.as_pointer()) == window_pointer),
            None,
        )
        if window is None:
            window = next(iter(windows), None)
        if window is None or getattr(window, "screen", None) is None:
            raise RuntimeError("没有可用的 Blender Window")

        area = next(
            (
                item for item in tuple(window.screen.areas)
                if item.type == 'VIEW_3D' and int(item.as_pointer()) == area_pointer
            ),
            None,
        )
        if area is None:
            area = next((item for item in tuple(window.screen.areas) if item.type == 'VIEW_3D'), None)
        if area is None:
            raise RuntimeError("没有可用的 3D View")

        region = next((item for item in tuple(area.regions) if item.type == 'WINDOW'), None)
        if region is None:
            raise RuntimeError("3D View 没有 WINDOW region")

        with bpy.context.temp_override(window=window, area=area, region=region):
            bpy.ops.lumafold.toggle_p0('INVOKE_DEFAULT')
    except Exception:
        STATE.last_error = traceback.format_exc()
        STATE.status = "Runtime ready · auto-open failed"
    return None


class LUMAFOLD_OT_install_runtime(bpy.types.Operator):
    bl_idname = "lumafold.install_runtime"
    bl_label = "Install LumaFold UI Runtime"
    bl_description = "Install the matching Blender 5.x UI runtime"

    def execute(self, context):
        try:
            started = begin_install_runtime_async()
            if started:
                self.report({'INFO'}, "LumaFold runtime installation started in background")
            else:
                self.report({'INFO'}, "LumaFold runtime is already ready or installing")
            return {'FINISHED'}
        except Exception as exc:
            STATE.last_error = traceback.format_exc()
            STATE.status = "Runtime install failed"
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}


class LUMAFOLD_OT_toggle_p0(bpy.types.Operator):
    bl_idname = "lumafold.toggle_p0"
    bl_label = "LumaFold 浮台"
    bl_description = "打开/关闭 LumaFold 浮台；卫星状态下点击可收回到 Blender"

    _timer = None
    _host = None
    _last_context_pulse = 0.0

    @classmethod
    def poll(cls, context):
        return context.area is not None and context.area.type == 'VIEW_3D' and any(r.type == 'WINDOW' for r in context.area.regions)

    def invoke(self, context, event):
        global _ACTIVE_OPERATOR
        if HOST_CONTROL.lease.state in {SATELLITE, DETACHING, ATTACHING} or STATE.host_mode == "satellite" or _external_satellite_alive():
            _request_return_from_external_satellite()
            return {'FINISHED'}
        if STATE.running:
            shutdown_active_runtime()
            return {'FINISHED'}
        if not bool(getattr(STATE, "runtime_ready", False)) and try_import() is None:
            try:
                begin_install_runtime_async()
                _schedule_runtime_autolaunch(context)
                self.report({'INFO'}, "LumaFold 首次启动正在准备 UI，完成后会自动打开")
                return {'FINISHED'}
            except Exception as exc:
                STATE.last_error = traceback.format_exc()
                STATE.status = "Runtime install failed"
                self.report({'ERROR'}, str(exc))
                return {'CANCELLED'}
        try:
            # A successful launch starts with a clean error state.
            STATE.last_error = ""
            STATE.frames = 0
            self._host = UIHost(context, host_mode="embedded")
            self._timer = None
            context.window_manager.modal_handler_add(self)
            _ACTIVE_OPERATOR = self

            # SpaceView3D draw handlers do not schedule their own first draw.
            # Trigger a bounded redraw latch only after the Header invoke returns.
            # It self-destructs after the first committed Host frame and never
            # becomes an idle heartbeat.
            _request_embedded_first_frame(self._host, operator=self)
            return {'RUNNING_MODAL'}
        except Exception as exc:
            STATE.last_error = traceback.format_exc()
            STATE.status = "Start failed"
            self.report({'ERROR'}, str(exc))
            self._finish(context)
            return {'CANCELLED'}

    def modal(self, context, event):
        if self._host is None or self._host.closed:
            self._finish(context)
            return {'FINISHED'}

        # Embedded owns no WindowManager event timer. TIMER traffic from
        # Blender or other add-ons always bypasses LumaFold.
        if event.type == 'TIMER':
            return {'PASS_THROUGH'}

        # S0.7.3: never gate Embedded input on context.area identity.  Blender can
        # keep a modal operator's event context associated with the Area from
        # which it was invoked even after the Window switches Workspace.  The
        # Host itself may already have rebound and be drawing in a different
        # View3D, which previously produced the exact failure mode "visible but
        # cannot click or drag until toggled off/on".
        window, area, _rebound = _ensure_host_binding(self._host)
        if window is None or area is None:
            return {'PASS_THROUGH'}
        try:
            event_window = getattr(context, 'window', None)
            if event_window is not None and event_window.as_pointer() != self._host.window_pointer:
                return {'PASS_THROUGH'}
        except Exception:
            pass
        region = next((r for r in area.regions if r.type == 'WINDOW'), None)
        if region is None:
            return {'PASS_THROUGH'}

        # Feed all same-Window events. UIHost owns only presses that start while
        # ImGui actually wants the mouse/keyboard, and releases are completed even
        # if the pointer leaves the floating surface. This keeps input alive across
        # Workspace/Area swaps without stealing unrelated Blender interaction.
        self._host.feed_event(event, region=region)
        try:
            area.tag_redraw()
        except Exception:
            pass
        if self._host.should_capture(event):
            return {'RUNNING_MODAL'}
        return {'PASS_THROUGH'}

    def cancel(self, context):
        self._finish(context)

    def _finish(self, context):
        global _ACTIVE_OPERATOR
        if self._timer is not None:
            try:
                context.window_manager.event_timer_remove(self._timer)
            except Exception:
                pass
            self._timer = None
        if self._host is not None:
            self._host.shutdown()
            self._host = None
        _ACTIVE_OPERATOR = None




class LUMAFOLD_OT_move_to_satellite(bpy.types.Operator):
    bl_idname = "lumafold.move_to_satellite"
    bl_label = "Move LumaFold to Satellite"
    bl_description = "Move the single LumaFold Sculpt View from Blender to the independent Satellite Host"

    @classmethod
    def poll(cls, context):
        return context.area is not None and context.area.type == 'VIEW_3D'

    def execute(self, context):
        global _RETURN_EMBEDDED_TARGET, _EXTERNAL_SATELLITE_HANDOFF_RUNNING, _MIGRATION_IN_PROGRESS
        try:
            if _MIGRATION_IN_PROGRESS or HOST_CONTROL.migration_locked:
                self.report({'INFO'}, "LumaFold Host 正在迁移，请稍候")
                return {'CANCELLED'}
            if STATE.host_mode == "satellite" or _external_satellite_alive():
                self.report({'INFO'}, "LumaFold 已经在卫星 Host 中")
                return {'FINISHED'}
            if not STATE.running or STATE.host is None:
                self.report({'ERROR'}, "请先打开 LumaFold 浮台，再迁移到卫星窗口")
                return {'CANCELLED'}
            transfer = STATE.host.export_transfer_state()
            scale = float(transfer.get("ui_scale", transfer.get("style_scale", 1.25)) or 1.25)
            surface_w = int(round(float(transfer.get("compact_surface_w", 264.0) or 264.0) * scale))
            surface_h = int(round(float(transfer.get("compact_surface_h", 338.0) or 338.0) * scale))
            region = next((r for r in context.area.regions if r.type == 'WINDOW'), None)
            if region is None:
                raise RuntimeError("当前 3D View 没有 WINDOW region")
            local_pos = (
                float(transfer.get("embedded_window_pos_x", 0.0) or 0.0),
                float(transfer.get("embedded_window_pos_y", 0.0) or 0.0),
            )
            hwnd = int(getattr(getattr(STATE.host, "ime_bridge", None), "hwnd", 0) or 0)
            source_rect = view3d_region_screen_rect(region, hwnd)
            spawn = imgui_local_to_screen(region, local_pos, hwnd)
            if source_rect is None or spawn is None:
                raise RuntimeError("无法解析浮台的屏幕坐标")
            _RETURN_EMBEDDED_TARGET = {
                "window_pointer": context.window.as_pointer(),
                "area_pointer": context.area.as_pointer(),
                "source_view3d_screen_rect": dict(source_rect),
                "embedded_last_valid_pos": [
                    float(transfer.get("embedded_last_valid_pos_x", local_pos[0]) or local_pos[0]),
                    float(transfer.get("embedded_last_valid_pos_y", local_pos[1]) or local_pos[1]),
                ],
            }
            lease = HOST_CONTROL.begin_detach()
            _MIGRATION_IN_PROGRESS = True
            launch_satellite_host(surface_w, surface_h, screen_x=spawn[0], screen_y=spawn[1], generation=lease.generation)
            STATE.status = "Detaching · Embedded owns lease until Satellite ready"
            if not _EXTERNAL_SATELLITE_HANDOFF_RUNNING:
                _EXTERNAL_SATELLITE_HANDOFF_RUNNING = True
                bpy.app.timers.register(_external_satellite_handoff_tick, first_interval=0.0)
            return {'FINISHED'}
        except Exception as exc:
            _MIGRATION_IN_PROGRESS = False
            STATE.last_error = traceback.format_exc()
            STATE.status = "Satellite migration failed"
            try:
                BRIDGE.stop_satellite_process()
            except Exception:
                pass
            try:
                if HOST_CONTROL.lease.state == DETACHING:
                    HOST_CONTROL.cancel_detach()
                elif HOST_CONTROL.lease.state != EMBEDDED:
                    HOST_CONTROL.recover_embedded()
            except Exception:
                pass
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}


def _restore_embedded_after_satellite(target):
    """Re-open the same unified surface in the original Blender View3D."""
    if not target:
        return None
    try:
        wm = bpy.context.window_manager
        window = next((w for w in wm.windows if w.as_pointer() == int(target.get("window_pointer", 0))), None)
        if window is None or window.screen is None:
            return None
        area = next((a for a in window.screen.areas if a.as_pointer() == int(target.get("area_pointer", 0))), None)
        if area is None or area.type != 'VIEW_3D':
            area = next((a for a in window.screen.areas if a.type == 'VIEW_3D'), None)
        if area is None:
            return None
        region = next((r for r in area.regions if r.type == 'WINDOW'), None)
        if region is None:
            return None

        # Spatial attach: if Satellite's final center is inside the original
        # View3D, put 浮台 at the same client-space position. Otherwise use
        # the last valid Embedded position.
        restore_pos = list(target.get("embedded_last_valid_pos") or [0.0, 0.0])
        sat = getattr(BRIDGE, "satellite_rect", None)
        src = target.get("source_view3d_screen_rect")
        if isinstance(sat, dict) and isinstance(src, dict):
            cx = (float(sat.get("left", 0)) + float(sat.get("right", 0))) * 0.5
            cy = (float(sat.get("top", 0)) + float(sat.get("bottom", 0))) * 0.5
            inside = float(src.get("left", 0)) <= cx < float(src.get("right", 0)) and float(src.get("top", 0)) <= cy < float(src.get("bottom", 0))
            if inside:
                restore_pos = [float(sat.get("left", 0)) - float(src.get("left", 0)), float(sat.get("top", 0)) - float(src.get("top", 0))]
        ui_state = APP.store.namespace("__ui__")
        ui_state["embedded_restore_pos_x"] = max(0.0, float(restore_pos[0]))
        ui_state["embedded_restore_pos_y"] = max(0.0, float(restore_pos[1]))
        ui_state["embedded_restore_pending"] = True
        if HOST_CONTROL.lease.state != EMBEDDED:
            if HOST_CONTROL.lease.state not in {ATTACHING, "RECOVERING"}:
                try:
                    HOST_CONTROL.begin_attach()
                except Exception:
                    pass
            if HOST_CONTROL.lease.state == ATTACHING:
                HOST_CONTROL.grant_embedded()
            elif HOST_CONTROL.lease.state != EMBEDDED:
                HOST_CONTROL.recover_embedded()
        with bpy.context.temp_override(window=window, area=area, region=region):
            result = bpy.ops.lumafold.toggle_p0('INVOKE_DEFAULT')
        if 'RUNNING_MODAL' in result:
            STATE.status = "Returned to Embedded host"
    except Exception:
        STATE.last_error = traceback.format_exc()
        STATE.status = "Return to Embedded failed"
    return None


class LUMAFOLD_OT_import_alpha_images(bpy.types.Operator):
    bl_idname = "lumafold.import_alpha_images"
    bl_label = "导入 Alpha 图片"
    bl_description = "选择 PNG/TIF/EXR 等图片并加载到当前 Blender 文件，随后刷新 LumaFold Alpha 库"

    directory: bpy.props.StringProperty(subtype='DIR_PATH', options={'HIDDEN'})
    files: bpy.props.CollectionProperty(type=bpy.types.OperatorFileListElement, options={'HIDDEN', 'SKIP_SAVE'})
    filter_glob: bpy.props.StringProperty(
        default="*.png;*.jpg;*.jpeg;*.tif;*.tiff;*.bmp;*.tga;*.exr;*.hdr",
        options={'HIDDEN'},
    )

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        from pathlib import Path
        selected = [Path(self.directory) / item.name for item in self.files if str(item.name or '').strip()]
        if not selected:
            self.report({'INFO'}, "没有选择 Alpha 图片")
            return {'CANCELLED'}
        loaded = 0
        failed = []
        for path in selected:
            try:
                if not path.is_file():
                    raise FileNotFoundError(str(path))
                bpy.data.images.load(str(path), check_existing=True)
                loaded += 1
            except Exception as exc:
                failed.append(f"{path.name}: {type(exc).__name__}: {exc}")
        try:
            result = APP.execute("sculpt.alpha.library_refresh")
            if not result.ok:
                failed.append("刷新失败: " + str(result.message))
        except Exception as exc:
            failed.append("刷新失败: " + str(exc))
        if failed:
            STATE.last_error = "\n".join(failed[-8:])
        if loaded:
            self.report({'INFO'}, f"已导入 {loaded} 个 Alpha 图片")
            return {'FINISHED'}
        self.report({'ERROR'}, failed[-1] if failed else "Alpha 导入失败")
        return {'CANCELLED'}


class LUMAFOLD_OT_open_desktop_host(bpy.types.Operator):
    bl_idname = "lumafold.open_desktop_host"
    bl_label = "Open Desktop Host"
    bl_description = "Launch the independent LumaFold Desktop Host stability/DPI gate"

    def execute(self, context):
        try:
            proc = launch_desktop_host()
            self.report({'INFO'}, f"LumaFold Desktop Host started (PID {proc.pid})")
            return {'FINISHED'}
        except Exception as exc:
            STATE.last_error = traceback.format_exc()
            STATE.status = "Desktop Host launch failed"
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}


class LUMAFOLD_OT_close_desktop_host(bpy.types.Operator):
    bl_idname = "lumafold.close_desktop_host"
    bl_label = "Close Desktop Host"
    bl_description = "Close the external LumaFold Desktop Host process"

    def execute(self, context):
        BRIDGE.stop_process()
        self.report({'INFO'}, "LumaFold Desktop Host closed")
        return {'FINISHED'}


class LUMAFOLD_OT_open_extension_preferences(bpy.types.Operator):
    bl_idname = "lumafold.open_extension_preferences"
    bl_label = "Open Extension Update Settings"
    bl_description = "Open Blender Preferences; LumaFold online updates use a remote Blender Extensions repository hosted on GitHub"

    def execute(self, context):
        try:
            bpy.ops.screen.userpref_show('INVOKE_DEFAULT')
            self.report({'INFO'}, "Preferences opened. Go to Get Extensions / Repositories for the LumaFold remote repository.")
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}


class LUMAFOLD_OT_write_diagnostics(bpy.types.Operator):
    bl_idname = "lumafold.write_diagnostics"
    bl_label = "Write Diagnostics"
    bl_description = "Write the LumaFold diagnostic JSON to the extension user directory"

    def execute(self, context):
        try:
            path = write_report()
            self.report({'INFO'}, f"Diagnostic written: {path}")
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}


CLASSES = (
    LUMAFOLD_OT_install_runtime,
    LUMAFOLD_OT_toggle_p0,
    LUMAFOLD_OT_move_to_satellite,
    LUMAFOLD_OT_import_alpha_images,
    LUMAFOLD_OT_open_desktop_host,
    LUMAFOLD_OT_close_desktop_host,
    LUMAFOLD_OT_open_extension_preferences,
    LUMAFOLD_OT_write_diagnostics,
)


def register():
    try_import()
    for cls in CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
