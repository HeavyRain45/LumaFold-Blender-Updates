from __future__ import annotations

"""Version-aware Embedded redraw pulse policy.

Blender 5.2+ reliably redraws the owning View3D from real mouse/keyboard events,
so the persistent modal TIMER can idle at 10 Hz.

Blender 5.0/5.1 need a continuous redraw heartbeat for the external ImGui surface
to visually track pointer motion smoothly. Keep a 60 Hz TIMER there, while the
authoritative operators._context_pulse still limits the heavier APP context
refresh to 10 Hz internally.
"""

import time


_INSTALLED = False
_ORIGINAL = None
_ORIGINAL_INVOKE = None
_OPERATORS = None
_MODERN_IDLE_INTERVAL = 0.10
_LEGACY_REDRAW_INTERVAL = 1.0 / 60.0


def _effective_interval() -> float:
    try:
        import bpy
        version = tuple(int(v) for v in tuple(getattr(bpy.app, "version", (0, 0, 0)))[:3])
        if version < (5, 2, 0):
            return _LEGACY_REDRAW_INTERVAL
    except Exception:
        pass
    return _MODERN_IDLE_INTERVAL


def install(operators_module) -> None:
    global _INSTALLED, _ORIGINAL, _ORIGINAL_INVOKE, _OPERATORS
    if _INSTALLED:
        return
    original = getattr(operators_module, "_context_pulse", None)
    toggle_cls = getattr(operators_module, "LUMAFOLD_OT_toggle_p0", None)
    original_invoke = getattr(toggle_cls, "invoke", None) if toggle_cls is not None else None
    if not callable(original) or not callable(original_invoke):
        return
    _OPERATORS = operators_module
    _ORIGINAL = original
    _ORIGINAL_INVOKE = original_invoke

    def version_aware_context_pulse(operator, host, host_id):
        interval = _effective_interval()
        now = time.perf_counter()
        last = float(getattr(operator, "_lumafold_idle_pulse_at", 0.0) or 0.0)
        if now - last < interval:
            return None
        operator._lumafold_idle_pulse_at = now
        return original(operator, host, host_id)

    def invoke_with_version_aware_timer(self, context, event):
        result = original_invoke(self, context, event)
        if "RUNNING_MODAL" in set(result or ()):
            old_timer = getattr(self, "_timer", None)
            if old_timer is not None:
                try:
                    new_timer = context.window_manager.event_timer_add(
                        _effective_interval(),
                        window=context.window,
                    )
                except Exception:
                    new_timer = None
                if new_timer is not None:
                    try:
                        context.window_manager.event_timer_remove(old_timer)
                    except Exception:
                        pass
                    self._timer = new_timer
                    self._lumafold_idle_pulse_at = 0.0
        return result

    operators_module._context_pulse = version_aware_context_pulse
    toggle_cls.invoke = invoke_with_version_aware_timer
    _INSTALLED = True


def uninstall() -> None:
    global _INSTALLED, _ORIGINAL, _ORIGINAL_INVOKE, _OPERATORS
    if _INSTALLED and _OPERATORS is not None:
        if callable(_ORIGINAL):
            _OPERATORS._context_pulse = _ORIGINAL
        toggle_cls = getattr(_OPERATORS, "LUMAFOLD_OT_toggle_p0", None)
        if toggle_cls is not None and callable(_ORIGINAL_INVOKE):
            toggle_cls.invoke = _ORIGINAL_INVOKE
    _INSTALLED = False
    _ORIGINAL = None
    _ORIGINAL_INVOKE = None
    _OPERATORS = None


def snapshot():
    interval = float(_effective_interval())
    return {
        "installed": bool(_INSTALLED),
        "idle_interval": interval,
        "modal_timer_hz": round(1.0 / interval, 3) if interval > 0.0 else 0.0,
        "legacy_continuous_redraw": bool(interval < _MODERN_IDLE_INTERVAL),
    }
