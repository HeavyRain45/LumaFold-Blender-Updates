from __future__ import annotations

import argparse
import ctypes
from ctypes import wintypes
import json
import tempfile
import subprocess
import os
from pathlib import Path
import queue
import socket
import sys
import threading
import time


parser = argparse.ArgumentParser(add_help=False)
parser.add_argument("--port", type=int, required=True)
parser.add_argument("--token", required=True)
parser.add_argument("--parent-pid", type=int, required=True)
parser.add_argument("--owner-hwnd", type=int, default=0)
parser.add_argument("--width", type=int, default=410)
parser.add_argument("--height", type=int, default=468)
parser.add_argument("--x", type=int, default=120)
parser.add_argument("--y", type=int, default=120)
parser.add_argument("--generation", type=int, required=True)
parser.add_argument("--runtime-path", required=True)
ARGS = parser.parse_args()

EXT_ROOT = Path(__file__).resolve().parent.parent
if str(EXT_ROOT) not in sys.path:
    sys.path.insert(0, str(EXT_ROOT))
if ARGS.runtime_path and ARGS.runtime_path not in sys.path:
    sys.path.insert(0, ARGS.runtime_path)

from slimgui import imgui
from desktop.native_imgui_wgl import NativeWGLImguiRenderer
from ui.design import apply_style, px
from ui.fonts import configure_fonts, reset_font_state
from ui.sculpt_view import draw_sculpt_compact, secondary_surface_design_size
from ui.preview_textures import PreviewTextureCache
from ui.icons import ensure_icon_atlas, reset_icon_state
from ui.components import muted
from ui.primary_surface_geometry import (
    clamp_quick_rows,
    normalize_base_height_design,
    primary_surface_geometry,
)


def _validate_imgui_api():
    """Fail early if the slimgui package layout/API is not the pinned runtime we expect."""
    required = (
        "create_context", "set_current_context", "get_io", "new_frame",
        "render", "get_draw_data", "destroy_context",
    )
    missing = [name for name in required if not hasattr(imgui, name)]
    if missing:
        raise RuntimeError(
            "slimgui.imgui API mismatch; missing: " + ", ".join(missing)
        )


HOST = "127.0.0.1"
CLIENT = "LumaFold Satellite S0.7.3 Window Input Router"
lease_generation = int(ARGS.generation)


def _wt(name, fallback):
    return getattr(wintypes, name, fallback)


HANDLE = _wt("HANDLE", ctypes.c_void_p)
HWND = _wt("HWND", HANDLE)
HDC = _wt("HDC", HANDLE)
HINSTANCE = _wt("HINSTANCE", HANDLE)
HMENU = _wt("HMENU", HANDLE)
HICON = _wt("HICON", HANDLE)
HCURSOR = _wt("HCURSOR", HANDLE)
HBRUSH = _wt("HBRUSH", HANDLE)
ATOM = _wt("ATOM", ctypes.c_ushort)
LRESULT = ctypes.c_ssize_t
LPVOID = ctypes.c_void_p

WM_DESTROY = 0x0002
WM_PAINT = 0x000F
WM_CLOSE = 0x0010
WM_SIZE = 0x0005
WM_ERASEBKGND = 0x0014
WM_GETMINMAXINFO = 0x0024
WM_SETFOCUS = 0x0007
WM_KILLFOCUS = 0x0008
WM_MOUSEMOVE = 0x0200
WM_LBUTTONDOWN = 0x0201
WM_LBUTTONUP = 0x0202
WM_RBUTTONDOWN = 0x0204
WM_RBUTTONUP = 0x0205
WM_MBUTTONDOWN = 0x0207
WM_MBUTTONUP = 0x0208
WM_MOUSEWHEEL = 0x020A
WM_DPICHANGED = 0x02E0
WM_NCHITTEST = 0x0084
WM_NCLBUTTONDOWN = 0x00A1
WM_NCRBUTTONDOWN = 0x00A4
WM_NCMBUTTONDOWN = 0x00A7
WM_APP_SHOW = 0x8002
WM_APP_SECONDARY_KIND = 0x8051
WM_QUIT = 0x0012

CS_HREDRAW = 0x0002
CS_VREDRAW = 0x0001
CS_OWNDC = 0x0020
WS_OVERLAPPEDWINDOW = 0x00CF0000
WS_POPUP = 0x80000000
IDC_ARROW = 32512
SW_SHOW = 5
SW_SHOWNOACTIVATE = 4
SW_HIDE = 0
SWP_NOSIZE = 0x0001
SWP_NOZORDER = 0x0004
SWP_NOACTIVATE = 0x0010
SWP_ASYNCWINDOWPOS = 0x4000
PM_REMOVE = 0x0001
SECONDARY_KIND_IDS = {"brush_library": 1, "alpha_library": 2, "settings": 3, "more": 4}
DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2 = ctypes.c_void_p(-4)


class PAINTSTRUCT(ctypes.Structure):
    _fields_ = [
        ("hdc", HDC), ("fErase", wintypes.BOOL), ("rcPaint", wintypes.RECT),
        ("fRestore", wintypes.BOOL), ("fIncUpdate", wintypes.BOOL),
        ("rgbReserved", ctypes.c_byte * 32),
    ]


class POINT(ctypes.Structure):
    _fields_ = [("x", wintypes.LONG), ("y", wintypes.LONG)]


class MINMAXINFO(ctypes.Structure):
    _fields_ = [
        ("ptReserved", POINT), ("ptMaxSize", POINT), ("ptMaxPosition", POINT),
        ("ptMinTrackSize", POINT), ("ptMaxTrackSize", POINT),
    ]


WNDPROC = ctypes.WINFUNCTYPE(ctypes.c_ssize_t, HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM)
WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, HWND, wintypes.LPARAM)


class WNDCLASSEXW(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.UINT), ("style", wintypes.UINT), ("lpfnWndProc", WNDPROC),
        ("cbClsExtra", ctypes.c_int), ("cbWndExtra", ctypes.c_int), ("hInstance", HINSTANCE),
        ("hIcon", HICON), ("hCursor", HANDLE), ("hbrBackground", HBRUSH),
        ("lpszMenuName", wintypes.LPCWSTR), ("lpszClassName", wintypes.LPCWSTR), ("hIconSm", HICON),
    ]


user32 = ctypes.WinDLL("user32", use_last_error=True)
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
gdi32 = ctypes.WinDLL("gdi32", use_last_error=True)

user32.RegisterClassExW.argtypes = [ctypes.POINTER(WNDCLASSEXW)]
user32.RegisterClassExW.restype = ATOM
user32.CreateWindowExW.argtypes = [
    wintypes.DWORD, wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.DWORD,
    ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
    HWND, HMENU, HINSTANCE, LPVOID,
]
user32.CreateWindowExW.restype = HWND
user32.DefWindowProcW.argtypes = [HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
user32.DefWindowProcW.restype = LRESULT
user32.LoadCursorW.argtypes = [HINSTANCE, wintypes.LPCWSTR]
user32.LoadCursorW.restype = HCURSOR
user32.BeginPaint.argtypes = [HWND, ctypes.POINTER(PAINTSTRUCT)]
user32.BeginPaint.restype = HDC
user32.EndPaint.argtypes = [HWND, ctypes.POINTER(PAINTSTRUCT)]
user32.EndPaint.restype = wintypes.BOOL
user32.GetClientRect.argtypes = [HWND, ctypes.POINTER(wintypes.RECT)]
user32.GetClientRect.restype = wintypes.BOOL
user32.GetWindowRect.argtypes = [HWND, ctypes.POINTER(wintypes.RECT)]
user32.GetWindowRect.restype = wintypes.BOOL
user32.ClientToScreen.argtypes = [HWND, ctypes.POINTER(POINT)]
user32.ClientToScreen.restype = wintypes.BOOL
user32.ScreenToClient.argtypes = [HWND, ctypes.POINTER(POINT)]
user32.ScreenToClient.restype = wintypes.BOOL
user32.GetCursorPos.argtypes = [ctypes.POINTER(POINT)]
user32.GetCursorPos.restype = wintypes.BOOL
user32.DestroyWindow.argtypes = [HWND]
user32.DestroyWindow.restype = wintypes.BOOL
user32.PostQuitMessage.argtypes = [ctypes.c_int]
user32.ShowWindow.argtypes = [HWND, ctypes.c_int]
user32.ShowWindow.restype = wintypes.BOOL
user32.ShowWindowAsync.argtypes = [HWND, ctypes.c_int]
user32.ShowWindowAsync.restype = wintypes.BOOL
user32.IsWindowVisible.argtypes = [HWND]
user32.IsWindowVisible.restype = wintypes.BOOL
user32.IsWindow.argtypes = [HWND]
user32.IsWindow.restype = wintypes.BOOL
user32.SetForegroundWindow.argtypes = [HWND]
user32.SetForegroundWindow.restype = wintypes.BOOL
user32.EnumWindows.argtypes = [WNDENUMPROC, wintypes.LPARAM]
user32.EnumWindows.restype = wintypes.BOOL
user32.GetWindowThreadProcessId.argtypes = [HWND, ctypes.POINTER(wintypes.DWORD)]
user32.GetWindowThreadProcessId.restype = wintypes.DWORD
user32.UpdateWindow.argtypes = [HWND]
user32.UpdateWindow.restype = wintypes.BOOL
user32.PeekMessageW.argtypes = [ctypes.POINTER(wintypes.MSG), HWND, wintypes.UINT, wintypes.UINT, wintypes.UINT]
user32.PeekMessageW.restype = wintypes.BOOL
user32.TranslateMessage.argtypes = [ctypes.POINTER(wintypes.MSG)]
user32.DispatchMessageW.argtypes = [ctypes.POINTER(wintypes.MSG)]
user32.DispatchMessageW.restype = LRESULT
user32.PostMessageW.argtypes = [HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
user32.PostMessageW.restype = wintypes.BOOL
user32.SetWindowPos.argtypes = [HWND, HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.UINT]
user32.SetWindowPos.restype = wintypes.BOOL
user32.SetWindowRgn.argtypes = [HWND, HANDLE, wintypes.BOOL]
user32.SetWindowRgn.restype = ctypes.c_int
user32.SetCapture.argtypes = [HWND]
user32.SetCapture.restype = HWND
user32.ReleaseCapture.argtypes = []
user32.ReleaseCapture.restype = wintypes.BOOL
if hasattr(user32, "SetProcessDpiAwarenessContext"):
    user32.SetProcessDpiAwarenessContext.argtypes = [ctypes.c_void_p]
    user32.SetProcessDpiAwarenessContext.restype = wintypes.BOOL

kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
kernel32.GetModuleHandleW.restype = HINSTANCE
kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel32.OpenProcess.restype = HANDLE
kernel32.GetExitCodeProcess.argtypes = [HANDLE, ctypes.POINTER(wintypes.DWORD)]
kernel32.GetExitCodeProcess.restype = wintypes.BOOL
kernel32.CloseHandle.argtypes = [HANDLE]
kernel32.CloseHandle.restype = wintypes.BOOL
gdi32.CreateRoundRectRgn.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int]
gdi32.CreateRoundRectRgn.restype = HANDLE
gdi32.DeleteObject.argtypes = [HANDLE]
gdi32.DeleteObject.restype = wintypes.BOOL

try:
    user32.SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2)
except Exception:
    pass


state_lock = threading.Lock()
bridge_state = {}
actions: "queue.Queue[dict]" = queue.Queue()
_state_change_lock = threading.Lock()
_pending_state_fields = {}
_pending_state_enqueued = False
_COALESCED_STATE_SENTINEL = "__lumafold_coalesced_sculpt_state__"
closing_event = threading.Event()
connected = False
ready_sent = False
visible = False
hwnd_main = None
renderer = None
preview_textures = None
imgui_context = None
io = None
surface_state = {"sculpt_product_notice": ""}
local_sculpt = {
    "quick_slot": 0,
    "quick_rows": 2,
    "slot_count": 8,
    "quick_brush_slots": [],
    "active_quick_slot": -1,
    "current_brush_name": "",
    "current_brush_asset": {},
    "current_brush_type": "",
    "current_brush_preview": {},
    "brush_preview_cache": {},
    "brush_size": 72.0,
    "brush_strength": 0.50,
    "current_alpha_name": "默认",
    "current_alpha_identity": "none",
    "current_alpha_filepath": "",
    "current_alpha_map_mode": "",
    "current_alpha_preview": {},
    "alpha_sync_status": "PENDING",
}
local_override_until = {}
last_frame_time = time.perf_counter()
current_scale = 1.25
secondary_process = None
secondary_kind = None
secondary_hwnd = None
secondary_lock = threading.RLock()
secondary_starting = False
secondary_pending_request = None
secondary_opened_at = 0.0
secondary_pointer_entered = False
secondary_trigger_screen_rect = None

# Launch width/height are transport geometry only. The Primary base height is
# established from the shared View's explicit bottom-action anchor during the
# off-screen preflight frame. Once calibrated, every 2/3/4-row variant is
# deterministic and comes from the shared geometry contract.
_primary_geometry_ready = False
_primary_width_design = 0.0
_primary_base_height_design = 0.0
_pending_quick_rows = None
_primary_resize_pending = False

HTCLIENT = 1
HTCAPTION = 2


def _titlebar_height_px():
    return int(max(28, px(25.0, current_scale) + 10))


def _titlebar_close_zone_width_px():
    return int(max(42, px(34.0, current_scale) + 12))


def _apply_rounded_window_region(hwnd):
    """Clip the native popup itself to the same rounded silhouette as ImGui."""
    cr = wintypes.RECT()
    if not user32.GetClientRect(hwnd, ctypes.byref(cr)):
        return False
    width = max(1, int(cr.right - cr.left))
    height = max(1, int(cr.bottom - cr.top))
    radius = max(2, int(round(px(6.0, current_scale))))
    region = gdi32.CreateRoundRectRgn(0, 0, width + 1, height + 1, radius * 2, radius * 2)
    if not region:
        return False
    result = user32.SetWindowRgn(hwnd, region, True)
    if not result:
        try:
            gdi32.DeleteObject(region)
        except Exception:
            pass
        return False
    return True


def request(payload, timeout=1.5):
    global lease_generation
    payload = dict(payload)
    payload["token"] = ARGS.token
    payload["client"] = CLIENT
    payload["generation"] = int(lease_generation)
    with socket.create_connection((HOST, ARGS.port), timeout=timeout) as sock:
        sock.settimeout(timeout)
        sock.sendall((json.dumps(payload, ensure_ascii=False) + "\n").encode("utf-8"))
        data = b""
        while b"\n" not in data and len(data) < 512 * 1024:
            chunk = sock.recv(65536)
            if not chunk:
                break
            data += chunk
    if not data:
        raise RuntimeError("empty bridge response")
    return json.loads(data.split(b"\n", 1)[0].decode("utf-8"))


def parent_alive():
    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
    STILL_ACTIVE = 259
    handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, ARGS.parent_pid)
    if not handle:
        return False
    code = wintypes.DWORD()
    ok = kernel32.GetExitCodeProcess(handle, ctypes.byref(code))
    kernel32.CloseHandle(handle)
    return bool(ok and code.value == STILL_ACTIVE)


def client_rect_screen(hwnd):
    cr = wintypes.RECT()
    pt = POINT(0, 0)
    if not user32.GetClientRect(hwnd, ctypes.byref(cr)):
        return None
    if not user32.ClientToScreen(hwnd, ctypes.byref(pt)):
        return None
    return {
        "left": int(pt.x), "top": int(pt.y),
        "right": int(pt.x + cr.right - cr.left), "bottom": int(pt.y + cr.bottom - cr.top),
        "width": int(cr.right - cr.left), "height": int(cr.bottom - cr.top),
    }


def _snapshot_sculpt(snapshot):
    return dict(((snapshot.get("module_state") or {}).get("sculpt") or {}))


def _sync_local_from_snapshot(snapshot):
    global current_scale, _pending_quick_rows, _primary_resize_pending
    now = time.monotonic()
    remote = _snapshot_sculpt(snapshot)

    remote_rows = None
    if "quick_rows" in remote and now >= float(local_override_until.get("quick_rows", 0.0)):
        try:
            remote_rows = clamp_quick_rows(int(remote.get("quick_rows", 2) or 2))
        except Exception:
            remote_rows = 2

    for key in (
        "quick_slot", "quick_brush_slots", "active_quick_slot",
        "current_brush_name", "current_brush_asset", "current_brush_type",
        "current_brush_preview", "brush_preview_cache", "brush_sync_status", "brush_action_status",
        "brush_size", "brush_strength",
        "current_alpha_name", "current_alpha_identity", "current_alpha_filepath",
        "current_alpha_map_mode", "current_alpha_preview", "alpha_sync_status",
    ):
        if now >= float(local_override_until.get(key, 0.0)) and key in remote:
            local_sculpt[key] = remote[key]

    if remote_rows is not None:
        if not _primary_geometry_ready:
            local_sculpt["quick_rows"] = remote_rows
            local_sculpt["slot_count"] = remote_rows * 4
            _pending_quick_rows = remote_rows
            _primary_resize_pending = True
        elif remote_rows != clamp_quick_rows(local_sculpt.get("quick_rows", 2)):
            _pending_quick_rows = remote_rows

    ui_state = dict(((snapshot.get("module_state") or {}).get("__ui__") or {}))
    requested = float(ui_state.get("ui_scale", ui_state.get("requested_scale", current_scale)) or current_scale)
    requested = max(0.85, min(2.0, requested))
    if abs(requested - current_scale) > 1e-6:
        current_scale = requested
        _primary_resize_pending = True
        try:
            imgui.set_current_context(imgui_context)
            apply_style(imgui, current_scale)
        except Exception:
            pass


def network_worker():
    global connected, bridge_state, ready_sent, visible, lease_generation
    failures = 0
    while not closing_event.is_set():
        if not parent_alive():
            if hwnd_main:
                user32.PostMessageW(hwnd_main, WM_CLOSE, 0, 0)
            return
        try:
            if not ready_sent:
                response = request({"action": "satellite_ready"})
                ready_sent = bool(response.get("ok"))
            else:
                try:
                    action = actions.get(timeout=0.055)
                except queue.Empty:
                    action = {"action": "get_state"}
                response = request(action)
            if not response.get("ok"):
                raise RuntimeError(response.get("error") or "bridge request failed")
            snapshot = response.get("state") or {}
            with state_lock:
                bridge_state = snapshot
                hc = snapshot.get("host_control") or {}
                if hc.get("owner") == "satellite" and int(hc.get("generation", 0) or 0) > 0:
                    lease_generation = int(hc.get("generation"))
                _sync_local_from_snapshot(snapshot)
                if bool(hc.get("satellite_active")) and hc.get("owner") == "satellite" and not visible and hwnd_main:
                    user32.PostMessageW(hwnd_main, WM_APP_SHOW, 0, 0)
            connected = True
            failures = 0
        except Exception:
            connected = False
            failures += 1
            time.sleep(min(0.04 * failures, 0.4))


def _xy(lparam):
    return ctypes.c_short(lparam & 0xFFFF).value, ctypes.c_short((lparam >> 16) & 0xFFFF).value


def _wheel_delta(wparam):
    return ctypes.c_short((int(wparam) >> 16) & 0xFFFF).value


def _feed_mouse_button(button, pressed):
    if io is None:
        return
    try:
        io.add_mouse_button_event(button, bool(pressed))
    except Exception:
        pass


@WNDPROC
def wndproc(hwnd, msg, wparam, lparam):
    global visible
    if msg == WM_ERASEBKGND:
        return 1
    if msg == WM_APP_SHOW:
        if not visible:
            user32.ShowWindow(hwnd, SW_SHOW)
            user32.UpdateWindow(hwnd)
            visible = True
        return 0
    if msg == WM_PAINT:
        ps = PAINTSTRUCT()
        user32.BeginPaint(hwnd, ctypes.byref(ps))
        user32.EndPaint(hwnd, ctypes.byref(ps))
        return 0
    if msg == WM_NCHITTEST:
        pt = POINT(ctypes.c_short(lparam & 0xFFFF).value, ctypes.c_short((lparam >> 16) & 0xFFFF).value)
        if user32.ScreenToClient(hwnd, ctypes.byref(pt)):
            cr = wintypes.RECT()
            if user32.GetClientRect(hwnd, ctypes.byref(cr)):
                client_w = max(1, int(cr.right - cr.left))
                if 0 <= pt.y < _titlebar_height_px() and 0 <= pt.x < (client_w - _titlebar_close_zone_width_px()):
                    return HTCAPTION
                if 0 <= pt.x < client_w and 0 <= pt.y < max(1, int(cr.bottom - cr.top)):
                    return HTCLIENT
    if msg == WM_MOUSEMOVE:
        if io is not None:
            x, y = _xy(lparam)
            try:
                io.add_mouse_pos_event(float(x), float(y))
            except Exception:
                pass
        return 0
    if msg in (WM_LBUTTONDOWN, WM_RBUTTONDOWN, WM_MBUTTONDOWN):
        if secondary_kind and secondary_hwnd and user32.IsWindowVisible(secondary_hwnd):
            x, y = _xy(lparam)
            pt = POINT(int(x), int(y))
            if user32.ClientToScreen(hwnd, ctypes.byref(pt)):
                if not _point_in_rect(pt, secondary_trigger_screen_rect):
                    _hide_secondary_surface()
        button = {WM_LBUTTONDOWN: imgui.MouseButton.LEFT, WM_RBUTTONDOWN: imgui.MouseButton.RIGHT, WM_MBUTTONDOWN: imgui.MouseButton.MIDDLE}[msg]
        user32.SetCapture(hwnd)
        _feed_mouse_button(button, True)
        return 0
    if msg in (WM_NCLBUTTONDOWN, WM_NCRBUTTONDOWN, WM_NCMBUTTONDOWN):
        if secondary_kind and secondary_hwnd and user32.IsWindowVisible(secondary_hwnd):
            _hide_secondary_surface()
        return user32.DefWindowProcW(hwnd, msg, wparam, lparam)
    if msg in (WM_LBUTTONUP, WM_RBUTTONUP, WM_MBUTTONUP):
        button = {WM_LBUTTONUP: imgui.MouseButton.LEFT, WM_RBUTTONUP: imgui.MouseButton.RIGHT, WM_MBUTTONUP: imgui.MouseButton.MIDDLE}[msg]
        _feed_mouse_button(button, False)
        user32.ReleaseCapture()
        return 0
    if msg == WM_MOUSEWHEEL:
        if io is not None:
            try:
                io.add_mouse_wheel_event(0.0, float(_wheel_delta(wparam)) / 120.0)
            except Exception:
                pass
        return 0
    if msg == WM_SETFOCUS:
        if io is not None and hasattr(io, "add_focus_event"):
            try:
                io.add_focus_event(True)
            except Exception:
                pass
        return 0
    if msg == WM_KILLFOCUS:
        if io is not None and hasattr(io, "add_focus_event"):
            try:
                io.add_focus_event(False)
            except Exception:
                pass
        return 0
    if msg == WM_SIZE:
        _apply_rounded_window_region(hwnd)
        return 0
    if msg == WM_DPICHANGED:
        suggested = ctypes.cast(lparam, ctypes.POINTER(wintypes.RECT)).contents
        user32.SetWindowPos(
            hwnd, None, suggested.left, suggested.top,
            suggested.right - suggested.left, suggested.bottom - suggested.top,
            SWP_NOZORDER | SWP_NOACTIVATE,
        )
        _apply_rounded_window_region(hwnd)
        return 0
    if msg == WM_GETMINMAXINFO:
        mmi = ctypes.cast(lparam, ctypes.POINTER(MINMAXINFO)).contents
        mmi.ptMinTrackSize.x = 240
        mmi.ptMinTrackSize.y = 300
        return 0
    if msg == WM_CLOSE:
        _destroy_secondary_surface()
        try:
            request({"action": "satellite_closing", "rect": client_rect_screen(hwnd)}, timeout=0.35)
        except Exception:
            pass
        closing_event.set()
        user32.DestroyWindow(hwnd)
        return 0
    if msg == WM_DESTROY:
        closing_event.set()
        user32.PostQuitMessage(0)
        return 0
    return user32.DefWindowProcW(hwnd, msg, wparam, lparam)


def set_client_screen_position(hwnd, client_x, client_y):
    pt = POINT(0, 0)
    wr = wintypes.RECT()
    if not (user32.ClientToScreen(hwnd, ctypes.byref(pt)) and user32.GetWindowRect(hwnd, ctypes.byref(wr))):
        return
    frame_x = int(pt.x - wr.left)
    frame_y = int(pt.y - wr.top)
    user32.SetWindowPos(
        hwnd, None, int(client_x) - frame_x, int(client_y) - frame_y,
        0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE,
    )


def set_exact_client_size(hwnd, width, height):
    cr = wintypes.RECT()
    wr = wintypes.RECT()
    if not (user32.GetClientRect(hwnd, ctypes.byref(cr)) and user32.GetWindowRect(hwnd, ctypes.byref(wr))):
        return
    cw = max(1, cr.right - cr.left)
    ch = max(1, cr.bottom - cr.top)
    ow = max(1, wr.right - wr.left)
    oh = max(1, wr.bottom - wr.top)
    frame_w = max(0, ow - cw)
    frame_h = max(0, oh - ch)
    user32.SetWindowPos(
        hwnd, None, wr.left, wr.top,
        int(width) + frame_w, int(height) + frame_h,
        SWP_NOZORDER | SWP_NOACTIVATE,
    )


def _calibrate_primary_surface_from_view(rows):
    """Establish the Primary base from the shared View's explicit bottom anchor.

    `draw_sculpt_compact` already publishes the real Brush Library button rect in
    `surface_state`. That bottom action row is the final Primary control. Using
    its real item rect keeps geometry owned by the shared View and avoids cursor
    heuristics, stale launch heights, and Host-local content measurement.
    """
    global _primary_geometry_ready, _primary_width_design, _primary_base_height_design
    global _primary_resize_pending
    if _primary_geometry_ready or not hwnd_main:
        return _primary_geometry_ready
    if visible:
        return False
    try:
        anchor = dict(surface_state.get("sculpt_brush_library_anchor") or {})
        bottom = float(anchor.get("button_bottom", 0.0) or 0.0)
        if bottom <= 0.0:
            return False
        window_pos = imgui.get_window_pos()
        style = imgui.get_style()
        bottom_padding = float(style.window_padding[1])
        desired_height_px = max(
            1.0,
            bottom - float(window_pos[1]) + bottom_padding,
        )
    except Exception:
        return False

    cr = wintypes.RECT()
    if not user32.GetClientRect(hwnd_main, ctypes.byref(cr)):
        return False
    cw = max(1, int(cr.right - cr.left))
    scale = max(0.01, float(current_scale))
    width_design = float(cw) / scale
    measured_height_design = float(desired_height_px) / scale
    _primary_width_design = width_design
    _primary_base_height_design = normalize_base_height_design(
        measured_height_design,
        rows=clamp_quick_rows(rows),
        width_design=width_design,
    )
    _primary_geometry_ready = True
    _primary_resize_pending = True
    return True


def _apply_primary_surface_contract(rows, *, force=False):
    """Apply deterministic Primary geometry from the shared contract.

    Initial calibration is owned by the hidden shared View pass. Visible row
    changes never measure ImGui or use the previous native window size as truth.
    """
    global _primary_resize_pending
    rows = clamp_quick_rows(rows)
    if not _primary_geometry_ready:
        return False
    geometry = primary_surface_geometry(
        width_design=_primary_width_design,
        base_height_design=_primary_base_height_design,
        rows=rows,
    )
    target_w = max(1, int(round(float(geometry.width_design) * float(current_scale))))
    target_h = max(1, int(round(float(geometry.height_design) * float(current_scale))))
    cr = wintypes.RECT()
    if not user32.GetClientRect(hwnd_main, ctypes.byref(cr)):
        return False
    current_w = max(1, int(cr.right - cr.left))
    current_h = max(1, int(cr.bottom - cr.top))
    if force or abs(target_w - current_w) > 1 or abs(target_h - current_h) > 1:
        set_exact_client_size(hwnd_main, target_w, target_h)
        _apply_rounded_window_region(hwnd_main)
    _primary_resize_pending = False
    return True


def _commit_pending_primary_surface():
    global _pending_quick_rows, _primary_resize_pending
    rows = _pending_quick_rows
    if rows is None:
        rows = clamp_quick_rows(local_sculpt.get("quick_rows", 2))
    else:
        rows = clamp_quick_rows(rows)
        local_sculpt["quick_rows"] = rows
        local_sculpt["slot_count"] = rows * 4
        local_override_until["quick_rows"] = time.monotonic() + 0.30
        _pending_quick_rows = None

    if _primary_geometry_ready and _primary_resize_pending:
        _apply_primary_surface_contract(rows)


def _queue_coalesced_sculpt_state(fields):
    global _pending_state_enqueued
    fields = dict(fields or {})
    if not fields:
        return
    with _state_change_lock:
        _pending_state_fields.update(fields)
        if not _pending_state_enqueued:
            _pending_state_enqueued = True
            actions.put({"action": _COALESCED_STATE_SENTINEL})


def _take_bridge_action(timeout=0.10):
    """Return one bridge action, collapsing rapid Satellite state churn.

    While one request is in flight, slider/continuous UI updates accumulate in
    one latest-value dictionary instead of creating a long FIFO that Blender
    must drain when focus returns.
    """
    global _pending_state_enqueued
    action = actions.get(timeout=timeout)
    if str(action.get("action", "")) != _COALESCED_STATE_SENTINEL:
        return action
    with _state_change_lock:
        fields = dict(_pending_state_fields)
        _pending_state_fields.clear()
        _pending_state_enqueued = False
    if not fields:
        return {"action": "get_state"}
    return {"action": "set_module_state", "namespace": "sculpt", "fields": fields}


def _queue_state_change(fields):
    if not fields:
        return
    fields = dict(fields)
    now = time.monotonic()
    for key, value in fields.items():
        local_sculpt[key] = value
        local_override_until[key] = now + 0.30

    if "quick_slot" in fields:
        slot = int(fields.pop("quick_slot"))
        local_sculpt["active_quick_slot"] = slot
        local_override_until["active_quick_slot"] = now + 0.30
        actions.put({
            "action": "command",
            "command_id": "sculpt.brush.activate_slot",
            "kwargs": {"slot": slot},
        })
    if fields:
        _queue_coalesced_sculpt_state(fields)


def _queue_command(command_id, **kwargs):
    actions.put({"action": "command", "command_id": str(command_id), "kwargs": dict(kwargs)})


def _queue_quick_rows(rows):
    global _pending_quick_rows, _primary_resize_pending
    rows = clamp_quick_rows(rows)
    _pending_quick_rows = rows
    _primary_resize_pending = True
    actions.put({"action": "command", "command_id": "sculpt.brush.set_quick_rows", "kwargs": {"rows": rows}})


def _secondary_log_path():
    root = Path(tempfile.gettempdir()) / "LumaFold"
    root.mkdir(parents=True, exist_ok=True)
    return root / "secondary_surface_s07_2.log"


def _find_secondary_hwnd(pid: int, timeout=0.0):
    """Resolve the top-level Secondary Surface HWND owned by a child PID."""
    deadline = time.monotonic() + max(0.0, float(timeout))
    while True:
        found = []

        @WNDENUMPROC
        def _enum(hwnd, _lparam):
            process_id = wintypes.DWORD(0)
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(process_id))
            if int(process_id.value) == int(pid):
                found.append(hwnd)
                return False
            return True

        try:
            user32.EnumWindows(_enum, 0)
        except Exception:
            found = []
        if found:
            return found[0]
        if time.monotonic() >= deadline:
            return None
        time.sleep(0.015)


def _destroy_secondary_surface():
    """Destroy the prewarmed child only when the Satellite itself is exiting."""
    global secondary_process, secondary_kind, secondary_hwnd
    with secondary_lock:
        proc = secondary_process
        secondary_process = None
        secondary_kind = None
        secondary_hwnd = None
    if proc is not None and proc.poll() is None:
        try:
            proc.terminate()
            proc.wait(timeout=0.6)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass


def _ensure_secondary_surface(*, wait=False):
    """Ensure the warm child exists without ever blocking the Satellite UI."""
    global secondary_process, secondary_kind, secondary_hwnd, secondary_starting

    with secondary_lock:
        proc = secondary_process
        hwnd = secondary_hwnd
        if proc is not None and proc.poll() is None:
            if hwnd and user32.IsWindow(hwnd):
                return proc, hwnd
        elif secondary_starting:
            proc = secondary_process
        else:
            if not hwnd_main:
                return None, None
            secondary_starting = True
            script = Path(__file__).resolve().parent / "secondary_surface_host.py"
            log_path = _secondary_log_path()
            try:
                log_path.unlink(missing_ok=True)
            except Exception:
                pass
            args = [
                sys.executable, "-u", str(script),
                "--port", str(ARGS.port), "--token", ARGS.token,
                "--parent-pid", str(os.getpid()),
                "--owner-hwnd", str(int(hwnd_main)),
                "--x", "-32000", "--y", "-32000",
                "--width", "490", "--height", "335",
                "--generation", str(int(lease_generation)),
                "--runtime-path", str(ARGS.runtime_path),
                "--kind", "brush_library",
                "--start-hidden",
            ]
            creationflags = 0
            if os.name == "nt":
                creationflags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0) | getattr(subprocess, "CREATE_NO_WINDOW", 0)
            log_handle = open(log_path, "ab", buffering=0)
            try:
                proc = subprocess.Popen(
                    args, cwd=str(script.parent), stdin=subprocess.DEVNULL,
                    stdout=log_handle, stderr=subprocess.STDOUT, close_fds=True,
                    creationflags=creationflags,
                )
            finally:
                log_handle.close()
            secondary_process = proc
            secondary_kind = None

    if proc is None or proc.poll() is not None:
        with secondary_lock:
            secondary_starting = False
        return proc, None
    hwnd = _find_secondary_hwnd(proc.pid, timeout=(0.75 if wait else 0.0))
    if hwnd:
        with secondary_lock:
            secondary_hwnd = hwnd
            secondary_starting = False
        return proc, hwnd
    if wait:
        with secondary_lock:
            secondary_starting = False
    return proc, None


def _hide_secondary_surface():
    global secondary_kind, secondary_hwnd, secondary_pointer_entered, secondary_trigger_screen_rect
    proc = secondary_process
    hwnd = secondary_hwnd
    if proc is None or proc.poll() is not None or hwnd is None or not user32.IsWindow(hwnd):
        secondary_kind = None
        secondary_pointer_entered = False
        secondary_trigger_screen_rect = None
        return False
    user32.ShowWindowAsync(hwnd, SW_HIDE)
    secondary_kind = None
    secondary_pointer_entered = False
    secondary_trigger_screen_rect = None
    return True


def _toggle_secondary_surface(kind="brush_library", anchor=None):
    """Toggle one warm Secondary Surface without blocking the Satellite UI thread."""
    global secondary_kind, secondary_hwnd, secondary_opened_at, secondary_pending_request
    global secondary_pointer_entered, secondary_trigger_screen_rect
    kind = str(kind or "brush_library")
    proc, hwnd = _ensure_secondary_surface(wait=False)
    if proc is None:
        return None
    if hwnd is None:
        secondary_pending_request = (kind, dict(anchor or {}))
        return proc
    secondary_pending_request = None
    secondary_hwnd = hwnd

    is_visible = bool(user32.IsWindowVisible(hwnd))
    if is_visible and secondary_kind == kind:
        _hide_secondary_surface()
        return proc

    if not hwnd_main:
        return proc
    rect = client_rect_screen(hwnd_main) or {
        "left": int(ARGS.x), "top": int(ARGS.y),
        "right": int(ARGS.x + ARGS.width), "bottom": int(ARGS.y + ARGS.height),
        "width": int(ARGS.width), "height": int(ARGS.height),
    }
    anchor = dict(anchor or {})
    local_x = float(anchor.get("x", px(12.0, current_scale)))
    local_y = float(anchor.get("y", rect["height"] - px(18.0, current_scale)))
    x = int(round(float(rect["left"]) + local_x))
    y = int(round(float(rect["top"]) + local_y))

    design_w, design_h = secondary_surface_design_size(kind)
    width = max(1, int(round(px(design_w, current_scale))))
    height = max(1, int(round(px(design_h, current_scale))))

    try:
        secondary_trigger_screen_rect = {
            "left": int(round(rect["left"] + float(anchor.get("button_left", local_x)))),
            "top": int(round(rect["top"] + float(anchor.get("button_top", local_y)))),
            "right": int(round(rect["left"] + float(anchor.get("button_right", local_x)))),
            "bottom": int(round(rect["top"] + float(anchor.get("button_bottom", local_y)))),
        }
    except Exception:
        secondary_trigger_screen_rect = None

    kind_id = int(SECONDARY_KIND_IDS.get(kind, 1))
    user32.PostMessageW(hwnd, WM_APP_SECONDARY_KIND, kind_id, 0)
    user32.SetWindowPos(
        hwnd, None, x, y, width, height,
        SWP_NOZORDER | SWP_NOACTIVATE | SWP_ASYNCWINDOWPOS,
    )
    user32.ShowWindowAsync(hwnd, SW_SHOWNOACTIVATE)
    secondary_kind = kind
    secondary_opened_at = time.monotonic()
    secondary_pointer_entered = False
    return proc


def _point_in_rect(pt, rect):
    return bool(rect and rect["left"] <= pt.x < rect["right"] and rect["top"] <= pt.y < rect["bottom"])


def _secondary_auto_dismiss_tick():
    global secondary_kind
    _flush_secondary_pending_request()
    hwnd = secondary_hwnd
    if not hwnd or not secondary_kind or not user32.IsWindow(hwnd):
        return
    if not user32.IsWindowVisible(hwnd):
        secondary_kind = None


def _prewarm_secondary_surface():
    try:
        _ensure_secondary_surface(wait=True)
    except Exception:
        pass


def _flush_secondary_pending_request():
    global secondary_pending_request
    pending = secondary_pending_request
    if not pending:
        return
    proc, hwnd = _ensure_secondary_surface(wait=False)
    if proc is None or hwnd is None:
        return
    secondary_pending_request = None
    kind, anchor = pending
    _toggle_secondary_surface(kind, anchor)


def _draw_frame():
    global last_frame_time
    if renderer is None or io is None:
        return

    _commit_pending_primary_surface()

    cr = wintypes.RECT()
    if not user32.GetClientRect(hwnd_main, ctypes.byref(cr)):
        return
    width = max(1, int(cr.right - cr.left))
    height = max(1, int(cr.bottom - cr.top))
    now = time.perf_counter()
    dt = max(1.0 / 1000.0, min(0.1, now - last_frame_time))
    last_frame_time = now
    io.delta_time = dt
    io.display_size = (float(width), float(height))
    io.display_framebuffer_scale = (1.0, 1.0)

    with state_lock:
        snapshot = dict(bridge_state)
        sculpt = dict(local_sculpt)
    status = dict(snapshot.get("sculpt_status") or {})
    available = bool(status.get("active", True))
    reason = str(status.get("reason", ""))
    can_enter = bool(status.get("enabled", True) and status.get("mode", "SCULPT") != "SCULPT")

    renderer.make_current()
    imgui.set_current_context(imgui_context)
    imgui.new_frame()
    imgui.set_next_window_pos((0.0, 0.0), imgui.Cond.ALWAYS)
    imgui.set_next_window_size((float(width), float(height)), imgui.Cond.ALWAYS)
    no_scroll = getattr(imgui.WindowFlags, "NO_SCROLLBAR", 0) | getattr(imgui.WindowFlags, "NO_SCROLL_WITH_MOUSE", 0)
    flags = (
        imgui.WindowFlags.NO_RESIZE
        | imgui.WindowFlags.NO_MOVE
        | imgui.WindowFlags.NO_COLLAPSE
        | imgui.WindowFlags.NO_SAVED_SETTINGS
        | no_scroll
    )
    workspace_name = str(status.get("workspace", "") or "")
    key = workspace_name.casefold().replace(" ", "")
    if key in {"modeling", "建模"} or "model" in key or "建模" in workspace_name:
        product_title = "LumaFold Model"
    elif key in {"rendering", "render", "渲染"} or "render" in key or "渲染" in workspace_name:
        product_title = "LumaFold Render"
    else:
        product_title = "LumaFold Sculpt"
    visible_content, opened = imgui.begin(f"{product_title} · 卫星###lumafold_primary_satellite", closable=True, flags=flags)
    if not opened:
        imgui.end()
        imgui.render()
        renderer.render(imgui.get_draw_data(), width, height)
        user32.PostMessageW(hwnd_main, WM_CLOSE, 0, 0)
        return
    if visible_content:
        draw_sculpt_compact(
            imgui, surface_state, sculpt, current_scale,
            available=available,
            unavailable_reason=reason,
            blender_mode=str(status.get("mode", "") or ""),
            blender_workspace=str(status.get("workspace", "") or ""),
            host_label="卫星",
            can_enter_sculpt=can_enter,
            on_enter_sculpt=lambda: actions.put({"action": "command", "command_id": "sculpt.enter", "kwargs": {}}),
            on_state_changed=_queue_state_change,
            on_more=lambda: surface_state.__setitem__("sculpt_product_notice", "更多：后续进入统一 Secondary Surface，不占用主卫星。"),
            on_assign_current_to_slot=lambda slot: _queue_command("sculpt.brush.assign_current_to_slot", slot=int(slot)),
            on_clear_slot=lambda slot: _queue_command("sculpt.brush.clear_slot", slot=int(slot)),
            on_reset_slots=lambda: _queue_command("sculpt.brush.reset_quick_slots"),
            on_set_quick_rows=_queue_quick_rows,
            on_open_brush_library=lambda anchor: _toggle_secondary_surface("brush_library", anchor),
            on_open_alpha_library=lambda anchor: _toggle_secondary_surface("alpha_library", anchor),
            on_toggle_host=lambda: user32.PostMessageW(hwnd_main, WM_CLOSE, 0, 0),
            resolve_preview_texture=(preview_textures.resolve if preview_textures is not None else None),
        )
        if not _primary_geometry_ready:
            rows = clamp_quick_rows(sculpt.get("quick_rows", local_sculpt.get("quick_rows", 2)))
            if _calibrate_primary_surface_from_view(rows):
                _apply_primary_surface_contract(rows, force=True)
    imgui.end()
    imgui.render()
    renderer.render(imgui.get_draw_data(), width, height)


def main():
    global hwnd_main, renderer, preview_textures, imgui_context, io, last_frame_time
    hinst = kernel32.GetModuleHandleW(None)
    class_name = "LumaFoldSatelliteNativeImguiS0630"
    wc = WNDCLASSEXW()
    wc.cbSize = ctypes.sizeof(WNDCLASSEXW)
    wc.style = CS_HREDRAW | CS_VREDRAW | CS_OWNDC
    wc.lpfnWndProc = wndproc
    wc.hInstance = hinst
    cursor_resource = ctypes.cast(ctypes.c_void_p(IDC_ARROW), wintypes.LPCWSTR)
    wc.hCursor = user32.LoadCursorW(None, cursor_resource)
    wc.hbrBackground = None
    wc.lpszClassName = class_name
    if not user32.RegisterClassExW(ctypes.byref(wc)):
        err = ctypes.get_last_error()
        if err != 1410:
            raise ctypes.WinError(err)

    hwnd_main = user32.CreateWindowExW(
        0, class_name, "LumaFold Sculpt · 卫星",
        WS_POPUP,
        int(ARGS.x), int(ARGS.y), max(240, int(ARGS.width)), max(340, int(ARGS.height)),
        (HWND(int(ARGS.owner_hwnd)) if int(ARGS.owner_hwnd or 0) else None), None, hinst, None,
    )
    if not hwnd_main:
        raise ctypes.WinError(ctypes.get_last_error())
    set_exact_client_size(hwnd_main, int(ARGS.width), int(ARGS.height))
    set_client_screen_position(hwnd_main, int(ARGS.x), int(ARGS.y))
    _apply_rounded_window_region(hwnd_main)
    user32.ShowWindow(hwnd_main, SW_HIDE)

    _validate_imgui_api()
    imgui_context = imgui.create_context()
    imgui.set_current_context(imgui_context)
    io = imgui.get_io()
    io.delta_time = 1.0 / 60.0
    io.display_framebuffer_scale = (1.0, 1.0)
    try:
        io.backend_flags |= imgui.BackendFlags.RENDERER_HAS_VTX_OFFSET
        io.backend_flags |= imgui.BackendFlags.RENDERER_HAS_TEXTURES
    except Exception:
        pass
    configure_fonts(imgui, io)
    apply_style(imgui, current_scale)
    renderer = NativeWGLImguiRenderer(hwnd_main, imgui)
    preview_textures = PreviewTextureCache(renderer)
    try:
        ensure_icon_atlas(renderer)
    except Exception:
        pass
    last_frame_time = time.perf_counter()

    threading.Thread(target=network_worker, name="LumaFoldSatelliteNetwork", daemon=True).start()
    threading.Thread(target=_prewarm_secondary_surface, name="LumaFoldSecondaryPrewarm", daemon=True).start()

    msg = wintypes.MSG()
    quit_requested = False
    try:
        while not closing_event.is_set() and not quit_requested:
            while user32.PeekMessageW(ctypes.byref(msg), None, 0, 0, PM_REMOVE):
                if msg.message == WM_QUIT:
                    quit_requested = True
                    break
                user32.TranslateMessage(ctypes.byref(msg))
                user32.DispatchMessageW(ctypes.byref(msg))
            if quit_requested or closing_event.is_set():
                break
            _secondary_auto_dismiss_tick()
            _draw_frame()
            time.sleep(1.0 / 120.0)
    finally:
        closing_event.set()
        _destroy_secondary_surface()
        if preview_textures is not None:
            try:
                preview_textures.shutdown()
            except Exception:
                pass
            preview_textures = None
        try:
            reset_icon_state(renderer)
        except Exception:
            pass
        if renderer is not None:
            try:
                renderer.shutdown()
            except Exception:
                pass
        try:
            imgui.set_current_context(imgui_context)
            imgui.destroy_context(imgui_context)
        except Exception:
            pass
        reset_font_state()


if __name__ == "__main__":
    main()
