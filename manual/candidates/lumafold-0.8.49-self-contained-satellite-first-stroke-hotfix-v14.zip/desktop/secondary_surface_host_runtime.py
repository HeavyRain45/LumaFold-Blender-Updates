from __future__ import annotations

import argparse
import ctypes
from ctypes import wintypes
import json
import queue
import socket
import sys
import threading
import time
from pathlib import Path


parser = argparse.ArgumentParser(add_help=False)
parser.add_argument("--port", type=int, required=True)
parser.add_argument("--token", required=True)
parser.add_argument("--parent-pid", type=int, required=True)
parser.add_argument("--owner-hwnd", type=int, default=0)
parser.add_argument("--x", type=int, default=200)
parser.add_argument("--y", type=int, default=160)
parser.add_argument("--width", type=int, default=560)
parser.add_argument("--height", type=int, default=360)
parser.add_argument("--generation", type=int, default=0)
parser.add_argument("--runtime-path", required=True)
parser.add_argument("--kind", default="brush_library")
parser.add_argument("--start-hidden", action="store_true")
ARGS = parser.parse_args()

EXT_ROOT = Path(__file__).resolve().parent.parent
if str(EXT_ROOT) not in sys.path:
    sys.path.insert(0, str(EXT_ROOT))
if ARGS.runtime_path and ARGS.runtime_path not in sys.path:
    sys.path.insert(0, ARGS.runtime_path)

from slimgui import imgui
from desktop.native_imgui_wgl import NativeWGLImguiRenderer
from ui.design import apply_style, px
from ui import theme as T
from ui.fonts import configure_fonts, reset_font_state
from ui.preview_textures import PreviewTextureCache
from ui.icons import ensure_icon_atlas, reset_icon_state
from ui.sculpt_view import draw_brush_library_foundation, draw_alpha_library_foundation

HOST = "127.0.0.1"
CLIENT = "LumaFold Secondary Surface S0.7.3 Window Input Router"


def _wt(name, fallback):
    return getattr(wintypes, name, fallback)


HANDLE = _wt("HANDLE", ctypes.c_void_p)
HWND = _wt("HWND", HANDLE)
HDC = _wt("HDC", HANDLE)
HINSTANCE = _wt("HINSTANCE", HANDLE)
HMENU = _wt("HMENU", HANDLE)
HICON = _wt("HICON", HANDLE)
HCURSOR = _wt("HCURSOR", HANDLE)
HBRUSH = _wt("HBRUSH", HANDLE)
ATOM = _wt("ATOM", ctypes.c_ushort)
LPVOID = ctypes.c_void_p
LRESULT = ctypes.c_ssize_t

WM_DESTROY = 0x0002
WM_PAINT = 0x000F
WM_CLOSE = 0x0010
WM_SIZE = 0x0005
WM_ERASEBKGND = 0x0014
WM_SETFOCUS = 0x0007
WM_KILLFOCUS = 0x0008
WM_KEYDOWN = 0x0100
WM_SYSKEYDOWN = 0x0104
WM_MOUSEMOVE = 0x0200
WM_LBUTTONDOWN = 0x0201
WM_LBUTTONUP = 0x0202
WM_RBUTTONDOWN = 0x0204
WM_RBUTTONUP = 0x0205
WM_MBUTTONDOWN = 0x0207
WM_MBUTTONUP = 0x0208
WM_MOUSEWHEEL = 0x020A
WM_DPICHANGED = 0x02E0
WM_NCHITTEST = 0x0084
WM_APP_SECONDARY_KIND = 0x8051
WM_APP_QUICK_REPLACE_SLOT = 0x8052
WM_APP_PRIMARY_BRUSH_VISUAL_SYNC = 0x8053
WM_QUIT = 0x0012

CS_HREDRAW = 0x0002
CS_VREDRAW = 0x0001
CS_OWNDC = 0x0020
WS_POPUP = 0x80000000
WS_EX_NOACTIVATE = 0x08000000
IDC_ARROW = 32512
SW_SHOW = 5
SW_HIDE = 0
SWP_NOZORDER = 0x0004
SWP_NOACTIVATE = 0x0010
PM_REMOVE = 0x0001
HTCLIENT = 1
HTCAPTION = 2
VK_ESCAPE = 0x1B
SECONDARY_KIND_NAMES = {1: "brush_library", 2: "alpha_library", 3: "settings", 4: "more"}
MONITOR_DEFAULTTONEAREST = 2
DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2 = ctypes.c_void_p(-4)


class PAINTSTRUCT(ctypes.Structure):
    _fields_ = [
        ("hdc", HDC), ("fErase", wintypes.BOOL), ("rcPaint", wintypes.RECT),
        ("fRestore", wintypes.BOOL), ("fIncUpdate", wintypes.BOOL),
        ("rgbReserved", ctypes.c_byte * 32),
    ]


class POINT(ctypes.Structure):
    _fields_ = [("x", wintypes.LONG), ("y", wintypes.LONG)]


class MONITORINFO(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.DWORD),
        ("rcMonitor", wintypes.RECT),
        ("rcWork", wintypes.RECT),
        ("dwFlags", wintypes.DWORD),
    ]


WNDPROC = ctypes.WINFUNCTYPE(LRESULT, HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM)


class WNDCLASSEXW(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.UINT), ("style", wintypes.UINT), ("lpfnWndProc", WNDPROC),
        ("cbClsExtra", ctypes.c_int), ("cbWndExtra", ctypes.c_int), ("hInstance", HINSTANCE),
        ("hIcon", HICON), ("hCursor", HANDLE), ("hbrBackground", HBRUSH),
        ("lpszMenuName", wintypes.LPCWSTR), ("lpszClassName", wintypes.LPCWSTR), ("hIconSm", HICON),
    ]


user32 = ctypes.WinDLL("user32", use_last_error=True)
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
gdi32 = ctypes.WinDLL("gdi32", use_last_error=True)

user32.RegisterClassExW.argtypes = [ctypes.POINTER(WNDCLASSEXW)]
user32.RegisterClassExW.restype = ATOM
user32.CreateWindowExW.argtypes = [
    wintypes.DWORD, wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.DWORD,
    ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
    HWND, HMENU, HINSTANCE, LPVOID,
]
user32.CreateWindowExW.restype = HWND
user32.DefWindowProcW.argtypes = [HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
user32.DefWindowProcW.restype = LRESULT
user32.LoadCursorW.argtypes = [HINSTANCE, wintypes.LPCWSTR]
user32.LoadCursorW.restype = HCURSOR
user32.BeginPaint.argtypes = [HWND, ctypes.POINTER(PAINTSTRUCT)]
user32.BeginPaint.restype = HDC
user32.EndPaint.argtypes = [HWND, ctypes.POINTER(PAINTSTRUCT)]
user32.EndPaint.restype = wintypes.BOOL
user32.GetClientRect.argtypes = [HWND, ctypes.POINTER(wintypes.RECT)]
user32.GetClientRect.restype = wintypes.BOOL
user32.GetWindowRect.argtypes = [HWND, ctypes.POINTER(wintypes.RECT)]
user32.GetWindowRect.restype = wintypes.BOOL
user32.ShowWindow.argtypes = [HWND, ctypes.c_int]
user32.ShowWindow.restype = wintypes.BOOL
user32.IsWindowVisible.argtypes = [HWND]
user32.IsWindowVisible.restype = wintypes.BOOL
user32.DestroyWindow.argtypes = [HWND]
user32.DestroyWindow.restype = wintypes.BOOL
user32.PostQuitMessage.argtypes = [ctypes.c_int]
user32.PeekMessageW.argtypes = [ctypes.POINTER(wintypes.MSG), HWND, wintypes.UINT, wintypes.UINT, wintypes.UINT]
user32.PeekMessageW.restype = wintypes.BOOL
user32.TranslateMessage.argtypes = [ctypes.POINTER(wintypes.MSG)]
user32.DispatchMessageW.argtypes = [ctypes.POINTER(wintypes.MSG)]
user32.DispatchMessageW.restype = LRESULT
user32.SetCapture.argtypes = [HWND]
user32.SetCapture.restype = HWND
user32.ReleaseCapture.argtypes = []
user32.ReleaseCapture.restype = wintypes.BOOL
user32.SetWindowPos.argtypes = [HWND, HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.UINT]
user32.SetWindowPos.restype = wintypes.BOOL
user32.SetWindowRgn.argtypes = [HWND, HANDLE, wintypes.BOOL]
user32.SetWindowRgn.restype = ctypes.c_int
user32.MonitorFromPoint.argtypes = [POINT, wintypes.DWORD]
user32.MonitorFromPoint.restype = HANDLE
user32.GetMonitorInfoW.argtypes = [HANDLE, ctypes.POINTER(MONITORINFO)]
user32.GetMonitorInfoW.restype = wintypes.BOOL
if hasattr(user32, "SetProcessDpiAwarenessContext"):
    user32.SetProcessDpiAwarenessContext.argtypes = [ctypes.c_void_p]
    user32.SetProcessDpiAwarenessContext.restype = wintypes.BOOL

kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
kernel32.GetModuleHandleW.restype = HINSTANCE
kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel32.OpenProcess.restype = HANDLE
kernel32.GetExitCodeProcess.argtypes = [HANDLE, ctypes.POINTER(wintypes.DWORD)]
kernel32.GetExitCodeProcess.restype = wintypes.BOOL
kernel32.CloseHandle.argtypes = [HANDLE]
kernel32.CloseHandle.restype = wintypes.BOOL

gdi32.CreateRoundRectRgn.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int]
gdi32.CreateRoundRectRgn.restype = HANDLE
gdi32.DeleteObject.argtypes = [HANDLE]
gdi32.DeleteObject.restype = wintypes.BOOL

try:
    user32.SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2)
except Exception:
    pass

hwnd_main = None
renderer = None
preview_textures = None
imgui_context = None
io = None
closing_event = threading.Event()
state_lock = threading.Lock()
bridge_state = {}
actions: "queue.Queue[dict]" = queue.Queue()
current_scale = 1.25
_applied_scale = None
last_frame_time = time.perf_counter()
current_kind = str(ARGS.kind or "brush_library")
library_ui_state = {}
quick_replace_slot = -1


def request(payload, timeout=1.5):
    payload = dict(payload)
    payload["token"] = ARGS.token
    payload["client"] = CLIENT
    payload["generation"] = int(ARGS.generation)
    with socket.create_connection((HOST, ARGS.port), timeout=timeout) as sock:
        sock.settimeout(timeout)
        sock.sendall((json.dumps(payload, ensure_ascii=False) + "\n").encode("utf-8"))
        data = b""
        while b"\n" not in data and len(data) < 2 * 1024 * 1024:
            chunk = sock.recv(65536)
            if not chunk:
                break
            data += chunk
    if not data:
        raise RuntimeError("empty bridge response")
    return json.loads(data.split(b"\n", 1)[0].decode("utf-8"))


def parent_alive():
    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
    STILL_ACTIVE = 259
    handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, ARGS.parent_pid)
    if not handle:
        return False
    code = wintypes.DWORD()
    ok = kernel32.GetExitCodeProcess(handle, ctypes.byref(code))
    kernel32.CloseHandle(handle)
    return bool(ok and code.value == STILL_ACTIVE)


def _network_worker():
    global bridge_state, current_scale
    while not closing_event.is_set():
        if not parent_alive():
            closing_event.set()
            return
        try:
            try:
                payload = actions.get(timeout=0.035)
            except queue.Empty:
                payload = {"action": "get_state"}
            response = request(payload)
            if response.get("ok"):
                snapshot = response.get("state") or {}
                with state_lock:
                    bridge_state = snapshot
                    ui_state = dict(((snapshot.get("module_state") or {}).get("__ui__") or {}))
                    requested = float(ui_state.get("ui_scale", ui_state.get("requested_scale", current_scale)) or current_scale)
                    current_scale = max(0.85, min(2.0, requested))
                if (
                    str(payload.get("action") or "") == "command"
                    and str(payload.get("command_id") or "") == "sculpt.brush.library_activate"
                    and int(ARGS.owner_hwnd or 0)
                ):
                    user32.PostMessageW(
                        HWND(int(ARGS.owner_hwnd)),
                        WM_APP_PRIMARY_BRUSH_VISUAL_SYNC,
                        0, 0,
                    )
        except Exception:
            time.sleep(0.025)


def _queue_command(command_id, **kwargs):
    # Never block the Secondary ImGui frame on a socket round-trip.
    actions.put({"action": "command", "command_id": str(command_id), "kwargs": dict(kwargs)})

def _queue_state(fields):
    actions.put({"action": "set_module_state", "namespace": "sculpt", "fields": dict(fields)})


def _activate_brush_library_product(identity):
    global quick_replace_slot
    identity = str(identity or "")
    slot = int(quick_replace_slot)
    if slot >= 0:
        # Match Embedded targeted replacement semantics.
        _queue_command("sculpt.brush.library_assign_slot", identity=identity, slot=slot)
        quick_replace_slot = -1
    _queue_command("sculpt.brush.library_activate", identity=identity)


def _xy(lparam):
    return ctypes.c_short(lparam & 0xFFFF).value, ctypes.c_short((lparam >> 16) & 0xFFFF).value


def _wheel_delta(wparam):
    return ctypes.c_short((int(wparam) >> 16) & 0xFFFF).value


def _apply_rounded_window_region(hwnd):
    cr = wintypes.RECT()
    if not user32.GetClientRect(hwnd, ctypes.byref(cr)):
        return
    width = max(1, int(cr.right - cr.left))
    height = max(1, int(cr.bottom - cr.top))
    radius = max(2, int(round(px(6.0, current_scale))))
    region = gdi32.CreateRoundRectRgn(0, 0, width + 1, height + 1, radius * 2, radius * 2)
    if region:
        if not user32.SetWindowRgn(hwnd, region, True):
            gdi32.DeleteObject(region)


def _clamp_to_monitor(x, y, width, height):
    pt = POINT(int(x), int(y))
    monitor = user32.MonitorFromPoint(pt, MONITOR_DEFAULTTONEAREST)
    info = MONITORINFO()
    info.cbSize = ctypes.sizeof(MONITORINFO)
    if monitor and user32.GetMonitorInfoW(monitor, ctypes.byref(info)):
        work = info.rcWork
        width = min(int(width), max(240, int(work.right - work.left)))
        height = min(int(height), max(180, int(work.bottom - work.top)))
        x = min(max(int(x), int(work.left)), int(work.right) - width)
        y = min(max(int(y), int(work.top)), int(work.bottom) - height)
    return int(x), int(y), int(width), int(height)


def _titlebar_height_px():
    return int(max(28, px(25.0, current_scale) + 10))


def _titlebar_close_zone_width_px():
    return int(max(42, px(34.0, current_scale) + 12))


@WNDPROC
def wndproc(hwnd, msg, wparam, lparam):
    if msg == WM_ERASEBKGND:
        return 1
    if msg == WM_PAINT:
        ps = PAINTSTRUCT()
        user32.BeginPaint(hwnd, ctypes.byref(ps))
        user32.EndPaint(hwnd, ctypes.byref(ps))
        return 0
    if msg == WM_NCHITTEST:
        # Screen coords in lParam, then convert manually from our known window position
        # through GetCursorPos to avoid adding another conversion dependency here.
        x = ctypes.c_short(lparam & 0xFFFF).value
        y = ctypes.c_short((lparam >> 16) & 0xFFFF).value
        wr = wintypes.RECT()
        if user32.GetWindowRect(hwnd, ctypes.byref(wr)):
            lx, ly = x - wr.left, y - wr.top
            client_w = max(1, int(wr.right - wr.left))
            if 0 <= ly < _titlebar_height_px() and 0 <= lx < client_w - _titlebar_close_zone_width_px():
                return HTCAPTION
            return HTCLIENT
    if msg == WM_MOUSEMOVE:
        if io is not None:
            x, y = _xy(lparam)
            try:
                io.add_mouse_pos_event(float(x), float(y))
            except Exception:
                pass
        return 0
    if msg in (WM_LBUTTONDOWN, WM_RBUTTONDOWN, WM_MBUTTONDOWN):
        button = {WM_LBUTTONDOWN: imgui.MouseButton.LEFT, WM_RBUTTONDOWN: imgui.MouseButton.RIGHT, WM_MBUTTONDOWN: imgui.MouseButton.MIDDLE}[msg]
        user32.SetCapture(hwnd)
        try:
            io.add_mouse_button_event(button, True)
        except Exception:
            pass
        return 0
    if msg in (WM_LBUTTONUP, WM_RBUTTONUP, WM_MBUTTONUP):
        button = {WM_LBUTTONUP: imgui.MouseButton.LEFT, WM_RBUTTONUP: imgui.MouseButton.RIGHT, WM_MBUTTONUP: imgui.MouseButton.MIDDLE}[msg]
        try:
            io.add_mouse_button_event(button, False)
        except Exception:
            pass
        user32.ReleaseCapture()
        return 0
    if msg == WM_MOUSEWHEEL:
        try:
            io.add_mouse_wheel_event(0.0, float(_wheel_delta(wparam)) / 120.0)
        except Exception:
            pass
        return 0
    if msg == WM_SETFOCUS:
        try:
            io.add_focus_event(True)
        except Exception:
            pass
        return 0
    if msg == WM_KILLFOCUS:
        try:
            io.add_focus_event(False)
        except Exception:
            pass
        return 0
    if msg in (WM_KEYDOWN, WM_SYSKEYDOWN):
        if int(wparam) == VK_ESCAPE:
            # Secondary surfaces close like a menu: keep the WGL/ImGui host
            # alive and hide it instantly so the next open is warm.
            user32.ShowWindow(hwnd, SW_HIDE)
            return 0
    if msg == WM_APP_QUICK_REPLACE_SLOT:
        global quick_replace_slot
        quick_replace_slot = int(wparam) - 1
        return 0
    if msg == WM_APP_SECONDARY_KIND:
        global current_kind
        current_kind = SECONDARY_KIND_NAMES.get(int(wparam), "brush_library")
        return 0
    if msg == WM_SIZE:
        _apply_rounded_window_region(hwnd)
        return 0
    if msg == WM_DPICHANGED:
        suggested = ctypes.cast(lparam, ctypes.POINTER(wintypes.RECT)).contents
        user32.SetWindowPos(
            hwnd, None, suggested.left, suggested.top,
            suggested.right - suggested.left, suggested.bottom - suggested.top,
            SWP_NOZORDER | SWP_NOACTIVATE,
        )
        _apply_rounded_window_region(hwnd)
        return 0
    if msg == WM_CLOSE:
        closing_event.set()
        user32.DestroyWindow(hwnd)
        return 0
    if msg == WM_DESTROY:
        closing_event.set()
        user32.PostQuitMessage(0)
        return 0
    return user32.DefWindowProcW(hwnd, msg, wparam, lparam)


def _draw_frame():
    global last_frame_time, _applied_scale
    if renderer is None or io is None:
        return
    cr = wintypes.RECT()
    if not user32.GetClientRect(hwnd_main, ctypes.byref(cr)):
        return
    width = max(1, int(cr.right - cr.left))
    height = max(1, int(cr.bottom - cr.top))
    now = time.perf_counter()
    io.delta_time = max(1.0 / 1000.0, min(0.1, now - last_frame_time))
    last_frame_time = now
    io.display_size = (float(width), float(height))
    io.display_framebuffer_scale = (1.0, 1.0)

    with state_lock:
        snapshot = dict(bridge_state)
    sculpt = dict(((snapshot.get("module_state") or {}).get("sculpt") or {}))

    renderer.make_current()
    imgui.set_current_context(imgui_context)
    if _applied_scale is None or abs(float(_applied_scale) - float(current_scale)) > 1e-6:
        apply_style(imgui, current_scale)
        _applied_scale = float(current_scale)
    imgui.new_frame()
    imgui.set_next_window_pos((0.0, 0.0), imgui.Cond.ALWAYS)
    imgui.set_next_window_size((float(width), float(height)), imgui.Cond.ALWAYS)
    flags = (
        imgui.WindowFlags.NO_TITLE_BAR
        | imgui.WindowFlags.NO_RESIZE
        | imgui.WindowFlags.NO_MOVE
        | imgui.WindowFlags.NO_COLLAPSE
        | imgui.WindowFlags.NO_SAVED_SETTINGS
    )
    # Secondary Surface Background Contract: Native Secondary Host must render
    # the same root background token as the Embedded ImGui Popup. Without this,
    # WINDOW_BG(SURFACE_0) creates an extra grey layer around CHILD_BG(SURFACE_1).
    imgui.push_style_color(imgui.Col.WINDOW_BG, T.SECONDARY_SURFACE_BG)
    try:
        visible, _opened = imgui.begin("LumaFold Secondary Surface##secondary", flags=flags)
    finally:
        imgui.pop_style_color()
    if visible:
        if current_kind == "brush_library":
            draw_brush_library_foundation(
                imgui, sculpt, current_scale, library_ui_state=library_ui_state,
                on_refresh_library=lambda: _queue_command("sculpt.brush.library_refresh"),
                on_activate_asset=lambda identity: _activate_brush_library_product(identity),
                on_toggle_favorite=lambda identity: _queue_command("sculpt.brush.library_toggle_favorite", identity=str(identity)),
                on_assign_asset_to_slot=lambda identity, slot: _queue_command("sculpt.brush.library_assign_slot", identity=str(identity), slot=int(slot)),
                on_request_preview=lambda identities: _queue_command("sculpt.brush.library_preview", identities=list(identities or ())),
                resolve_preview_texture=(preview_textures.resolve if preview_textures is not None else None),
            )
        elif current_kind == "alpha_library":
            draw_alpha_library_foundation(
                imgui, sculpt, current_scale, library_ui_state=library_ui_state,
                on_refresh_library=lambda: _queue_command("sculpt.alpha.library_refresh"),
                on_activate_asset=lambda identity: _queue_command("sculpt.alpha.library_activate", identity=str(identity)),
                on_toggle_favorite=lambda identity: _queue_command("sculpt.alpha.library_toggle_favorite", identity=str(identity)),
                on_request_preview=lambda identities: _queue_command("sculpt.alpha.library_preview", identities=list(identities or ())),
                on_import_files=lambda: _queue_command("sculpt.alpha.library_import_dialog"),
                resolve_preview_texture=(preview_textures.resolve if preview_textures is not None else None),
            )
    imgui.end()
    imgui.render()
    renderer.render(imgui.get_draw_data(), width, height)


def main():
    global hwnd_main, renderer, preview_textures, imgui_context, io, last_frame_time
    hinst = kernel32.GetModuleHandleW(None)
    class_name = "LumaFoldSecondarySurfaceS072"
    wc = WNDCLASSEXW()
    wc.cbSize = ctypes.sizeof(WNDCLASSEXW)
    wc.style = CS_HREDRAW | CS_VREDRAW | CS_OWNDC
    wc.lpfnWndProc = wndproc
    wc.hInstance = hinst
    cursor_resource = ctypes.cast(ctypes.c_void_p(IDC_ARROW), wintypes.LPCWSTR)
    wc.hCursor = user32.LoadCursorW(None, cursor_resource)
    wc.hbrBackground = None
    wc.lpszClassName = class_name
    if not user32.RegisterClassExW(ctypes.byref(wc)):
        err = ctypes.get_last_error()
        if err != 1410:
            raise ctypes.WinError(err)

    x, y, width, height = _clamp_to_monitor(ARGS.x, ARGS.y, ARGS.width, ARGS.height)
    owner = HWND(int(ARGS.owner_hwnd)) if int(ARGS.owner_hwnd or 0) else None
    hwnd_main = user32.CreateWindowExW(
        WS_EX_NOACTIVATE, class_name, "LumaFold Secondary Surface", WS_POPUP,
        x, y, width, height,
        owner, None, hinst, None,
    )
    if not hwnd_main:
        raise ctypes.WinError(ctypes.get_last_error())
    _apply_rounded_window_region(hwnd_main)

    imgui_context = imgui.create_context()
    imgui.set_current_context(imgui_context)
    io = imgui.get_io()
    io.delta_time = 1.0 / 60.0
    io.display_framebuffer_scale = (1.0, 1.0)
    try:
        io.backend_flags |= imgui.BackendFlags.RENDERER_HAS_VTX_OFFSET
        io.backend_flags |= imgui.BackendFlags.RENDERER_HAS_TEXTURES
    except Exception:
        pass
    configure_fonts(imgui, io)
    apply_style(imgui, current_scale)
    renderer = NativeWGLImguiRenderer(hwnd_main, imgui, clear_linear_rgb=T.SECONDARY_SURFACE_BG[:3])
    preview_textures = PreviewTextureCache(renderer, max_items=24)
    try:
        ensure_icon_atlas(renderer)
    except Exception:
        pass
    last_frame_time = time.perf_counter()

    threading.Thread(target=_network_worker, name="LumaFoldSecondaryBridge", daemon=True).start()
    # Render one frame while still invisible. This uploads the font atlas and
    # primes WGL so the first visible Show is not also the first GPU frame.
    try:
        _draw_frame()
    except Exception:
        pass
    user32.ShowWindow(hwnd_main, SW_HIDE if ARGS.start_hidden else SW_SHOW)

    msg = wintypes.MSG()
    quit_requested = False
    try:
        while not closing_event.is_set() and not quit_requested:
            while user32.PeekMessageW(ctypes.byref(msg), None, 0, 0, PM_REMOVE):
                if msg.message == WM_QUIT:
                    quit_requested = True
                    break
                user32.TranslateMessage(ctypes.byref(msg))
                user32.DispatchMessageW(ctypes.byref(msg))
            if quit_requested or closing_event.is_set():
                break
            if user32.IsWindowVisible(hwnd_main):
                _draw_frame()
                time.sleep(1.0 / 120.0)
            else:
                # Keep the native/WGL/ImGui resources warm without burning a
                # full render loop while the menu is closed.
                time.sleep(0.010)
    finally:
        closing_event.set()
        if preview_textures is not None:
            try:
                preview_textures.shutdown()
            except Exception:
                pass
            preview_textures = None
        try:
            reset_icon_state(renderer)
        except Exception:
            pass
        if renderer is not None:
            try:
                renderer.shutdown()
            except Exception:
                pass
        try:
            imgui.set_current_context(imgui_context)
            imgui.destroy_context(imgui_context)
        except Exception:
            pass
        reset_font_state()


if __name__ == "__main__":
    main()
