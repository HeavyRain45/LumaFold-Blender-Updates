from __future__ import annotations

"""Stable Sculpt interaction composition.

This layer owns product-specific visual/input affordances, but never owns Blender
Modal routing. Shortcut capture is sampled only from the real ImGui popup during
the draw frame, preventing stale global capture state after a menu closes.
"""

from . import sculpt_control_icons as control_icons
from . import sculpt_view as sculpt_view
from . import sculpt_view_foundation as foundation
from .design import px
from .layout_system import SculptPrimaryMetrics

_INSTALLED = False
_ORIGINALS = {}
_NEXT_QUICK_ANCHOR = None
_LOCKED_QUICK_ANCHOR = None
_SHORTCUT_CAPTURE_ACTIVE = False
_HOST_SWITCH_RECT = None


def shortcut_capture_active() -> bool:
    return bool(_SHORTCUT_CAPTURE_ACTIVE)


def host_switch_hit_test(x: float, y: float) -> bool:
    rect = _HOST_SWITCH_RECT
    if not rect:
        return False
    try:
        x0, y0, x1, y1 = rect
        return float(x0) <= float(x) <= float(x1) and float(y0) <= float(y) <= float(y1)
    except Exception:
        return False


def ensure_controls(renderer):
    try:
        return control_icons.ensure(renderer)
    except Exception:
        return 0


def _host_switch_button(imgui, scale: float, host_label: str, on_toggle_host):
    global _HOST_SWITCH_RECT
    satellite = str(host_label or "").strip() == "卫星"
    name = "embedded" if satellite else "satellite"
    tooltip = "返回 Blender 浮台" if satellite else "切换到卫星窗口"
    clicked = control_icons.icon_button(
        imgui, name, "host_switch_b4", scale,
        box=24.0, glyph=15.0, selected=False, tooltip=tooltip,
    )

    # Publish the exact client-local hit rectangle to the native Win32
    # wrapper. Satellite -> Embedded can then commit on WM_LBUTTONDOWN
    # without depending on ImGui focus/release state.
    try:
        rmin = imgui.get_item_rect_min()
        rmax = imgui.get_item_rect_max()
        _HOST_SWITCH_RECT = (
            float(rmin[0]), float(rmin[1]),
            float(rmax[0]), float(rmax[1]),
        )
    except Exception:
        _HOST_SWITCH_RECT = None

    pressed = False
    if satellite:
        try:
            pressed = bool(imgui.is_item_hovered()) and bool(imgui.is_mouse_clicked(0))
        except Exception:
            pressed = False

    activate = bool(pressed or clicked)
    if activate and on_toggle_host is not None:
        on_toggle_host()
    return activate


def _draw_input_profile_switch(imgui, sculpt, scale, blender_mode, *, host_x: float, on_state_changed=None):
    in_sculpt = str(blender_mode or "").upper() == "SCULPT"
    preferred = sculpt_view._normalize_input_profile(sculpt.get("input_profile", "blender"))
    effective = preferred if in_sculpt else "blender"

    side = 24.0
    inner_gap = 4.0
    host_group_gap = 12.0
    group_w = px(side * 2.0 + inner_gap, scale)
    start_x = max(0.0, float(host_x) - group_w - px(host_group_gap, scale))
    try:
        imgui.set_cursor_pos_x(start_x)
    except Exception:
        return

    z_clicked = control_icons.icon_button(
        imgui, "zbrush", "profile_zbrush_b4", scale,
        box=side, glyph=16.0,
        selected=(effective == "zbrush"), disabled=not in_sculpt,
        tooltip=sculpt_view._profile_tooltip("zbrush", in_sculpt),
    )
    imgui.same_line(spacing=px(inner_gap, scale))
    b_clicked = control_icons.icon_button(
        imgui, "blender", "profile_blender_b4", scale,
        box=side, glyph=16.0,
        selected=(effective == "blender"), disabled=not in_sculpt,
        tooltip=sculpt_view._profile_tooltip("blender", in_sculpt),
    )

    requested = None
    if in_sculpt:
        if z_clicked:
            requested = "zbrush"
        elif b_clicked:
            requested = "blender"
    if requested is not None and requested != preferred:
        sculpt["input_profile"] = requested
        if on_state_changed is not None:
            on_state_changed({"input_profile": requested})


def _visual_quick_slot_widget(*args, **kwargs):
    global _NEXT_QUICK_ANCHOR
    clicked = bool(_ORIGINALS["visual_quick"](*args, **kwargs))
    if not clicked:
        return False
    try:
        imgui = args[0]
        scale = float(args[4])
        empty = bool(args[7])
    except Exception:
        return clicked
    if empty:
        return clicked
    try:
        rmin = imgui.get_item_rect_min()
        rmax = imgui.get_item_rect_max()
        mouse = imgui.get_mouse_pos()
        if float(mouse[1]) >= float(rmax[1]) - px(15.0, scale):
            return clicked
        _NEXT_QUICK_ANCHOR = {
            "x": float(rmax[0]) + px(8.0, scale),
            "y": float(rmin[1]),
            "button_left": float(rmin[0]),
            "button_top": float(rmin[1]),
            "button_right": float(rmax[0]),
            "button_bottom": float(rmax[1]),
        }
    except Exception:
        _NEXT_QUICK_ANCHOR = None
    return clicked


def _item_anchor(imgui, scale):
    global _NEXT_QUICK_ANCHOR, _LOCKED_QUICK_ANCHOR
    if _NEXT_QUICK_ANCHOR is not None:
        anchor = dict(_NEXT_QUICK_ANCHOR)
        _NEXT_QUICK_ANCHOR = None
        _LOCKED_QUICK_ANCHOR = dict(anchor)
        return anchor
    if _LOCKED_QUICK_ANCHOR is not None:
        anchor = dict(_LOCKED_QUICK_ANCHOR)
        _LOCKED_QUICK_ANCHOR = None
        return anchor
    return _ORIGINALS["item_anchor"](imgui, scale)


def _prepare_shortcut_editor(surface_state, sculpt, slot: int):
    global _SHORTCUT_CAPTURE_ACTIVE
    surface_state["_quick_shortcut_editor_slot"] = int(slot)
    surface_state["_quick_shortcut_editor_open_requested"] = True
    surface_state["_quick_shortcut_capture_armed"] = True
    # Optimistically capture the opening key frame. The draw wrapper below
    # replaces this with the real popup lifetime immediately afterwards.
    _SHORTCUT_CAPTURE_ACTIVE = True


def _draw_shortcut_editor(imgui, surface_state, sculpt, scale, on_state_changed):
    global _SHORTCUT_CAPTURE_ACTIVE
    result = _ORIGINALS["shortcut_editor"](
        imgui, surface_state, sculpt, scale, on_state_changed
    )
    try:
        _SHORTCUT_CAPTURE_ACTIVE = bool(
            imgui.is_popup_open("编辑快捷键##quick_shortcut_product")
        )
    except Exception:
        # Never leave a speculative capture alive after a draw API mismatch.
        _SHORTCUT_CAPTURE_ACTIVE = False
    return result


def _modifier_now(imgui):
    def down(key_name, io_name):
        try:
            return bool(imgui.is_key_down(getattr(imgui.Key, key_name)))
        except Exception:
            try:
                return bool(getattr(imgui.get_io(), io_name))
            except Exception:
                return False
    if down("MOD_CTRL", "key_ctrl"):
        return "CTRL"
    if down("MOD_ALT", "key_alt"):
        return "ALT"
    if down("MOD_SHIFT", "key_shift"):
        return "SHIFT"
    return "NONE"


def _pressed_main_key(imgui):
    digit_events = {
        "0": "ZERO", "1": "ONE", "2": "TWO", "3": "THREE", "4": "FOUR",
        "5": "FIVE", "6": "SIX", "7": "SEVEN", "8": "EIGHT", "9": "NINE",
    }
    for ch in "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ":
        try:
            key = getattr(imgui.Key, f"KEY_{ch}")
            if imgui.is_key_pressed(key):
                return digit_events.get(ch, ch)
        except Exception:
            continue
    return ""


def install_shared():
    global _INSTALLED
    if _INSTALLED:
        return
    _INSTALLED = True

    _ORIGINALS["host_switch"] = foundation._host_switch_button
    _ORIGINALS["profile_switch"] = sculpt_view._draw_input_profile_switch
    _ORIGINALS["visual_quick"] = sculpt_view._visual_quick_slot_widget
    _ORIGINALS["item_anchor"] = foundation._item_anchor
    _ORIGINALS["prepare_shortcut"] = sculpt_view._prepare_shortcut_editor
    _ORIGINALS["shortcut_editor"] = sculpt_view._draw_shortcut_editor
    _ORIGINALS["metrics"] = foundation.SCULPT_PRIMARY

    old = foundation.SCULPT_PRIMARY
    foundation.SCULPT_PRIMARY = SculptPrimaryMetrics(
        min_content_w=old.min_content_w,
        alpha_card_w=72.0,
        current_card_h=72.0,
        current_preview=56.0,
        quick_combo_w=old.quick_combo_w,
        quick_tile_min=old.quick_tile_min,
        bottom_button_min=old.bottom_button_min,
        slider_label_w=old.slider_label_w,
        grid_gap=old.grid_gap,
    )

    foundation._host_switch_button = _host_switch_button
    sculpt_view._draw_input_profile_switch = _draw_input_profile_switch
    sculpt_view._visual_quick_slot_widget = _visual_quick_slot_widget
    foundation._item_anchor = _item_anchor
    sculpt_view._prepare_shortcut_editor = _prepare_shortcut_editor
    sculpt_view._draw_shortcut_editor = _draw_shortcut_editor


def install_embedded(host_module):
    """Install shared control artwork only; Runtime Core owns input routing."""
    install_shared()
    if bool(getattr(host_module, "_lumafold_b4_controls_installed", False)):
        return
    host_module._lumafold_b4_controls_installed = True
    original_ensure = host_module.ensure_icon_atlas
    original_reset = host_module.reset_icon_state

    def ensure_both(renderer):
        result = original_ensure(renderer)
        ensure_controls(renderer)
        return result

    def reset_both(renderer=None):
        try:
            control_icons.reset(renderer)
        finally:
            return original_reset(renderer)

    host_module.ensure_icon_atlas = ensure_both
    host_module.reset_icon_state = reset_both
