from __future__ import annotations

"""Stateless Blender-native View3D navigation handoff.

LumaFold may decide *when* a ZBrush-style pointer press should become viewport
navigation, but it never owns navigation state itself.

Hard isolation contract:
- never write RegionView3D.view_rotation;
- never mutate Blender's View3D Rotate Modal keymap;
- never keep rotate/session/timer state;
- never synthesize orbit increments;
- once VIEW3D_OT_rotate is invoked, Blender owns the complete drag lifecycle.

Plain-LMB Sculpt-vs-background ownership is decided by Blender itself through
``sculpt_native_pointer``. This module is retained only for already-authorized
native navigation paths such as plain RMB; it never raycasts or decides whether
a brush stroke exists.
"""

import importlib
import time

import bpy


_base = importlib.import_module(__package__ + ".sculpt_input_core")

_CONFIGURED = False
_REGISTERED = False

_NATIVE_SESSIONS = {}
_NATIVE_TIMER_RUNNING = False
_SHIFT_MODAL_KM = None
_SHIFT_MODAL_ITEMS = []
_SHIFT_BRIDGE_ERROR = ""
_SHIFT_KEYS = ("LEFT_SHIFT", "RIGHT_SHIFT")


def _ptr(value) -> int:
    try:
        return int(value.as_pointer())
    except Exception:
        return 0


def _live_rotate_modal_keymap():
    """Resolve Blender's existing Rotate modal map; never create/replace it."""
    global _SHIFT_MODAL_KM
    if _SHIFT_MODAL_KM is not None:
        try:
            if bool(_SHIFT_MODAL_KM.is_modal):
                return _SHIFT_MODAL_KM
        except Exception:
            pass
        _SHIFT_MODAL_KM = None

    try:
        wm = bpy.context.window_manager
        kc = wm.keyconfigs.user
    except Exception:
        kc = None
    if kc is None:
        return None

    try:
        km = kc.keymaps.find(
            "View3D Rotate Modal", space_type="EMPTY", region_type="WINDOW"
        )
    except Exception:
        km = None
    try:
        if km is not None and not bool(km.is_modal):
            km = None
    except Exception:
        km = None
    _SHIFT_MODAL_KM = km
    return km


def _enable_native_shift_snap() -> bool:
    global _SHIFT_BRIDGE_ERROR
    if _SHIFT_MODAL_ITEMS:
        return True
    km = _live_rotate_modal_keymap()
    if km is None:
        _SHIFT_BRIDGE_ERROR = "Live View3D Rotate Modal keymap unavailable"
        return False

    created = []
    try:
        for key in _SHIFT_KEYS:
            created.append(km.keymap_items.new_modal(
                "AXIS_SNAP_ENABLE", key, "PRESS", any=True
            ))
            created.append(km.keymap_items.new_modal(
                "AXIS_SNAP_DISABLE", key, "RELEASE", any=True
            ))
        _SHIFT_MODAL_ITEMS.extend(created)
        _SHIFT_BRIDGE_ERROR = ""
        return True
    except Exception as exc:
        _SHIFT_BRIDGE_ERROR = f"{type(exc).__name__}: {exc}"
        for item in created:
            try:
                km.keymap_items.remove(item)
            except Exception:
                pass
        _SHIFT_MODAL_ITEMS.clear()
        return False


def _disable_native_shift_snap():
    km = _SHIFT_MODAL_KM
    if km is not None:
        for item in tuple(_SHIFT_MODAL_ITEMS):
            try:
                km.keymap_items.remove(item)
            except Exception:
                pass
    _SHIFT_MODAL_ITEMS.clear()


def _operator_identifier(op) -> str:
    values = []
    for attr in ("bl_idname", "idname", "name"):
        try:
            values.append(str(getattr(op, attr, "") or ""))
        except Exception:
            pass
    for owner_name in ("bl_rna", "rna_type"):
        try:
            owner = getattr(op, owner_name, None)
            values.append(str(getattr(owner, "identifier", "") or ""))
        except Exception:
            pass
    try:
        values.append(str(op))
    except Exception:
        pass
    return " | ".join(v for v in values if v)


def _native_rotate_alive(window) -> bool:
    if window is None:
        return False
    try:
        operators = tuple(window.modal_operators)
    except Exception:
        return False
    for op in operators:
        ident = _operator_identifier(op).upper()
        if "VIEW3D_OT_ROTATE" in ident or "VIEW3D.ROTATE" in ident:
            return True
    return False


def _window_by_ptr(pointer: int):
    try:
        for window in tuple(bpy.context.window_manager.windows):
            if _ptr(window) == int(pointer or 0):
                return window
    except Exception:
        pass
    return None


def _native_session_tick():
    global _NATIVE_TIMER_RUNNING
    if not _REGISTERED:
        _NATIVE_SESSIONS.clear()
        _disable_native_shift_snap()
        _NATIVE_TIMER_RUNNING = False
        return None

    now = time.monotonic()
    for pointer, record in tuple(_NATIVE_SESSIONS.items()):
        window = _window_by_ptr(pointer)
        if window is None:
            _NATIVE_SESSIONS.pop(pointer, None)
            continue
        alive = _native_rotate_alive(window)
        if alive:
            record["seen"] = True
            record["last_alive"] = now
            continue
        age = now - float(record.get("started", now))
        if bool(record.get("seen")) or age > 0.75:
            _NATIVE_SESSIONS.pop(pointer, None)

    if not _NATIVE_SESSIONS:
        _disable_native_shift_snap()
        _NATIVE_TIMER_RUNNING = False
        state = _runtime_state()
        if state is not None:
            state["native_shift_snap_bridge"] = "IDLE"
        return None
    return 0.03


def _ensure_native_session_timer():
    global _NATIVE_TIMER_RUNNING
    if _NATIVE_TIMER_RUNNING:
        return
    _NATIVE_TIMER_RUNNING = True
    try:
        bpy.app.timers.register(_native_session_tick, first_interval=0.02)
    except Exception:
        _NATIVE_TIMER_RUNNING = False


def _runtime_state():
    try:
        return _base._APP.store.namespace("sculpt")
    except Exception:
        return None


def _set_status(text: str):
    state = _runtime_state()
    if state is not None:
        state["native_orbit_status"] = str(text or "")
        state["native_shift_snap_bridge"] = "BLENDER_NATIVE"
        state.pop("native_shift_snap_error", None)


def invoke_blender_rotate(target) -> bool:
    if target is None:
        return False
    window, area, region = target
    _enable_native_shift_snap()
    pointer = _ptr(window)
    try:
        with bpy.context.temp_override(window=window, area=area, region=region):
            result = bpy.ops.view3d.rotate("INVOKE_DEFAULT")
        running = "RUNNING_MODAL" in set(result or ())
    except Exception as exc:
        running = False
        _set_status(f"Blender Native Rotate ERROR: {type(exc).__name__}: {exc}")

    if not running:
        if not _NATIVE_SESSIONS:
            _disable_native_shift_snap()
        return False

    _NATIVE_SESSIONS[pointer] = {
        "started": time.monotonic(),
        "last_alive": time.monotonic(),
        "seen": False,
    }
    _ensure_native_session_timer()
    state = _runtime_state()
    if state is not None:
        state["native_shift_snap_bridge"] = "ACTIVE"
        state.pop("native_shift_snap_error", None)
    _set_status("Blender Native Rotate · Shift=Native Axis Snap")
    return True


def _invoke_blender_rotate(target) -> bool:
    """Compatibility wrapper; all LumaFold rotate starts share one gateway."""
    return invoke_blender_rotate(target)


def try_native_navigation(context, event, target, *, host=None):
    event_type = str(getattr(event, "type", "") or "")
    event_value = str(getattr(event, "value", "") or "").upper()
    if event_value != "PRESS" or event_type not in {"LEFTMOUSE", "RIGHTMOUSE"}:
        return None
    if bool(getattr(event, "ctrl", False)) or bool(getattr(event, "alt", False)):
        return None
    return _invoke_blender_rotate(target)


def configure(app, sculpt_input_profile, shortcut_product, ui_patch, operators_module):
    global _CONFIGURED
    if _CONFIGURED:
        return
    _base.configure(app, sculpt_input_profile, shortcut_product, ui_patch, operators_module)
    setter = getattr(_base, "set_navigation_handler", None)
    if not callable(setter):
        raise RuntimeError("Sculpt navigation handler slot is unavailable")
    setter(try_native_navigation)
    _CONFIGURED = True


def register():
    global _REGISTERED
    if _REGISTERED:
        return
    _REGISTERED = True
    _NATIVE_SESSIONS.clear()
    _disable_native_shift_snap()
    _base.register()
    _set_status("Blender-native navigation isolation ready")


def unregister():
    global _REGISTERED, _CONFIGURED, _NATIVE_TIMER_RUNNING, _SHIFT_MODAL_KM
    _REGISTERED = False
    _NATIVE_SESSIONS.clear()
    _disable_native_shift_snap()
    _SHIFT_MODAL_KM = None
    _NATIVE_TIMER_RUNNING = False
    try:
        setter = getattr(_base, "set_navigation_handler", None)
        if callable(setter):
            setter(None)
        _base.unregister()
    finally:
        _CONFIGURED = False
