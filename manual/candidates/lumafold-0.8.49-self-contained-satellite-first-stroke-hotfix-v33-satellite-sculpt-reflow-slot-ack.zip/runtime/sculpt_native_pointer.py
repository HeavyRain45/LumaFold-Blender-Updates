from __future__ import annotations

"""Blender-native arbitration for plain Sculpt LMB.

LumaFold must not duplicate Blender's sculpt-surface hit testing. Blender 5.2.1
already exposes the exact production decision through SCULPT_OT_brush_stroke:
with ``ignore_background_click=True`` its invoke path returns PASS_THROUGH when
Blender's own ``over_mesh`` test rejects the background click, and enters the
native Sculpt modal when the pointer belongs to the sculpt surface.

Policy:
- Blender Sculpt decides surface ownership;
- only Blender's explicit PASS_THROUGH may promote the same press to Rotate;
- CANCELLED/errors fail closed to normal event pass-through, never to Rotate;
- LumaFold owns no brush-stroke or rotate lifecycle after invocation.
"""

import importlib

import bpy

SCULPT = "SCULPT"
ROTATE = "ROTATE"
FALLBACK = "FALLBACK"


def _invoke_sculpt(target, *, smooth: bool = False):
    if target is None:
        return set()
    window, area, region = target
    try:
        with bpy.context.temp_override(window=window, area=area, region=region):
            result = bpy.ops.sculpt.brush_stroke(
                "INVOKE_DEFAULT",
                True,
                mode="SMOOTH" if smooth else "NORMAL",
                ignore_background_click=True,
            )
        return set(result or ())
    except (RuntimeError, TypeError, AttributeError):
        return set()


def _invoke_rotate(target) -> bool:
    """Start background orbit through LumaFold's single native gateway."""
    try:
        navigation = importlib.import_module(__package__ + ".sculpt_navigation")
        invoke = getattr(navigation, "invoke_blender_rotate", None)
        if not callable(invoke):
            return False
        return bool(invoke(target))
    except (RuntimeError, TypeError, AttributeError, ImportError):
        return False


def arbitrate_plain_lmb(context, event, target) -> str:
    """Let Blender itself choose Sculpt vs background Rotate for one LMB press."""
    del context  # target override is the only View3D authority used here.
    smooth = bool(getattr(event, "shift", False))
    sculpt_result = _invoke_sculpt(target, smooth=smooth)

    if "RUNNING_MODAL" in sculpt_result or "FINISHED" in sculpt_result:
        return SCULPT

    # This is the crucial boundary: Rotate is legal only when Blender's own
    # Sculpt operator explicitly says the click should pass through.
    if "PASS_THROUGH" in sculpt_result:
        return ROTATE if _invoke_rotate(target) else FALLBACK

    # CANCELLED/error can mean brush/tool/context constraints, not background.
    # Never reinterpret those failures as viewport navigation.
    return FALLBACK
