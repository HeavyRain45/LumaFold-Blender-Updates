from __future__ import annotations

"""ZBrush-style Ctrl Mask intent router backed by Blender-native modal tools.

P6 keeps Blender as the sole live modal owner for Box/Lasso/Line/Polyline.
LumaFold only resolves ZBrush-specific intent:

- Ctrl tap on sculpt surface -> native Smooth Mask.
- Ctrl+Alt tap on sculpt surface -> native Sharpen Mask.
- Ctrl tap on background -> native Invert Mask.
- Ctrl drag from sculpt surface -> native Mask brush stroke.
- Ctrl/Ctrl+Alt drag from background -> selected native Mask gesture.
- After the native gesture has fully finished, a passive watcher may classify
  the registered native gesture geometry. If it provably missed the sculpt
  object, LumaFold performs native Clear Mask.

No LumaFold modal remains alive beside a Blender Mask gesture. This avoids
competing modal handlers and keeps native preview/input ownership intact.
"""

import bpy
from bpy_extras import view3d_utils


MASK_GESTURE_ID = "lumafold.sculpt_mask_gesture_v2"

_INSTALLED = False
_TRACE = None
_TOOL_BRIDGE = None
_OBSERVER = None
_GENERATION = 0
_MOVE_EVENTS = {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}

_TOOL_TO_OPERATOR = {
    "builtin.box_mask": "mask_box_gesture",
    "builtin.lasso_mask": "mask_lasso_gesture",
    "builtin.line_mask": "mask_line_gesture",
    "builtin.polyline_mask": "mask_polyline_gesture",
}
_TOOL_PROPERTY_NAMES = {
    "builtin.box_mask": ("use_front_faces_only",),
    "builtin.lasso_mask": (
        "use_front_faces_only",
        "use_smooth_stroke",
        "smooth_stroke_radius",
        "smooth_stroke_factor",
    ),
    "builtin.line_mask": ("use_front_faces_only", "use_limit_to_segment"),
    "builtin.polyline_mask": ("use_front_faces_only",),
}


def _trace(reason: str, context=None, event=None, **extra) -> None:
    if _TRACE is None:
        return
    try:
        payload = {
            "reason": str(reason),
            "event": str(getattr(event, "type", "") or "") if event is not None else "",
            "value": str(getattr(event, "value", "") or "") if event is not None else "",
        }
        payload.update(extra)
        _TRACE.trace("ZBRUSH_MASK_GESTURE", **payload)
    except Exception:
        pass


def _bridge_state(context) -> dict:
    bridge = _TOOL_BRIDGE
    if bridge is None:
        return {"shape": "BOX", "tool_id": "builtin.box_mask"}
    fn = getattr(bridge, "gesture_begin", None)
    if not callable(fn):
        return {"shape": "BOX", "tool_id": "builtin.box_mask"}
    try:
        return dict(fn(context) or {})
    except Exception:
        return {"shape": "BOX", "tool_id": "builtin.box_mask"}


def _bridge_observe_event(context, event) -> None:
    bridge = _TOOL_BRIDGE
    if bridge is None:
        return
    fn = getattr(bridge, "observe_event", None)
    if callable(fn):
        try:
            fn(context, event)
        except Exception:
            pass


def _bridge_current_tool(context) -> str:
    bridge = _TOOL_BRIDGE
    if bridge is None:
        return "builtin.box_mask"
    fn = getattr(bridge, "current_tool", None)
    if callable(fn):
        try:
            tool_id = str(fn(context) or "")
            if tool_id in _TOOL_TO_OPERATOR:
                return tool_id
        except Exception:
            pass
    return "builtin.box_mask"


def _region_xy(event):
    try:
        return float(event.mouse_region_x), float(event.mouse_region_y)
    except Exception:
        return 0.0, 0.0


def _drag_threshold(context) -> float:
    try:
        inputs = context.preferences.inputs
        values = []
        for name in ("drag_threshold_tablet", "drag_threshold_mouse", "drag_threshold"):
            value = getattr(inputs, name, None)
            if value is not None and float(value) > 0.0:
                values.append(float(value))
        if values:
            return max(2.0, min(values))
    except Exception:
        pass
    return 4.0


def _active_sculpt_mesh(context):
    obj = getattr(context, "sculpt_object", None)
    if obj is None:
        objects = getattr(getattr(context, "view_layer", None), "objects", None)
        obj = getattr(objects, "active", None) if objects is not None else None
    if obj is None or getattr(obj, "type", "") != "MESH":
        return None
    return obj


def _surface_hit_xy(context, x: float, y: float) -> bool:
    """Mask-local surface classifier used only for ZBrush tap/drag intent."""
    obj = _active_sculpt_mesh(context)
    region = getattr(context, "region", None)
    rv3d = getattr(context, "region_data", None)
    scene = getattr(context, "scene", None)
    if obj is None or region is None or rv3d is None:
        return False
    try:
        origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, (float(x), float(y)))
        direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, (float(x), float(y)))
        depsgraph = context.evaluated_depsgraph_get()
        if scene is not None:
            hit, _loc, _normal, _index, hit_obj, _matrix = scene.ray_cast(
                depsgraph, origin, direction
            )
            if hit and hit_obj is not None:
                original = getattr(hit_obj, "original", hit_obj)
                if hit_obj == obj or original == obj:
                    return True
        eval_obj = obj.evaluated_get(depsgraph)
        inv = eval_obj.matrix_world.inverted_safe()
        hit, _loc, _normal, _index = eval_obj.ray_cast(
            inv @ origin, inv.to_3x3() @ direction
        )
        return bool(hit)
    except Exception:
        return False


def _drag_hits_active_surface(context, event) -> bool:
    x, y = _region_xy(event)
    return _surface_hit_xy(context, x, y)


def _view3d_override(context):
    window = getattr(context, "window", None)
    area = getattr(context, "area", None)
    region = getattr(context, "region", None)
    if (
        window is None
        or area is None
        or region is None
        or getattr(area, "type", "") != "VIEW_3D"
        or getattr(region, "type", "") != "WINDOW"
    ):
        return None
    return window, area, region


def _run_mask_filter(context, sharpen: bool):
    kwargs = {
        "filter_type": "SHARPEN" if sharpen else "SMOOTH",
        "iterations": 1,
        "auto_iteration_count": True,
    }
    target = _view3d_override(context)
    try:
        if target is not None:
            window, area, region = target
            with bpy.context.temp_override(window=window, area=area, region=region):
                result = set(bpy.ops.sculpt.mask_filter("EXEC_DEFAULT", **kwargs) or ())
        else:
            result = set(bpy.ops.sculpt.mask_filter("EXEC_DEFAULT", **kwargs) or ())
        _trace("mask_filter_finished", context, None, sharpen=bool(sharpen), result=sorted(result))
        return result
    except (RuntimeError, TypeError, AttributeError) as exc:
        _trace(
            "mask_filter_exception",
            context,
            None,
            sharpen=bool(sharpen),
            error=f"{type(exc).__name__}: {exc}",
        )
        return {"CANCELLED"}


def _run_mask_flood(context, mode: str, value: float = 0.0):
    kwargs = {"mode": str(mode), "value": float(value)}
    target = _view3d_override(context)
    try:
        if target is not None:
            window, area, region = target
            with bpy.context.temp_override(window=window, area=area, region=region):
                result = set(bpy.ops.paint.mask_flood_fill("EXEC_DEFAULT", **kwargs) or ())
        else:
            result = set(bpy.ops.paint.mask_flood_fill("EXEC_DEFAULT", **kwargs) or ())
        _trace("mask_flood_finished", context, None, mode=str(mode), result=sorted(result))
        return result
    except (RuntimeError, TypeError, AttributeError) as exc:
        _trace(
            "mask_flood_exception",
            context,
            None,
            mode=str(mode),
            error=f"{type(exc).__name__}: {exc}",
        )
        return {"CANCELLED"}


def _run_mask_flood_target(target, mode: str, value: float = 0.0):
    if target is None:
        return {"CANCELLED"}
    window, area, region = target
    try:
        with bpy.context.temp_override(window=window, area=area, region=region):
            result = set(
                bpy.ops.paint.mask_flood_fill(
                    "EXEC_DEFAULT",
                    mode=str(mode),
                    value=float(value),
                )
                or ()
            )
        _trace(
            "post_native_mask_flood_finished",
            None,
            None,
            mode=str(mode),
            result=sorted(result),
        )
        return result
    except (RuntimeError, TypeError, AttributeError) as exc:
        _trace(
            "post_native_mask_flood_exception",
            None,
            None,
            mode=str(mode),
            error=f"{type(exc).__name__}: {exc}",
        )
        return {"CANCELLED"}


def _native_mask_stroke(context, invert: bool):
    """Invoke Blender's native Mask brush without leaving the Ctrl tool session."""
    target = _view3d_override(context)
    try:
        if target is None:
            return {"CANCELLED"}
        window, area, region = target
        with bpy.context.temp_override(window=window, area=area, region=region):
            return set(
                bpy.ops.sculpt.brush_stroke(
                    "INVOKE_DEFAULT",
                    mode="INVERT" if invert else "NORMAL",
                    brush_toggle="MASK",
                    ignore_background_click=True,
                )
                or ()
            )
    except (RuntimeError, TypeError, AttributeError):
        return {"CANCELLED"}


def _active_tool_properties(context, operator_id: str):
    workspace = getattr(context, "workspace", None)
    if workspace is None:
        return None
    try:
        tool = workspace.tools.from_space_view3d_mode("SCULPT", create=False)
        if tool is None:
            return None
        return tool.operator_properties(operator_id)
    except Exception:
        return None


def _copy_native_tool_settings(context, tool_id: str, operator_id: str) -> dict:
    """Mirror Blender's visible native Tool Settings into the explicit invoke."""
    props = _active_tool_properties(context, operator_id)
    if props is None:
        return {}
    values = {}
    for name in _TOOL_PROPERTY_NAMES.get(tool_id, ()):
        try:
            value = getattr(props, name)
        except Exception:
            continue
        if isinstance(value, (bool, int, float, str)):
            values[name] = value
    return values


def _observer_arm(context, tool_id: str):
    observer = _OBSERVER
    arm = getattr(observer, "arm", None) if observer is not None else None
    if not callable(arm):
        return None

    target = _view3d_override(context)
    generation = int(_GENERATION)

    def completed(should_clear: bool):
        if not _INSTALLED or generation != int(_GENERATION):
            return
        _trace(
            "post_native_background_classified",
            None,
            None,
            tool=tool_id,
            should_clear=bool(should_clear),
        )
        if should_clear:
            _run_mask_flood_target(target, "VALUE", 0.0)

    try:
        return arm(context, tool_id, completed)
    except Exception:
        return None


def _observer_cancel(state) -> None:
    observer = _OBSERVER
    cancel = getattr(observer, "cancel", None) if observer is not None else None
    if callable(cancel):
        try:
            cancel(state)
        except Exception:
            pass


def _invoke_native_background_gesture(context, tool_id: str, *, erase: bool):
    """Hand off once; Blender alone owns the live native gesture from here."""
    tool_id = str(tool_id)
    op_name = _TOOL_TO_OPERATOR.get(tool_id, "mask_box_gesture")
    operator_id = f"paint.{op_name}"
    operator = getattr(getattr(bpy.ops, "paint", None), op_name, None)
    if operator is None:
        return {"CANCELLED"}

    kwargs = _copy_native_tool_settings(context, tool_id, operator_id)
    kwargs["value"] = 0.0 if erase else 1.0
    if tool_id == "builtin.box_mask":
        kwargs["wait_for_input"] = False

    watcher = _observer_arm(context, tool_id)
    target = _view3d_override(context)
    try:
        if target is None:
            result = set(operator("INVOKE_DEFAULT", **kwargs) or ())
        else:
            window, area, region = target
            with bpy.context.temp_override(window=window, area=area, region=region):
                result = set(operator("INVOKE_DEFAULT", **kwargs) or ())
        if "RUNNING_MODAL" not in result:
            _observer_cancel(watcher)
        _trace(
            "native_modal_mask_handoff",
            context,
            None,
            tool=tool_id,
            operator=operator_id,
            erase=bool(erase),
            result=sorted(result),
        )
        return result
    except (RuntimeError, TypeError, AttributeError) as exc:
        _observer_cancel(watcher)
        _trace(
            "native_modal_mask_exception",
            context,
            None,
            tool=tool_id,
            operator=operator_id,
            error=f"{type(exc).__name__}: {exc}",
        )
        return {"CANCELLED"}


class LUMAFOLD_OT_sculpt_mask_gesture_v2(bpy.types.Operator):
    """Thin ZBrush intent classifier; Blender owns native gesture interaction."""

    bl_idname = MASK_GESTURE_ID
    bl_label = "LumaFold ZBrush Mask Intent"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        return bool(
            str(getattr(context, "mode", "") or "").upper() == "SCULPT"
            and getattr(getattr(context, "area", None), "type", "") == "VIEW_3D"
            and getattr(getattr(context, "region", None), "type", "") == "WINDOW"
        )

    def invoke(self, context, event):
        if not bool(getattr(event, "ctrl", False)) or bool(getattr(event, "shift", False)):
            return {"CANCELLED"}

        state = _bridge_state(context)
        self._tool_id = str(state.get("tool_id") or _bridge_current_tool(context))
        if self._tool_id not in _TOOL_TO_OPERATOR:
            self._tool_id = "builtin.box_mask"
        self._sharpen = bool(getattr(event, "alt", False))
        self._start_x, self._start_y = _region_xy(event)
        self._start_on_surface = bool(_drag_hits_active_surface(context, event))
        self._dragging = False
        threshold = _drag_threshold(context)
        self._threshold_sq = threshold * threshold
        context.window_manager.modal_handler_add(self)
        _trace(
            "intent_started",
            context,
            event,
            tool=self._tool_id,
            start_on_surface=bool(self._start_on_surface),
            sharpen=bool(self._sharpen),
        )
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        event_type = str(getattr(event, "type", "") or "").upper()
        event_value = str(getattr(event, "value", "") or "").upper()

        if event_type in {"LEFT_CTRL", "RIGHT_CTRL"} and event_value == "RELEASE":
            _bridge_observe_event(context, event)
            return {"CANCELLED"}

        if event_type == "WINDOW_DEACTIVATE":
            _bridge_observe_event(context, event)
            return {"CANCELLED"}

        if event_type == "ESC":
            return {"CANCELLED"}

        if event_type in _MOVE_EVENTS:
            x, y = _region_xy(event)
            dx = x - self._start_x
            dy = y - self._start_y
            if not self._dragging and dx * dx + dy * dy >= self._threshold_sq:
                self._dragging = True
                if self._start_on_surface:
                    result = _native_mask_stroke(context, bool(self._sharpen))
                    _trace(
                        "surface_mask_drag_handoff",
                        context,
                        event,
                        result=sorted(result),
                    )
                else:
                    result = _invoke_native_background_gesture(
                        context,
                        self._tool_id,
                        erase=bool(self._sharpen),
                    )
                    _trace(
                        "background_native_mask_handoff",
                        context,
                        event,
                        tool=self._tool_id,
                        result=sorted(result),
                    )

                # Critical P6 invariant: once the native modal starts, this
                # LumaFold operator terminates immediately. There is never a
                # second LumaFold modal handler competing for release/clicks.
                return {"FINISHED"}

            return {"RUNNING_MODAL"}

        if event_type == "LEFTMOUSE" and event_value == "RELEASE":
            if self._dragging:
                return {"FINISHED"}
            if self._start_on_surface:
                result = _run_mask_filter(context, bool(self._sharpen))
                reason = "mask_sharpen_tap" if self._sharpen else "mask_smooth_tap"
            elif not self._sharpen:
                result = _run_mask_flood(context, "INVERT")
                reason = "background_invert_tap"
            else:
                result = {"CANCELLED"}
                reason = "background_alt_tap_noop"
            _trace(
                reason,
                context,
                event,
                result=sorted(result),
                tool=_bridge_current_tool(context),
            )
            return {"FINISHED"}

        return {"RUNNING_MODAL", "PASS_THROUGH"}


_CLASSES = (LUMAFOLD_OT_sculpt_mask_gesture_v2,)


def handle_pointer_press(context, event, target):
    if str(getattr(event, "type", "") or "").upper() != "LEFTMOUSE":
        return None
    if str(getattr(event, "value", "") or "").upper() != "PRESS":
        return None
    if not bool(getattr(event, "ctrl", False)) or bool(getattr(event, "shift", False)):
        return None
    if target is None:
        return False

    window, area, region = target
    try:
        # Convert the original window-space pointer to the target
        # View3D region explicitly; do not depend on whichever area
        # happened to own the universal modal event.
        try:
            x = float(event.mouse_x) - float(region.x)
            y = float(event.mouse_y) - float(region.y)
        except Exception:
            x, y = _region_xy(event)

        with bpy.context.temp_override(window=window, area=area, region=region):
            routed_context = bpy.context
            on_surface = bool(_surface_hit_xy(routed_context, x, y))
            invert = bool(getattr(event, "alt", False))

            if on_surface:
                # Important: invoke on the original LEFTMOUSE PRESS.
                # Waiting until MOUSEMOVE loses Blender's native
                # brush-stroke press edge and was why Ctrl painting
                # appeared to disappear. The active toolbar icon is
                # intentionally left on the temporary Mask tool.
                result = _native_mask_stroke(routed_context, invert)
                ok = bool({"RUNNING_MODAL", "FINISHED"} & set(result or ()))
                _trace(
                    "surface_native_mask_press_handoff" if ok else "surface_native_mask_press_failed",
                    routed_context, event, result=sorted(result or ()),
                )
                return ok

            state = _bridge_state(routed_context)
            tool_id = str(state.get("tool_id") or _bridge_current_tool(routed_context))
            if tool_id not in _TOOL_TO_OPERATOR:
                tool_id = "builtin.box_mask"
            result = _invoke_native_background_gesture(
                routed_context, tool_id, erase=invert,
            )
            ok = bool({"RUNNING_MODAL", "FINISHED"} & set(result or ()))
            _trace(
                "background_native_mask_press_handoff" if ok else "background_native_mask_press_failed",
                routed_context, event, tool=tool_id, result=sorted(result or ()),
            )
            return ok
    except (RuntimeError, TypeError, AttributeError) as exc:
        _trace(
            "mask_press_split_exception", context, event,
            error=f"{type(exc).__name__}: {exc}",
        )
        return False



def install(real_machine_trace=None, tool_bridge=None, observer=None):
    global _INSTALLED, _TRACE, _TOOL_BRIDGE, _OBSERVER, _GENERATION
    if _INSTALLED:
        return
    if observer is None:
        raise RuntimeError("Mask post-native observer is unavailable")
    for name in ("arm", "cancel"):
        if not callable(getattr(observer, name, None)):
            raise RuntimeError(f"Mask post-native observer missing {name}")
    _GENERATION += 1
    _TRACE = real_machine_trace
    _TOOL_BRIDGE = tool_bridge
    _OBSERVER = observer
    for cls in _CLASSES:
        bpy.utils.register_class(cls)
    _INSTALLED = True


def uninstall():
    global _INSTALLED, _TRACE, _TOOL_BRIDGE, _OBSERVER, _GENERATION
    _GENERATION += 1
    if not _INSTALLED:
        _OBSERVER = None
        _TOOL_BRIDGE = None
        _TRACE = None
        return
    for cls in reversed(_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    _OBSERVER = None
    _TOOL_BRIDGE = None
    _TRACE = None
    _INSTALLED = False
