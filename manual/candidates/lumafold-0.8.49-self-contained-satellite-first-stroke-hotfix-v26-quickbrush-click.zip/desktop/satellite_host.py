from __future__ import annotations

import sys
from pathlib import Path

# This file is launched directly as a script by desktop.launcher. In that mode
# sys.path[0] is the desktop/ directory, so the repository root must be inserted
# before importing the desktop package. The runtime owns native Host mechanics;
# this wrapper only composes product UI/focus policy around that runtime.
EXT_ROOT = Path(__file__).resolve().parent.parent
if str(EXT_ROOT) not in sys.path:
    sys.path.insert(0, str(EXT_ROOT))

from desktop import satellite_host_runtime as _runtime
from desktop import secondary_surface_session as _secondary_session
from ui import sculpt_interactions as _interactions
from ui import sculpt_shortcut_keys as _shortcut_keys
from ui import sculpt_primary_layout as _primary_layout
from ui import sculpt_presentation as _presentation
from ui import theme as _theme
from ui import theme_wire as _theme_wire

_interactions.install_shared()
_primary_layout.install()
_presentation.install()

_original_draw_sculpt_compact = _runtime.draw_sculpt_compact
_original_sync_local_from_snapshot = _runtime._sync_local_from_snapshot
_original_draw_frame = _runtime._draw_frame
_original_wndproc = _runtime.wndproc
_last_target_sent = None
_last_theme_signature = ""
_initial_state_ready = _runtime.threading.Event()
_first_render_ready = _runtime.threading.Event()
_shortcut_capture_was_active = False

# The child stays off-screen until one complete Blender snapshot has rendered.
_target_screen_x = int(_runtime.ARGS.x)
_target_screen_y = int(_runtime.ARGS.y)
_OFFSCREEN_COORD = -32000
_runtime.ARGS.x = _OFFSCREEN_COORD
_runtime.ARGS.y = _OFFSCREEN_COORD
_preflight_visible = False
_visible_ready = False

WM_APP_QUICK_REPLACE_SLOT = 0x8052
WM_APP_PRIMARY_BRUSH_VISUAL_SYNC = 0x8053
WM_MOUSEACTIVATE = 0x0021
MA_NOACTIVATE = 3
WM_KEYDOWN = 0x0100
WM_KEYUP = 0x0101
WM_SYSKEYDOWN = 0x0104
WM_SYSKEYUP = 0x0105
VK_ESCAPE = 0x1B

_VK_BUTTONS = (0x01, 0x02, 0x04)
_external_down_last = {vk: False for vk in _VK_BUTTONS}
_external_injected = set()
_shortcut_mirror_down = {}


def _shortcut_vk(token):
    token = str(token or "").strip().upper()
    if len(token) == 1 and "0" <= token <= "9":
        return ord(token)
    if len(token) == 1 and "A" <= token <= "Z":
        return ord(token)
    if token.startswith("NUM") and token[3:].isdigit():
        value = int(token[3:])
        if 0 <= value <= 9:
            return 0x60 + value
    return 0


def _key_down(vk):
    try:
        return bool(int(_runtime.user32.GetAsyncKeyState(int(vk))) & 0x8000)
    except Exception:
        return False


def _mirror_quick_shortcut_selection():
    if _interactions.shortcut_capture_active():
        return
    labels = list(_runtime.local_sculpt.get("quick_shortcuts") or ())
    slots = list(_runtime.local_sculpt.get("quick_brush_slots") or ())
    if not labels:
        return

    ctrl = _key_down(0x11)
    alt = _key_down(0x12)
    shift = _key_down(0x10)
    oskey = _key_down(0x5B) or _key_down(0x5C)

    for slot, raw in enumerate(labels[:16]):
        label = str(raw or "").strip()
        if not label:
            _shortcut_mirror_down[slot] = False
            continue
        parts = [part.strip() for part in label.split("+") if part.strip()]
        if not parts:
            _shortcut_mirror_down[slot] = False
            continue

        mods = {part.casefold() for part in parts[:-1]}
        key_token = parts[-1]
        vk = _shortcut_vk(key_token)
        if not vk:
            _shortcut_mirror_down[slot] = False
            continue

        expected_ctrl = "ctrl" in mods
        expected_alt = "alt" in mods
        expected_shift = "shift" in mods
        expected_os = "os" in mods
        pressed = bool(
            _key_down(vk)
            and ctrl == expected_ctrl
            and alt == expected_alt
            and shift == expected_shift
            and oskey == expected_os
        )
        was = bool(_shortcut_mirror_down.get(slot, False))
        _shortcut_mirror_down[slot] = pressed
        if not pressed or was:
            continue

        # Blender remains the authority and has already received the same
        # keymap event. This is a visual mirror only.
        _runtime.local_sculpt["quick_slot"] = int(slot)
        _runtime.local_sculpt["active_quick_slot"] = int(slot)
        if 0 <= slot < len(slots):
            spec = dict(slots[slot] or {})
            if not bool(spec.get("empty", False)):
                _runtime.local_sculpt["current_brush_name"] = str(spec.get("label") or "")
                rel = str(spec.get("relative_asset_identifier") or "")
                if rel:
                    _runtime.local_sculpt["current_brush_asset"] = {
                        "relative_asset_identifier": rel,
                        "full_library_path": str(spec.get("full_library_path") or ""),
                    }
        break


try:
    _runtime.user32.GetAsyncKeyState.argtypes = [_runtime.ctypes.c_int]
    _runtime.user32.GetAsyncKeyState.restype = _runtime.ctypes.c_short
except Exception:
    pass


def _owner_work_area():
    try:
        class MONITORINFO(_runtime.ctypes.Structure):
            _fields_ = [
                ("cbSize", _runtime.wintypes.DWORD),
                ("rcMonitor", _runtime.wintypes.RECT),
                ("rcWork", _runtime.wintypes.RECT),
                ("dwFlags", _runtime.wintypes.DWORD),
            ]

        user32 = _runtime.user32
        user32.MonitorFromWindow.argtypes = [_runtime.HWND, _runtime.wintypes.DWORD]
        user32.MonitorFromWindow.restype = _runtime.wintypes.HANDLE
        user32.GetMonitorInfoW.argtypes = [_runtime.wintypes.HANDLE, _runtime.ctypes.POINTER(MONITORINFO)]
        user32.GetMonitorInfoW.restype = _runtime.wintypes.BOOL

        source = int(_runtime.ARGS.owner_hwnd or 0)
        if not source or not user32.IsWindow(_runtime.HWND(source)):
            source = int(_runtime.hwnd_main or 0)
        monitor = user32.MonitorFromWindow(_runtime.HWND(source), 2)
        if not monitor:
            return None
        info = MONITORINFO()
        info.cbSize = _runtime.ctypes.sizeof(MONITORINFO)
        if not user32.GetMonitorInfoW(monitor, _runtime.ctypes.byref(info)):
            return None
        return {
            "left": int(info.rcWork.left),
            "top": int(info.rcWork.top),
            "right": int(info.rcWork.right),
            "bottom": int(info.rcWork.bottom),
        }
    except Exception:
        return None


def _show_visible_ready_window() -> bool:
    global _visible_ready
    if _visible_ready:
        return True
    hwnd = _runtime.hwnd_main
    if not hwnd or not _runtime.user32.IsWindow(hwnd):
        return False

    rect = _runtime.wintypes.RECT()
    if not _runtime.user32.GetWindowRect(hwnd, _runtime.ctypes.byref(rect)):
        return False
    width = max(240, int(rect.right - rect.left))
    height = max(300, int(rect.bottom - rect.top))
    x = int(_target_screen_x)
    y = int(_target_screen_y)
    work = _owner_work_area()
    if work:
        margin = 24
        min_x = int(work["left"]) + margin
        min_y = int(work["top"]) + margin
        max_x = max(min_x, int(work["right"]) - width - margin)
        max_y = max(min_y, int(work["bottom"]) - height - margin)
        x = min(max(x, min_x), max_x)
        y = min(max(y, min_y), max_y)

    try:
        _runtime.set_client_screen_position(hwnd, x, y)
        _runtime.user32.ShowWindow(hwnd, _runtime.SW_SHOWNOACTIVATE)
        _runtime.user32.UpdateWindow(hwnd)
    except Exception:
        return False

    rect2 = _runtime.wintypes.RECT()
    if not _runtime.user32.GetWindowRect(hwnd, _runtime.ctypes.byref(rect2)):
        return False
    if not bool(_runtime.user32.IsWindowVisible(hwnd)):
        return False

    left = int(rect2.left)
    top = int(rect2.top)
    right = int(rect2.right)
    bottom = int(rect2.bottom)
    if work:
        on_screen = bool(
            right > int(work["left"]) + 8
            and left < int(work["right"]) - 8
            and bottom > int(work["top"]) + 8
            and top < int(work["bottom"]) - 8
        )
    else:
        on_screen = left > -10000 and top > -10000
    if not on_screen:
        return False

    _visible_ready = True
    return True


def _sync_shortcut_focus_policy():
    global _shortcut_capture_was_active
    active = bool(_interactions.shortcut_capture_active())
    if active == _shortcut_capture_was_active:
        return
    _shortcut_capture_was_active = active
    try:
        if active and _runtime.hwnd_main:
            _runtime.user32.SetForegroundWindow(_runtime.hwnd_main)
        elif not active:
            owner = int(_runtime.ARGS.owner_hwnd or 0)
            if owner and _runtime.user32.IsWindow(_runtime.HWND(owner)):
                _runtime.user32.SetForegroundWindow(_runtime.HWND(owner))
    except Exception:
        pass


def _restore_blender_foreground_if_satellite_activated():
    if _interactions.shortcut_capture_active():
        return False
    try:
        fg = int(_runtime.user32.GetForegroundWindow() or 0)
        ours = {int(_runtime.hwnd_main or 0), int(_runtime.secondary_hwnd or 0)}
        ours.discard(0)
        if fg not in ours:
            return False

        # Never steal focus in the middle of an ImGui click. V10 could
        # return Blender foreground between press/release, so Host switch
        # sometimes needed several clicks. Restore only after release.
        for vk in (0x01, 0x02, 0x04):
            down, _pressed = _button_state(vk)
            if down:
                return False

        owner = int(_runtime.ARGS.owner_hwnd or 0)
        if not owner or not _runtime.user32.IsWindow(_runtime.HWND(owner)):
            return False
        return bool(_runtime.user32.SetForegroundWindow(_runtime.HWND(owner)))
    except Exception:
        return False


def _prime_pointer_focus():
    """Keep ImGui pointer interaction live without activating the Satellite HWND.

    The Satellite intentionally returns MA_NOACTIVATE so Blender keeps keyboard
    focus. A previous WM_KILLFOCUS can still leave ImGui's internal focus state
    false, and MA_NOACTIVATE then prevents Win32 from sending a compensating
    WM_SETFOCUS. Prime the ImGui focus queue immediately before the mouse-down
    that follows WM_MOUSEACTIVATE; keyboard ownership remains with Blender.
    """
    if _runtime.io is None or not hasattr(_runtime.io, "add_focus_event"):
        return
    try:
        _runtime.io.add_focus_event(True)
    except Exception:
        pass


@_runtime.WNDPROC
def _wndproc_with_shortcut_capture(hwnd, msg, wparam, lparam):
    if int(msg) == int(_runtime.WM_LBUTTONDOWN) and not _interactions.shortcut_capture_active():
        try:
            x, y = _runtime._xy(lparam)
        except Exception:
            x, y = -1, -1
        if _interactions.host_switch_hit_test(x, y):
            _runtime.user32.PostMessageW(hwnd, _runtime.WM_CLOSE, 0, 0)
            return 0

    if int(msg) == WM_MOUSEACTIVATE and not _interactions.shortcut_capture_active():
        _prime_pointer_focus()
        # Important: ordinary Satellite re-entry must remain local-only.
        # Queuing get_state here schedules Blender-main-thread work exactly
        # when the user is about to return to the viewport, which can land
        # on the next Sculpt stroke. Startup/handoff reconciliation remains
        # owned by the existing one-shot ready/lease path.
        return MA_NOACTIVATE

    if int(msg) == WM_APP_PRIMARY_BRUSH_VISUAL_SYNC:
        try:
            _runtime.actions.put({"action": "get_sculpt_visual_state"})
        except Exception:
            pass
        return 0

    if int(msg) in (
        int(_runtime.WM_LBUTTONDOWN),
        int(_runtime.WM_RBUTTONDOWN),
        int(_runtime.WM_MBUTTONDOWN),
    ) and not _interactions.shortcut_capture_active():
        _prime_pointer_focus()
        # satellite_client_pointer_reprime

    if int(msg) == int(_runtime.WM_APP_SHOW):
        _show_visible_ready_window()
        return _original_wndproc(hwnd, msg, wparam, lparam)

    if int(wparam) == VK_ESCAPE and msg in (WM_KEYDOWN, WM_SYSKEYDOWN, WM_KEYUP, WM_SYSKEYUP):
        secondary = _runtime.secondary_hwnd
        if secondary and _runtime.user32.IsWindow(secondary) and _runtime.user32.IsWindowVisible(secondary):
            if msg in (WM_KEYDOWN, WM_SYSKEYDOWN):
                _runtime._hide_secondary_surface()
            return 0
        if _runtime.io is not None and bool(_runtime.surface_state.get("_secondary_surface_open", False)):
            try:
                _runtime.io.add_key_event(
                    _runtime.imgui.Key.KEY_ESCAPE,
                    msg in (WM_KEYDOWN, WM_SYSKEYDOWN),
                )
            except Exception:
                pass
            return 0

    if _runtime.io is not None and _interactions.shortcut_capture_active():
        if _shortcut_keys.feed_win32_key(_runtime.imgui, _runtime.io, int(msg), int(wparam)):
            return 0
    return _original_wndproc(hwnd, msg, wparam, lparam)


def _button_state(vk):
    try:
        raw = int(_runtime.user32.GetAsyncKeyState(int(vk)))
    except Exception:
        return False, False
    return bool(raw & 0x8000), bool(raw & 0x0001)


def _inject_internal_popup_outside_click():
    if _runtime.io is None or not _runtime.hwnd_main:
        return

    states = {vk: _button_state(vk) for vk in _VK_BUTTONS}
    for vk in tuple(_external_injected):
        down, _pressed = states.get(vk, (False, False))
        if not down:
            button = {0x01: _runtime.imgui.MouseButton.LEFT, 0x02: _runtime.imgui.MouseButton.RIGHT, 0x04: _runtime.imgui.MouseButton.MIDDLE}[vk]
            try:
                _runtime.io.add_mouse_button_event(button, False)
            except Exception:
                pass
            _external_injected.discard(vk)

    popup_open = bool(_runtime.surface_state.get("_secondary_surface_open", False))
    if not popup_open:
        for vk, (down, _pressed) in states.items():
            _external_down_last[vk] = bool(down)
        return

    pt = _runtime.POINT()
    wr = _runtime.wintypes.RECT()
    try:
        if not (_runtime.user32.GetCursorPos(_runtime.ctypes.byref(pt)) and _runtime.user32.GetWindowRect(_runtime.hwnd_main, _runtime.ctypes.byref(wr))):
            return
    except Exception:
        return

    outside = not (
        int(wr.left) <= int(pt.x) < int(wr.right)
        and int(wr.top) <= int(pt.y) < int(wr.bottom)
    )
    for vk, (down, pressed_since) in states.items():
        new_press = (down and not _external_down_last.get(vk, False)) or pressed_since
        _external_down_last[vk] = bool(down)
        if not (outside and new_press) or vk in _external_injected:
            continue
        button = {0x01: _runtime.imgui.MouseButton.LEFT, 0x02: _runtime.imgui.MouseButton.RIGHT, 0x04: _runtime.imgui.MouseButton.MIDDLE}[vk]
        try:
            _runtime.io.add_mouse_pos_event(float(pt.x - wr.left), float(pt.y - wr.top))
            _runtime.io.add_mouse_button_event(button, True)
            _external_injected.add(vk)
        except Exception:
            pass
        break


def _sync_target_slot_to_secondary():
    global _last_target_sent
    hwnd = _runtime.secondary_hwnd
    if not hwnd or not _runtime.user32.IsWindow(hwnd):
        _last_target_sent = None
        return
    try:
        slot = int(_runtime.local_sculpt.get("quick_replace_slot", -1))
    except Exception:
        slot = -1
    wire = slot + 1
    if wire == _last_target_sent:
        return
    try:
        _runtime.user32.PostMessageW(hwnd, WM_APP_QUICK_REPLACE_SLOT, int(wire), 0)
        _last_target_sent = wire
    except Exception:
        pass


def _apply_preflight_state(response) -> bool:
    if not isinstance(response, dict) or not bool(response.get("ok")):
        return False
    snapshot = response.get("state") or {}
    if not isinstance(snapshot, dict):
        return False
    status = dict(snapshot.get("sculpt_status") or {})
    if not str(status.get("mode") or "").strip():
        return False

    try:
        with _runtime.state_lock:
            _runtime.bridge_state = snapshot
            hc = snapshot.get("host_control") or {}
            generation = int(hc.get("generation", 0) or 0)
            if generation > 0:
                _runtime.lease_generation = generation
            _runtime._sync_local_from_snapshot(snapshot)
        _runtime.connected = True
        _initial_state_ready.set()
        return True
    except Exception:
        return False


def _apply_theme_follow_snapshot() -> bool:
    """Apply parent-authored semantic theme tokens at the Satellite frame boundary."""
    global _last_theme_signature
    if _runtime.imgui_context is None:
        return False
    try:
        with _runtime.state_lock:
            payload = dict((_runtime.bridge_state or {}).get("theme_follow") or {})
        signature, changed = _theme_wire.apply_payload(payload, _theme)
        if not signature:
            return False
        if not changed and signature == _last_theme_signature:
            return False

        _runtime.imgui.set_current_context(_runtime.imgui_context)
        _runtime.apply_style(_runtime.imgui, _runtime.current_scale)
        if _runtime.renderer is not None:
            _runtime.renderer.clear_linear_rgb = tuple(_theme.SURFACE_0[:3])
        _last_theme_signature = signature
        return True
    except Exception:
        return False


def _draw_frame_with_popup_dismiss():
    global _preflight_visible
    _inject_internal_popup_outside_click()
    _apply_theme_follow_snapshot()
    _mirror_quick_shortcut_selection()

    if (
        not _preflight_visible
        and _runtime.hwnd_main
        and _runtime.renderer is not None
        and not _runtime.closing_event.is_set()
    ):
        try:
            _runtime.user32.ShowWindow(_runtime.hwnd_main, _runtime.SW_SHOWNOACTIVATE)
            _runtime.user32.UpdateWindow(_runtime.hwnd_main)
            _preflight_visible = True
        except Exception:
            _preflight_visible = False

    state_ready_before_draw = _initial_state_ready.is_set()
    result = _original_draw_frame()
    _sync_target_slot_to_secondary()
    _sync_shortcut_focus_policy()
    _restore_blender_foreground_if_satellite_activated()

    if (
        state_ready_before_draw
        and _preflight_visible
        and _runtime.hwnd_main
        and _runtime.renderer is not None
        and not _runtime.closing_event.is_set()
        and _show_visible_ready_window()
    ):
        _first_render_ready.set()
    return result


def _network_worker_after_first_render():
    # One preflight snapshot is required before visible-ready.
    # After satellite_ready, Blender grants the Satellite lease asynchronously.
    # Keep a short startup-only reconcile phase until the child observes that
    # grant; normal Satellite idle remains fully event-driven afterwards.
    awaiting_grant = False
    failures = 0
    while not _runtime.closing_event.is_set() and not _initial_state_ready.is_set():
        if not _runtime.parent_alive():
            return
        try:
            response = _runtime.request({"action": "get_state"})
            if not _apply_preflight_state(response):
                raise RuntimeError("Satellite preflight state is incomplete")
            break
        except Exception:
            failures += 1
            _runtime.connected = False
            _runtime.time.sleep(min(0.04 * failures, 0.25))

    while not _runtime.closing_event.is_set() and not _first_render_ready.wait(0.02):
        if not _runtime.parent_alive():
            return
    if _runtime.closing_event.is_set():
        return

    # After ready, commands remain event-driven through Queue.get. Idle get_state
    # is only a 10 Hz watchdog; it is not a source of correctness.
    failures = 0
    while not _runtime.closing_event.is_set():
        if not _runtime.parent_alive():
            if _runtime.hwnd_main:
                _runtime.user32.PostMessageW(_runtime.hwnd_main, _runtime.WM_CLOSE, 0, 0)
            return
        try:
            if not _runtime.ready_sent:
                response = _runtime.request({"action": "satellite_ready"})
                _runtime.ready_sent = bool(response.get("ok"))
                awaiting_grant = bool(_runtime.ready_sent)
            elif awaiting_grant:
                # Required handoff handshake only: satellite_ready is answered
                # while Blender still owns the DETACHING lease. The Blender-side
                # handoff timer grants SATELLITE immediately afterwards, so the
                # child must observe that one state transition before it can show
                # its hidden HWND. This is not an idle heartbeat.
                response = _runtime.request({"action": "get_state"})
            else:
                try:
                    action = _runtime.actions.get(timeout=0.25)
                except _runtime.queue.Empty:
                    # Idle Satellite never wakes Blender. Parent liveness stays
                    # local to this child process; state reconciliation is queued
                    # explicitly on Satellite re-entry above.
                    continue
                response = _runtime.request(action)
            if not response.get("ok"):
                raise RuntimeError(response.get("error") or "bridge request failed")
            snapshot = response.get("state")
            if isinstance(snapshot, dict) and snapshot:
                with _runtime.state_lock:
                    _runtime.bridge_state = snapshot
                    hc = snapshot.get("host_control") or {}
                    if hc.get("owner") == "satellite" and int(hc.get("generation", 0) or 0) > 0:
                        _runtime.lease_generation = int(hc.get("generation"))
                    _runtime._sync_local_from_snapshot(snapshot)
                    if bool(hc.get("satellite_active")) and hc.get("owner") == "satellite":
                        awaiting_grant = False
                        if not _runtime.visible and _runtime.hwnd_main:
                            _runtime.user32.PostMessageW(_runtime.hwnd_main, _runtime.WM_APP_SHOW, 0, 0)
            if awaiting_grant:
                # Blender's handoff timer normally grants within one or two
                # 20 ms ticks; keep this startup reconcile gentle.
                _runtime.time.sleep(0.02)
            _runtime.connected = True
            failures = 0
        except Exception:
            _runtime.connected = False
            failures += 1
            _runtime.time.sleep(min(0.04 * failures, 0.4))



def _sync_product_extras(snapshot):
    remote = dict(((snapshot.get("module_state") or {}).get("sculpt") or {}))
    now = _runtime.time.monotonic()

    if "input_profile" in remote and now >= float(_runtime.local_override_until.get("input_profile", 0.0)):
        value = str(remote.get("input_profile") or "").strip().casefold()
        _runtime.local_sculpt["input_profile"] = "zbrush" if value in {"zbrush", "z"} else "blender"

    for key in (
        "quick_shortcuts", "quick_shortcuts_status", "quick_hotkey_bindings", "quick_replace_slot",
        "primary_brush_preview_cache", "primary_alpha_preview_cache",
        "brush_library_status", "brush_library_scan_serial",
        "alpha_library_status", "alpha_library_scan_serial",
    ):
        if key in remote and now >= float(_runtime.local_override_until.get(key, 0.0)):
            _runtime.local_sculpt[key] = remote[key]


def _sync_local_from_snapshot(snapshot):
    _original_sync_local_from_snapshot(snapshot)
    _sync_product_extras(snapshot)


def _draw_sculpt_compact_with_more(*args, **kwargs):
    if _runtime.renderer is not None:
        _interactions.ensure_controls(_runtime.renderer)

    surface_state = args[1] if len(args) > 1 else kwargs.get("surface_state", _runtime.surface_state)

    def _open_product_secondary(kind, anchor=None):
        return _secondary_session.open_surface(_runtime, kind, anchor)

    def _open_more_secondary():
        anchor = dict(surface_state.get("sculpt_more_anchor") or {})
        _open_product_secondary("more", anchor)

    # Product controls express OPEN intent. The native runtime still owns child
    # process/HWND mechanics and outside/ESC dismissal; repeated open callbacks
    # must not route through toggle semantics and accidentally hide the surface.
    kwargs["on_open_brush_library"] = lambda anchor: _open_product_secondary("brush_library", anchor)
    kwargs["on_open_alpha_library"] = lambda anchor: _open_product_secondary("alpha_library", anchor)
    kwargs["on_more"] = _open_more_secondary
    kwargs.setdefault("on_refresh_brush_library", lambda: _runtime._queue_command("sculpt.brush.library_refresh"))
    kwargs.setdefault(
        "on_request_brush_preview",
        lambda identities: _runtime._queue_command("sculpt.brush.library_preview", identities=list(identities or ())),
    )
    return _original_draw_sculpt_compact(*args, **kwargs)


def _lazy_secondary_prewarm():
    # Do not spawn a second Python/WGL process automatically during Host handoff.
    # Product open-session policy performs non-blocking lazy launch and records
    # the user's pending open intent until the child HWND is ready.
    return None


_runtime.wndproc = _wndproc_with_shortcut_capture
_runtime._sync_local_from_snapshot = _sync_local_from_snapshot
_runtime.draw_sculpt_compact = _draw_sculpt_compact_with_more
_runtime._draw_frame = _draw_frame_with_popup_dismiss
_runtime._prewarm_secondary_surface = _lazy_secondary_prewarm
_runtime.network_worker = _network_worker_after_first_render


if __name__ == "__main__":
    _runtime.main()