from __future__ import annotations

"""Native Sculpt Mask tool bridge for LumaFold's ZBrush-style Ctrl session.

P4 deliberately removes per-stroke tool ownership. Ctrl itself owns the temporary
Mask session:

- Press Ctrl while a normal Sculpt tool is active -> remember that Sculpt tool and
  temporarily activate the last native Blender Mask tool.
- Keep Ctrl held -> the native Mask tool stays active across any number of mask
  gestures. Changing Box/Lasso/Line/Polyline in Blender's toolbar updates the one
  authoritative Mask selection for the same session.
- Release Ctrl -> restore the exact Sculpt tool that was active before Ctrl.
- Explicitly selecting a native Mask tool without a LumaFold Ctrl session remains
  entirely Blender-owned and is never auto-restored.

The bridge only switches WorkSpaceTool state at runtime. It never creates or
changes keymaps, preferences, startup files, or any other persistent Blender
configuration. Uninstall restores only a LumaFold-owned temporary session.
"""

import bpy


BOX_TOOL_ID = "builtin.box_mask"
LASSO_TOOL_ID = "builtin.lasso_mask"
LINE_TOOL_ID = "builtin.line_mask"
POLYLINE_TOOL_ID = "builtin.polyline_mask"

TOOL_TO_SHAPE = {
    BOX_TOOL_ID: "BOX",
    LASSO_TOOL_ID: "LASSO",
    LINE_TOOL_ID: "LINE",
    POLYLINE_TOOL_ID: "POLYLINE",
}
SHAPE_TO_TOOL = {shape: tool_id for tool_id, shape in TOOL_TO_SHAPE.items()}
MASK_TOOL_IDS = frozenset(TOOL_TO_SHAPE)

_POLL_INTERVAL = 0.10
_INSTALLED = False
_INPUT_CORE = None
_TRACE = None
_STATES = {}
_TIMER_RUNNING = False


def _trace(reason: str, **extra) -> None:
    if _TRACE is None:
        return
    try:
        _TRACE.trace("MASK_NATIVE_TOOL_BRIDGE", reason=str(reason), **extra)
    except Exception:
        pass


def _ptr(value) -> int:
    try:
        return int(value.as_pointer())
    except Exception:
        return 0


def _workspace(context=None):
    workspace = getattr(context, "workspace", None) if context is not None else None
    if workspace is None:
        try:
            workspace = bpy.context.workspace
        except Exception:
            workspace = None
    return workspace


def _state(workspace) -> dict:
    key = _ptr(workspace) or id(workspace)
    state = _STATES.get(key)
    if state is None:
        state = {
            "selected_mask_tool": BOX_TOOL_ID,
            "base_tool": "",
            "session_active": False,
            "session_tool": "",
            "restore_tool": "",
            "ctrl_held": False,
        }
        _STATES[key] = state
    return state


def _active_tool(workspace):
    if workspace is None:
        return None
    try:
        return workspace.tools.from_space_view3d_mode("SCULPT", create=False)
    except Exception:
        return None


def _active_tool_id(workspace) -> str:
    tool = _active_tool(workspace)
    try:
        return str(getattr(tool, "idname", "") or "")
    except Exception:
        return ""


def _context_is_sculpt(context=None) -> bool:
    try:
        mode = str(getattr(context, "mode", "") or "") if context is not None else ""
        if not mode:
            mode = str(getattr(bpy.context, "mode", "") or "")
        return mode.upper() == "SCULPT"
    except Exception:
        return False


def _zbrush_product_active() -> bool:
    core = _INPUT_CORE
    if core is None:
        return False
    try:
        return bool(core._product_active() and core._profile() == "zbrush")
    except Exception:
        return False


def _view3d_target(context=None):
    window = getattr(context, "window", None) if context is not None else None
    area = getattr(context, "area", None) if context is not None else None
    region = getattr(context, "region", None) if context is not None else None

    if window is None:
        try:
            window = bpy.context.window
        except Exception:
            window = None
    if window is None:
        return None

    if area is None or getattr(area, "type", "") != "VIEW_3D":
        screen = getattr(window, "screen", None)
        area = next(
            (
                item
                for item in tuple(getattr(screen, "areas", ()) or ())
                if getattr(item, "type", "") == "VIEW_3D"
            ),
            None,
        )
    if area is None:
        return None

    if region is None or getattr(region, "type", "") != "WINDOW":
        region = next(
            (
                item
                for item in tuple(getattr(area, "regions", ()) or ())
                if getattr(item, "type", "") == "WINDOW"
            ),
            None,
        )
    if region is None:
        return None
    return window, area, region


def _set_tool(context, tool_id: str) -> bool:
    """Switch one native View3D tool for this runtime session only."""
    tool_id = str(tool_id or "")
    if not tool_id:
        return False
    target = _view3d_target(context)
    if target is None:
        return False
    window, area, region = target
    try:
        with bpy.context.temp_override(window=window, area=area, region=region):
            result = set(
                bpy.ops.wm.tool_set_by_id(
                    "EXEC_DEFAULT",
                    name=tool_id,
                    space_type="VIEW_3D",
                )
                or ()
            )
        return "FINISHED" in result
    except (RuntimeError, TypeError, AttributeError):
        return False


def _record_mask(state: dict, tool_id: str, *, reason: str) -> None:
    tool_id = str(tool_id or "")
    if tool_id not in MASK_TOOL_IDS:
        return
    previous = str(state.get("selected_mask_tool") or "")
    state["selected_mask_tool"] = tool_id
    if tool_id != previous:
        _trace(
            reason,
            tool=tool_id,
            shape=str(TOOL_TO_SHAPE.get(tool_id, "BOX")),
            previous_tool=previous,
        )


def _clear_session(state: dict) -> None:
    state["session_active"] = False
    state["session_tool"] = ""
    state["restore_tool"] = ""


def _observe_native_tool(context=None) -> str:
    """Synchronize the one Mask selection without fighting explicit Blender use."""
    workspace = _workspace(context)
    if workspace is None:
        return ""
    state = _state(workspace)
    active_id = _active_tool_id(workspace)

    if state.get("session_active"):
        session_tool = str(state.get("session_tool") or "")
        if active_id == session_tool:
            return active_id

        # While Ctrl owns the session, switching among native Mask tools changes
        # the session shape but never ends the session or loses the restore tool.
        if bool(state.get("ctrl_held")) and active_id in MASK_TOOL_IDS:
            _record_mask(state, active_id, reason="ctrl_mask_shape_changed")
            state["session_tool"] = active_id
            _trace(
                "ctrl_mask_session_tool_changed",
                previous_tool=session_tool,
                tool=active_id,
                restore_tool=str(state.get("restore_tool") or ""),
            )
            return active_id

        # Any non-Mask explicit choice while Ctrl is held is respected. We give
        # up ownership rather than forcing an older tool back over the user.
        _trace(
            "ctrl_mask_session_relinquished",
            session_tool=session_tool,
            active_tool=active_id,
        )
        _clear_session(state)

    if active_id in MASK_TOOL_IDS:
        _record_mask(state, active_id, reason="explicit_native_mask_selected")
        return active_id

    if active_id:
        state["base_tool"] = active_id
    return active_id


def explicit_native_mask_active(context=None) -> bool:
    """True only for a user-owned native Mask tool outside a Ctrl session."""
    workspace = _workspace(context)
    if workspace is None:
        return False
    active_id = _observe_native_tool(context)
    state = _state(workspace)
    return bool(active_id in MASK_TOOL_IDS and not state.get("session_active"))


def ctrl_session_active(context=None) -> bool:
    workspace = _workspace(context)
    return bool(workspace is not None and _state(workspace).get("session_active"))


def current_tool(context=None) -> str:
    """Return the single native Mask tool shared by toolbar and Ctrl session."""
    workspace = _workspace(context)
    if workspace is None:
        return BOX_TOOL_ID
    if _zbrush_product_active() and _context_is_sculpt(context):
        _observe_native_tool(context)
    state = _state(workspace)
    if state.get("session_active"):
        tool_id = str(state.get("session_tool") or "")
        if tool_id in MASK_TOOL_IDS:
            return tool_id
    tool_id = str(state.get("selected_mask_tool") or BOX_TOOL_ID)
    return tool_id if tool_id in MASK_TOOL_IDS else BOX_TOOL_ID


def current_shape(context=None) -> str:
    return str(TOOL_TO_SHAPE.get(current_tool(context), "BOX"))


def session_begin(context=None) -> dict:
    """Enter the temporary Mask tool family; Ctrl owns the whole session."""
    workspace = _workspace(context)
    if workspace is None:
        return {
            "shape": "BOX",
            "tool_id": BOX_TOOL_ID,
            "session_active": False,
            "passthrough": False,
        }

    state = _state(workspace)
    active_id = _observe_native_tool(context)

    if state.get("session_active"):
        tool_id = current_tool(context)
        return {
            "shape": str(TOOL_TO_SHAPE.get(tool_id, "BOX")),
            "tool_id": tool_id,
            "session_active": True,
            "passthrough": False,
        }

    if active_id in MASK_TOOL_IDS:
        # The user explicitly selected a Mask tool before Ctrl. Blender owns it;
        # LumaFold must not invent a restore target for that explicit choice.
        _record_mask(state, active_id, reason="explicit_native_mask_selected")
        return {
            "shape": str(TOOL_TO_SHAPE.get(active_id, "BOX")),
            "tool_id": active_id,
            "session_active": False,
            "passthrough": True,
        }

    mask_tool = str(state.get("selected_mask_tool") or BOX_TOOL_ID)
    if mask_tool not in MASK_TOOL_IDS:
        mask_tool = BOX_TOOL_ID

    restore_tool = active_id or str(state.get("base_tool") or "")
    if active_id:
        state["base_tool"] = active_id

    if not (
        _zbrush_product_active()
        and _context_is_sculpt(context)
        and restore_tool
        and _set_tool(context, mask_tool)
    ):
        return {
            "shape": str(TOOL_TO_SHAPE.get(mask_tool, "BOX")),
            "tool_id": mask_tool,
            "session_active": False,
            "passthrough": False,
        }

    state["session_active"] = True
    state["session_tool"] = mask_tool
    state["restore_tool"] = restore_tool
    _trace(
        "ctrl_mask_session_started",
        tool=mask_tool,
        shape=str(TOOL_TO_SHAPE.get(mask_tool, "BOX")),
        restore_tool=restore_tool,
    )
    return {
        "shape": str(TOOL_TO_SHAPE.get(mask_tool, "BOX")),
        "tool_id": mask_tool,
        "session_active": True,
        "passthrough": False,
    }


def session_end(context=None, *, force: bool = False) -> None:
    """Leave the Ctrl Mask session and restore only LumaFold-owned tool state."""
    workspace = _workspace(context)
    if workspace is None:
        return
    state = _state(workspace)
    if not state.get("session_active"):
        return
    if bool(state.get("ctrl_held")) and not force:
        return

    # Absorb a final toolbar shape change before restoration.
    _observe_native_tool(context)
    if not state.get("session_active"):
        return

    session_tool = str(state.get("session_tool") or "")
    restore_tool = str(state.get("restore_tool") or state.get("base_tool") or "")
    active_id = _active_tool_id(workspace)

    if active_id == session_tool and restore_tool and restore_tool not in MASK_TOOL_IDS:
        if _set_tool(context, restore_tool):
            _trace(
                "ctrl_mask_session_restored",
                tool=restore_tool,
                mask_tool=session_tool,
                selected_mask_tool=str(state.get("selected_mask_tool") or BOX_TOOL_ID),
            )
    elif active_id != session_tool:
        _trace(
            "ctrl_mask_session_restore_skipped_external_change",
            session_tool=session_tool,
            active_tool=active_id,
        )

    _clear_session(state)


# Compatibility name used by the gesture owner. In P4 a gesture never owns
# restoration; the keyboard Ctrl session does.
def cancel_shortcut_session(context=None) -> None:
    """Cancel only LumaFold-owned Ctrl Mask state before a Ctrl keyboard shortcut."""
    workspace = _workspace(context)
    if workspace is None:
        return
    state = _state(workspace)
    was_active = bool(state.get("session_active"))
    session_tool = str(state.get("session_tool") or "")
    restore_tool = str(state.get("restore_tool") or state.get("base_tool") or "")
    state["ctrl_held"] = False
    session_end(context, force=True)
    _trace(
        "ctrl_mask_session_cancelled_shortcut",
        was_active=was_active,
        mask_tool=session_tool,
        restore_tool=restore_tool,
        active_tool=_active_tool_id(workspace),
    )


def surface_brush_handoff_begin(context=None) -> bool:
    """Expose the saved brush WorkSpaceTool for native Mask brush poll.

    Event.ctrl is authoritative here. Satellite focus handoff can miss the
    standalone Ctrl keydown event before the first pen press, so this path
    repairs the temporary Mask session synchronously on that first LMB.
    """
    workspace = _workspace(context)
    if workspace is None:
        return False
    state = _state(workspace)
    state["ctrl_held"] = True

    if not state.get("session_active"):
        info = session_begin(context)
        state = _state(workspace)
        if not bool(info.get("session_active")) or not state.get("session_active"):
            _trace(
                "ctrl_mask_surface_self_heal_failed",
                active_tool=_active_tool_id(workspace),
                base_tool=str(state.get("base_tool") or ""),
            )
            return False
        _trace(
            "ctrl_mask_surface_self_healed",
            mask_tool=str(state.get("session_tool") or ""),
            restore_tool=str(state.get("restore_tool") or ""),
        )

    restore_tool = str(state.get("restore_tool") or state.get("base_tool") or "")
    if not restore_tool or restore_tool in MASK_TOOL_IDS:
        return False
    active_id = _active_tool_id(workspace)
    if active_id == restore_tool:
        return True
    if _set_tool(context, restore_tool):
        _trace(
            "ctrl_mask_surface_brush_handoff_begin",
            tool=restore_tool,
            mask_tool=str(state.get("session_tool") or ""),
        )
        return True
    _trace(
        "ctrl_mask_surface_brush_handoff_failed",
        tool=restore_tool,
        mask_tool=str(state.get("session_tool") or ""),
    )
    return False



def surface_brush_handoff_end(context=None) -> bool:
    """Restore the temporary native Mask tool while Ctrl still owns the session."""
    workspace = _workspace(context)
    if workspace is None:
        return False
    state = _state(workspace)
    if not state.get("session_active") or not bool(state.get("ctrl_held")):
        return False
    mask_tool = str(state.get("session_tool") or state.get("selected_mask_tool") or BOX_TOOL_ID)
    if mask_tool not in MASK_TOOL_IDS:
        mask_tool = BOX_TOOL_ID
    if _active_tool_id(workspace) == mask_tool:
        return True
    if _set_tool(context, mask_tool):
        _trace("ctrl_mask_surface_brush_handoff_end", tool=mask_tool)
        return True
    _trace("ctrl_mask_surface_brush_restore_failed", tool=mask_tool)
    return False


def ctrl_session_ensure(context=None) -> dict:
    """Repair Ctrl-session truth from a live Ctrl+LMB event.

    Satellite is non-activating by design, so Windows can occasionally
    omit the standalone Ctrl keydown before the first pen press. The
    pointer event still carries Ctrl truth; use it as the authoritative
    session repair signal.
    """
    workspace = _workspace(context)
    if workspace is None:
        return {"session_active": False, "tool_id": BOX_TOOL_ID}
    state = _state(workspace)
    state["ctrl_held"] = True
    if not state.get("session_active"):
        info = session_begin(context)
    else:
        tool_id = current_tool(context)
        info = {
            "shape": str(TOOL_TO_SHAPE.get(tool_id, "BOX")),
            "tool_id": tool_id,
            "session_active": True,
            "passthrough": False,
        }
    _trace(
        "ctrl_mask_session_ensured_from_pointer",
        active=bool(info.get("session_active")),
        tool=str(info.get("tool_id") or ""),
    )
    return dict(info or {})


def gesture_begin(context=None) -> dict:
    if ctrl_session_active(context):
        tool_id = current_tool(context)
        return {
            "shape": str(TOOL_TO_SHAPE.get(tool_id, "BOX")),
            "tool_id": tool_id,
            "session_active": True,
            "passthrough": False,
        }
    return session_begin(context)


def gesture_end(context=None) -> None:
    # Deliberate no-op while Ctrl is held. Per-stroke completion must never
    # return the toolbar to Brush; Ctrl release owns that transition.
    session_end(context, force=False)


def gesture_finish(context=None) -> None:
    gesture_end(context)


def observe_event(context, event) -> None:
    """Passive route observer; Ctrl press/release owns the Mask session lifetime."""
    workspace = _workspace(context)
    state = _state(workspace) if workspace is not None else None
    event_type = str(getattr(event, "type", "") or "").upper()
    event_value = str(getattr(event, "value", "") or "").upper()

    if not _zbrush_product_active() or not _context_is_sculpt(context):
        if state is not None:
            state["ctrl_held"] = False
        session_end(context, force=True)
        return

    if state is not None and event_type in {"LEFT_CTRL", "RIGHT_CTRL"}:
        if event_value == "PRESS":
            state["ctrl_held"] = True
            session_begin(context)
            return
        if event_value == "RELEASE":
            state["ctrl_held"] = False
            session_end(context, force=False)
            return

    if event_type == "WINDOW_DEACTIVATE":
        if state is not None:
            state["ctrl_held"] = False
        session_end(context, force=True)
        return

    _observe_native_tool(context)


def _poll_native_tool():
    if not _TIMER_RUNNING:
        return None
    try:
        context = bpy.context
        if _zbrush_product_active() and _context_is_sculpt(context):
            _observe_native_tool(context)
        else:
            workspace = _workspace(context)
            if workspace is not None:
                _state(workspace)["ctrl_held"] = False
            session_end(context, force=True)
    except Exception:
        pass
    return _POLL_INTERVAL


def snapshot(context=None) -> dict:
    workspace = _workspace(context)
    if workspace is None:
        return {
            "installed": bool(_INSTALLED),
            "shape": "BOX",
            "selected_mask_tool": BOX_TOOL_ID,
            "session_active": False,
            "ctrl_held": False,
        }
    state = dict(_state(workspace))
    state["installed"] = bool(_INSTALLED)
    state["active_tool"] = _active_tool_id(workspace)
    state["shape"] = str(TOOL_TO_SHAPE.get(current_tool(context), "BOX"))
    state["explicit_mask"] = bool(
        state["active_tool"] in MASK_TOOL_IDS and not state.get("session_active")
    )
    return state


def install(sculpt_input_core, real_machine_trace=None) -> None:
    global _INSTALLED, _INPUT_CORE, _TRACE, _TIMER_RUNNING
    if _INSTALLED:
        return
    _INPUT_CORE = sculpt_input_core
    _TRACE = real_machine_trace
    _INSTALLED = True

    try:
        if _context_is_sculpt(bpy.context):
            _observe_native_tool(bpy.context)
    except Exception:
        pass

    _TIMER_RUNNING = True
    try:
        if not bpy.app.timers.is_registered(_poll_native_tool):
            bpy.app.timers.register(_poll_native_tool, first_interval=0.10, persistent=False)
    except Exception:
        pass


def uninstall() -> None:
    """Restore an owned Ctrl session and leave all explicit Blender choices alone."""
    global _INSTALLED, _INPUT_CORE, _TRACE, _TIMER_RUNNING
    _TIMER_RUNNING = False
    try:
        if bpy.app.timers.is_registered(_poll_native_tool):
            bpy.app.timers.unregister(_poll_native_tool)
    except Exception:
        pass

    try:
        windows = tuple(bpy.context.window_manager.windows)
    except Exception:
        windows = ()

    for window in windows:
        workspace = getattr(window, "workspace", None)
        if workspace is None:
            continue
        state = _state(workspace)
        state["ctrl_held"] = False
        if not state.get("session_active"):
            continue
        try:
            area = next(
                (
                    item
                    for item in tuple(getattr(window.screen, "areas", ()) or ())
                    if getattr(item, "type", "") == "VIEW_3D"
                ),
                None,
            )
            region = (
                next(
                    (
                        item
                        for item in tuple(getattr(area, "regions", ()) or ())
                        if getattr(item, "type", "") == "WINDOW"
                    ),
                    None,
                )
                if area is not None
                else None
            )
            if area is not None and region is not None:
                with bpy.context.temp_override(window=window, area=area, region=region):
                    session_end(bpy.context, force=True)
        except Exception:
            pass

    _STATES.clear()
    _INPUT_CORE = None
    _TRACE = None
    _INSTALLED = False
