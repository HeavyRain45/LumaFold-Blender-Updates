from __future__ import annotations

import ctypes
from ctypes import wintypes

"""Event-context authority for Sculpt input routing.

The universal broker receives Blender's live modal ``context``. Route truth
comes from that context, never from global ``bpy.context`` during Host migration.

Plain LMB ownership is resolved by Blender itself before any LumaFold transient:
- Blender Sculpt ``brush_stroke(ignore_background_click=True)`` owns surface hits;
- only Blender's explicit PASS_THROUGH may promote the press to native Rotate;
- CANCELLED/errors fail closed and never become Rotate.

ZBrush-specific modifier gestures are delegated to isolated gesture modules.
Ctrl+Shift LMB is owned by the visibility route bridge before the Ctrl mask
owner. Ctrl/Ctrl+Alt LMB remains fully owned by the mask gesture module only
while a normal Sculpt tool is active. Explicit Blender Mask tools pass through.
"""

_INSTALLED = False
_BASE = None
_TRACE = None
_NATIVE_POINTER = None
_ALT_GESTURE = None
_MASK_GESTURE = None
_VISIBILITY_ROUTE = None
_MASK_TOOL_BRIDGE = None
_SATELLITE_BRIDGE = None
_UNDO_SESSION_QUEUE = []
_UNDO_SESSION_WORKER_RUNNING = False


def _trace(reason: str, context, event, **extra):
    if _TRACE is None:
        return
    try:
        payload = {
            "reason": str(reason),
            "event": str(getattr(event, "type", "") or ""),
            "value": str(getattr(event, "value", "") or "").upper(),
            "mode": str(getattr(context, "mode", "") or ""),
            "area_type": str(getattr(getattr(context, "area", None), "type", "") or ""),
            "region_type": str(getattr(getattr(context, "region", None), "type", "") or ""),
        }
        payload.update(extra)
        _TRACE.trace("SCULPT_ROUTE_DECISION", **payload)
    except Exception:
        pass


def _undo_diagnostic_snapshot(context=None) -> dict:
    """Read Blender's public Undo RNA and current Sculpt tool without mutating state."""
    base = _BASE
    if base is None:
        return {"available": False, "detail": "no-base"}

    live_context = context
    if live_context is None:
        try:
            live_context = base.bpy.context
        except Exception:
            live_context = None

    mode = ""
    active_tool = ""
    try:
        mode = str(getattr(live_context, "mode", "") or "")
    except Exception:
        pass

    workspace = getattr(live_context, "workspace", None) if live_context is not None else None
    if workspace is None:
        try:
            workspace = base.bpy.context.workspace
        except Exception:
            workspace = None
    if workspace is not None:
        try:
            tool = workspace.tools.from_space_view3d_mode("SCULPT", create=False)
            active_tool = str(getattr(tool, "idname", "") or "")
        except Exception:
            active_tool = ""

    mode_snapshot = {}
    try:
        app = getattr(base, "_APP", None)
        services = getattr(app, "services", None) if app is not None else None
        service = services.get("blender.mode") if services is not None else None
        if service is not None:
            mode_snapshot = dict(service.snapshot() or {})
    except Exception:
        mode_snapshot = {}

    wm = getattr(live_context, "window_manager", None) if live_context is not None else None
    if wm is None:
        try:
            wm = base.bpy.context.window_manager
        except Exception:
            wm = None

    stack = getattr(wm, "undo_stack", None) if wm is not None else None
    if stack is None:
        return {
            "available": False,
            "mode": mode,
            "active_tool": active_tool,
            "last_boundary": str(mode_snapshot.get("last_boundary") or ""),
            "last_transition": str(mode_snapshot.get("last_transition") or ""),
            "last_tool_normalization": str(mode_snapshot.get("last_tool_normalization") or ""),
            "detail": "undo_stack_unavailable",
        }

    try:
        steps = tuple(getattr(stack, "steps", ()) or ())
        active_index = int(getattr(stack, "active_index", -1))
    except Exception as exc:
        return {
            "available": False,
            "mode": mode,
            "active_tool": active_tool,
            "last_boundary": str(mode_snapshot.get("last_boundary") or ""),
            "last_transition": str(mode_snapshot.get("last_transition") or ""),
            "last_tool_normalization": str(mode_snapshot.get("last_tool_normalization") or ""),
            "detail": f"undo_stack_read_failed:{type(exc).__name__}",
        }

    start = max(0, active_index - 4)
    end = min(len(steps), active_index + 3)
    recent = []
    for index in range(start, end):
        step = steps[index]
        try:
            name = str(getattr(step, "name", "") or "")
        except Exception:
            name = ""
        try:
            step_type = str(getattr(step, "type", "") or "")
        except Exception:
            step_type = ""
        try:
            substep = bool(getattr(step, "is_substep", False))
        except Exception:
            substep = False
        marker = "*" if index == active_index else ""
        recent.append(f"{marker}{index}:{name}[{step_type}]sub={int(substep)}")

    active_name = ""
    active_type = ""
    try:
        active = getattr(stack, "active", None)
        active_name = str(getattr(active, "name", "") or "") if active is not None else ""
        active_type = str(getattr(active, "type", "") or "") if active is not None else ""
    except Exception:
        pass

    return {
        "available": True,
        "mode": mode,
        "active_tool": active_tool,
        "active_index": active_index,
        "step_count": len(steps),
        "active_name": active_name,
        "active_type": active_type,
        "recent_steps": " || ".join(recent),
        "last_boundary": str(mode_snapshot.get("last_boundary") or ""),
        "last_transition": str(mode_snapshot.get("last_transition") or ""),
        "last_tool_normalization": str(mode_snapshot.get("last_tool_normalization") or ""),
    }


def _queue_sculpt_session_undo(context) -> bool:
    """Serialize Ctrl+Z through Blender Undo and clamp at the LumaFold Sculpt boundary."""
    global _UNDO_SESSION_WORKER_RUNNING

    base = _BASE
    trace = _TRACE
    if base is None:
        return False

    obj = getattr(context, "sculpt_object", None)
    if obj is None:
        objects = getattr(getattr(context, "view_layer", None), "objects", None)
        obj = getattr(objects, "active", None) if objects is not None else None
    same_object_name = str(getattr(obj, "name", "") or "")
    if not same_object_name:
        return False

    request = {
        "same_object_name": same_object_name,
        "window": getattr(context, "window", None),
        "area": getattr(context, "area", None),
        "region": getattr(context, "region", None),
    }
    _UNDO_SESSION_QUEUE.append(request)
    if trace is not None:
        trace.trace(
            "SCULPT_UNDO_DIAGNOSTIC",
            reason="undo_session_queued",
            same_object_name=same_object_name,
            queue_depth=len(_UNDO_SESSION_QUEUE),
        )

    if _UNDO_SESSION_WORKER_RUNNING:
        return True
    _UNDO_SESSION_WORKER_RUNNING = True

    def call_history_operator(op_name: str, item: dict):
        op = getattr(base.bpy.ops.ed, op_name)
        window = item.get("window")
        area = item.get("area")
        region = item.get("region")
        override = {}
        if window is not None:
            override["window"] = window
        if area is not None:
            override["area"] = area
        if region is not None:
            override["region"] = region
        try:
            if override:
                with base.bpy.context.temp_override(**override):
                    return set(op("EXEC_DEFAULT") or ())
            return set(op("EXEC_DEFAULT") or ())
        except (RuntimeError, TypeError, AttributeError):
            try:
                return set(op("EXEC_DEFAULT") or ())
            except Exception:
                return set()

    def active_truth():
        live = base.bpy.context
        mode = str(getattr(live, "mode", "") or "").upper()
        objects = getattr(getattr(live, "view_layer", None), "objects", None)
        active = getattr(objects, "active", None) if objects is not None else None
        return (
            mode,
            str(getattr(active, "name", "") or "") if active is not None else "",
            str(getattr(active, "type", "") or "") if active is not None else "",
        )

    def worker():
        global _UNDO_SESSION_WORKER_RUNNING
        try:
            if not _UNDO_SESSION_QUEUE:
                _UNDO_SESSION_WORKER_RUNNING = False
                return None
            if not base._product_active():
                _UNDO_SESSION_QUEUE.clear()
                _UNDO_SESSION_WORKER_RUNNING = False
                return None

            item = _UNDO_SESSION_QUEUE.pop(0)
            expected_name = str(item.get("same_object_name") or "")

            before_mode, before_name, before_type = active_truth()
            if (
                before_mode != "SCULPT"
                or before_type != "MESH"
                or before_name != expected_name
            ):
                if trace is not None:
                    trace.trace(
                        "SCULPT_UNDO_DIAGNOSTIC",
                        reason="undo_session_cancelled_before_step",
                        detail="session_context_changed",
                        same_object_name=expected_name,
                        mode=before_mode,
                        active_object_name=before_name,
                        queue_depth=len(_UNDO_SESSION_QUEUE),
                    )
                _UNDO_SESSION_QUEUE.clear()
                _UNDO_SESSION_WORKER_RUNNING = False
                return None

            undo_result = call_history_operator("undo", item)
            after_mode, after_name, after_type = active_truth()
            crossed_boundary = (
                after_mode != "SCULPT"
                or after_type != "MESH"
                or after_name != expected_name
            )

            if not crossed_boundary:
                if trace is not None:
                    trace.trace(
                        "SCULPT_UNDO_DIAGNOSTIC",
                        reason="undo_session_step_finished",
                        detail="native_undo_stayed_in_sculpt",
                        same_object_name=expected_name,
                        mode=after_mode,
                        active_object_name=after_name,
                        result=sorted(undo_result),
                        queue_depth=len(_UNDO_SESSION_QUEUE),
                    )
            else:
                if trace is not None:
                    trace.trace(
                        "SCULPT_UNDO_DIAGNOSTIC",
                        reason="undo_session_boundary_detected",
                        detail="native_undo_crossed_sculpt_session",
                        same_object_name=expected_name,
                        mode=after_mode,
                        active_object_name=after_name,
                        result=sorted(undo_result),
                        queue_depth=len(_UNDO_SESSION_QUEUE),
                    )

                redo_result = call_history_operator("redo", item)
                redo_mode, redo_name, redo_type = active_truth()

                if (
                    redo_type == "MESH"
                    and redo_name == expected_name
                    and redo_mode != "SCULPT"
                ):
                    try:
                        app = getattr(base, "_APP", None)
                        services = getattr(app, "services", None) if app is not None else None
                        mode_service = services.get("blender.mode") if services is not None else None
                        if mode_service is not None:
                            mode_service.set_mode("SCULPT", sculpt_entry_undo=False)
                    except Exception:
                        pass
                    redo_mode, redo_name, redo_type = active_truth()

                if trace is not None:
                    trace.trace(
                        "SCULPT_UNDO_DIAGNOSTIC",
                        reason="undo_session_boundary_redone",
                        detail="cross_session_undo_clamped",
                        same_object_name=expected_name,
                        mode=redo_mode,
                        active_object_name=redo_name,
                        result=sorted(redo_result),
                        queue_depth=len(_UNDO_SESSION_QUEUE),
                    )

                # Any repeat requests already queued are beyond the same session
                # boundary. Swallow them instead of walking Object-mode history.
                _UNDO_SESSION_QUEUE.clear()

            if _UNDO_SESSION_QUEUE:
                return 0.0
            _UNDO_SESSION_WORKER_RUNNING = False
            return None
        except Exception as exc:
            _UNDO_SESSION_QUEUE.clear()
            _UNDO_SESSION_WORKER_RUNNING = False
            if trace is not None:
                try:
                    trace.trace(
                        "SCULPT_UNDO_DIAGNOSTIC",
                        reason="undo_session_worker_error",
                        detail=f"{type(exc).__name__}:{exc}",
                    )
                except Exception:
                    pass
            return None

    try:
        base.bpy.app.timers.register(worker, first_interval=0.0)
        return True
    except Exception:
        _UNDO_SESSION_QUEUE.clear()
        _UNDO_SESSION_WORKER_RUNNING = False
        return False


def _schedule_post_undo_diagnostic() -> None:
    """Observe the result on the next timer tick; never intercept or repair Undo."""
    base = _BASE
    trace = _TRACE
    if base is None or trace is None:
        return

    def emit():
        try:
            payload = _undo_diagnostic_snapshot(None)
            trace.trace("SCULPT_UNDO_DIAGNOSTIC", reason="after_ctrl_z", **payload)
        except Exception:
            pass
        return None

    try:
        base.bpy.app.timers.register(emit, first_interval=0.03)
    except Exception:
        pass


def _context_sculpt_truth(base, context) -> bool:
    try:
        if str(getattr(context, "mode", "") or "").upper() != "SCULPT":
            return False
        obj = getattr(context, "sculpt_object", None)
        if obj is None:
            objects = getattr(getattr(context, "view_layer", None), "objects", None)
            obj = getattr(objects, "active", None) if objects is not None else None
        return bool(obj is not None and getattr(obj, "type", "") == "MESH")
    except Exception:
        return False


def _observe_mask_tool(context, event):
    bridge = _MASK_TOOL_BRIDGE
    if bridge is None:
        return
    observer = getattr(bridge, "observe_event", None)
    if callable(observer):
        try:
            observer(context, event)
        except Exception:
            pass


def _cancel_mask_shortcut_session(context) -> None:
    bridge = _MASK_TOOL_BRIDGE
    cancel = getattr(bridge, "cancel_shortcut_session", None) if bridge is not None else None
    if not callable(cancel):
        return
    try:
        cancel(context)
    except Exception:
        pass


def _explicit_native_mask_active(context) -> bool:
    bridge = _MASK_TOOL_BRIDGE
    if bridge is None:
        return False
    checker = getattr(bridge, "explicit_native_mask_active", None)
    if not callable(checker):
        return False
    try:
        return bool(checker(context))
    except Exception:
        return False


def _observe_visibility_tool(context, event):
    bridge = _VISIBILITY_TOOL_BRIDGE
    if bridge is None:
        return
    observer = getattr(bridge, "observe_event", None)
    if callable(observer):
        try:
            observer(context, event)
        except Exception:
            pass


def _visibility_native_session_active(context) -> bool:
    bridge = _VISIBILITY_TOOL_BRIDGE
    checker = getattr(bridge, "ctrl_shift_session_active", None) if bridge is not None else None
    if not callable(checker):
        return False
    try:
        return bool(checker(context))
    except Exception:
        return False


def _visibility_tool_family(context) -> str:
    bridge = _VISIBILITY_TOOL_BRIDGE
    getter = getattr(bridge, "current_family", None) if bridge is not None else None
    if not callable(getter):
        return ""
    try:
        return str(getter(context) or "")
    except Exception:
        return ""


def _visibility_current_tool(context) -> str:
    bridge = _VISIBILITY_TOOL_BRIDGE
    getter = getattr(bridge, "current_tool", None) if bridge is not None else None
    if not callable(getter):
        return ""
    try:
        return str(getter(context) or "")
    except Exception:
        return ""


def _explicit_native_visibility_tool_active(context) -> bool:
    bridge = _VISIBILITY_TOOL_BRIDGE
    checker = getattr(bridge, "explicit_native_tool_active", None) if bridge is not None else None
    if not callable(checker):
        return False
    try:
        return bool(checker(context))
    except Exception:
        return False


def _pointer_over_satellite_process() -> bool:
    bridge = _SATELLITE_BRIDGE
    base = _BASE
    if bridge is None or base is None:
        return False
    try:
        if str(base._host_mode() or "") != "satellite":
            return False
        proc = getattr(bridge, "satellite_process", None)
        pid = int(getattr(proc, "pid", 0) or 0)
        if pid <= 0 or proc.poll() is not None:
            return False

        class POINT(ctypes.Structure):
            _fields_ = [("x", wintypes.LONG), ("y", wintypes.LONG)]

        user32 = ctypes.WinDLL("user32", use_last_error=True)
        user32.GetCursorPos.argtypes = [ctypes.POINTER(POINT)]
        user32.GetCursorPos.restype = wintypes.BOOL
        user32.WindowFromPoint.argtypes = [POINT]
        user32.WindowFromPoint.restype = wintypes.HWND
        user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
        user32.GetWindowThreadProcessId.restype = wintypes.DWORD

        pt = POINT()
        if not user32.GetCursorPos(ctypes.byref(pt)):
            return False
        hwnd = user32.WindowFromPoint(pt)
        if not hwnd:
            return False
        owner_pid = wintypes.DWORD(0)
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(owner_pid))
        return int(owner_pid.value) == pid
    except Exception:
        return False


def _route_event_context_authority(context, event, *, host=None) -> bool:
    base = _BASE
    if base is None:
        return False

    event_type = str(getattr(event, "type", "") or "")
    event_value = str(getattr(event, "value", "") or "").upper()

    if event_type in {
        "LEFTMOUSE", "RIGHTMOUSE", "MIDDLEMOUSE",
        "WHEELUPMOUSE", "WHEELDOWNMOUSE",
    } and _pointer_over_satellite_process():
        _trace("satellite_pointer_guard", context, event)
        return True

    if event_type == "WINDOW_DEACTIVATE":
        _observe_visibility_tool(context, event)
        _observe_mask_tool(context, event)
        base._reset_transient_input(host)
        base._clear_gesture_registry()
        _trace("window_deactivate", context, event)
        return False

    base._note_alt(event)

    if not base._product_active():
        _trace("product_inactive", context, event)
        return False
    if base._shortcut_capture_active():
        _trace("shortcut_capture", context, event)
        return False
    if not _context_sculpt_truth(base, context):
        if event_type not in {"TIMER", "TIMER_REPORT", "MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}:
            _trace("context_not_sculpt", context, event)
        return False
    if bool(
        getattr(base.STATE, "capture_keyboard", False)
        or getattr(base.STATE, "capture_text", False)
    ):
        _trace("ui_keyboard_capture", context, event)
        return False

    if (
        event_type == "Z"
        and event_value == "PRESS"
        and bool(getattr(event, "ctrl", False))
        and not bool(getattr(event, "shift", False))
        and not bool(getattr(event, "alt", False))
    ):
        _cancel_mask_shortcut_session(context)
        try:
            payload = _undo_diagnostic_snapshot(context)
            if _TRACE is not None:
                _TRACE.trace("SCULPT_UNDO_DIAGNOSTIC", reason="before_ctrl_z", **payload)
        except Exception:
            pass
        handled = _queue_sculpt_session_undo(context)
        _trace(
            "ctrl_z_session_undo_queued" if handled else "ctrl_z_session_undo_queue_failed",
            context,
            event,
        )
        return True

    slot = base._quick_slot_for_event(event)
    if slot is not None:
        _trace("quick_slot", context, event, slot=int(slot))
        return base._activate_quick_slot(slot)

    if base._profile() != "zbrush":
        _trace("profile_not_zbrush", context, event, profile=base._profile())
        return False

    # Ctrl+Shift native Hide/Trim proof gets first chance to establish a
    # temporary WorkSpaceTool session. While it owns the chord, Blender's
    # active Box Hide / Box Trim tool receives the pointer directly.
    _observe_visibility_tool(context, event)
    if _visibility_native_session_active(context):
        if event_type == "LEFTMOUSE" and event_value == "PRESS":
            target = base._view3d_region_under_pointer(context, event)
            if target is not None and not (host is not None and base._pointer_over_host(host, event)):
                family = _visibility_tool_family(context)
                tool_id = _visibility_current_tool(context)

                if (
                    family == "HIDE"
                    and tool_id == "builtin.polyline_hide"
                    and _VISIBILITY_TOOL_BRIDGE is not None
                ):
                    continuation = getattr(
                        _VISIBILITY_TOOL_BRIDGE,
                        "policy_gesture_active",
                        None,
                    )
                    if callable(continuation) and continuation(context, tool_id=tool_id):
                        _trace(
                            "zbrush_visibility_polyline_policy_continue",
                            context,
                            event,
                            tool=tool_id,
                        )
                        return False

                if (
                    family == "HIDE"
                    and tool_id in {"builtin.box_hide", "builtin.lasso_hide", "builtin.line_hide", "builtin.polyline_hide"}
                    and _VISIBILITY_ROUTE is not None
                ):
                    handled = _VISIBILITY_ROUTE.handle_pointer_press(
                        context,
                        event,
                        target,
                        tool_id=tool_id,
                    )
                    if handled is not None:
                        if tool_id == "builtin.lasso_hide":
                            reason = (
                                "zbrush_visibility_lasso_policy"
                                if handled
                                else "zbrush_visibility_lasso_policy_failed"
                            )
                        elif tool_id == "builtin.line_hide":
                            reason = (
                                "zbrush_visibility_line_policy"
                                if handled
                                else "zbrush_visibility_line_policy_failed"
                            )
                        elif tool_id == "builtin.polyline_hide":
                            reason = (
                                "zbrush_visibility_polyline_policy"
                                if handled
                                else "zbrush_visibility_polyline_policy_failed"
                            )
                        else:
                            reason = (
                                "zbrush_visibility_box_policy"
                                if handled
                                else "zbrush_visibility_box_policy_failed"
                            )
                        _trace(
                            reason,
                            context,
                            event,
                            tool=tool_id,
                        )
                        return bool(handled)

                handoff = getattr(_VISIBILITY_TOOL_BRIDGE, "handle_pointer_press", None)
                if callable(handoff):
                    handled = handoff(context, event, target)
                    if handled is not None:
                        _trace(
                            "native_visibility_tool_gesture"
                            if handled
                            else "native_visibility_tool_gesture_failed",
                            context,
                            event,
                        )
                        return bool(handled)
        if event_type in base._POINTER_BUTTONS:
            _trace("native_visibility_tool_passthrough", context, event)
        return False

    # Explicitly selected Blender Box Hide / Box Trim tools remain Blender-owned
    # even outside a LumaFold Ctrl+Shift session.
    if _explicit_native_visibility_tool_active(context):
        _trace("explicit_native_visibility_tool_passthrough", context, event)
        return False

    # Observe Blender's native Mask toolbar state only when Ctrl+Shift does not
    # own the temporary native visibility session.
    _observe_mask_tool(context, event)

    # P1 explicit-tool rule: when the user intentionally selected Blender's
    # Box/Lasso/Line/Polyline Mask tool, Blender owns the entire interaction.
    # LumaFold only intercepts Ctrl masks while a normal Sculpt tool is active.
    if _explicit_native_mask_active(context):
        _trace("explicit_native_mask_passthrough", context, event)
        return False

    if event_value != "PRESS" or event_type not in base._POINTER_BUTTONS:
        return False

    target = base._view3d_region_under_pointer(context, event)
    if target is None:
        _trace("no_view3d_target", context, event)
        return False
    if host is not None and base._pointer_over_host(host, event):
        _trace("pointer_over_embedded_host", context, event)
        return False

    ctrl = bool(getattr(event, "ctrl", False))
    shift = bool(getattr(event, "shift", False))
    alt = bool(getattr(event, "alt", False))

    # LumaFold's universal modal route is ahead of Blender add-on keymaps, so
    # Ctrl+Shift SelectRect must be delegated here rather than hoping the
    # keymap sees the press later. This narrow bridge owns no other input.
    if event_type == "LEFTMOUSE" and ctrl and shift and _VISIBILITY_ROUTE is not None:
        handled = _VISIBILITY_ROUTE.handle_pointer_press(context, event, target)
        if handled is not None:
            _trace(
                "zbrush_visibility_gesture" if handled else "zbrush_visibility_gesture_failed",
                context,
                event,
            )
            return bool(handled)

    # One temporary Ctrl owner. The actual Box/Lasso tool id comes from the same
    # native-tool bridge that drives the temporary toolbar highlight.
    if event_type == "LEFTMOUSE" and ctrl and _MASK_GESTURE is not None:
        handled = _MASK_GESTURE.handle_pointer_press(context, event, target)
        if handled is not None:
            _trace(
                "zbrush_mask_gesture" if handled else "zbrush_mask_gesture_failed",
                context,
                event,
            )
            return bool(handled)

    # Alt-only left gestures use strict current-event Alt truth. Historical Alt
    # timestamps may not arm a new gesture.
    if event_type == "LEFTMOUSE" and alt and not ctrl and _ALT_GESTURE is not None:
        handled = _ALT_GESTURE.handle_pointer_press(context, event, target)
        if handled is not None:
            _trace(
                "zbrush_alt_gesture" if handled else "zbrush_alt_gesture_failed",
                context,
                event,
            )
            return bool(handled)

    if event_type == "LEFTMOUSE" and not ctrl and not alt and _NATIVE_POINTER is not None:
        outcome = _NATIVE_POINTER.arbitrate_plain_lmb(context, event, target)
        if outcome == _NATIVE_POINTER.SCULPT:
            _trace("blender_native_sculpt", context, event, pointer_owner=outcome)
            return True
        if outcome == _NATIVE_POINTER.ROTATE:
            _trace("blender_native_rotate", context, event, pointer_owner=outcome)
            return True
        _trace("blender_native_pointer_fallback", context, event, pointer_owner=outcome)
        return False

    navigation = getattr(base, "_native_navigation_handoff", None)
    if callable(navigation):
        nav_result = navigation(context, event, target, host=host)
        if nav_result is not None:
            _trace(
                "native_navigation_handoff" if nav_result else "native_navigation_failed",
                context,
                event,
                operator="VIEW3D_OT_rotate",
            )
            return bool(nav_result)

    # Legacy transient remains only for modifier RMB and other not-yet-migrated
    # gestures. Ctrl LMB no longer falls through here.
    operator_name = (
        "sculpt_z_left_runtime_v4"
        if event_type == "LEFTMOUSE"
        else "sculpt_z_right_runtime_v4"
    )
    ok = base._invoke_transient(operator_name, target)
    _trace(
        "transient_started" if ok else "transient_invoke_failed",
        context,
        event,
        operator=operator_name,
    )
    return bool(ok)


def install(
    sculpt_input_core,
    real_machine_trace=None,
    native_pointer=None,
    alt_gesture=None,
    mask_gesture=None,
    visibility_route=None,
    visibility_tool_bridge=None,
    mask_tool_bridge=None,
    satellite_bridge=None,
):
    global _INSTALLED, _BASE, _TRACE, _NATIVE_POINTER, _ALT_GESTURE, _MASK_GESTURE, _VISIBILITY_ROUTE, _VISIBILITY_TOOL_BRIDGE, _MASK_TOOL_BRIDGE, _SATELLITE_BRIDGE
    if _INSTALLED:
        return
    setter = getattr(sculpt_input_core, "set_route_handler", None)
    if not callable(setter):
        raise RuntimeError("Sculpt route handler slot is unavailable")
    if native_pointer is None:
        raise RuntimeError("Blender-native pointer arbiter is unavailable")
    if alt_gesture is None or mask_gesture is None:
        raise RuntimeError("ZBrush gesture dependencies are incomplete")
    _BASE = sculpt_input_core
    _TRACE = real_machine_trace
    _NATIVE_POINTER = native_pointer
    _ALT_GESTURE = alt_gesture
    _MASK_GESTURE = mask_gesture
    _VISIBILITY_ROUTE = visibility_route
    _VISIBILITY_TOOL_BRIDGE = visibility_tool_bridge
    _MASK_TOOL_BRIDGE = mask_tool_bridge
    _SATELLITE_BRIDGE = satellite_bridge
    setter(_route_event_context_authority)
    _INSTALLED = True


def uninstall():
    global _INSTALLED, _BASE, _TRACE, _NATIVE_POINTER, _ALT_GESTURE, _MASK_GESTURE, _VISIBILITY_ROUTE, _VISIBILITY_TOOL_BRIDGE, _MASK_TOOL_BRIDGE, _SATELLITE_BRIDGE, _UNDO_SESSION_WORKER_RUNNING
    if not _INSTALLED:
        return
    if _BASE is not None:
        setter = getattr(_BASE, "set_route_handler", None)
        if callable(setter):
            setter(None)
    _BASE = None
    _TRACE = None
    _NATIVE_POINTER = None
    _ALT_GESTURE = None
    _MASK_GESTURE = None
    _VISIBILITY_ROUTE = None
    _VISIBILITY_TOOL_BRIDGE = None
    _MASK_TOOL_BRIDGE = None
    _SATELLITE_BRIDGE = None
    _UNDO_SESSION_QUEUE.clear()
    _UNDO_SESSION_WORKER_RUNNING = False
    _INSTALLED = False
