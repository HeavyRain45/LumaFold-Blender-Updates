import bpy

from .core.state import STATE


def _draw_lumafold_header(self, context):
    """Single product entry for the manual-ZIP distribution phase."""
    row = self.layout.row(align=True)
    row.separator(factor=0.35)
    embedded_running = bool(
        getattr(STATE, "running", False)
        and str(getattr(STATE, "host_mode", "embedded") or "embedded").lower() == "embedded"
    )
    operator_id = "lumafold.close_embedded_host" if embedded_running else "lumafold.toggle_p0"
    row.operator(
        operator_id,
        text="LumaFold",
        icon='BRUSH_DATA',
        depress=bool(getattr(STATE, "running", False)),
    )


def _tag_view3d_headers_redraw():
    try:
        wm = bpy.context.window_manager
        for window in wm.windows:
            screen = window.screen
            if screen is None:
                continue
            for area in screen.areas:
                if area.type != 'VIEW_3D':
                    continue
                for region in area.regions:
                    if region.type == 'HEADER':
                        region.tag_redraw()
    except Exception:
        pass


def register():
    try:
        bpy.types.VIEW3D_HT_header.remove(_draw_lumafold_header)
    except Exception:
        pass
    try:
        bpy.types.VIEW3D_HT_header.append(_draw_lumafold_header)
    except Exception:
        pass
    _tag_view3d_headers_redraw()


def unregister():
    try:
        bpy.types.VIEW3D_HT_header.remove(_draw_lumafold_header)
    except Exception:
        pass
