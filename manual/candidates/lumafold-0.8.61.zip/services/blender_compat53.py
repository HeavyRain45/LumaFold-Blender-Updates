from __future__ import annotations

"""Blender 5.0+ compatibility bridge for Sculpt assets.

Keep version-specific RNA and data-file discovery out of product UI/modules.
The implementation is capability-driven where possible, with version-aware
fallbacks only for locating Blender's bundled Essentials asset file.
"""

from pathlib import Path

from .blender import BlenderAlphaService, BlenderBrushService
from .sculpt_settings import BlenderCapabilitiesService


class BlenderBrushServiceCompat(BlenderBrushService):
    """Brush bridge with version-neutral Essentials discovery."""

    @staticmethod
    def _essentials_sculpt_blend():
        import bpy

        candidates = []
        seen = set()

        def add(path):
            try:
                path = Path(path)
                key = str(path).casefold()
            except Exception:
                return
            if key in seen:
                return
            seen.add(key)
            candidates.append(path)

        # Preferred path: Blender tells us its active DATAFILES root. This is
        # stable across Blender 5.x and avoids hard-coding an installation version.
        try:
            datafiles = bpy.utils.system_resource('DATAFILES')
            if datafiles:
                add(Path(datafiles) / "assets" / "brushes" / "essentials_brushes-mesh_sculpt.blend")
        except Exception:
            pass

        # Portable/alternate layouts: derive the active major.minor at runtime.
        try:
            version = tuple(int(v) for v in tuple(getattr(bpy.app, "version", (0, 0, 0)))[:2])
            version_dir = f"{version[0]}.{version[1]}" if version[0] else ""
            binary = Path(bpy.app.binary_path).resolve()
            for parent in (binary.parent, binary.parent.parent):
                if version_dir:
                    add(parent / version_dir / "datafiles" / "assets" / "brushes" / "essentials_brushes-mesh_sculpt.blend")
                add(parent / "datafiles" / "assets" / "brushes" / "essentials_brushes-mesh_sculpt.blend")
        except Exception:
            pass

        # Last-resort compatibility probes. They do not select a version; they
        # only recover unusual portable layouts across supported Blender 5.x installs.
        try:
            binary = Path(bpy.app.binary_path).resolve()
            for parent in (binary.parent, binary.parent.parent):
                for version_dir in ("5.3", "5.2", "5.1", "5.0"):
                    add(parent / version_dir / "datafiles" / "assets" / "brushes" / "essentials_brushes-mesh_sculpt.blend")
        except Exception:
            pass

        for candidate in candidates:
            try:
                if candidate.is_file():
                    return candidate
            except Exception:
                continue
        return None


class BlenderAlphaServiceCompat(BlenderAlphaService):
    """Alpha index that preserves canonical source folders after image loading.

    S0.7.0 indexed Images already loaded in the .blend before registered Asset
    Library folders. Because identity is filepath-based, a library Alpha moved to
    "当前文件" after first use. This implementation scans canonical disk sources
    first, then merges Blender-loaded state into those records instead of moving
    them between folders.
    """

    def list_sculpt_alphas(self, max_files=512):
        import bpy

        records = []
        folders = []
        errors = []
        by_identity = {}
        folder_ids = set()

        def add_folder(folder_id, label, source, path, readonly=False):
            folder_id = str(folder_id or "")
            if not folder_id or folder_id in folder_ids:
                return
            folder_ids.add(folder_id)
            folders.append({
                "id": folder_id,
                "label": str(label or folder_id),
                "source": str(source or ""),
                "path": str(path or ""),
                "readonly": bool(readonly),
            })

        def add_record(*, name, identity, filepath="", image_name="", folder_id,
                       folder_label, source_label, readonly=False, loaded=False):
            identity = str(identity or "")
            if not identity:
                return None
            existing = by_identity.get(identity)
            if existing is not None:
                # Runtime-loaded state enriches the canonical disk record; it
                # never steals that record from its actual library/folder.
                if image_name:
                    existing["image_name"] = str(image_name)
                existing["loaded"] = bool(existing.get("loaded")) or bool(loaded)
                return existing
            item = {
                "name": str(name or "Alpha"),
                "identity": identity,
                "filepath": self._norm_path(filepath),
                "image_name": str(image_name or ""),
                "folder_id": str(folder_id),
                "folder_label": str(folder_label),
                "source_label": str(source_label),
                "readonly": bool(readonly),
                "loaded": bool(loaded),
            }
            records.append(item)
            by_identity[identity] = item
            return item

        # Built-in LumaFold test seed is a real image source and therefore gets
        # the same canonical-source treatment as user Asset Libraries.
        try:
            seed_root = Path(__file__).resolve().parent.parent / "assets" / "test_alphas"
            if seed_root.is_dir():
                seed_folder = "alpha|lumafold|test_seed"
                seed_files = sorted(
                    (p for p in seed_root.iterdir() if p.is_file() and p.suffix.casefold() in self.IMAGE_EXTS),
                    key=lambda p: p.name.casefold(),
                )
                if seed_files:
                    add_folder(seed_folder, "LumaFold 测试 Alpha", "LumaFold", str(seed_root), readonly=True)
                for path in seed_files:
                    add_record(
                        name=path.stem.replace("_", " "),
                        identity=self._identity_from_path(path),
                        filepath=str(path),
                        folder_id=seed_folder,
                        folder_label="LumaFold 测试 Alpha",
                        source_label="LumaFold 测试 Alpha",
                        readonly=True,
                    )
        except Exception as exc:
            errors.append(f"LumaFold Test Alpha: {type(exc).__name__}: {exc}")

        # Registered Asset Library folders are canonical for file-backed Alphas.
        try:
            libraries = list(getattr(bpy.context.preferences.filepaths, "asset_libraries", ()) or ())
        except Exception:
            libraries = []
        file_limit = max(1, int(max_files))
        file_count = 0
        for lib in libraries:
            if not bool(getattr(lib, "enabled", True)) or file_count >= file_limit:
                continue
            lib_name = str(getattr(lib, "name", "") or "用户资产库")
            raw_root = str(getattr(lib, "path", "") or "")
            try:
                root = Path(bpy.path.abspath(raw_root)).resolve()
            except Exception:
                root = Path(raw_root)
            if not root.is_dir():
                continue
            try:
                paths = sorted(
                    (p for p in root.rglob("*") if p.is_file() and p.suffix.casefold() in self.IMAGE_EXTS),
                    key=lambda p: str(p).casefold(),
                )
            except Exception as exc:
                errors.append(f"{lib_name}: {type(exc).__name__}: {exc}")
                continue
            for path in paths[:max(0, file_limit - file_count)]:
                file_count += 1
                try:
                    rel_parent = path.parent.relative_to(root).as_posix()
                except Exception:
                    rel_parent = ""
                suffix = rel_parent if rel_parent not in ("", ".") else "根目录"
                folder_id = f"alpha|{lib_name}|{suffix}"
                folder_label = lib_name if suffix == "根目录" else f"{lib_name} / {suffix}"
                add_folder(folder_id, folder_label, lib_name, str(path.parent))
                add_record(
                    name=path.stem,
                    identity=self._identity_from_path(path),
                    filepath=str(path),
                    folder_id=folder_id,
                    folder_label=folder_label,
                    source_label=lib_name,
                )

        # Finally merge current .blend Images. File-backed Images that already
        # belong to a canonical source stay there; packed/generated/other images
        # get a truthful "当前文件" entry.
        loaded_folder = "loaded|current_file"
        current_file_count = 0
        for image in list(getattr(bpy.data, "images", ()) or ()):
            try:
                image_name = str(getattr(image, "name", "") or "")
                if str(getattr(image, "source", "")) == "VIEWER" or image_name in {"Render Result", "Viewer Node"}:
                    continue
                raw = str(getattr(image, "filepath", "") or "")
                path = self._norm_path(bpy.path.abspath(raw)) if raw else ""
                identity = self._loaded_identity(image_name, path)
                existing = by_identity.get(identity)
                if existing is not None:
                    existing["image_name"] = image_name
                    existing["loaded"] = True
                    continue
                if not current_file_count:
                    add_folder(loaded_folder, "当前文件", "Blender", "")
                current_file_count += 1
                add_record(
                    name=image_name or "Alpha",
                    identity=identity,
                    filepath=path,
                    image_name=image_name,
                    folder_id=loaded_folder,
                    folder_label="当前文件",
                    source_label="当前 Blender 文件",
                    loaded=True,
                )
            except Exception:
                continue

        counts = {}
        for item in records:
            counts[item["folder_id"]] = counts.get(item["folder_id"], 0) + 1
        for folder in folders:
            folder["count"] = int(counts.get(folder["id"], 0))
        folders = [folder for folder in folders if folder.get("count", 0) > 0]
        folders.sort(key=lambda folder: (
            0 if folder.get("id") == loaded_folder else 1,
            0 if folder.get("readonly") else 1,
            str(folder.get("label") or "").casefold(),
        ))
        records.sort(key=lambda item: (
            str(item.get("folder_label") or "").casefold(),
            str(item.get("name") or "").casefold(),
        ))
        return {
            "assets": records,
            "folders": folders,
            "errors": errors[-8:],
            "asset_count": len(records),
            "folder_count": len(folders),
        }


class BlenderCapabilitiesServiceCompat(BlenderCapabilitiesService):
    """Capability snapshot for supported Blender 5.x releases."""

    @staticmethod
    def _asset_shelf_library_types():
        import bpy

        result = []
        try:
            rna = getattr(bpy.types.AssetShelf, "bl_rna", None)
            prop = rna.properties.get("asset_library_reference") if rna is not None else None
            result = [str(item.identifier) for item in getattr(prop, "enum_items", ()) or ()]
        except Exception:
            pass
        return tuple(result)

    def snapshot(self):
        import bpy

        result = dict(super().snapshot() or {})
        version = tuple(int(v) for v in tuple(getattr(bpy.app, "version", (0, 0, 0)))[:3])
        shelf_types = self._asset_shelf_library_types()
        ui_layout = getattr(bpy.types, "UILayout", None)
        result.update({
            "compat_profile": "5.3+" if version >= (5, 3, 0) or result.get("per_brush_unified_settings") else "5.0-5.2",
            "ui_layout_label_multiline": bool(ui_layout is not None and hasattr(ui_layout, "label_multiline")),
            "asset_shelf_library_types": shelf_types,
            "online_essentials": "ONLINE_ESSENTIALS" in shelf_types,
            "brush_asset_activate": bool(hasattr(getattr(bpy.ops, "brush", None), "asset_activate")),
            "unified_flags_deprecated": bool(version >= (5, 3, 0)),
        })
        return result


class BlenderCompatibilityGateService:
    service_id = "blender.compat_gate"

    def __init__(self, capabilities):
        self.capabilities = capabilities

    def snapshot(self):
        caps = dict(self.capabilities.snapshot() or {})
        missing = []
        if not caps.get("brush_asset_activate"):
            missing.append("brush.asset_activate")
        if not (caps.get("per_brush_unified_settings") or caps.get("legacy_unified_paint_flags")):
            missing.append("Sculpt unified Size/Strength owner")
        if not caps.get("window_modal_operators"):
            missing.append("Window.modal_operators")
        return {
            "status": "READY" if not missing else "DEGRADED",
            "profile": str(caps.get("compat_profile") or "unknown"),
            "missing": missing,
            "label_multiline": bool(caps.get("ui_layout_label_multiline")),
            "node_root_panel": bool(caps.get("node_tree_root_panel")),
            "online_essentials": bool(caps.get("online_essentials")),
        }
