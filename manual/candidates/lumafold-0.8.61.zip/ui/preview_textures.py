from __future__ import annotations

import base64
from collections import OrderedDict
import time


class PreviewTextureCache:
    """Host-local GPU texture cache for host-independent RGBA preview payloads.

    Core/Bridge state only transports JSON-safe preview pixels. Texture ids are
    always created inside the active Host renderer and never cross Host borders.

    Preview payloads are UI artwork in display/sRGB byte space. Native WGL uses
    those bytes directly; Blender's embedded GPU host exposes a dedicated sRGB
    upload method so POST_PIXEL color management does not brighten them twice.

    dev11 keeps an entire practical Brush/Alpha browsing session resident.
    dev12 adds a small first-upload budget: proactive CPU-side prewarm may make
    dozens of RGBA payloads available before the library opens, but creating all
    GPU textures in one ImGui frame would simply move the hitch from Blender
    thumbnail extraction to the renderer.  Missing textures are therefore
    admitted a few at a time per ~60 Hz time slice; cached textures remain O(1).
    """

    def __init__(self, renderer, max_items: int = 64):
        self.renderer = renderer
        # Older native hosts may still pass max_items=24 explicitly. Preserve
        # source compatibility while enforcing a product-safe residency floor.
        self.max_items = max(32, min(64, int(max_items)))
        self._textures = OrderedDict()
        self._upload_bucket = -1
        self._uploads_in_bucket = 0
        self._max_new_uploads_per_bucket = 4

    def _admit_new_upload(self) -> bool:
        # Approximate a 60 Hz frame budget without requiring every existing Host
        # to call a new begin_frame API.  At 120 Hz two draw frames may share one
        # bucket; that is intentional and keeps first-open work visually smooth.
        bucket = int(time.perf_counter() * 60.0)
        if bucket != self._upload_bucket:
            self._upload_bucket = bucket
            self._uploads_in_bucket = 0
        if self._uploads_in_bucket >= self._max_new_uploads_per_bucket:
            return False
        self._uploads_in_bucket += 1
        return True

    @staticmethod
    def _flip_rows(raw: bytes, width: int, height: int) -> bytes:
        """Flip tightly packed RGBA8 rows without touching pixel/channel order."""
        stride = int(width) * 4
        if stride <= 0 or int(height) <= 1 or len(raw) != stride * int(height):
            return raw
        return b"".join(
            raw[row * stride:(row + 1) * stride]
            for row in range(int(height) - 1, -1, -1)
        )

    def _native_wgl_alpha_legacy_rows(self, preview, key: str) -> bool:
        """Return True only for Blender ImagePreview Alpha payloads on Native WGL.

        dev62's real-pixel Alpha payloads (`alpha_data_pixels`) are already
        top-down and must never be flipped again.  Blender's legacy
        `ImagePreview.icon_pixels/image_pixels` fallback is the exceptional path:
        its row origin matches Blender preview storage, while the standalone WGL
        upload consumes application RGBA rows with the opposite vertical origin.

        Restrict the compatibility transform to Alpha identities (`file|` or
        `loaded|`) and the native WGL renderer so Brush previews and Embedded GPU
        behavior remain unchanged.
        """
        try:
            source = str(preview.get("source") or "")
        except Exception:
            return False
        if source != "image":
            return False
        if not (str(key).startswith("file|") or str(key).startswith("loaded|")):
            return False
        renderer = self.renderer
        return bool(renderer is not None and type(renderer).__name__ == "NativeWGLImguiRenderer")

    def resolve(self, preview) -> int:
        if not preview or self.renderer is None:
            return 0
        try:
            key = str(preview.get("key") or "")
            width = int(preview.get("width") or 0)
            height = int(preview.get("height") or 0)
            encoded = str(preview.get("rgba_b64") or "")
        except Exception:
            return 0
        if not key or width <= 0 or height <= 0 or not encoded:
            return 0
        cached = self._textures.get(key)
        if cached:
            self._textures.move_to_end(key)
            return int(cached)

        # Do not decode Base64 or touch the GPU if this time slice has already
        # consumed its upload budget. The next draw will retry automatically.
        if not self._admit_new_upload():
            return 0

        try:
            raw = base64.b64decode(encoded.encode("ascii"), validate=True)
            if len(raw) != width * height * 4:
                return 0
            if self._native_wgl_alpha_legacy_rows(preview, key):
                raw = self._flip_rows(raw, width, height)
            upload = getattr(self.renderer, "register_srgb_texture", None)
            if not callable(upload):
                upload = self.renderer.register_rgba_texture
            tex_id = int(upload(width, height, raw) or 0)
        except Exception:
            return 0
        if not tex_id:
            return 0
        self._textures[key] = tex_id
        self._textures.move_to_end(key)
        while len(self._textures) > self.max_items:
            _old_key, old_id = self._textures.popitem(last=False)
            try:
                self.renderer.unregister_texture(old_id)
            except Exception:
                pass
        return tex_id

    def shutdown(self):
        renderer = self.renderer
        self.renderer = None
        if renderer is not None:
            for tex_id in tuple(self._textures.values()):
                try:
                    renderer.unregister_texture(tex_id)
                except Exception:
                    pass
        self._textures.clear()
