"""LumaFold font foundation for Blender-hosted ImGui.

P0.3 deliberately does not bundle or redistribute fonts.  It first tries to
reuse Blender's installed UI font, then adds a Windows CJK fallback from the
local OS when available.  The resulting font object is shared by all LumaFold
components and rendered through the existing ImGui -> Blender GPU backend.
"""
from __future__ import annotations

from pathlib import Path

try:
    import bpy
except ImportError:  # Native Satellite is intentionally bpy-free.
    bpy = None

_UI_FONT = None
_FONT_INFO = {
    "base": "Dear ImGui default",
    "cjk": "none",
    "custom": False,
    "error": "",
}


def _existing(paths):
    seen = set()
    for path in paths:
        if not path:
            continue
        p = Path(path)
        key = str(p).lower()
        if key in seen:
            continue
        seen.add(key)
        try:
            if p.is_file():
                yield p
        except OSError:
            continue


def _blender_font_candidates():
    # Blender documents ./datafiles/fonts as the UI font resource directory.
    if bpy is None:
        return
    roots = []
    for kind in ("LOCAL", "SYSTEM", "USER"):
        try:
            root = bpy.utils.resource_path(kind)
        except Exception:
            root = ""
        if root:
            roots.append(Path(root))

    # Portable installs can also keep versioned resources beside blender.exe.
    try:
        binary_dir = Path(bpy.app.binary_path).resolve().parent
        roots.extend((binary_dir, binary_dir / f"{bpy.app.version[0]}.{bpy.app.version[1]}"))
    except Exception:
        pass

    names = ("bfont.ttf", "bfont.woff2")
    for root in roots:
        for name in names:
            yield root / "datafiles" / "fonts" / name
            yield root / "fonts" / name


def _windows_base_candidates():
    win = Path("C:/Windows/Fonts")
    # Segoe UI is a strong Windows fallback if the Blender font path changes.
    return (win / "segoeui.ttf", win / "SegoeUI.ttf")


def _windows_cjk_candidates():
    win = Path("C:/Windows/Fonts")
    # The target machine is a Chinese Windows install, but keep multiple safe
    # fallbacks so P0.3 remains useful if one optional font family is absent.
    return (
        win / "msyh.ttc",       # Microsoft YaHei
        win / "msyh.ttf",
        win / "simhei.ttf",
        win / "simsun.ttc",
        win / "Deng.ttf",       # DengXian
    )


def get_ui_font():
    return _UI_FONT


def get_font_info():
    return dict(_FONT_INFO)


def reset_font_state():
    global _UI_FONT, _FONT_INFO
    _UI_FONT = None
    _FONT_INFO = {
        "base": "Dear ImGui default",
        "cjk": "none",
        "custom": False,
        "error": "",
    }


def _font_config(imgui, *, merge=False):
    cfg = imgui.FontConfig()
    # UI is rendered at 1:1 screen scale; horizontal 2x oversampling only
    # enlarges font atlas work/memory without improving the product geometry.
    cfg.oversample_h = 1
    cfg.oversample_v = 1
    cfg.pixel_snap_h = True
    cfg.pixel_snap_v = True
    cfg.merge_mode = bool(merge)
    return cfg


def configure_fonts(imgui, io):
    """Load the Blender UI font and local CJK fallback before NewFrame().

    Failure is non-fatal: the host will continue with Dear ImGui's default font
    and expose the reason in the P0 gallery/diagnostics instead of crashing.
    """
    global _UI_FONT, _FONT_INFO
    reset_font_state()

    base = next(_existing((*_blender_font_candidates(), *_windows_base_candidates())), None)
    cjk = next(_existing(_windows_cjk_candidates()), None)
    if base is None:
        _FONT_INFO["error"] = "No Blender/Segoe UI font file found; using ImGui default"
        return None

    try:
        base_bytes = base.read_bytes()
        font = io.fonts.add_font_from_memory_ttf(base_bytes, 14.0, _font_config(imgui, merge=False))
        _UI_FONT = font
        _FONT_INFO.update({"base": base.name, "custom": True})

        if cjk is not None and cjk.resolve() != base.resolve():
            try:
                cjk_bytes = cjk.read_bytes()
                cfg = _font_config(imgui, merge=True)
                cfg.font_no = 0
                io.fonts.add_font_from_memory_ttf(cjk_bytes, 14.0, cfg)
                _FONT_INFO["cjk"] = cjk.name
            except Exception as exc:
                _FONT_INFO["cjk"] = "fallback failed"
                _FONT_INFO["error"] = f"CJK fallback: {type(exc).__name__}: {exc}"
        return font
    except Exception as exc:
        _UI_FONT = None
        _FONT_INFO["error"] = f"Base font: {type(exc).__name__}: {exc}"
        return None
