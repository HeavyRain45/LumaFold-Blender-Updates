import time
import traceback

import bpy

from ..core.state import STATE
from ..core.app import APP
from ..core.host_control import HOST_CONTROL
from ..runtime.bootstrap import try_import
from .gallery import draw_gallery
from .fonts import configure_fonts, get_font_info, reset_font_state
from .icons import ensure_icon_atlas, get_icon_info, reset_icon_state
from .preview_textures import PreviewTextureCache
from .design import apply_style
from .renderer import BlenderImguiRenderer
from .win32_ime import Win32IMEBridge


class UIHost:
    TRANSFER_KEYS = (
        "ui_scale", "requested_scale", "style_scale", "page", "segment",
        "strength", "solver", "thumb", "bevel", "segments", "hud_mode",
        "stress", "cjk_input", "icon_selected",
        "compact_surface_w", "compact_surface_h",
        "embedded_window_pos_x", "embedded_window_pos_y",
        "embedded_last_valid_pos_x", "embedded_last_valid_pos_y",
        "embedded_restore_pos_x", "embedded_restore_pos_y", "embedded_restore_pending",
    )

    def __init__(self, context, *, host_mode="embedded", initial_state=None):
        slimgui = try_import()
        if slimgui is None:
            raise RuntimeError("slimgui runtime is not installed")
        from slimgui import imgui

        self.imgui = imgui
        self.renderer = BlenderImguiRenderer(imgui)
        self.io = self.renderer.io
        self.window_pointer = context.window.as_pointer()
        self.area_pointer = context.area.as_pointer()
        self.screen_pointer = context.window.screen.as_pointer() if context.window and context.window.screen else 0
        window_region = next((r for r in context.area.regions if r.type == "WINDOW"), None)
        if window_region is None:
            raise RuntimeError("No WINDOW region found in the active 3D View")
        self.region_pointer = window_region.as_pointer()
        self.handler = bpy.types.SpaceView3D.draw_handler_add(self._draw, (), "WINDOW", "POST_PIXEL")
        self.host_mode = str(host_mode or "embedded")
        self.lease_generation = int(HOST_CONTROL.lease.generation)
        self.state = {
            "opened": True,
            "ui_scale": 1.25,
            "requested_scale": 1.25,
            "style_scale": 1.25,
            "typography_gate": "blender_font_cjk",
            "input_gate": "locked_p031",
            "icon_gate": "atlas_p04",
            "ime_gate": "composition_result_p051",
            "host_gate": "shared_core_p09",
            "host_mode": self.host_mode,
            "host_window_pointer": self.window_pointer,
            "blender_workspace": str(getattr(getattr(context.window, "workspace", None), "name", "") or ""),
            "blender_mode": str(getattr(context, "mode", "UNKNOWN") or "UNKNOWN"),
            "ime_events": [],
            "ime_unicode": [],
            "_bound_region_x": float(getattr(window_region, "x", 0) or 0),
            "_bound_region_y": float(getattr(window_region, "y", 0) or 0),
            "_bound_region_w": float(getattr(window_region, "width", 0) or 0),
            "_bound_region_h": float(getattr(window_region, "height", 0) or 0),
        }
        # A0.12: stable host-independent UI preferences live in Core StateStore,
        # so a fresh host can restore them before its first ImGui frame.
        APP.register_state_schema("__ui__", 1)
        persisted_ui = APP.store.namespace("__ui__")
        for key in self.TRANSFER_KEYS:
            if key in persisted_ui:
                self.state[key] = persisted_ui[key]
        if initial_state:
            for key in self.TRANSFER_KEYS:
                if key in initial_state:
                    self.state[key] = initial_state[key]
        self.preview_textures = PreviewTextureCache(self.renderer)
        self.state["_preview_texture_resolver"] = self.preview_textures.resolve
        # Font resources are configured once, before the first ImGui frame.
        configure_fonts(self.imgui, self.io)
        self.state["font_info"] = get_font_info()
        self._applied_scale = None
        # Global style/font mutation must happen at frame boundaries.
        self._apply_pending_style()
        self.last_time = time.perf_counter()
        self.closed = False
        self._dirty_serial = 1
        self._drawn_serial = 0
        self._last_draw_region_size = (0, 0)
        self._event_unsubscribers = []
        self._key_map = self._make_key_map(imgui)
        # Input ownership is explicit. Blender events that start outside LumaFold
        # must never mutate ImGui button/key state, otherwise a Blender modal
        # operator may consume the matching RELEASE and leave ImGui stuck.
        self._mouse_owned = {
            imgui.MouseButton.LEFT: False,
            imgui.MouseButton.RIGHT: False,
            imgui.MouseButton.MIDDLE: False,
        }
        self._key_owned = set()
        self._focus_active = True
        self.ime_bridge = Win32IMEBridge()
        self.state["ime_info"] = self.ime_bridge.info()
        STATE.running = True
        STATE.area_pointer = self.area_pointer
        STATE.window_pointer = self.window_pointer
        STATE.host_mode = self.host_mode
        STATE.host = self
        STATE.status = "Running"

        # Core/product commands can change UI truth without sending an event
        # through the Embedded modal (for example Alt+1 Quick Brush). Mark the
        # cached frame dirty only for those explicit state transitions.
        for topic in (
            "context.changed",
            "sculpt.state.changed",
            "sculpt.brush.changed",
            "sculpt.quick_slot.assigned",
            "sculpt.quick_slot.cleared",
            "sculpt.quick_slots.reset",
            "sculpt.quick_rows.changed",
            "sculpt.brush_library.refreshed",
            "sculpt.brush_library.activated",
            "sculpt.alpha_library.refreshed",
            "sculpt.alpha_library.activated",
        ):
            try:
                self._event_unsubscribers.append(
                    APP.events.subscribe(topic, lambda _payload, self=self: self._mark_dirty())
                )
            except Exception:
                pass

    def _mark_dirty(self):
        self._dirty_serial = int(getattr(self, "_dirty_serial", 0) or 0) + 1

    @staticmethod
    def _make_key_map(imgui):
        mapping = {
            "TAB": imgui.Key.KEY_TAB,
            "LEFT_ARROW": imgui.Key.KEY_LEFT_ARROW,
            "RIGHT_ARROW": imgui.Key.KEY_RIGHT_ARROW,
            "UP_ARROW": imgui.Key.KEY_UP_ARROW,
            "DOWN_ARROW": imgui.Key.KEY_DOWN_ARROW,
            "PAGE_UP": imgui.Key.KEY_PAGE_UP,
            "PAGE_DOWN": imgui.Key.KEY_PAGE_DOWN,
            "HOME": imgui.Key.KEY_HOME,
            "END": imgui.Key.KEY_END,
            "INSERT": imgui.Key.KEY_INSERT,
            "DEL": imgui.Key.KEY_DELETE,
            "BACK_SPACE": imgui.Key.KEY_BACKSPACE,
            "SPACE": imgui.Key.KEY_SPACE,
            "RET": imgui.Key.KEY_ENTER,
            "NUMPAD_ENTER": imgui.Key.KEY_KEYPAD_ENTER,
            "ESC": imgui.Key.KEY_ESCAPE,
            "LEFT_CTRL": imgui.Key.KEY_LEFT_CTRL,
            "RIGHT_CTRL": imgui.Key.KEY_RIGHT_CTRL,
            "LEFT_SHIFT": imgui.Key.KEY_LEFT_SHIFT,
            "RIGHT_SHIFT": imgui.Key.KEY_RIGHT_SHIFT,
            "LEFT_ALT": imgui.Key.KEY_LEFT_ALT,
            "RIGHT_ALT": imgui.Key.KEY_RIGHT_ALT,
            "OSKEY": imgui.Key.KEY_LEFT_SUPER,
        }
        for ch in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
            mapping[ch] = getattr(imgui.Key, f"KEY_{ch}")
        for d in "0123456789":
            mapping[d] = getattr(imgui.Key, f"KEY_{d}")
        return mapping


    def _apply_pending_style(self):
        requested = float(self.state.get("requested_scale", self.state.get("ui_scale", 1.0)))
        if self._applied_scale is None or abs(requested - self._applied_scale) > 1e-6:
            self.renderer.ensure_context()
            applied, skipped = apply_style(self.imgui, requested)
            self._applied_scale = applied
            self.state["ui_scale"] = applied
            self.state["requested_scale"] = applied
            self.state["style_scale"] = applied
            self.state["style_skipped_setters"] = skipped

    def _same_region(self):
        area = bpy.context.area
        region = bpy.context.region
        window = bpy.context.window
        return bool(
            window and area and region
            and window.as_pointer() == self.window_pointer
            and area.as_pointer() == self.area_pointer
            and region.as_pointer() == self.region_pointer
        )

    def _window_region(self):
        area = bpy.context.area
        if area is None or area.as_pointer() != self.area_pointer:
            return None
        return next((r for r in area.regions if r.type == "WINDOW" and r.as_pointer() == self.region_pointer), None)

    def _reset_transient_input(self):
        """Hard-reset transient ImGui input across Blender context transitions."""
        try:
            self._release_owned_input()
        except Exception:
            pass
        try:
            self.io.add_mouse_pos_event(-3.4e38, -3.4e38)
        except Exception:
            pass
        try:
            if hasattr(self.io, "add_focus_event"):
                self.io.add_focus_event(False)
        except Exception:
            pass
        self._focus_active = False
        STATE.capture_mouse = False
        STATE.capture_keyboard = False
        STATE.capture_text = False

    def context_transition_pulse(self, *, workspace_name="", mode="UNKNOWN"):
        workspace_name = str(workspace_name or "")
        mode = str(mode or "UNKNOWN")
        old_workspace = str(self.state.get("blender_workspace") or "")
        old_mode = str(self.state.get("blender_mode") or "UNKNOWN")
        if workspace_name != old_workspace or mode != old_mode:
            self._reset_transient_input()
            self._mark_dirty()
        self.state["blender_workspace"] = workspace_name
        self.state["blender_mode"] = mode

    def _cache_bound_region_geometry(self, region):
        if region is None:
            return
        try:
            self.state["_bound_region_x"] = float(region.x)
            self.state["_bound_region_y"] = float(region.y)
            self.state["_bound_region_w"] = float(region.width)
            self.state["_bound_region_h"] = float(region.height)
        except Exception:
            pass

    def rebind_view3d(self, window, area, region, *, workspace_name=""):
        """Move one live Embedded Host to the current Workspace's View3D.

        Blender replaces Screen/Area/Region objects when switching Workspaces.
        The ImGui context and draw handler remain valid, so rebind ownership
        rather than destroying/recreating the product Host.
        """
        if self.closed or window is None or area is None or region is None:
            return False
        if getattr(area, "type", "") != "VIEW_3D" or getattr(region, "type", "") != "WINDOW":
            return False
        self._reset_transient_input()
        self.window_pointer = window.as_pointer()
        self.area_pointer = area.as_pointer()
        self.region_pointer = region.as_pointer()
        self.screen_pointer = window.screen.as_pointer() if getattr(window, "screen", None) else 0
        self._cache_bound_region_geometry(region)
        self.state["host_window_pointer"] = self.window_pointer
        self.state["blender_workspace"] = str(workspace_name or getattr(getattr(window, "workspace", None), "name", "") or "")
        self.state["blender_mode"] = str(getattr(bpy.context, "mode", "UNKNOWN") or "UNKNOWN")
        STATE.area_pointer = self.area_pointer
        STATE.window_pointer = self.window_pointer
        # Reuse the last local floating position, clamped to the new View3D.
        scale = max(0.01, float(self.state.get("ui_scale", 1.25) or 1.25))
        surface_w = float(self.state.get("compact_surface_w", 264.0) or 264.0) * scale
        surface_h = float(self.state.get("compact_surface_h", 338.0) or 338.0) * scale
        rx = float(self.state.get("embedded_last_valid_pos_x", 18.0) or 18.0)
        ry = float(self.state.get("embedded_last_valid_pos_y", 64.0) or 64.0)
        max_x = max(0.0, float(getattr(region, "width", 0) or 0) - surface_w)
        max_y = max(0.0, float(getattr(region, "height", 0) or 0) - surface_h)
        self.state["embedded_restore_pos_x"] = max(0.0, min(rx, max_x))
        self.state["embedded_restore_pos_y"] = max(0.0, min(ry, max_y))
        self.state["embedded_restore_pending"] = True
        self.last_time = time.perf_counter()
        self._mark_dirty()
        try:
            area.tag_redraw()
        except Exception:
            pass
        return True

    def export_transfer_state(self):
        """Return only stable, host-independent UI state for a host migration."""
        return {key: self.state.get(key) for key in self.TRANSFER_KEYS if key in self.state}

    def _release_owned_input(self):
        """Release only the input state that LumaFold actually owns.

        Blender modal tools can temporarily sit above our modal handler and consume
        RELEASE events.  If we had forwarded an outside-UI PRESS to ImGui, ImGui
        would then believe that button/key is held forever.  Explicit ownership
        prevents that class of focus-loss bug.
        """
        if self.closed:
            return
        io = self.io
        for button, owned in tuple(self._mouse_owned.items()):
            if owned:
                try:
                    io.add_mouse_button_event(button, False)
                except Exception:
                    pass
                self._mouse_owned[button] = False
        for key in tuple(self._key_owned):
            try:
                io.add_key_event(key, False)
            except Exception:
                pass
        self._key_owned.clear()
        # Modifier flags are state snapshots, so force them clean on a hard focus loss.
        for mod in (
            self.imgui.Key.MOD_CTRL,
            self.imgui.Key.MOD_SHIFT,
            self.imgui.Key.MOD_ALT,
            self.imgui.Key.MOD_SUPER,
        ):
            try:
                io.add_key_event(mod, False)
            except Exception:
                pass

    def feed_event(self, event, *, region=None):
        if self.closed or not HOST_CONTROL.owns(self.host_mode, self.lease_generation):
            return
        self._mark_dirty()
        self.renderer.ensure_context()
        imgui = self.imgui
        io = self.io

        # P0.5 IME diagnostics: keep a tiny ring-buffer of Blender event names and
        # committed unicode while the LumaFold text field owns focus.
        if "IME" in str(event.type):
            events = self.state.setdefault("ime_events", [])
            events.append(str(event.type))
            del events[:-8]
        if event.unicode and bool(STATE.capture_text):
            chars = self.state.setdefault("ime_unicode", [])
            chars.append(event.unicode)
            del chars[:-16]

        if event.type == "WINDOW_DEACTIVATE":
            self._release_owned_input()
            if hasattr(io, "add_focus_event"):
                try:
                    io.add_focus_event(False)
                except Exception:
                    pass
            self._focus_active = False
            return
        elif not self._focus_active:
            if hasattr(io, "add_focus_event"):
                try:
                    io.add_focus_event(True)
                except Exception:
                    pass
            self._focus_active = True

        # S0.7.3: input routing is Window-level, not context.area-level.  After a
        # Workspace switch Blender may keep delivering modal events with an Area
        # context that is no longer the View3D currently hosting LumaFold.  The
        # caller therefore resolves the bound WINDOW region explicitly and passes
        # it here.  Fall back to the legacy resolver only when no explicit region
        # was supplied.
        if region is None:
            region = self._window_region()
        pointer_in_region = False
        if region is not None:
            try:
                pointer_in_region = bool(
                    float(region.x) <= float(event.mouse_x) < float(region.x + region.width)
                    and float(region.y) <= float(event.mouse_y) < float(region.y + region.height)
                )
            except Exception:
                pointer_in_region = False
        if event.type in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"} and region is not None:
            rx = float(event.mouse_x - region.x)
            ry = float(event.mouse_y - region.y)
            io.add_mouse_pos_event(rx, float(region.height - 1) - ry)

        mouse_event_to_button = {
            "LEFTMOUSE": imgui.MouseButton.LEFT,
            "RIGHTMOUSE": imgui.MouseButton.RIGHT,
            "MIDDLEMOUSE": imgui.MouseButton.MIDDLE,
        }
        button = mouse_event_to_button.get(event.type)
        if button is not None and event.value in {"PRESS", "RELEASE"}:
            if event.value == "PRESS":
                # Only presses that begin on LumaFold belong to ImGui.  Presses that
                # begin in Blender are deliberately invisible to ImGui.
                if pointer_in_region and bool(STATE.capture_mouse):
                    io.add_mouse_button_event(button, True)
                    self._mouse_owned[button] = True
            elif self._mouse_owned.get(button, False):
                # Always finish a gesture that began on LumaFold, even if the pointer
                # is now outside the visual bounds.
                io.add_mouse_button_event(button, False)
                self._mouse_owned[button] = False

        if event.type == "WHEELUPMOUSE" and pointer_in_region and bool(STATE.capture_mouse):
            io.add_mouse_wheel_event(0.0, 1.0)
        elif event.type == "WHEELDOWNMOUSE" and pointer_in_region and bool(STATE.capture_mouse):
            io.add_mouse_wheel_event(0.0, -1.0)

        # Modifier state is a fresh snapshot on every Blender event.  This also heals
        # modifier releases that may have been consumed by another Blender modal tool.
        io.add_key_event(imgui.Key.MOD_CTRL, bool(event.ctrl))
        io.add_key_event(imgui.Key.MOD_SHIFT, bool(event.shift))
        io.add_key_event(imgui.Key.MOD_ALT, bool(event.alt))
        io.add_key_event(imgui.Key.MOD_SUPER, bool(event.oskey))

        if event.value in {"PRESS", "RELEASE"}:
            key = self._key_map.get(event.type)
            if key is not None:
                if event.value == "PRESS":
                    if bool(STATE.capture_keyboard or STATE.capture_text):
                        io.add_key_event(key, True)
                        self._key_owned.add(key)
                elif key in self._key_owned:
                    io.add_key_event(key, False)
                    self._key_owned.discard(key)

        if event.value == "PRESS" and event.unicode and bool(STATE.capture_text):
            # Native IME composition owns text generation while composing.  Blender
            # may still expose the physical pinyin key as event.unicode; feeding it
            # here would insert Latin pinyin beside the eventual Chinese result.
            if not bool(getattr(self.ime_bridge, "composing", False)):
                codepoint = ord(event.unicode)
                if codepoint > 0:
                    io.add_input_character(codepoint)

    def should_capture(self, event):
        if self.closed or not HOST_CONTROL.owns(self.host_mode, self.lease_generation):
            return False
        if event.type in {"TIMER", "WINDOW_DEACTIVATE"}:
            return False
        if event.type in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE", "LEFTMOUSE", "RIGHTMOUSE", "MIDDLEMOUSE", "WHEELUPMOUSE", "WHEELDOWNMOUSE"}:
            # Once a LumaFold gesture starts, retain it until release.  Outside-UI
            # Blender gestures never become owned in the first place.
            return bool(STATE.capture_mouse or any(self._mouse_owned.values()))
        if event.value == "RELEASE":
            key = self._key_map.get(event.type)
            if key is not None and key in self._key_owned:
                return True
        return bool(STATE.capture_keyboard or STATE.capture_text)

    def _process_pending_module_action(self):
        pending = self.state.pop("pending_module_action", None)
        if not pending:
            return
        action, module_id = pending
        loader = getattr(APP, "module_loader", None)
        if loader is None:
            self.state["module_action_status"] = "模块加载器不可用"
            return
        try:
            if action == "load":
                loader.load(module_id)
                label = "加载完成"
            elif action == "unload":
                loader.unload(module_id)
                label = "卸载完成"
            elif action == "reload":
                loader.reload(module_id)
                label = "重载完成"
            elif action == "install_demo":
                loader.install_demo_external()
                loader.discover()
                loader.load("external_demo")
                label = "示例外部模块已安装并加载"
                module_id = "external_demo"
            elif action == "remove_demo":
                loader.remove_demo_external()
                label = "示例外部模块已删除"
                module_id = "external_demo"
            elif action == "package_good":
                report = loader.install_demo_package("compatible", try_load=True)
                label = report.status
                module_id = report.module_id or "package_demo"
            elif action == "package_bad":
                report = loader.install_demo_package("incompatible", try_load=False)
                label = report.status
                module_id = report.module_id or "package_incompatible"
            elif action == "package_faulty":
                report = loader.install_demo_package("faulty", try_load=True)
                label = report.status
                module_id = report.module_id or "package_faulty"
            elif action == "package_cleanup":
                loader.cleanup_demo_packages()
                label = "A0.8 测试包已清理"
                module_id = "demo_packages"
            elif action == "service_install":
                loader.install_service_demo()
                label = "A0.10 服务示例已安装"
                module_id = "service_demo"
            elif action == "service_load":
                order = loader.load_service_demo()
                label = "服务消费者加载完成：" + " -> ".join(order)
                module_id = "svc_consumer"
            elif action == "service_call":
                label = loader.call_service_demo()
                module_id = "demo.greeter"
            elif action == "service_unload_provider":
                try:
                    loader.unload("svc_provider")
                    label = "服务提供者已卸载（异常：服务保护没有生效）"
                except RuntimeError as exc:
                    label = "服务卸载已阻止 SERVICE PROTECTED：" + str(exc)
                module_id = "svc_provider"
            elif action == "service_missing":
                label = loader.run_missing_service_demo()
                module_id = "svc_missing"
            elif action == "service_cleanup":
                loader.cleanup_service_demo()
                label = "A0.10 服务示例已清理"
                module_id = "service_demo"
            elif action == "life_install_v1":
                report = loader.install_lifecycle_version("1.0.0", allow_reinstall=True)
                label = report.status
                module_id = "lifecycle_demo"
            elif action == "life_update_v2":
                report = loader.install_lifecycle_version("1.1.0")
                label = report.status
                module_id = "lifecycle_demo"
            elif action == "life_downgrade_block":
                report = loader.install_lifecycle_version("1.0.0")
                label = report.status
                module_id = "lifecycle_demo"
            elif action == "life_downgrade_confirm":
                report = loader.install_lifecycle_version("1.0.0", allow_downgrade=True)
                label = report.status
                module_id = "lifecycle_demo"
            elif action == "life_disable":
                label = loader.disable_package("lifecycle_demo")
                module_id = "lifecycle_demo"
            elif action == "life_enable":
                label = loader.enable_package("lifecycle_demo", load=True)
                module_id = "lifecycle_demo"
            elif action == "life_ping":
                label = loader.ping_lifecycle_demo()
                module_id = "lifecycle_demo"
            elif action == "life_uninstall":
                label = loader.uninstall_package("lifecycle_demo", purge_state=False)
                module_id = "lifecycle_demo"
            elif action == "life_cleanup":
                label = loader.cleanup_lifecycle_demo()
                module_id = "lifecycle_demo"
            elif action == "perm_install":
                loader.install_permission_demo()
                label = "A0.13 权限示例已安装"
                module_id = "permission_demo"
            elif action == "perm_block":
                label = loader.run_permission_block_demo()
                module_id = "perm_sensitive"
            elif action == "perm_trust_load":
                label = loader.trust_and_load_permission_demo()
                module_id = "perm_sensitive"
            elif action == "perm_revoke":
                label = loader.revoke_permission_demo()
                module_id = "perm_sensitive"
            elif action == "perm_cleanup":
                loader.cleanup_permission_demo()
                label = "A0.13 权限示例已清理"
                module_id = "permission_demo"
            elif action == "dep_install":
                loader.install_dependency_demo()
                label = "A0.9 依赖示例已安装"
                module_id = "dependency_demo"
            elif action == "dep_load":
                order = loader.load_dependency_demo()
                label = "依赖链加载完成：" + " -> ".join(order)
                module_id = "dep_tool"
            elif action == "dep_unload_base":
                try:
                    loader.unload("dep_base")
                    label = "基础模块已卸载（异常：保护没有生效）"
                except RuntimeError as exc:
                    label = "卸载已阻止 PROTECTED：" + str(exc)
                module_id = "dep_base"
            elif action == "dep_fault":
                label = loader.run_fault_dependency_demo()
                module_id = "dep_fault_tool"
            elif action == "dep_cleanup":
                loader.cleanup_dependency_demo()
                label = "A0.9 依赖示例已清理"
                module_id = "dependency_demo"
            else:
                raise ValueError(f"Unknown module action: {action}")
            APP.refresh_context(host_id=self.host_mode)
            self.state["module_action_status"] = f"{label}: {module_id}"
            STATE.last_error = ""
        except Exception as exc:
            self.state["module_action_status"] = f"操作失败: {module_id} · {type(exc).__name__}: {exc}"
            STATE.last_error = traceback.format_exc()

    def _process_pending_persistence_action(self):
        action = self.state.pop("pending_persistence_action", None)
        if not action:
            return
        try:
            if action == "seed":
                APP.store.namespace("sculpt").update({
                    "quick_slot": 4, "brush_size": 137.0,
                    "brush_strength": 0.73, "alpha_slot": 2,
                })
                APP.store.namespace("model").update({
                    "bevel_width": 0.041, "bevel_segments": 7,
                })
                APP.store.namespace("render").update({
                    "resolution_x": 2560, "resolution_y": 1440, "percentage": 75,
                })
                APP.store.namespace("persistence_demo").update({"marker": "A0.12-SAVED"})
                APP.state.shared_value = 0.62
                label = "已写入 A0.12 测试值（尚未保存）"
            elif action == "save":
                report = APP.persistence.save(ui_state=self.export_transfer_state(), force=True)
                label = f"{report.status}: {report.message}"
            elif action == "mutate":
                APP.store.namespace("sculpt").update({
                    "quick_slot": 0, "brush_size": 31.0,
                    "brush_strength": 0.18, "alpha_slot": 0,
                })
                APP.store.namespace("model").update({
                    "bevel_width": 0.005, "bevel_segments": 2,
                })
                APP.store.namespace("render").update({
                    "resolution_x": 640, "resolution_y": 480, "percentage": 50,
                })
                APP.store.namespace("persistence_demo").update({"marker": "MUTATED"})
                APP.state.shared_value = 0.11
                label = "内存已扰动 MUTATED（磁盘文件未改）"
            elif action == "load":
                report = APP.persistence.load(apply=True, rewrite_migrated=True)
                # Pull restored stable UI preferences into this live Host as well.
                restored_ui = APP.store.namespace("__ui__")
                for key in self.TRANSFER_KEYS:
                    if key in restored_ui:
                        self.state[key] = restored_ui[key]
                label = f"{report.status}: {report.message}"
                if report.issues:
                    label += " · " + "; ".join(report.issues)
            elif action == "migrate":
                report = APP.persistence.run_migration_probe()
                label = f"{report.status}: {report.message}"
            elif action == "cleanup_probe":
                APP.persistence.cleanup_probe()
                label = "迁移测试文件已清理"
            else:
                raise ValueError("Unknown persistence action: " + str(action))
            self.state["persistence_action_status"] = label
            STATE.last_error = ""
        except Exception as exc:
            self.state["persistence_action_status"] = f"状态操作失败：{type(exc).__name__}: {exc}"
            STATE.last_error = traceback.format_exc()


    def _process_pending_freeze_action(self):
        action = self.state.pop("pending_freeze_action", None)
        if not action:
            return
        try:
            manager = APP.contract
            if action == "platform":
                report = manager.run_regression()
                label = report.status
            elif action == "blender":
                report = manager.run_blender_regression()
                label = report.status
            elif action == "freeze_docs":
                label = manager.freeze_sdk_reference()
            elif action == "compare":
                _ok, label = manager.compare_saved()
            elif action == "save":
                label = manager.save_snapshot()
            elif action == "final":
                platform = manager.run_regression()
                real = manager.run_blender_regression()
                try:
                    # A1.0 establishes the stable v1 contract baseline on first run.
                    # Never overwrite an existing baseline automatically: future drift must remain visible.
                    if not manager.default_path().exists():
                        manager.save_snapshot()
                    compare_ok, compare_msg = manager.compare_saved()
                except Exception as exc:
                    compare_ok = False
                    compare_msg = f"契约对比失败：{type(exc).__name__}: {exc}"
                    manager.last_compare_ok = False
                docs_msg = manager.freeze_sdk_reference()
                ready, readiness = manager.a1_readiness()
                label = f"{readiness} · 平台 {platform.passed_count}/{platform.total_count} · 真实 {real.passed_count}/{real.total_count} · {compare_msg} · {docs_msg}"
            else:
                raise ValueError("Unknown freeze action: " + str(action))
            self.state["contract_action_status"] = label
            STATE.last_error = ""
        except Exception as exc:
            self.state["contract_action_status"] = f"最终验证失败：{type(exc).__name__}: {exc}"
            STATE.last_error = traceback.format_exc()

    def _draw(self):
        if self.closed:
            return
        if not HOST_CONTROL.owns(self.host_mode, self.lease_generation):
            return

        # SpaceView3D draw handlers are global to the space type. A Workspace
        # switch replaces Screen/Area/Region objects and causes the new View3D
        # to draw immediately, so use that real draw as the rebind trigger
        # instead of polling Blender from a timer.
        if not self._same_region():
            try:
                window = bpy.context.window
                area = bpy.context.area
                region = bpy.context.region
                screen = getattr(window, "screen", None) if window is not None else None
                screen_ptr = screen.as_pointer() if screen is not None else 0
                if (
                    window is not None
                    and window.as_pointer() == self.window_pointer
                    and screen_ptr != int(self.screen_pointer or 0)
                    and area is not None and area.type == "VIEW_3D"
                    and region is not None and region.type == "WINDOW"
                ):
                    self.rebind_view3d(
                        window, area, region,
                        workspace_name=str(getattr(getattr(window, "workspace", None), "name", "") or ""),
                    )
            except Exception:
                pass
            if not self._same_region():
                return

        try:
            # Mode/workspace truth changes are already accompanied by a View3D
            # redraw. Observe them here once and refresh Core only on change.
            try:
                window = bpy.context.window
                workspace_name = str(getattr(getattr(window, "workspace", None), "name", "") or "")
                mode = str(getattr(bpy.context, "mode", "UNKNOWN") or "UNKNOWN")
                if (
                    workspace_name != str(self.state.get("blender_workspace") or "")
                    or mode != str(self.state.get("blender_mode") or "UNKNOWN")
                ):
                    self.context_transition_pulse(workspace_name=workspace_name, mode=mode)
                    APP.refresh_context(host_id=self.host_mode)
            except Exception:
                pass

            self.renderer.ensure_context()
            region = bpy.context.region
            self._cache_bound_region_geometry(region)
            region_size = (int(region.width), int(region.height))
            if region_size != tuple(getattr(self, "_last_draw_region_size", (0, 0))):
                self._mark_dirty()

            # Blender may redraw View3D continuously while orbiting/sculpting.
            # If LumaFold itself has not changed, reuse the last GPU geometry and
            # skip ImGui layout, resource synchronization and NumPy/batch rebuilds.
            if int(self._drawn_serial) == int(self._dirty_serial):
                self.renderer.render_cached(region.width, region.height)
                STATE.frames += 1
                return

            frame_serial = int(self._dirty_serial)

            # Apply registry mutations and UI-scale/font changes only at frame
            # boundaries. Never unload/reload a module while ImGui traverses.
            self._process_pending_module_action()
            self._process_pending_persistence_action()
            self._process_pending_freeze_action()
            APP.tasks.pump_main_thread()
            self._apply_pending_style()
            ensure_icon_atlas(self.renderer)
            self.state["icon_info"] = get_icon_info()

            now = time.perf_counter()
            dt = max(1.0 / 1000.0, min(0.1, now - self.last_time))
            self.last_time = now
            self.io.delta_time = dt
            self.io.display_size = (float(region.width), float(region.height))
            self.io.display_framebuffer_scale = (1.0, 1.0)
            self.state["display_size"] = (float(region.width), float(region.height))

            committed = self.ime_bridge.drain_committed()
            if committed:
                result_log = self.state.setdefault("ime_results", [])
                for result in committed:
                    for ch in result:
                        self.io.add_input_character(ord(ch))
                    result_log.append(result)
                del result_log[:-8]

            self.imgui.new_frame()
            draw_gallery(self.imgui, self.state)
            self.ime_bridge.update(
                active=bool(self.state.get("ime_input_active", False)),
                region=region,
                anchor=self.state.get("ime_anchor"),
            )
            self.state["ime_info"] = self.ime_bridge.info()
            self.imgui.render()
            draw_data = self.imgui.get_draw_data()
            self.renderer.render(draw_data, region.width, region.height)

            self._drawn_serial = frame_serial
            self._last_draw_region_size = region_size
            STATE.frames += 1
            STATE.capture_mouse = bool(self.io.want_capture_mouse)
            STATE.capture_keyboard = bool(self.io.want_capture_keyboard)
            STATE.capture_text = bool(self.io.want_text_input)
            if not self.state.get("opened", True):
                self.closed = True
        except Exception:
            STATE.last_error = traceback.format_exc()
            lines = [line.strip() for line in STATE.last_error.splitlines() if line.strip()]
            STATE.status = "Draw error: " + (lines[-1] if lines else "unknown")
            self.closed = True

    def shutdown(self):
        for unsubscribe in tuple(getattr(self, "_event_unsubscribers", ()) or ()):
            try:
                unsubscribe()
            except Exception:
                pass
        self._event_unsubscribers = []

        # A0.12: persist stable UI + module/Core state on a normal Host shutdown.
        # Failure is isolated; closing LumaFold must never block Blender shutdown.
        try:
            APP.persistence.save(ui_state=self.export_transfer_state(), force=False)
        except Exception:
            pass
        try:
            self._release_owned_input()
        except Exception:
            pass
        if self.handler is not None:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(self.handler, "WINDOW")
            except Exception:
                pass
            self.handler = None
        if getattr(self, "ime_bridge", None) is not None:
            try:
                self.ime_bridge.shutdown()
            except Exception:
                pass
            self.ime_bridge = None
        if getattr(self, "preview_textures", None) is not None:
            try:
                self.preview_textures.shutdown()
            except Exception:
                pass
            self.preview_textures = None
        if self.renderer is not None:
            try:
                reset_icon_state(self.renderer)
            except Exception:
                pass
            try:
                self.renderer.shutdown()
            except Exception:
                STATE.last_error = traceback.format_exc()
            self.renderer = None
        reset_font_state()
        self.closed = True
        STATE.running = False
        STATE.host = None
        STATE.host_mode = "embedded"
        STATE.window_pointer = 0
        STATE.capture_mouse = False
        STATE.capture_keyboard = False
        STATE.capture_text = False
        if STATE.status != "Error":
            STATE.status = "Stopped"
