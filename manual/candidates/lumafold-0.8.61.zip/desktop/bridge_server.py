from __future__ import annotations

from dataclasses import dataclass, field
import json
import queue
import secrets
import socketserver
import threading
import time
from typing import Any, Dict, Optional

import bpy

from ..core.app import APP
from ..core.host_control import HOST_CONTROL
from ..modules.sculpt import sync_brush_state, sync_alpha_state


@dataclass
class PendingRequest:
    payload: Dict[str, Any]
    done: threading.Event = field(default_factory=threading.Event)
    response: Optional[Dict[str, Any]] = None


class _LocalOnlyTCPServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


class DesktopBridge:
    """Local-only process bridge.

    Socket threads only parse JSON and enqueue work. All bpy/Core access happens
    from the Blender main thread via bpy.app.timers.
    """

    def __init__(self):
        self.server: Optional[_LocalOnlyTCPServer] = None
        self.thread: Optional[threading.Thread] = None
        self.port: int = 0
        self.token: str = ""
        self.requests: "queue.Queue[PendingRequest]" = queue.Queue()
        self.running = False
        self.last_seen = 0.0
        self.last_error = ""
        self.client_name = ""
        self.request_count = 0
        self.desktop_process = None
        self.satellite_process = None
        self.satellite_ready = False
        self.satellite_active = False
        self.satellite_closing = False
        self.satellite_client = ""
        self.satellite_expected_generation = 0
        self.satellite_rect = None
        self._timer_registered = False

    @property
    def connected(self) -> bool:
        return self.running and (time.monotonic() - self.last_seen) < 1.5

    def start(self) -> None:
        if self.running and self.server is not None:
            return
        self.token = secrets.token_hex(24)
        bridge = self

        class Handler(socketserver.StreamRequestHandler):
            def handle(self):
                try:
                    raw = self.rfile.readline(256 * 1024)
                    if not raw:
                        return
                    payload = json.loads(raw.decode("utf-8"))
                    if not secrets.compare_digest(str(payload.get("token", "")), bridge.token):
                        response = {"ok": False, "error": "unauthorized"}
                    else:
                        req = PendingRequest(payload=payload)
                        bridge.requests.put(req)
                        if not req.done.wait(3.0):
                            response = {"ok": False, "error": "Blender main-thread bridge timeout"}
                        else:
                            response = req.response or {"ok": False, "error": "empty response"}
                    self.wfile.write((json.dumps(response, ensure_ascii=False) + "\n").encode("utf-8"))
                except Exception as exc:
                    try:
                        self.wfile.write((json.dumps({"ok": False, "error": f"{type(exc).__name__}: {exc}"}) + "\n").encode("utf-8"))
                    except Exception:
                        pass

        self.server = _LocalOnlyTCPServer(("127.0.0.1", 0), Handler)
        self.port = int(self.server.server_address[1])
        self.thread = threading.Thread(
            target=lambda: self.server.serve_forever(poll_interval=0.05),
            name="LumaFoldDesktopBridge",
            daemon=True,
        )
        self.thread.start()
        self.running = True
        self.last_error = ""
        if not self._timer_registered:
            self._timer_registered = True
            bpy.app.timers.register(self._pump_main_thread, first_interval=0.02, persistent=False)

    def _snapshot(self, client_name: str = "") -> Dict[str, Any]:
        # Keep the real Blender Sculpt Brush reflected into host-independent state.
        # _snapshot runs only on Blender's main thread through _pump_main_thread.
        sync_brush_state(APP)
        sync_alpha_state(APP)
        s = APP.state
        try:
            # Read the already-maintained Core context; do not mutate Host context
            # from a Bridge snapshot while a lease transfer may be in flight.
            sculpt_status = APP.modules.status("sculpt")
            context = APP.state.context
            try:
                workspace_name = str(getattr(getattr(bpy.context.window, "workspace", None), "name", "") or "")
            except Exception:
                workspace_name = ""
            sculpt_status_snapshot = {
                "active": bool(sculpt_status.active),
                "enabled": bool(sculpt_status.enabled),
                "reason": str(sculpt_status.reason or ""),
                "mode": str(context.mode or ""),
                "workspace": workspace_name,
            }
        except Exception as exc:
            sculpt_status_snapshot = {
                "active": True, "enabled": True, "reason": f"status unavailable: {exc}", "mode": "SCULPT", "workspace": ""
            }
        obj = bpy.context.view_layer.objects.active
        active = None
        if obj is not None:
            active = {
                "name": obj.name,
                "location": [float(obj.location.x), float(obj.location.y), float(obj.location.z)],
            }
        module_state = APP.store.snapshot()
        try:
            sculpt_state = dict(module_state.get("sculpt") or {})
            client = str(client_name or self.client_name or "")
            if client.startswith("LumaFold Satellite"):
                # The compact Satellite never renders the full library. Keep its
                # bridge snapshots small and responsive.
                for key in (
                    "brush_library_assets", "brush_library_folders", "brush_library_errors", "brush_library_preview_cache",
                    "alpha_library_assets", "alpha_library_folders", "alpha_library_errors", "alpha_library_preview_cache",
                ):
                    sculpt_state.pop(key, None)
            elif client.startswith("LumaFold Secondary"):
                # Secondary Brush Library needs its own previews/assets, but not
                # the compact-host quick-preview cache.
                sculpt_state.pop("brush_preview_cache", None)
                sculpt_state.pop("current_brush_preview", None)
                sculpt_state.pop("current_alpha_preview", None)
            module_state["sculpt"] = sculpt_state
        except Exception:
            pass

        return {
            "shared_counter": int(s.shared_counter),
            "shared_value": float(s.shared_value),
            "shared_enabled": bool(s.shared_enabled),
            "shared_text": str(s.shared_text),
            "last_command": str(s.last_command),
            "last_command_message": str(s.last_command_message),
            "last_command_ok": bool(s.last_command_ok),
            "command_count": int(s.command_count),
            "event_log": list(s.event_log[-8:]),
            "active_object": active,
            "blender_version": bpy.app.version_string,
            "sculpt_status": sculpt_status_snapshot,
            "modules": [
                {
                    "id": spec.module_id,
                    "label": spec.label,
                    "category": spec.category,
                    "version": spec.version,
                    "hosts": list(spec.hosts),
                    "capabilities": list(spec.capabilities),
                    "commands": list(spec.commands),
                }
                for spec in APP.modules.all()
            ],
            "services": APP.services.all_ids(),
            "module_state": module_state,
            "event_bus": [
                {"topic": event.topic, "payload": event.payload}
                for event in APP.events.tail(8)
            ],
            "host_control": {
                **HOST_CONTROL.snapshot(),
                "satellite_ready": bool(self.satellite_ready),
                "satellite_active": bool(self.satellite_active),
                "satellite_closing": bool(self.satellite_closing),
                "satellite_rect": dict(self.satellite_rect) if isinstance(self.satellite_rect, dict) else None,
            },
        }

    def _process(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        action = str(payload.get("action", ""))
        self.last_seen = time.monotonic()
        self.request_count += 1
        self.client_name = str(payload.get("client", "LumaFold Desktop"))
        satellite_client = self.client_name.startswith("LumaFold Satellite")
        if action in {"ping", "get_state"}:
            return {"ok": True, "state": self._snapshot(self.client_name)}
        if action == "set_state":
            fields = payload.get("fields") or {}
            s = APP.state
            if "shared_value" in fields:
                s.shared_value = max(0.0, min(1.0, float(fields["shared_value"])))
                s.log(f"desktop.shared_value = {s.shared_value:.3f}")
            if "shared_enabled" in fields:
                s.shared_enabled = bool(fields["shared_enabled"])
                s.log(f"desktop.shared_enabled = {s.shared_enabled}")
            if "shared_text" in fields:
                s.shared_text = str(fields["shared_text"])
                s.log("desktop.shared_text updated")
            if satellite_client:
                return {"ok": True}
            return {"ok": True, "state": self._snapshot(self.client_name)}
        if action == "command":
            command_id = str(payload.get("command_id", ""))
            kwargs = payload.get("kwargs") or {}
            result = APP.execute(command_id, **kwargs)
            response = {
                "ok": bool(result.ok),
                "command": {
                    "id": result.command_id,
                    "message": result.message,
                    "elapsed_ms": result.elapsed_ms,
                },
            }
            # Satellite already applies optimistic local UI state.  Returning a
            # full snapshot after every click/slider command duplicates work on
            # Blender's main thread and can accumulate into the first viewport
            # interaction after focus returns.  The 10 Hz get_state watchdog
            # remains the authoritative reconciliation path.
            if not satellite_client:
                response["state"] = self._snapshot(self.client_name)
            return response
        if action == "set_module_state":
            if str(payload.get("client", "")).startswith("LumaFold Satellite"):
                generation = int(payload.get("generation", 0) or 0)
                if not HOST_CONTROL.owns("satellite", generation):
                    return {"ok": False, "error": "stale or non-owner Satellite lease"}
            namespace = str(payload.get("namespace", "")).strip()
            fields = payload.get("fields") or {}
            if not namespace or not isinstance(fields, dict):
                return {"ok": False, "error": "invalid module state request"}
            target = APP.store.namespace(namespace)
            for key, value in fields.items():
                target[str(key)] = value

            # 0.8.58: Satellite Sculpt settings are applied at the explicit
            # bridge action boundary. No background watcher is allowed to defer
            # this work into the user's next viewport/sculpt interaction.
            if namespace == "sculpt" and (
                "brush_size" in fields or "brush_strength" in fields
            ):
                try:
                    service = APP.services.get("blender.sculpt_settings")
                    if service is not None:
                        kwargs = {}
                        if "brush_size" in fields:
                            kwargs["size"] = float(fields["brush_size"])
                        if "brush_strength" in fields:
                            kwargs["strength"] = float(fields["brush_strength"])
                        snap = dict(service.apply(**kwargs) or {})
                        if snap.get("available"):
                            target["brush_size"] = float(snap.get("size", target.get("brush_size", 72.0)))
                            target["brush_strength"] = float(snap.get("strength", target.get("brush_strength", 0.5)))
                except Exception:
                    pass

            APP.events.emit(f"{namespace}.state.changed", {"fields": dict(fields), "source": "satellite"})
            if satellite_client:
                return {"ok": True}
            return {"ok": True, "state": self._snapshot(self.client_name)}
        if action == "satellite_ready":
            generation = int(payload.get("generation", 0) or 0)
            if generation != int(self.satellite_expected_generation or 0):
                return {"ok": False, "error": "stale Satellite launch generation"}
            lease = HOST_CONTROL.snapshot()
            if lease.get("state") != "DETACHING" or lease.get("owner") != "embedded" or int(lease.get("generation", 0)) != generation:
                return {"ok": False, "error": "Satellite ready outside active detach lease"}
            self.satellite_ready = True
            self.satellite_closing = False
            self.satellite_client = str(payload.get("client", "LumaFold Satellite"))
            return {"ok": True, "state": self._snapshot(self.client_name)}
        if action == "satellite_closing":
            generation = int(payload.get("generation", 0) or 0)
            if generation and not HOST_CONTROL.owns("satellite", generation):
                return {"ok": False, "error": "stale Satellite close generation"}
            rect = payload.get("rect")
            if isinstance(rect, dict):
                self.satellite_rect = dict(rect)
            self.satellite_closing = True
            self.satellite_active = False
            return {"ok": True, "state": self._snapshot(self.client_name)}
        return {"ok": False, "error": f"Unknown action: {action}"}

    def _pump_main_thread(self):
        if not self.running:
            self._timer_registered = False
            return None
        processed = 0
        for _ in range(32):
            try:
                req = self.requests.get_nowait()
            except queue.Empty:
                break
            try:
                req.response = self._process(req.payload)
            except Exception as exc:
                self.last_error = f"{type(exc).__name__}: {exc}"
                req.response = {"ok": False, "error": self.last_error}
            finally:
                req.done.set()
                processed += 1
        # Keep interactive command latency reasonable without waking Blender's
        # main thread fifty times per second while the Satellite is idle.
        return 0.02 if processed else 0.10

    def stop_process(self) -> None:
        proc = self.desktop_process
        self.desktop_process = None
        if proc is not None and proc.poll() is None:
            try:
                proc.terminate()
                proc.wait(timeout=1.0)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass

    def _stop_transport_if_idle(self) -> None:
        desktop_alive = bool(self.desktop_process is not None and self.desktop_process.poll() is None)
        satellite_alive = bool(self.satellite_process is not None and self.satellite_process.poll() is None)
        if desktop_alive or satellite_alive:
            return

        # Retire Blender's bridge pump immediately. The timer unregisters itself
        # on its next callback because running is now False.
        self.running = False
        server = self.server
        self.server = None
        thread = self.thread
        self.thread = None
        if server is not None:
            try:
                server.shutdown()
                server.server_close()
            except Exception:
                pass

        while True:
            try:
                req = self.requests.get_nowait()
            except queue.Empty:
                break
            req.response = {"ok": False, "error": "bridge stopped"}
            req.done.set()

    def stop_satellite_process(self) -> None:
        proc = self.satellite_process
        self.satellite_process = None
        self.satellite_active = False
        self.satellite_ready = False
        self.satellite_closing = False
        self.satellite_client = ""
        self.satellite_expected_generation = 0
        if proc is not None and proc.poll() is None:
            try:
                proc.terminate()
                proc.wait(timeout=1.0)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass
        self._stop_transport_if_idle()

    def stop(self) -> None:
        self.stop_satellite_process()
        self.stop_process()
        self.running = False
        if self.server is not None:
            try:
                self.server.shutdown()
                self.server.server_close()
            except Exception:
                pass
        self.server = None
        self.thread = None
        while True:
            try:
                req = self.requests.get_nowait()
            except queue.Empty:
                break
            req.response = {"ok": False, "error": "bridge stopped"}
            req.done.set()


BRIDGE = DesktopBridge()
