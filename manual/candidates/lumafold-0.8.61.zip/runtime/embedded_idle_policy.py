from __future__ import annotations

"""Low-rate lifecycle watchdog for the Embedded Host.

0.8.56 removes the old redraw heartbeat entirely. Real pointer/key input is
event-driven and tags the View3D only when LumaFold itself is being operated.
The timer now exists only to keep workspace/host lifecycle truth healthy.
"""

import time

_INSTALLED = False
_ORIGINAL = None
_ORIGINAL_INVOKE = None
_OPERATORS = None
_WATCHDOG_INTERVAL = 1.00


def _timer_interval() -> float:
    return _WATCHDOG_INTERVAL


def install(operators_module) -> None:
    global _INSTALLED, _ORIGINAL, _ORIGINAL_INVOKE, _OPERATORS
    if _INSTALLED:
        return
    original = getattr(operators_module, "_context_pulse", None)
    toggle_cls = getattr(operators_module, "LUMAFOLD_OT_toggle_p0", None)
    original_invoke = getattr(toggle_cls, "invoke", None) if toggle_cls is not None else None
    if not callable(original) or not callable(original_invoke):
        return
    _OPERATORS = operators_module
    _ORIGINAL = original
    _ORIGINAL_INVOKE = original_invoke

    def watchdog_context_pulse(operator, host, host_id):
        now = time.perf_counter()
        last = float(getattr(operator, "_lumafold_watchdog_at", 0.0) or 0.0)
        if last > 0.0 and now - last < _WATCHDOG_INTERVAL:
            return None
        operator._lumafold_watchdog_at = now
        return original(operator, host, host_id)

    def invoke_with_watchdog_timer(self, context, event):
        result = original_invoke(self, context, event)
        if "RUNNING_MODAL" in set(result or ()):
            old_timer = getattr(self, "_timer", None)
            if old_timer is not None:
                try:
                    new_timer = context.window_manager.event_timer_add(
                        _timer_interval(), window=context.window
                    )
                except Exception:
                    new_timer = None
                if new_timer is not None:
                    try:
                        context.window_manager.event_timer_remove(old_timer)
                    except Exception:
                        pass
                    self._timer = new_timer
                    self._lumafold_watchdog_at = 0.0
        return result

    operators_module._context_pulse = watchdog_context_pulse
    toggle_cls.invoke = invoke_with_watchdog_timer
    _INSTALLED = True


def uninstall() -> None:
    global _INSTALLED, _ORIGINAL, _ORIGINAL_INVOKE, _OPERATORS
    if _INSTALLED and _OPERATORS is not None:
        if callable(_ORIGINAL):
            _OPERATORS._context_pulse = _ORIGINAL
        toggle_cls = getattr(_OPERATORS, "LUMAFOLD_OT_toggle_p0", None)
        if toggle_cls is not None and callable(_ORIGINAL_INVOKE):
            toggle_cls.invoke = _ORIGINAL_INVOKE
    _INSTALLED = False
    _ORIGINAL = None
    _ORIGINAL_INVOKE = None
    _OPERATORS = None


def snapshot():
    return {
        "installed": bool(_INSTALLED),
        "modal_timer_hz": 1.0,
        "idle_redraw_hz": 0.0,
        "event_driven_redraw": True,
    }
