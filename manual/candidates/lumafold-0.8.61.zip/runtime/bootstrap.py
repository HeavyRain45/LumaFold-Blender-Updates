import hashlib
import importlib
import os
import platform
import shutil
import sys
import threading
import traceback
import urllib.request
import zipfile
from pathlib import Path

import bpy

from ..core.state import STATE

RUNTIME_VERSION = "0.8.2"

# One product runtime version, two Python ABI builds:
# - Blender 5.0 ships CPython 3.11.
# - Newer supported Blender 5.x builds can use the CPython 3.12+ abi3 wheel.
# Keep the runtime cache split by ABI so installing/running multiple Blender
# versions on the same Windows account can never load the wrong native module.
_RUNTIME_SPECS = {
    "cp311": {
        "name": "slimgui-0.8.2-cp311-cp311-win_amd64.whl",
        "url": "https://files.pythonhosted.org/packages/fb/24/27ed99812c2a56253dc10fd6d7213664d51d932d6d9816f81a8d7bf543a5/slimgui-0.8.2-cp311-cp311-win_amd64.whl",
        "sha256": "d91665719a3a0ec2f9352d314c1f78d0425b124ca5016fefcc7039ffa0019a4d",
    },
    "cp312abi3": {
        "name": "slimgui-0.8.2-cp312-abi3-win_amd64.whl",
        "url": "https://files.pythonhosted.org/packages/82/66/33ec0d18d023d700fd177ac55a4709d99402d62d0e463f446fbad19b0b7e/slimgui-0.8.2-cp312-abi3-win_amd64.whl",
        "sha256": "1d48527068372a43eb52a0ac40857f1bcad8a1def93b17490f0cb3611fea56e8",
    },
}

_INSTALL_LOCK = threading.Lock()
_INSTALL = {
    "running": False,
    "done": False,
    "ok": False,
    "phase": "idle",
    "progress": 0.0,
    "error": "",
    "root": None,
    "wheel": None,
    "staging": None,
}


def _base_package():
    return __package__.rsplit('.runtime', 1)[0]


def _runtime_spec():
    py = tuple(int(v) for v in sys.version_info[:2])
    if py == (3, 11):
        return "cp311", _RUNTIME_SPECS["cp311"]
    if py >= (3, 12):
        return "cp312abi3", _RUNTIME_SPECS["cp312abi3"]
    raise RuntimeError(
        "LumaFold supports Blender/Python builds using CPython 3.11 or newer; current="
        + _environment_label()
    )


def runtime_root():
    abi_tag, _spec = _runtime_spec()
    return Path(bpy.utils.user_resource(
        "CONFIG",
        path=f"lumafold/runtime/{RUNTIME_VERSION}/{abi_tag}",
        create=True,
    ))


def vendor_dir():
    p = runtime_root() / "vendor"
    p.mkdir(parents=True, exist_ok=True)
    return p


def _activate_vendor_path():
    p = str(vendor_dir())
    if p not in sys.path:
        sys.path.insert(0, p)


def try_import():
    try:
        _activate_vendor_path()
        mod = importlib.import_module("slimgui")
        STATE.runtime_ready = True
        STATE.runtime_version = getattr(mod, "__version__", RUNTIME_VERSION)
        if not is_installing():
            STATE.status = "Runtime ready"
        return mod
    except Exception as exc:
        STATE.runtime_ready = False
        STATE.runtime_version = ""
        if not is_installing():
            STATE.last_error = f"slimgui import failed: {exc}"
            STATE.status = "Runtime missing"
        return None


def _verify(path: Path, expected_sha256: str):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest().lower() == str(expected_sha256 or "").lower()


def _environment_label():
    return (
        f"sys.platform={sys.platform}, machine={platform.machine()}, "
        f"bits={64 if sys.maxsize > 2**32 else 32}, "
        f"Python={sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    )


def _validate_environment():
    is_windows = sys.platform == "win32"
    is_64bit = sys.maxsize > 2**32
    machine = platform.machine().lower()
    is_x64_machine = machine in {"amd64", "x86_64", "x64"} or (not machine and is_64bit)
    py = sys.version_info[:2]

    if not (is_windows and is_64bit and is_x64_machine):
        raise RuntimeError(
            "LumaFold currently targets Windows x64; current=" + _environment_label()
        )
    if py < (3, 11):
        raise RuntimeError(
            "LumaFold requires CPython 3.11+; current=" + _environment_label()
        )
    _runtime_spec()


def is_installing():
    with _INSTALL_LOCK:
        return bool(_INSTALL["running"])


def install_snapshot():
    with _INSTALL_LOCK:
        return {
            "running": bool(_INSTALL["running"]),
            "phase": str(_INSTALL["phase"]),
            "progress": float(_INSTALL["progress"]),
            "error": str(_INSTALL["error"]),
        }


def _set_install(**kwargs):
    with _INSTALL_LOCK:
        _INSTALL.update(kwargs)


def _download_worker(root_s: str, wheel_s: str, staging_s: str, wheel_url: str, wheel_sha256: str):
    root = Path(root_s)
    wheel = Path(wheel_s)
    staging = Path(staging_s)
    temp = wheel.with_suffix(wheel.suffix + ".part")
    try:
        downloads = wheel.parent
        downloads.mkdir(parents=True, exist_ok=True)

        cached_ok = wheel.exists() and _verify(wheel, wheel_sha256)
        if cached_ok:
            _set_install(phase="Using cached runtime", progress=0.86)
        else:
            wheel.unlink(missing_ok=True)
            _set_install(phase="Downloading runtime", progress=0.02)
            req = urllib.request.Request(
                wheel_url,
                headers={"User-Agent": "LumaFold/0.8.51"},
            )
            with urllib.request.urlopen(req, timeout=20) as response, temp.open("wb") as out:
                total_header = response.headers.get("Content-Length")
                total = int(total_header) if total_header and total_header.isdigit() else 0
                received = 0
                while True:
                    block = response.read(128 * 1024)
                    if not block:
                        break
                    out.write(block)
                    received += len(block)
                    if total:
                        p = 0.02 + min(received / total, 1.0) * 0.83
                        _set_install(progress=p)
            os.replace(temp, wheel)

            _set_install(phase="Verifying runtime", progress=0.87)
            if not _verify(wheel, wheel_sha256):
                wheel.unlink(missing_ok=True)
                raise RuntimeError("Downloaded slimgui wheel failed SHA256 verification")

        _set_install(phase="Preparing runtime", progress=0.91)
        shutil.rmtree(staging, ignore_errors=True)
        staging.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(wheel, "r") as zf:
            zf.extractall(staging)

        _set_install(done=True, ok=True, phase="Finalizing runtime", progress=0.97)
    except Exception:
        try:
            temp.unlink(missing_ok=True)
        except Exception:
            pass
        _set_install(
            done=True,
            ok=False,
            error=traceback.format_exc(),
            phase="Runtime install failed",
            progress=0.0,
        )


def _install_poll():
    snap = install_snapshot()
    with _INSTALL_LOCK:
        done = bool(_INSTALL["done"])
        ok = bool(_INSTALL["ok"])
        error = str(_INSTALL["error"])
        root_s = _INSTALL["root"]
        staging_s = _INSTALL["staging"]

    if not done:
        STATE.status = snap["phase"]
        return 0.10

    if not ok:
        STATE.runtime_ready = False
        STATE.status = "Runtime install failed"
        STATE.last_error = error or "Unknown runtime install error"
        _set_install(running=False)
        return None

    try:
        root = Path(root_s)
        staging = Path(staging_s)
        vendor = root / "vendor"
        old = root / "vendor_old"
        shutil.rmtree(old, ignore_errors=True)
        if vendor.exists():
            vendor.rename(old)
        staging.rename(vendor)
        shutil.rmtree(old, ignore_errors=True)

        for key in list(sys.modules):
            if key == "slimgui" or key.startswith("slimgui."):
                del sys.modules[key]

        mod = try_import()
        if mod is None:
            raise RuntimeError(STATE.last_error or "slimgui import failed after install")
        STATE.last_error = ""
        STATE.status = "Runtime ready"
        _set_install(running=False, phase="Runtime ready", progress=1.0)
    except Exception:
        STATE.runtime_ready = False
        STATE.status = "Runtime install failed"
        STATE.last_error = traceback.format_exc()
        _set_install(running=False, phase="Runtime install failed", error=STATE.last_error, progress=0.0)
    return None


def begin_install_runtime_async():
    """Install the matching Windows x64 slimgui runtime in the background.

    Blender 5.0/Python 3.11 uses the cp311 wheel. Newer Blender/Python versions
    use the cp312 abi3 wheel. The result is cached per Python ABI in Blender's
    user CONFIG so different Blender versions can coexist safely.
    """
    _validate_environment()

    if try_import() is not None:
        return False
    if is_installing():
        return False

    _abi_tag, spec = _runtime_spec()
    root = runtime_root()
    downloads = root / "downloads"
    downloads.mkdir(parents=True, exist_ok=True)
    wheel = downloads / spec["name"]
    cached_ok = wheel.exists() and _verify(wheel, spec["sha256"])
    if not cached_ok and not getattr(bpy.app, "online_access", False):
        raise RuntimeError(
            "LumaFold 首次启动需要下载一次 UI runtime，但 Blender 当前禁止联网。"
            "请启用 Blender Online Access 后再次点击 LumaFold。"
        )
    staging = root / "vendor_staging"

    _set_install(
        running=True,
        done=False,
        ok=False,
        phase="Starting background install",
        progress=0.01,
        error="",
        root=str(root),
        wheel=str(wheel),
        staging=str(staging),
    )
    STATE.last_error = ""
    STATE.status = "Starting background install"

    worker = threading.Thread(
        target=_download_worker,
        args=(str(root), str(wheel), str(staging), spec["url"], spec["sha256"]),
        name="LumaFoldRuntimeInstaller",
        daemon=True,
    )
    worker.start()

    if not bpy.app.timers.is_registered(_install_poll):
        bpy.app.timers.register(_install_poll, first_interval=0.10, persistent=False)
    return True


def install_runtime():
    return begin_install_runtime_async()
