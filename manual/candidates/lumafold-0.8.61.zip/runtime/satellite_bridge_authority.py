from __future__ import annotations

"""Authoritative lightweight state path for native Satellite/Secondary hosts.

Bridge snapshots are transport only. They must never rescan Blender Brush/Alpha
state as a side effect of polling. Blender -> LumaFold resource truth is owned by
``SculptResourceSyncService``; this module only publishes already-maintained
Store state plus cached Blender Mode/Workspace truth.

The authority also keeps the compact Satellite wire contract so accumulated
preview/library caches cannot exceed the child receive budget.
"""

import time

from ..core.app import APP
from ..core.host_control import HOST_CONTROL
from ..core.state import STATE
from ..desktop import bridge_server
from ..ui import theme_wire
from . import theme_follow

_INSTALLED = False
_ORIGINAL_SNAPSHOT = None
_ORIGINAL_PROCESS = None
_TRUTH_PUBLISHING = False
_BLENDER_TRUTH = ("", "", 0)  # (mode, workspace, serial), atomically replaced
_THEME_WIRE_REFRESH_INTERVAL = 0.50
_THEME_WIRE_LAST_AT = 0.0
_THEME_WIRE_CACHE = {}

_SATELLITE_SCULPT_KEYS = (
    "quick_slot", "quick_rows", "slot_count", "quick_brush_slots", "active_quick_slot",
    "current_brush_name", "current_brush_asset", "current_brush_type",
    "current_brush_preview", "brush_sync_status", "brush_action_status",
    "brush_size", "brush_strength",
    "current_alpha_name", "current_alpha_identity", "current_alpha_filepath",
    "current_alpha_map_mode", "current_alpha_preview", "alpha_sync_status", "alpha_action_status",
    "input_profile", "quick_shortcuts", "quick_shortcuts_status", "quick_hotkey_bindings",
    "quick_replace_slot",
    "brush_library_status", "brush_library_scan_serial",
    "alpha_library_status", "alpha_library_scan_serial",
    "native_orbit_status", "native_shift_snap_bridge", "input_runtime_status",
)
_UI_KEYS = ("ui_scale", "requested_scale", "style_scale")
_SECONDARY_PREVIEW_BUDGET_BYTES = 384 * 1024
_SECONDARY_PREVIEW_MAX_ITEMS = 24


def _copy_selected(bucket, keys):
    result = {}
    for key in keys:
        if key not in bucket:
            continue
        value = bucket[key]
        if isinstance(value, dict):
            result[key] = dict(value)
        elif isinstance(value, list):
            result[key] = list(value)
        else:
            result[key] = value
    return result


def _asset_identity(slot) -> str:
    slot = dict(slot or {})
    rel = str(slot.get("relative_asset_identifier") or "").replace("\\", "/").strip()
    if not rel:
        return ""
    return "asset|{}|{}|{}".format(
        str(slot.get("asset_library_type") or "").casefold(),
        str(slot.get("asset_library_identifier") or "").casefold(),
        rel.casefold(),
    )


def _compact_quick_preview_cache(sculpt_bucket) -> dict:
    primary = dict(sculpt_bucket.get("primary_brush_preview_cache") or {})
    legacy = dict(sculpt_bucket.get("brush_preview_cache") or {})
    slots = list(sculpt_bucket.get("quick_brush_slots") or ())
    try:
        rows = max(2, min(4, int(sculpt_bucket.get("quick_rows", 2) or 2)))
    except Exception:
        rows = 2

    identities = []
    for slot in slots[: rows * 4]:
        identity = _asset_identity(slot)
        if identity and identity not in identities:
            identities.append(identity)

    compact = {}
    for identity in identities[:16]:
        payload = dict(primary.get(identity) or legacy.get(identity) or {})
        if payload.get("rgba_b64"):
            payload["key"] = identity
            compact[identity] = payload
    return compact


def _bounded_preview_cache(cache, *, max_items=_SECONDARY_PREVIEW_MAX_ITEMS, byte_budget=_SECONDARY_PREVIEW_BUDGET_BYTES):
    """Keep newest preview payloads under a deterministic wire budget.

    Native Secondary requests visible previews again when they are absent, so a
    snapshot never needs to carry every accumulated base64 preview.  Keeping a
    bounded tail prevents real user libraries from silently exceeding the
    Secondary socket receive cap while preserving the most recently requested
    assets.
    """
    items = list(dict(cache or {}).items())
    kept = []
    used = 0
    for identity, raw in reversed(items):
        payload = dict(raw or {})
        rgba = str(payload.get("rgba_b64") or "")
        if not rgba:
            continue
        estimated = len(rgba) + len(str(identity)) + 512
        if kept and used + estimated > int(byte_budget):
            continue
        if estimated > int(byte_budget):
            continue
        kept.append((str(identity), payload))
        used += estimated
        if len(kept) >= int(max_items):
            break
    kept.reverse()
    return dict(kept)


def _context_mode(context) -> str:
    if context is None:
        return ""
    try:
        value = str(getattr(context, "mode", "") or "")
        if value:
            return value
    except Exception:
        pass
    for name in ("object", "active_object"):
        try:
            obj = getattr(context, name, None)
            value = str(getattr(obj, "mode", "") or "")
            if value:
                return value
        except Exception:
            pass
    return ""


def _context_workspace(context) -> str:
    if context is None:
        return ""
    try:
        window = getattr(context, "window", None)
        return str(getattr(getattr(window, "workspace", None), "name", "") or "")
    except Exception:
        return ""


def publish_context_truth(context=None):
    global _BLENDER_TRUTH
    previous_mode, previous_workspace, serial = _BLENDER_TRUTH

    bpy_context = None
    try:
        import bpy
        bpy_context = bpy.context
    except Exception:
        bpy_context = None

    mode = _context_mode(context)
    workspace_name = _context_workspace(context)
    if not mode:
        mode = _context_mode(bpy_context)
    if not workspace_name:
        workspace_name = _context_workspace(bpy_context)
    if not mode:
        try:
            mode = str(getattr(APP.state.context, "mode", "") or "")
        except Exception:
            mode = ""

    mode = mode or previous_mode
    workspace_name = workspace_name or previous_workspace
    _BLENDER_TRUTH = (str(mode or ""), str(workspace_name or ""), int(serial) + 1)

    try:
        bridge = bridge_server.BRIDGE
        bridge.satellite_truth_mode = _BLENDER_TRUTH[0]
        bridge.satellite_truth_workspace = _BLENDER_TRUTH[1]
        bridge.satellite_truth_serial = _BLENDER_TRUTH[2]
    except Exception:
        pass

    return {
        "mode": _BLENDER_TRUTH[0],
        "workspace": _BLENDER_TRUTH[1],
        "serial": _BLENDER_TRUTH[2],
    }


def _publish_blender_truth(bpy_module=None):
    if bpy_module is None:
        result = publish_context_truth(None)
    else:
        try:
            result = publish_context_truth(getattr(bpy_module, "context", None))
        except Exception:
            result = publish_context_truth(None)
    return (
        str(result.get("mode") or ""),
        str(result.get("workspace") or ""),
        int(result.get("serial", 0) or 0),
    )


def _truth_timer():
    if not _TRUTH_PUBLISHING:
        return None
    # Do not poll Blender context merely because the add-on is enabled.
    # Active Embedded/Satellite hosts keep STATE.running true.
    if not bool(getattr(STATE, "running", False)):
        return 2.00
    try:
        publish_context_truth(None)
    except Exception:
        pass
    return 1.00


def _cached_blender_context_truth():
    mode, workspace_name, _serial = _BLENDER_TRUTH
    if not mode:
        try:
            mode = str(getattr(APP.state.context, "mode", "") or "")
        except Exception:
            mode = ""
    return str(mode or ""), str(workspace_name or "")


def truth_snapshot():
    mode, workspace_name, serial = _BLENDER_TRUTH
    return {"mode": str(mode or ""), "workspace": str(workspace_name or ""), "serial": int(serial or 0)}


def _theme_follow_wire_snapshot():
    """Publish Blender-authored semantic tokens without mutating parent UI state.

    Embedded Theme Follow keeps its existing frame-boundary poll. Native child
    processes receive the same derived semantic tokens over the bridge, so they
    never import bpy or guess Blender widget colors on their own.
    """
    global _THEME_WIRE_LAST_AT, _THEME_WIRE_CACHE
    now = time.monotonic()
    if _THEME_WIRE_CACHE and now - float(_THEME_WIRE_LAST_AT) < _THEME_WIRE_REFRESH_INTERVAL:
        return dict(_THEME_WIRE_CACHE)

    try:
        raw_snapshot = theme_follow.blender_theme_snapshot()
        if not raw_snapshot:
            return dict(_THEME_WIRE_CACHE)
        tokens = theme_follow._tokens_from_snapshot(raw_snapshot)
        payload = theme_wire.build_payload(tokens, source="Blender Preferences Theme")
        if payload:
            _THEME_WIRE_CACHE = dict(payload)
            _THEME_WIRE_LAST_AT = now
    except Exception:
        pass
    return dict(_THEME_WIRE_CACHE)


def _status_snapshot():
    mode, workspace_name = _cached_blender_context_truth()
    try:
        sculpt_status = APP.modules.status("sculpt")
        return {
            "active": bool(sculpt_status.active),
            "enabled": bool(sculpt_status.enabled),
            "reason": str(sculpt_status.reason or ""),
            "mode": mode,
            "workspace": workspace_name,
        }
    except Exception as exc:
        return {
            "active": True,
            "enabled": True,
            "reason": f"status unavailable: {exc}",
            "mode": mode or "SCULPT",
            "workspace": workspace_name,
        }


def _active_object_snapshot(bpy):
    obj = getattr(getattr(bpy.context, "view_layer", None), "objects", None)
    obj = getattr(obj, "active", None) if obj is not None else None
    if obj is None:
        return None
    try:
        return {
            "name": obj.name,
            "location": [float(obj.location.x), float(obj.location.y), float(obj.location.z)],
        }
    except Exception:
        return {"name": str(getattr(obj, "name", "")), "location": [0.0, 0.0, 0.0]}


def _common_state(module_state):
    import bpy

    s = APP.state
    bridge = bridge_server.BRIDGE
    return {
        "shared_counter": int(s.shared_counter),
        "shared_value": float(s.shared_value),
        "shared_enabled": bool(s.shared_enabled),
        "shared_text": str(s.shared_text),
        "last_command": str(s.last_command),
        "last_command_message": str(s.last_command_message),
        "last_command_ok": bool(s.last_command_ok),
        "command_count": int(s.command_count),
        "event_log": list(s.event_log[-8:]),
        "active_object": _active_object_snapshot(bpy),
        "blender_version": bpy.app.version_string,
        "sculpt_status": _status_snapshot(),
        "theme_follow": _theme_follow_wire_snapshot(),
        "modules": [
            {
                "id": spec.module_id,
                "label": spec.label,
                "category": spec.category,
                "version": spec.version,
                "hosts": list(spec.hosts),
                "capabilities": list(spec.capabilities),
                "commands": list(spec.commands),
            }
            for spec in APP.modules.all()
        ],
        "services": APP.services.all_ids(),
        "module_state": module_state,
        "event_bus": [
            {"topic": event.topic, "payload": event.payload}
            for event in APP.events.tail(8)
        ],
        "host_control": {
            **HOST_CONTROL.snapshot(),
            "satellite_ready": bool(bridge.satellite_ready),
            "satellite_active": bool(bridge.satellite_active),
            "satellite_closing": bool(bridge.satellite_closing),
            "satellite_rect": dict(bridge.satellite_rect) if isinstance(bridge.satellite_rect, dict) else None,
        },
    }


def _satellite_snapshot(_client_name: str):
    sculpt_bucket = APP.store.namespace("sculpt")
    ui_bucket = APP.store.namespace("__ui__")
    sculpt_state = _copy_selected(sculpt_bucket, _SATELLITE_SCULPT_KEYS)
    sculpt_state["brush_preview_cache"] = _compact_quick_preview_cache(sculpt_bucket)
    return _common_state({
        "sculpt": sculpt_state,
        "__ui__": _copy_selected(ui_bucket, _UI_KEYS),
    })


def _secondary_snapshot(_client_name: str):
    # Secondary receives full asset/folder metadata, but base64 preview caches are
    # bounded independently.  A real user library can otherwise grow beyond the
    # child's 2 MiB socket receive cap and leave the Secondary stuck on its empty
    # startup snapshot ("全部 · 0"). Missing previews are requested lazily by UI.
    module_state = APP.store.snapshot()
    sculpt_state = dict(module_state.get("sculpt") or {})
    sculpt_state.pop("brush_preview_cache", None)
    sculpt_state.pop("current_brush_preview", None)
    sculpt_state.pop("current_alpha_preview", None)
    for key in (
        "brush_library_preview_cache",
        "primary_brush_preview_cache",
        "alpha_library_preview_cache",
        "primary_alpha_preview_cache",
    ):
        if key in sculpt_state:
            sculpt_state[key] = _bounded_preview_cache(sculpt_state.get(key))
    sculpt_state["secondary_preview_wire_budget"] = int(_SECONDARY_PREVIEW_BUDGET_BYTES)
    module_state["sculpt"] = sculpt_state
    return _common_state(module_state)


def _enforce_satellite_wire_truth(response, client_name: str = ""):
    if not isinstance(response, dict):
        return response
    client = str(client_name or "")
    if not client.startswith("LumaFold Satellite"):
        return response
    state = response.get("state")
    if not isinstance(state, dict):
        return response

    mode, workspace_name = _cached_blender_context_truth()
    status = dict(state.get("sculpt_status") or {})
    if mode:
        status["mode"] = str(mode)
    if workspace_name:
        status["workspace"] = str(workspace_name)
    state["sculpt_status"] = status
    state["satellite_context_truth"] = truth_snapshot()
    response["state"] = state
    return response


def install():
    global _INSTALLED, _ORIGINAL_SNAPSHOT, _ORIGINAL_PROCESS, _TRUTH_PUBLISHING
    if _INSTALLED:
        return

    bridge = bridge_server.BRIDGE
    original_snapshot = getattr(bridge, "_snapshot", None)
    original_process = getattr(bridge, "_process", None)
    if not callable(original_snapshot):
        raise RuntimeError("Live Desktop Bridge snapshot entry is unavailable")
    if not callable(original_process):
        raise RuntimeError("Live Desktop Bridge process entry is unavailable")

    _ORIGINAL_SNAPSHOT = original_snapshot
    _ORIGINAL_PROCESS = original_process

    _TRUTH_PUBLISHING = True
    # Publish one initial snapshot only. Later truth updates are explicit at
    # Host/context transitions and Satellite handoff boundaries; Embedded keeps
    # no permanent context-poll timer.
    try:
        import bpy
        _publish_blender_truth(bpy)
    except Exception:
        pass

    def snapshot_authority(client_name: str = ""):
        client = str(client_name or bridge.client_name or "")
        if client.startswith("LumaFold Satellite"):
            return _satellite_snapshot(client)
        if client.startswith("LumaFold Secondary"):
            return _secondary_snapshot(client)
        return _ORIGINAL_SNAPSHOT(client_name)

    def process_authority(payload):
        payload = dict(payload or {})
        action = str(payload.get("action") or "")
        # Context truth is refreshed only when a child explicitly asks for a
        # snapshot/ready handshake. No permanent Blender polling is required.
        if action in {"get_state", "satellite_ready"}:
            try:
                publish_context_truth(None)
            except Exception:
                pass
        response = _ORIGINAL_PROCESS(payload)
        client = str(payload.get("client") or bridge.client_name or "")
        return _enforce_satellite_wire_truth(response, client)

    bridge._snapshot = snapshot_authority
    bridge._process = process_authority
    _INSTALLED = True


def uninstall():
    global _INSTALLED, _ORIGINAL_SNAPSHOT, _ORIGINAL_PROCESS, _TRUTH_PUBLISHING
    global _THEME_WIRE_LAST_AT, _THEME_WIRE_CACHE
    if not _INSTALLED:
        return
    _TRUTH_PUBLISHING = False
    bridge = bridge_server.BRIDGE
    if callable(_ORIGINAL_PROCESS):
        bridge._process = _ORIGINAL_PROCESS
    if callable(_ORIGINAL_SNAPSHOT):
        bridge._snapshot = _ORIGINAL_SNAPSHOT
    _ORIGINAL_PROCESS = None
    _ORIGINAL_SNAPSHOT = None
    _THEME_WIRE_LAST_AT = 0.0
    _THEME_WIRE_CACHE = {}
    _INSTALLED = False