from __future__ import annotations

"""Compatibility shim for the retired preview/Sculpt warm-up layer.

0.8.56 removes all background Sculpt warm-up from the normal product path.
LumaFold must never rebuild Sculpt BVH, ray-cast the active sculpt object, or
otherwise mutate/warm Blender sculpt data merely because the UI is enabled.

Preview extraction is now demand-driven by preview_scheduler only.
These functions remain as no-op compatibility hooks for older unregister/test
paths so upgrades do not need a second lifecycle implementation.
"""

_INSTALLED = False


def configure(preview_module, input_profile):
    global _INSTALLED
    _INSTALLED = True
    return None


def unconfigure():
    global _INSTALLED
    _INSTALLED = False
    return None


def snapshot():
    return {
        "installed": bool(_INSTALLED),
        "sculpt_warmup": False,
        "bvh_rebuild": False,
        "raycast_warmup": False,
    }
