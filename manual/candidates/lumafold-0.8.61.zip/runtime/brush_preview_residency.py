from __future__ import annotations

"""Resident native Brush thumbnail adapter.

This module owns only Brush-library preview residency. Blender remains the image
source of truth; LumaFold merely keeps Blender's PreviewCollection alive long
enough that scrolling/reopening a library does not repeatedly recreate and tear
down native thumbnail resources.

The adapter sits at the public ``blender.brush.brush_asset_previews`` service
boundary and is fully reversible on unregister. It does not own Brush assets,
Host rendering, input, UI layout, or preview scheduling.
"""

import hashlib
import time

from ..core.app import APP


_MAX_NATIVE_ITEMS = 24
_FAILED_RETRY_SECONDS = 0.65
_INSTALLED = False
_SERVICE = None
_ORIGINAL = None
_COLLECTION = None
_NATIVE_KEYS = {}
_NATIVE_TOUCH = {}
_FAILED_AT = {}


def _identity(service, spec) -> str:
    try:
        return str(service._asset_identity(dict(spec or {})) or "")
    except Exception:
        return ""


def _native_key(identity: str, filepath: str) -> str:
    raw = (str(identity) + "\n" + str(filepath)).encode("utf-8", errors="replace")
    return "lf_" + hashlib.sha1(raw).hexdigest()


def _ensure_collection():
    global _COLLECTION
    if _COLLECTION is not None:
        return _COLLECTION
    import bpy.utils.previews
    _COLLECTION = bpy.utils.previews.new()
    return _COLLECTION


def _collection_get(collection, key: str):
    try:
        return collection.get(key)
    except Exception:
        try:
            return collection[key]
        except Exception:
            return None


def _trim_native_collection():
    """Bound native residency without rebuilding the whole collection."""
    if len(_NATIVE_KEYS) <= _MAX_NATIVE_ITEMS:
        return
    ordered = sorted(_NATIVE_TOUCH.items(), key=lambda item: float(item[1]))
    remove_count = max(0, len(_NATIVE_KEYS) - _MAX_NATIVE_ITEMS)
    collection = _COLLECTION
    for identity, _stamp in ordered[:remove_count]:
        key = _NATIVE_KEYS.pop(identity, "")
        _NATIVE_TOUCH.pop(identity, None)
        _FAILED_AT.pop(identity, None)
        if collection is not None and key:
            try:
                del collection[key]
            except Exception:
                pass


def _resident_thumbnail(service, spec, max_edge: int):
    identity = _identity(service, spec)
    if not identity:
        return {}
    now = time.monotonic()
    failed_at = float(_FAILED_AT.get(identity, 0.0) or 0.0)
    if failed_at and now - failed_at < _FAILED_RETRY_SECONDS:
        return {}

    try:
        filepath = str(service._blend_id_preview_path(dict(spec or {})) or "")
    except Exception:
        filepath = ""
    if not filepath:
        return {}

    collection = _ensure_collection()
    key = _NATIVE_KEYS.get(identity) or _native_key(identity, filepath)
    preview = _collection_get(collection, key)
    if preview is None:
        try:
            preview = collection.load(key, filepath, "BLEND")
            _NATIVE_KEYS[identity] = key
        except Exception:
            preview = None

    payload = {}
    if preview is not None:
        try:
            payload = dict(service._image_preview_payload(preview, max_edge=max_edge) or {})
        except Exception:
            payload = {}

    # Blender's thumbnail manager may need one native reload before pixels become
    # available. Retry inside the same resident PreviewImage instead of creating
    # another collection / decoding the .blend thumbnail from scratch.
    if not payload and preview is not None:
        try:
            preview.reload()
        except Exception:
            pass
        try:
            payload = dict(service._image_preview_payload(preview, max_edge=max_edge) or {})
        except Exception:
            payload = {}

    if payload.get("rgba_b64"):
        payload["key"] = identity
        payload["source"] = str(payload.get("source") or "") + "+resident_blend_thumb"
        _NATIVE_KEYS[identity] = key
        _NATIVE_TOUCH[identity] = now
        _FAILED_AT.pop(identity, None)
        _trim_native_collection()
        try:
            service._thumbnail_hits += 1
            service._last_preview_path = "resident_blend_thumb"
        except Exception:
            pass
        return payload

    _FAILED_AT[identity] = now
    try:
        service._thumbnail_misses += 1
    except Exception:
        pass
    return {}


def _resident_batch(service, specs, max_edge: int = 64):
    specs = [dict(item or {}) for item in list(specs or ())]
    if not specs:
        return {}

    results = {}
    missing = []
    try:
        current = dict(service.current_sculpt_brush() or {})
        current_identity = _identity(service, current)
    except Exception:
        current_identity = ""

    for spec in specs:
        identity = _identity(service, spec)
        if not identity:
            continue
        payload = {}
        if current_identity and identity == current_identity:
            try:
                payload = dict(service.current_sculpt_brush_preview(max_edge=max_edge) or {})
            except Exception:
                payload = {}
        if not payload:
            payload = _resident_thumbnail(service, spec, max_edge)
        if payload.get("rgba_b64"):
            payload["key"] = identity
            results[identity] = payload
        else:
            missing.append(spec)

    # Preserve the existing serialized Brush-ID fallback for genuinely missing
    # thumbnails only. The normal path never appends/removes Brush datablocks,
    # eliminating the old per-thumbnail main-thread churn.
    if missing:
        try:
            fallback = dict(service._linked_preview_batch(missing, max_edge=max_edge) or {})
        except Exception:
            fallback = {}
        results.update(fallback)
    return results


def install() -> None:
    global _INSTALLED, _SERVICE, _ORIGINAL
    if _INSTALLED:
        return
    service = APP.services.get("blender.brush")
    if service is None:
        return
    original = getattr(service, "brush_asset_previews", None)
    if not callable(original):
        return
    required = (
        "_asset_identity", "_blend_id_preview_path", "_image_preview_payload",
        "_linked_preview_batch", "current_sculpt_brush", "current_sculpt_brush_preview",
    )
    if not all(callable(getattr(service, name, None)) for name in required):
        return

    def brush_asset_previews(asset_specs, max_edge: int = 64):
        return _resident_batch(service, asset_specs, max_edge=max_edge)

    _SERVICE = service
    _ORIGINAL = original
    service.brush_asset_previews = brush_asset_previews
    _INSTALLED = True


def uninstall() -> None:
    global _INSTALLED, _SERVICE, _ORIGINAL, _COLLECTION
    if _SERVICE is not None and callable(_ORIGINAL):
        try:
            _SERVICE.brush_asset_previews = _ORIGINAL
        except Exception:
            pass
    if _COLLECTION is not None:
        try:
            import bpy.utils.previews
            bpy.utils.previews.remove(_COLLECTION)
        except Exception:
            try:
                _COLLECTION.close()
            except Exception:
                pass
    _COLLECTION = None
    _NATIVE_KEYS.clear()
    _NATIVE_TOUCH.clear()
    _FAILED_AT.clear()
    _SERVICE = None
    _ORIGINAL = None
    _INSTALLED = False


def snapshot() -> dict:
    return {
        "installed": bool(_INSTALLED),
        "native_resident": int(len(_NATIVE_KEYS)),
        "retry_backoff": int(len(_FAILED_AT)),
        "max_native_items": int(_MAX_NATIVE_ITEMS),
    }
