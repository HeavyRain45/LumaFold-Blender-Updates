from __future__ import annotations

import sys
import time
from pathlib import Path

# This host is also launched directly from desktop/. Preserve the same bootstrap
# contract as the frozen runtime before importing package-qualified modules.
EXT_ROOT = Path(__file__).resolve().parent.parent
if str(EXT_ROOT) not in sys.path:
    sys.path.insert(0, str(EXT_ROOT))

from desktop import secondary_surface_host_runtime as _runtime
from desktop import secondary_transport_policy as _transport_policy
from ui import theme_wire as _theme_wire
from ui.sculpt_more_view import draw_more_foundation

# Transport owns post-command state recovery. A successful command ACK may not
# erase the last complete Secondary snapshot.
_transport_policy.install(_runtime)

# Product UI resolves the Native command boundary through __main__ because the
# same module is imported by Blender and standalone children. The executable
# entry module is *this* wrapper, not secondary_surface_host_runtime, so expose
# the runtime adapters here explicitly.
def _queue_command(command_id, **kwargs):
    return _runtime._queue_command(command_id, **kwargs)


def _queue_state(fields):
    return _runtime._queue_state(fields)


# Native Secondary surfaces behave like menus: once the opening mouse gesture
# has been released, the next click anywhere outside the Secondary window hides
# it. Polling GetAsyncKeyState avoids a global hook and also catches clicks in
# Blender, which are not delivered to this child HWND.
_VK_BUTTONS = (0x01, 0x02, 0x04)
_VK_ESCAPE = 0x1B
WM_APP_QUICK_REPLACE_SLOT = 0x8052
WM_APP_PRIMARY_BRUSH_VISUAL_SYNC = 0x8053
WM_MOUSEACTIVATE = 0x0021
MA_NOACTIVATE = 3
_outside_visible_last = False
_outside_armed = False
_outside_down_last = {vk: False for vk in _VK_BUTTONS}
_escape_down_last = False
try:
    _runtime.user32.GetAsyncKeyState.argtypes = [_runtime.ctypes.c_int]
    _runtime.user32.GetAsyncKeyState.restype = _runtime.ctypes.c_short
    _runtime.user32.GetCursorPos.argtypes = [_runtime.ctypes.POINTER(_runtime.POINT)]
    _runtime.user32.GetCursorPos.restype = _runtime.wintypes.BOOL
except Exception:
    pass

_target_quick_slot = -1
_last_theme_signature = ""
_original_wndproc = _runtime.wndproc


@_runtime.WNDPROC
def _wndproc_with_product_boundary(hwnd, msg, wparam, lparam):
    global _target_quick_slot
    if int(msg) == WM_MOUSEACTIVATE:
        return MA_NOACTIVATE
    if int(msg) == WM_APP_QUICK_REPLACE_SLOT:
        _target_quick_slot = int(wparam) - 1
        return 0
    if int(msg) == int(_runtime.WM_APP_SECONDARY_KIND):
        try:
            _runtime.actions.put_nowait({"action": "get_state"})
        except Exception:
            pass
    return _original_wndproc(hwnd, msg, wparam, lparam)


_runtime.wndproc = _wndproc_with_product_boundary


def _network_worker_watchdog():
    """Event-driven Secondary transport; no idle full get_state polling."""
    while not _runtime.closing_event.is_set():
        if not _runtime.parent_alive():
            _runtime.closing_event.set()
            return
        try:
            payload = _runtime.actions.get(timeout=0.25)
        except _runtime.queue.Empty:
            continue

        try:
            response = _runtime.request(payload)
            if (
                bool(response.get("ok"))
                and str(payload.get("action") or "") == "get_brush_preview_delta"
            ):
                _merge_brush_preview_delta(response, payload)

            if response.get("ok") and isinstance(response.get("state"), dict):
                snapshot = dict(response.get("state") or {})
                with _runtime.state_lock:
                    _runtime.bridge_state = snapshot
                    ui_state = dict(((snapshot.get("module_state") or {}).get("__ui__") or {}))
                    requested = float(ui_state.get("ui_scale", ui_state.get("requested_scale", _runtime.current_scale)) or _runtime.current_scale)
                    _runtime.current_scale = max(0.85, min(2.0, requested))

            if (
                bool(response.get("ok"))
                and str(payload.get("action") or "") == "command"
                and str(payload.get("command_id") or "") == "sculpt.brush.library_replace_slot"
                and int(_runtime.ARGS.owner_hwnd or 0)
            ):
                _runtime.user32.PostMessageW(
                    _runtime.HWND(int(_runtime.ARGS.owner_hwnd)),
                    WM_APP_PRIMARY_BRUSH_VISUAL_SYNC,
                    0, 0,
                )
        except Exception:
            _runtime.time.sleep(0.05)


_runtime._network_worker = _network_worker_watchdog

_stable_brush_previews = {}
_stable_alpha_previews = {}
_preview_inflight = set()
_preview_retry_after = {}
_PREVIEW_BATCH = 4
_PREVIEW_MAX_INFLIGHT = 8
_PREVIEW_RETRY_SECONDS = 0.70


def _request_brush_preview_delta(identities):
    """Queue only exact visible Brush previews; never a full snapshot."""
    requested_map = _runtime.library_ui_state.setdefault("brush_preview_requested", {})
    now = _runtime.time.monotonic()
    ids = []
    for raw in list(identities or ()):
        identity = str(raw or "")
        if identity and identity not in ids:
            ids.append(identity)

    capacity = max(0, int(_PREVIEW_MAX_INFLIGHT) - len(_preview_inflight))
    batch = []
    for identity in ids:
        if identity in _preview_inflight:
            continue
        if now < float(_preview_retry_after.get(identity, 0.0) or 0.0):
            requested_map.pop(identity, None)
            continue
        if len(batch) < min(int(_PREVIEW_BATCH), capacity):
            batch.append(identity)
        else:
            # Shared gallery pre-marks up to 16 ids. Release ids
            # we did not enqueue so the next frame can offer them.
            requested_map.pop(identity, None)

    if not batch:
        return
    _preview_inflight.update(batch)
    try:
        _runtime.actions.put_nowait({
            "action": "get_brush_preview_delta",
            "identities": list(batch),
        })
    except Exception:
        for identity in batch:
            _preview_inflight.discard(identity)
            requested_map.pop(identity, None)


def _merge_brush_preview_delta(response, payload):
    delta = dict(response.get("preview_delta") or {})
    requested = [str(x) for x in list(payload.get("identities") or ()) if str(x or "")]
    now = _runtime.time.monotonic()
    requested_map = _runtime.library_ui_state.setdefault("brush_preview_requested", {})

    with _runtime.state_lock:
        snapshot = dict(_runtime.bridge_state or {})
        module_state = dict(snapshot.get("module_state") or {})
        sculpt = dict(module_state.get("sculpt") or {})
        cache = dict(sculpt.get("brush_library_preview_cache") or {})
        for identity, raw in delta.items():
            payload_preview = dict(raw or {})
            if payload_preview.get("rgba_b64"):
                payload_preview["key"] = str(identity)
                cache[str(identity)] = payload_preview
        while len(cache) > 128:
            cache.pop(next(iter(cache)), None)
        sculpt["brush_library_preview_cache"] = cache
        module_state["sculpt"] = sculpt
        snapshot["module_state"] = module_state
        _runtime.bridge_state = snapshot

    for identity in requested:
        _preview_inflight.discard(identity)
        requested_map.pop(identity, None)
        if identity in delta:
            _preview_retry_after.pop(identity, None)
        else:
            _preview_retry_after[identity] = now + float(_PREVIEW_RETRY_SECONDS)


def _button_state(vk):
    try:
        raw = int(_runtime.user32.GetAsyncKeyState(int(vk)))
    except Exception:
        return False, False
    return bool(raw & 0x8000), bool(raw & 0x0001)


def _escape_dismiss_tick():
    global _escape_down_last, _outside_visible_last, _outside_armed
    hwnd = _runtime.hwnd_main
    down, pressed_since = _button_state(_VK_ESCAPE)
    new_press = bool(down and not _escape_down_last) or bool(pressed_since)
    _escape_down_last = bool(down)
    if not hwnd:
        return False
    try:
        visible = bool(_runtime.user32.IsWindowVisible(hwnd))
    except Exception:
        visible = False
    if not visible or not new_press:
        return False
    try:
        _runtime.user32.ShowWindow(hwnd, _runtime.SW_HIDE)
        _outside_visible_last = False
        _outside_armed = False
        return True
    except Exception:
        return False


def _outside_click_dismiss_tick():
    global _outside_visible_last, _outside_armed
    hwnd = _runtime.hwnd_main
    if not hwnd:
        return False
    try:
        visible = bool(_runtime.user32.IsWindowVisible(hwnd))
    except Exception:
        visible = False

    states = {vk: _button_state(vk) for vk in _VK_BUTTONS}
    any_down = any(down for down, _pressed in states.values())

    if not visible:
        _outside_visible_last = False
        _outside_armed = False
        for vk, (down, _pressed) in states.items():
            _outside_down_last[vk] = bool(down)
        return False

    if not _outside_visible_last:
        _outside_visible_last = True
        _outside_armed = not any_down
        for vk, (down, _pressed) in states.items():
            _outside_down_last[vk] = bool(down)
        return False

    if not _outside_armed:
        if not any_down:
            _outside_armed = True
        for vk, (down, _pressed) in states.items():
            _outside_down_last[vk] = bool(down)
        return False

    clicked = False
    for vk, (down, pressed_since) in states.items():
        if (down and not _outside_down_last.get(vk, False)) or pressed_since:
            clicked = True
            break
    for vk, (down, _pressed) in states.items():
        _outside_down_last[vk] = bool(down)
    if not clicked:
        return False

    pt = _runtime.POINT()
    wr = _runtime.wintypes.RECT()
    try:
        if not (_runtime.user32.GetCursorPos(_runtime.ctypes.byref(pt)) and _runtime.user32.GetWindowRect(hwnd, _runtime.ctypes.byref(wr))):
            return False
    except Exception:
        return False
    inside = int(wr.left) <= int(pt.x) < int(wr.right) and int(wr.top) <= int(pt.y) < int(wr.bottom)
    if inside:
        return False
    try:
        _runtime.user32.ShowWindow(hwnd, _runtime.SW_HIDE)
        _outside_visible_last = False
        _outside_armed = False
        return True
    except Exception:
        return False


def _merge_cache(stable: dict, incoming: dict, limit: int):
    for identity, raw in dict(incoming or {}).items():
        payload = dict(raw or {})
        if payload.get("rgba_b64"):
            stable[str(identity)] = payload
    while len(stable) > int(limit):
        stable.pop(next(iter(stable)), None)
    return dict(stable)


def _merge_real_preview_caches(sculpt):
    brush = dict(sculpt.get("brush_library_preview_cache") or {})
    brush.update(dict(sculpt.get("primary_brush_preview_cache") or {}))
    sculpt["brush_library_preview_cache"] = _merge_cache(_stable_brush_previews, brush, 128)

    alpha = dict(sculpt.get("alpha_library_preview_cache") or {})
    alpha.update(dict(sculpt.get("primary_alpha_preview_cache") or {}))
    sculpt["alpha_library_preview_cache"] = _merge_cache(_stable_alpha_previews, alpha, 96)
    return sculpt


def _apply_theme_follow_snapshot(snapshot) -> bool:
    """Apply the same parent-authored semantic theme to one Secondary frame."""
    global _last_theme_signature
    try:
        payload = dict((snapshot or {}).get("theme_follow") or {})
        signature, changed = _theme_wire.apply_payload(payload, _runtime.T)
        if not signature:
            return False
        if not changed and signature == _last_theme_signature:
            return False

        # The normal draw path already owns style application. Invalidate its
        # scale sentinel so all Blender Dark/Light border rules are recomputed at
        # this frame boundary, then keep the native clear color in the same
        # Secondary surface family to avoid edge flashes around the rounded HWND.
        _runtime._applied_scale = None
        if _runtime.renderer is not None:
            _runtime.renderer.clear_linear_rgb = tuple(_runtime.T.SECONDARY_SURFACE_BG[:3])
        _last_theme_signature = signature
        return True
    except Exception:
        return False


def _draw_frame():
    global _target_quick_slot
    if _runtime.renderer is None or _runtime.io is None:
        return
    _escape_dismiss_tick()
    _outside_click_dismiss_tick()
    cr = _runtime.wintypes.RECT()
    if not _runtime.user32.GetClientRect(_runtime.hwnd_main, _runtime.ctypes.byref(cr)):
        return
    width = max(1, int(cr.right - cr.left))
    height = max(1, int(cr.bottom - cr.top))
    now = time.perf_counter()
    _runtime.io.delta_time = max(1.0 / 1000.0, min(0.1, now - _runtime.last_frame_time))
    _runtime.last_frame_time = now
    _runtime.io.display_size = (float(width), float(height))
    _runtime.io.display_framebuffer_scale = (1.0, 1.0)

    with _runtime.state_lock:
        snapshot = dict(_runtime.bridge_state)
    sculpt = _merge_real_preview_caches(dict(((snapshot.get("module_state") or {}).get("sculpt") or {})))

    _runtime.renderer.make_current()
    _runtime.imgui.set_current_context(_runtime.imgui_context)
    _apply_theme_follow_snapshot(snapshot)
    if _runtime._applied_scale is None or abs(float(_runtime._applied_scale) - float(_runtime.current_scale)) > 1e-6:
        _runtime.apply_style(_runtime.imgui, _runtime.current_scale)
        _runtime._applied_scale = float(_runtime.current_scale)
    _runtime.imgui.new_frame()
    _runtime.imgui.set_next_window_pos((0.0, 0.0), _runtime.imgui.Cond.ALWAYS)
    _runtime.imgui.set_next_window_size((float(width), float(height)), _runtime.imgui.Cond.ALWAYS)
    flags = (
        _runtime.imgui.WindowFlags.NO_TITLE_BAR
        | _runtime.imgui.WindowFlags.NO_RESIZE
        | _runtime.imgui.WindowFlags.NO_MOVE
        | _runtime.imgui.WindowFlags.NO_COLLAPSE
        | _runtime.imgui.WindowFlags.NO_SAVED_SETTINGS
    )
    _runtime.imgui.push_style_color(_runtime.imgui.Col.WINDOW_BG, _runtime.T.SECONDARY_SURFACE_BG)
    try:
        visible, _opened = _runtime.imgui.begin("LumaFold Secondary Surface##secondary", flags=flags)
    finally:
        _runtime.imgui.pop_style_color()

    if visible:
        if _runtime.current_kind == "brush_library":
            def _activate_brush(identity):
                global _target_quick_slot
                target = int(_target_quick_slot)
                if target < 0:
                    try:
                        target = int(sculpt.get("quick_replace_slot", -1))
                    except Exception:
                        target = -1

                if target >= 0:
                    _queue_command(
                        "sculpt.brush.library_replace_slot",
                        identity=str(identity),
                        slot=int(target),
                    )
                    _target_quick_slot = -1
                    try:
                        _queue_state({"quick_replace_slot": -1})
                    except Exception:
                        pass
                else:
                    _queue_command("sculpt.brush.library_activate", identity=str(identity))

                try:
                    _runtime.user32.ShowWindow(_runtime.hwnd_main, _runtime.SW_HIDE)
                except Exception:
                    pass


            _runtime.draw_brush_library_foundation(
                _runtime.imgui,
                sculpt,
                _runtime.current_scale,
                library_ui_state=_runtime.library_ui_state,
                on_refresh_library=lambda: _queue_command("sculpt.brush.library_refresh"),
                on_activate_asset=_activate_brush,
                on_toggle_favorite=lambda identity: _queue_command("sculpt.brush.library_toggle_favorite", identity=str(identity)),
                on_assign_asset_to_slot=lambda identity, slot: _queue_command("sculpt.brush.library_assign_slot", identity=str(identity), slot=int(slot)),
                on_request_preview=_request_brush_preview_delta,
                resolve_preview_texture=(_runtime.preview_textures.resolve if _runtime.preview_textures is not None else None),
            )
        elif _runtime.current_kind == "alpha_library":
            _runtime.draw_alpha_library_foundation(
                _runtime.imgui,
                sculpt,
                _runtime.current_scale,
                library_ui_state=_runtime.library_ui_state,
                on_refresh_library=lambda: _queue_command("sculpt.alpha.library_refresh"),
                on_activate_asset=lambda identity: _queue_command("sculpt.alpha.library_activate", identity=str(identity)),
                on_toggle_favorite=lambda identity: _queue_command("sculpt.alpha.library_toggle_favorite", identity=str(identity)),
                on_request_preview=lambda identities: _queue_command("sculpt.alpha.library_preview", identities=list(identities or ())),
                # One product command owns native Blender Alpha selection across
                # Embedded, Satellite Alpha and More. Never route Satellite to
                # the historical module-local import dialog again.
                on_import_files=lambda: _queue_command("sculpt.alpha.source_add_dialog"),
                resolve_preview_texture=(_runtime.preview_textures.resolve if _runtime.preview_textures is not None else None),
            )
        elif _runtime.current_kind == "more":
            draw_more_foundation(
                _runtime.imgui,
                sculpt,
                _runtime.current_scale,
                on_set_quick_rows=lambda rows: _queue_command("sculpt.brush.set_quick_rows", rows=int(rows)),
                on_reset_quick_slots=lambda: _queue_command("sculpt.brush.reset_quick_slots"),
                on_refresh_brush_library=lambda: _queue_command("sculpt.brush.library_refresh"),
                on_refresh_alpha_library=lambda: _queue_command("sculpt.alpha.library_refresh"),
                on_import_alpha_files=lambda: _queue_command("sculpt.alpha.source_add_dialog"),
            )

    _runtime.imgui.end()
    _runtime.imgui.render()
    _runtime.renderer.render(_runtime.imgui.get_draw_data(), width, height)


_runtime._draw_frame = _draw_frame


if __name__ == "__main__":
    _runtime.main()