"""LumaFold application bootstrap kept outside Core business primitives.

Core knows registries and protocols. Blender services and concrete business
modules are registered here so Core never imports Sculpt/Model directly.
"""
from ..services import register_services
from ..modules import register_modules

_BOOTSTRAPPED = False


def bootstrap_platform(app):
    global _BOOTSTRAPPED
    if _BOOTSTRAPPED:
        return
    register_services(app)
    app.module_loader = register_modules(app)
    _BOOTSTRAPPED = True
