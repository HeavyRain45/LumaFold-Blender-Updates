from __future__ import annotations

from dataclasses import dataclass, field
import importlib
import importlib.util
import pkgutil
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path, PurePosixPath
from typing import Dict, List, Optional, Tuple

import tomllib


CORE_API_VERSION = "1"
PACKAGE_FORMAT_VERSION = "1"
MAX_PACKAGE_FILES = 128
MAX_PACKAGE_UNCOMPRESSED = 16 * 1024 * 1024
DISABLED_MARKER = ".lumafold-disabled"


def _version_tuple(text: str) -> Tuple[int, ...]:
    parts = []
    for piece in str(text or "").replace("-", ".").split("."):
        digits = "".join(ch for ch in piece if ch.isdigit())
        if digits:
            parts.append(int(digits))
        if len(parts) >= 3:
            break
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts)


@dataclass(frozen=True)
class ModuleManifest:
    module_id: str
    name: str
    version: str
    category: str = "General"
    entry: str = "register"
    api_version: str = CORE_API_VERSION
    package_format: str = PACKAGE_FORMAT_VERSION
    hosts: Tuple[str, ...] = ("embedded", "satellite")
    description: str = ""
    self_test: str = ""
    blender_min: str = "5.2.0"
    blender_max: str = ""
    requires_modules: Tuple[str, ...] = ()
    provides_services: Tuple[str, ...] = ()
    requires_services: Tuple[str, ...] = ()
    permissions: Tuple[str, ...] = ()

    @classmethod
    def from_mapping(cls, data):
        if not isinstance(data, dict):
            raise TypeError("MODULE_MANIFEST must be a dict")
        if isinstance(data.get("module"), dict):
            data = data["module"]
        module_id = str(data.get("id") or data.get("module_id") or "").strip()
        name = str(data.get("name") or data.get("label") or module_id).strip()
        version = str(data.get("version") or "0.0").strip()
        if not module_id:
            raise ValueError("Module manifest requires id")
        return cls(
            module_id=module_id,
            name=name or module_id,
            version=version,
            category=str(data.get("category") or "General"),
            entry=str(data.get("entry") or "register"),
            api_version=str(data.get("api_version") or CORE_API_VERSION),
            package_format=str(data.get("package_format") or PACKAGE_FORMAT_VERSION),
            hosts=tuple(data.get("hosts") or ("embedded", "satellite")),
            description=str(data.get("description") or ""),
            self_test=str(data.get("self_test") or ""),
            blender_min=str(data.get("blender_min") or data.get("blender_version_min") or "5.2.0"),
            blender_max=str(data.get("blender_max") or data.get("blender_version_max") or ""),
            requires_modules=tuple(data.get("requires_modules") or data.get("dependencies") or ()),
            provides_services=tuple(data.get("provides_services") or ()),
            requires_services=tuple(data.get("requires_services") or ()),
            permissions=tuple(data.get("permissions") or ()),
        )


@dataclass
class ModuleRecord:
    import_name: str
    manifest: ModuleManifest
    loaded: bool = False
    error: str = ""
    load_count: int = 0
    source: str = "builtin"
    source_path: str = ""
    compatible: bool = True
    compatibility_issues: Tuple[str, ...] = ()
    dependency_blocked_by: Tuple[str, ...] = ()
    dependency_note: str = ""
    trust_level: str = "unknown"
    permission_allowed: Tuple[str, ...] = ()
    permission_denied: Tuple[str, ...] = ()
    permission_unknown: Tuple[str, ...] = ()
    enabled: bool = True


@dataclass
class PackageReport:
    package_path: str = ""
    module_id: str = ""
    name: str = ""
    version: str = ""
    compatible: bool = False
    status: str = "未检查"
    issues: Tuple[str, ...] = ()
    installed: bool = False
    loaded: bool = False
    load_error: str = ""
    file_count: int = 0
    unpacked_bytes: int = 0
    previous_version: str = ""
    action: str = ""
    enabled: bool = True


class ModuleLoader:
    """Discover built-in/external modules and validate installable .lfmod packages.

    A0.8 is a compatibility/install gate, not a Python security sandbox.  External
    module code is not imported during discovery or package preflight.  It is only
    imported after compatibility checks pass and the user explicitly loads it.
    """

    def __init__(self, app, package, external_root=None):
        self.app = app
        self.package = package
        self.external_root = Path(external_root).expanduser() if external_root else None
        if self.external_root:
            self.external_root.mkdir(parents=True, exist_ok=True)
            self.package_root = self.external_root.parent / "packages"
            self.package_root.mkdir(parents=True, exist_ok=True)
        else:
            self.package_root = None
        self.records: Dict[str, ModuleRecord] = {}
        self.last_package_report = PackageReport()
        self.last_service_demo_order: Tuple[str, ...] = ()
        self.last_service_demo_message: str = ""
        self.last_lifecycle_message: str = "尚未运行 A0.14 生命周期测试"
        self.lifecycle_history: List[str] = []

    def _current_blender_version(self) -> Tuple[int, ...]:
        try:
            import bpy
            return tuple(int(x) for x in bpy.app.version[:3])
        except Exception:
            return (0, 0, 0)

    def _compatibility_issues(self, manifest: ModuleManifest, available_ids=None, available_services=None) -> Tuple[str, ...]:
        issues = []
        if str(manifest.package_format) != PACKAGE_FORMAT_VERSION:
            issues.append(f"模块包格式 {manifest.package_format} 不受支持（需要 {PACKAGE_FORMAT_VERSION}）")
        if str(manifest.api_version) != CORE_API_VERSION:
            issues.append(f"Core API {manifest.api_version} 不兼容（当前 {CORE_API_VERSION}）")
        current = self._current_blender_version()
        if manifest.blender_min and current < _version_tuple(manifest.blender_min):
            issues.append(f"需要 Blender >= {manifest.blender_min}")
        if manifest.blender_max and current > _version_tuple(manifest.blender_max):
            issues.append(f"需要 Blender <= {manifest.blender_max}")
        if available_ids is not None:
            missing = [mid for mid in manifest.requires_modules if mid not in available_ids]
            if missing:
                issues.append("缺少模块依赖: " + ", ".join(missing))
        if available_services is not None:
            missing_services = [sid for sid in manifest.requires_services if sid not in available_services]
            if missing_services:
                issues.append("缺少服务依赖: " + ", ".join(missing_services))
        return tuple(issues)

    def _apply_compatibility(self, discovered: Dict[str, ModuleRecord]) -> None:
        available = set(discovered)
        available_services = set(self.app.services.all_ids())
        for item in discovered.values():
            available_services.update(item.manifest.provides_services)
        for record in discovered.values():
            if record.source == "builtin":
                record.compatible = True
                record.compatibility_issues = ()
                continue
            issues = self._compatibility_issues(record.manifest, available, available_services)
            record.compatible = not issues
            record.compatibility_issues = issues

    def _refresh_permission_record(self, record: ModuleRecord):
        decision = self.app.security.evaluate(
            record.manifest.module_id, record.source, record.manifest.permissions
        )
        record.trust_level = decision.trust
        record.permission_allowed = decision.allowed
        record.permission_denied = decision.denied
        record.permission_unknown = decision.unknown
        return decision

    def _apply_permissions(self, discovered: Dict[str, ModuleRecord]) -> None:
        for record in discovered.values():
            try:
                self._refresh_permission_record(record)
            except Exception as exc:
                record.trust_level = "builtin" if record.source == "builtin" else "unknown"
                record.permission_allowed = ()
                record.permission_denied = tuple(record.manifest.permissions) if record.source != "builtin" else ()
                record.permission_unknown = ()
                if record.source != "builtin":
                    record.error = f"权限策略读取失败: {type(exc).__name__}: {exc}"

    def _discover_builtin(self, discovered):
        prefix = self.package.__name__ + "."
        for info in pkgutil.iter_modules(self.package.__path__, prefix):
            leaf = info.name.rsplit(".", 1)[-1]
            if leaf.startswith("_"):
                continue
            try:
                mod = importlib.import_module(info.name)
                raw = getattr(mod, "MODULE_MANIFEST", None)
                if raw is None:
                    continue
                manifest = ModuleManifest.from_mapping(raw)
                previous = self.records.get(manifest.module_id)
                record = previous or ModuleRecord(info.name, manifest)
                record.import_name = info.name
                record.manifest = manifest
                record.source = "builtin"
                record.source_path = ""
                discovered[manifest.module_id] = record
            except Exception as exc:
                discovered[leaf] = ModuleRecord(
                    info.name,
                    ModuleManifest(leaf, leaf, "?"),
                    loaded=False,
                    error=f"{type(exc).__name__}: {exc}",
                    source="builtin",
                )

    def _read_external_manifest(self, folder: Path):
        manifest_path = folder / "manifest.toml"
        module_path = folder / "module.py"
        if not manifest_path.is_file() or not module_path.is_file():
            return None
        raw = tomllib.loads(manifest_path.read_text(encoding="utf-8"))
        manifest = ModuleManifest.from_mapping(raw)
        return manifest, module_path

    def _discover_external(self, discovered):
        if not self.external_root:
            return
        self.external_root.mkdir(parents=True, exist_ok=True)
        for folder in sorted(p for p in self.external_root.iterdir() if p.is_dir() and not p.name.startswith(".")):
            try:
                found = self._read_external_manifest(folder)
                if found is None:
                    continue
                manifest, module_path = found
                previous = self.records.get(manifest.module_id)
                record = previous or ModuleRecord("", manifest)
                record.import_name = f"_lumafold_external_{manifest.module_id}"
                record.manifest = manifest
                record.source = "external"
                record.source_path = str(module_path)
                record.enabled = not (folder / DISABLED_MARKER).exists()
                discovered[manifest.module_id] = record
            except Exception as exc:
                fallback_id = folder.name
                discovered[fallback_id] = ModuleRecord(
                    f"_lumafold_external_{fallback_id}",
                    ModuleManifest(fallback_id, folder.name, "?"),
                    loaded=False,
                    error=f"{type(exc).__name__}: {exc}",
                    source="external",
                    source_path=str(folder / "module.py"),
                    compatible=False,
                    enabled=not (folder / DISABLED_MARKER).exists(),
                    compatibility_issues=("manifest.toml 无法解析",),
                )

    def discover(self) -> List[ModuleRecord]:
        discovered: Dict[str, ModuleRecord] = {}
        self._discover_builtin(discovered)
        self._discover_external(discovered)
        for module_id, record in self.records.items():
            if module_id not in discovered and record.loaded:
                discovered[module_id] = record
        self._apply_compatibility(discovered)
        self._apply_permissions(discovered)
        # Core ModuleRegistry is authoritative for what is actually live.  Preserve that
        # truth across rescans so dependency protection cannot be bypassed by stale
        # ModuleRecord.loaded flags.
        for module_id, record in discovered.items():
            if self.app.modules.get(module_id) is not None:
                record.loaded = True
        self.records = discovered
        return self.all_records()

    def all_records(self) -> List[ModuleRecord]:
        return sorted(self.records.values(), key=lambda r: (r.source != "builtin", r.manifest.category, r.manifest.name))

    def get(self, module_id: str) -> Optional[ModuleRecord]:
        return self.records.get(module_id)

    def _import_external(self, record: ModuleRecord):
        path = Path(record.source_path)
        if not path.is_file():
            raise FileNotFoundError(path)
        sys.modules.pop(record.import_name, None)
        spec = importlib.util.spec_from_file_location(record.import_name, str(path))
        if spec is None or spec.loader is None:
            raise RuntimeError(f"Cannot create import spec for {path}")
        mod = importlib.util.module_from_spec(spec)
        sys.modules[record.import_name] = mod
        spec.loader.exec_module(mod)
        return mod

    def _module_object(self, record: ModuleRecord):
        if record.source == "external":
            return self._import_external(record)
        return importlib.import_module(record.import_name)

    def service_provider_candidates(self, service_id: str) -> List[str]:
        return sorted(mid for mid, rec in self.records.items() if service_id in rec.manifest.provides_services)

    def service_provider_for(self, service_id: str) -> Optional[str]:
        live_owner = self.app.services.owner_of(service_id)
        if live_owner and live_owner != "core":
            return live_owner
        candidates = self.service_provider_candidates(service_id)
        if not candidates:
            return None
        if len(candidates) > 1:
            raise RuntimeError("服务提供者冲突: " + service_id + " <- " + ", ".join(candidates))
        return candidates[0]

    def effective_dependencies(self, module_id: str) -> Tuple[str, ...]:
        record = self.records.get(module_id)
        if record is None:
            raise RuntimeError("未知模块: " + module_id)
        deps = list(record.manifest.requires_modules)
        for service_id in record.manifest.requires_services:
            if self.app.services.get(service_id) is not None:
                owner = self.app.services.owner_of(service_id)
                if owner and owner != "core" and owner != module_id and owner not in deps:
                    deps.append(owner)
                continue
            provider = self.service_provider_for(service_id)
            if provider is None:
                raise RuntimeError("缺少服务依赖: " + service_id)
            if provider != module_id and provider not in deps:
                deps.append(provider)
        return tuple(deps)

    def dependency_graph(self) -> Dict[str, Tuple[str, ...]]:
        graph = {}
        for mid in self.records:
            try:
                graph[mid] = self.effective_dependencies(mid)
            except Exception:
                graph[mid] = tuple(self.records[mid].manifest.requires_modules)
        return graph

    def resolve_load_order(self, targets=None) -> List[str]:
        """Return deterministic dependency-first order; reject cycles/missing deps."""
        if not self.records:
            self.discover()
        graph = self.dependency_graph()
        target_ids = list(targets or sorted(graph))
        order: List[str] = []
        visiting = set()
        visited = set()

        def visit(mid: str, trail=()):
            if mid in visited:
                return
            if mid in visiting:
                cycle = " -> ".join((*trail, mid))
                raise RuntimeError("检测到循环依赖: " + cycle)
            if mid not in graph:
                raise RuntimeError("缺少模块依赖: " + mid)
            visiting.add(mid)
            for dep in graph.get(mid, ()):
                visit(dep, (*trail, mid))
            visiting.remove(mid)
            visited.add(mid)
            order.append(mid)

        for mid in target_ids:
            visit(mid)
        return order

    def _is_effectively_loaded(self, module_id: str, record: Optional[ModuleRecord] = None) -> bool:
        """Use Core registry as the authoritative runtime truth.

        ModuleRecord.loaded is useful discovery metadata, but a rescan/reconciliation can
        temporarily leave it out of sync with the live ModuleRegistry.  Unload protection
        must never rely on that cache alone.
        """
        record = record or self.records.get(module_id)
        registry_loaded = self.app.modules.get(module_id) is not None
        if record is not None and registry_loaded and not record.loaded:
            record.loaded = True
        return bool(registry_loaded or (record.loaded if record is not None else False))

    def dependents_of(self, module_id: str, *, loaded_only=False) -> List[str]:
        result = []
        for mid, record in self.records.items():
            if module_id not in record.manifest.requires_modules:
                continue
            if loaded_only and not self._is_effectively_loaded(mid, record):
                continue
            result.append(mid)
        return sorted(result)

    def load(self, module_id: str, _stack=None) -> ModuleRecord:
        record = self.records.get(module_id)
        if record is None:
            self.discover()
            record = self.records.get(module_id)
        if record is None:
            raise KeyError(module_id)
        if record.source == "external" and not record.enabled:
            record.error = "模块已禁用 DISABLED"
            raise RuntimeError(record.error)
        if record.source == "external" and not record.compatible:
            record.error = "模块兼容性检查未通过: " + "; ".join(record.compatibility_issues)
            raise RuntimeError(record.error)
        decision = self._refresh_permission_record(record)
        if record.source == "external" and not decision.ok:
            problems = []
            if decision.denied:
                problems.append("未授权权限: " + ", ".join(decision.denied))
            if decision.unknown:
                problems.append("未知权限: " + ", ".join(decision.unknown))
            record.error = "权限检查未通过: " + "; ".join(problems)
            self.app.events.emit("module.permission_blocked", {
                "module": module_id, "trust": decision.trust,
                "denied": decision.denied, "unknown": decision.unknown,
            })
            self.app.state.log(f"module.permission_blocked: {module_id} · {record.error}")
            raise RuntimeError(record.error)
        if record.loaded and self.app.modules.get(module_id) is not None:
            return record

        stack = tuple(_stack or ())
        if module_id in stack:
            cycle = " -> ".join((*stack, module_id))
            record.dependency_blocked_by = (module_id,)
            record.dependency_note = "循环依赖"
            raise RuntimeError("检测到循环依赖: " + cycle)

        try:
            effective_deps = self.effective_dependencies(module_id)
        except Exception as exc:
            record.loaded = False
            record.dependency_note = "服务依赖解析失败"
            record.error = str(exc)
            self.app.events.emit("module.service_blocked", {"module": module_id, "error": record.error})
            raise

        for dep_id in effective_deps:
            dep = self.records.get(dep_id)
            if dep is None:
                record.dependency_blocked_by = (dep_id,)
                record.dependency_note = "缺少依赖"
                record.error = f"缺少模块依赖: {dep_id}"
                raise RuntimeError(record.error)
            try:
                self.load(dep_id, _stack=(*stack, module_id))
            except Exception as exc:
                record.loaded = False
                record.dependency_blocked_by = (dep_id,)
                record.dependency_note = f"依赖 {dep_id} 加载失败"
                record.error = f"依赖 {dep_id} 加载失败: {type(exc).__name__}: {exc}"
                self.app.events.emit("module.dependency_blocked", {"module": module_id, "dependency": dep_id, "error": record.error})
                self.app.state.log(f"module.dependency_blocked: {module_id} <- {dep_id}")
                raise RuntimeError(record.error)

        for service_id in record.manifest.requires_services:
            if self.app.services.get(service_id) is None:
                record.loaded = False
                record.dependency_note = "缺少服务依赖"
                record.error = "缺少服务依赖: " + service_id
                self.app.events.emit("module.service_blocked", {"module": module_id, "service": service_id})
                raise RuntimeError(record.error)
            self.app.services.bind(service_id, module_id)

        try:
            mod = self._module_object(record)
            entry = getattr(mod, record.manifest.entry)
            entry(self.app)
            if self.app.modules.get(module_id) is None:
                raise RuntimeError(f"Module {module_id} did not register a ModuleSpec")
            for service_id in record.manifest.provides_services:
                if self.app.services.get(service_id) is None:
                    raise RuntimeError(f"模块声明提供服务但未注册: {service_id}")
                owner = self.app.services.owner_of(service_id)
                if owner != module_id:
                    raise RuntimeError(f"服务所有者不匹配: {service_id} <- {owner}")
            record.loaded = True
            record.error = ""
            record.dependency_blocked_by = ()
            record.dependency_note = ""
            record.load_count += 1
            self.app.events.emit("module.loaded", {"module": module_id, "version": record.manifest.version, "source": record.source})
            self.app.state.log(f"module.loaded: {module_id} · {record.manifest.version} · {record.source}")
            return record
        except Exception as exc:
            record.loaded = False
            record.error = f"{type(exc).__name__}: {exc}"
            self.app.services.release_consumer(module_id)
            # Roll back partial registrations so one bad module cannot poison Core.
            spec = self.app.modules.get(module_id)
            if spec is not None:
                for command_id in spec.commands:
                    self.app.commands.unregister(command_id)
                self.app.modules.unregister(module_id)
            try:
                self.app.services.unregister_owner(module_id)
            except Exception:
                pass
            self.app.events.emit("module.load_failed", {"module": module_id, "error": record.error})
            raise

    def unload(self, module_id: str) -> ModuleRecord:
        record = self.records.get(module_id)
        if record is None:
            raise KeyError(module_id)
        dependents = self.dependents_of(module_id, loaded_only=True)
        if dependents:
            raise RuntimeError("仍被已加载模块依赖，不能卸载: " + ", ".join(dependents))
        service_blockers = {}
        for service_id in self.app.services.services_of_owner(module_id):
            consumers = [mid for mid in self.app.services.consumers_of(service_id) if self._is_effectively_loaded(mid)]
            if consumers:
                service_blockers[service_id] = consumers
        if service_blockers:
            details = "; ".join(f"{sid} <- {', '.join(consumers)}" for sid, consumers in service_blockers.items())
            raise RuntimeError("服务仍被模块使用，不能卸载: " + details)
        spec = self.app.modules.get(module_id)
        if spec is not None:
            for command_id in spec.commands:
                self.app.commands.unregister(command_id)
            self.app.modules.unregister(module_id)
        self.app.services.release_consumer(module_id)
        self.app.services.unregister_owner(module_id)
        record.loaded = False
        record.error = ""
        record.dependency_blocked_by = ()
        record.dependency_note = ""
        self.app.store.namespace(module_id)["lifecycle"] = "UNLOADED"
        self.app.events.emit("module.unloaded", {"module": module_id})
        self.app.state.log(f"module.unloaded: {module_id}")
        return record

    def reload(self, module_id: str) -> ModuleRecord:
        record = self.records.get(module_id)
        if record is None:
            raise KeyError(module_id)
        self.unload(module_id)
        importlib.invalidate_caches()
        if record.source == "external":
            folder = Path(record.source_path).parent
            found = self._read_external_manifest(folder)
            if found is None:
                raise RuntimeError(f"External module {module_id} is missing manifest.toml or module.py")
            record.manifest, module_path = found
            record.source_path = str(module_path)
            available_services = set(self.app.services.all_ids())
            for item in self.records.values():
                available_services.update(item.manifest.provides_services)
            issues = self._compatibility_issues(record.manifest, set(self.records), available_services)
            record.compatible = not issues
            record.compatibility_issues = issues
            if issues:
                raise RuntimeError("模块兼容性检查未通过: " + "; ".join(issues))
        else:
            mod = importlib.import_module(record.import_name)
            importlib.reload(mod)
            raw = getattr(mod, "MODULE_MANIFEST", None)
            if raw is None:
                raise RuntimeError(f"Reloaded module {module_id} has no MODULE_MANIFEST")
            record.manifest = ModuleManifest.from_mapping(raw)
        return self.load(module_id)

    def load_all(self) -> None:
        self.discover()
        for record in self.all_records():
            if record.source == "external" and not record.enabled:
                continue
            if record.source == "external" and not record.compatible:
                continue
            if record.source == "external":
                decision = self._refresh_permission_record(record)
                if not decision.ok:
                    continue
            try:
                self.load(record.manifest.module_id)
            except Exception:
                # One bad external module must never stop LumaFold startup.
                pass

    @property
    def external_root_display(self) -> str:
        return str(self.external_root) if self.external_root else ""

    @property
    def package_root_display(self) -> str:
        return str(self.package_root) if self.package_root else ""


    # ------------------------------------------------------------------
    # A0.10 service contracts / provider-consumer demo
    # ------------------------------------------------------------------
    def install_service_demo(self) -> None:
        common = '''category = "A0.10服务测试"
package_format = "1"
api_version = "1"
entry = "register"
hosts = ["embedded", "satellite", "desktop"]
blender_min = "5.2.0"
permissions = ["blender.read"]
'''
        provider_manifest = '''[module]
id = "svc_provider"
name = "服务提供模块"
version = "0.10"
''' + common + '''requires_modules = []
provides_services = ["demo.greeter"]
requires_services = []
description = "提供 demo.greeter 服务；消费者无需 import 本模块。"
'''
        provider_module = '''class GreeterService:
    def __init__(self, state):
        self.state = state
    def greet(self, who="LumaFold"):
        self.state["greet_count"] = int(self.state.get("greet_count", 0)) + 1
        return "来自服务提供模块的问候：{} #{}".format(who, self.state["greet_count"])

def register(app):
    module_id = "svc_provider"
    state = app.store.namespace(module_id, {"greet_count": 0, "lifecycle": "REGISTERED"})
    app.provide_service(module_id, "demo.greeter", GreeterService(state), version="1")
    app.register_module(module_id=module_id, label="服务提供模块", category="A0.10服务测试", version="0.10", description="提供 demo.greeter Service Contract", hosts=("embedded","satellite","desktop"), modes=(), requires=(), capabilities=("service.provider",), commands=())
'''
        consumer_manifest = '''[module]
id = "svc_consumer"
name = "服务消费模块"
version = "0.10"
''' + common + '''requires_modules = []
provides_services = []
requires_services = ["demo.greeter"]
description = "只依赖 service id，不 import 服务提供模块。"
self_test = "svc_consumer.greet"
'''
        consumer_module = '''def register(app):
    module_id = "svc_consumer"
    state = app.store.namespace(module_id, {"call_count": 0, "lifecycle": "REGISTERED"})
    greeter = app.require_service(module_id, "demo.greeter")
    def greet():
        state["call_count"] = int(state.get("call_count", 0)) + 1
        return greeter.greet("服务消费模块")
    app.commands.register("svc_consumer.greet", greet)
    app.register_module(module_id=module_id, label="服务消费模块", category="A0.10服务测试", version="0.10", description="通过 Core Service Contract 调用 demo.greeter", hosts=("embedded","satellite","desktop"), modes=(), requires=(), capabilities=("service.consumer",), commands=("svc_consumer.greet",))
'''
        missing_manifest = '''[module]
id = "svc_missing"
name = "缺失服务测试模块"
version = "0.10"
''' + common + '''requires_modules = []
provides_services = []
requires_services = ["demo.service.missing"]
description = "用于验证缺失服务会在执行模块代码前被阻止。"
'''
        missing_module = '''def register(app):
    raise RuntimeError("不应该执行：缺失服务必须在 module.py 执行前被 Core 阻止")
'''
        self._write_external_demo("svc_provider", provider_manifest, provider_module)
        self._write_external_demo("svc_consumer", consumer_manifest, consumer_module)
        self._write_external_demo("svc_missing", missing_manifest, missing_module)
        self.discover()
        self.last_service_demo_order = ()
        self.last_service_demo_message = "A0.10 服务示例已安装"
        self.app.events.emit("service.demo_installed", {"count": 3})

    def _ensure_service_demo_installed(self) -> None:
        """Make the A0.10 demo action self-contained and race-proof.

        The UI executes module mutations at frame boundaries.  A user can therefore
        press the load action before the previous install action has been processed,
        or simply skip the explicit install button.  Service loading must not surface
        an internal "missing module: svc_consumer" error in either case.
        """
        self.discover()
        required = {"svc_provider", "svc_consumer", "svc_missing"}
        if not required.issubset(self.records):
            self.install_service_demo()
            self.discover()
        missing = sorted(required.difference(self.records))
        if missing:
            raise RuntimeError("A0.10 服务示例准备失败，缺少模块: " + ", ".join(missing))

    def load_service_demo(self) -> Tuple[str, ...]:
        self._ensure_service_demo_installed()
        order = tuple(self.resolve_load_order(["svc_consumer"]))
        self.load("svc_consumer")
        if self.app.services.owner_of("demo.greeter") != "svc_provider":
            raise RuntimeError("demo.greeter 服务所有者错误")
        consumers = self.app.services.consumers_of("demo.greeter")
        if "svc_consumer" not in consumers:
            raise RuntimeError("服务消费绑定没有建立")
        self.last_service_demo_order = order
        self.last_service_demo_message = "服务链加载完成：" + " -> ".join(order)
        self.app.state.log("service.order: " + " -> ".join(order))
        return order

    def call_service_demo(self) -> str:
        if not self._is_effectively_loaded("svc_consumer"):
            self.load_service_demo()
        result = self.app.execute("svc_consumer.greet")
        if not result.ok:
            raise RuntimeError(result.message)
        self.last_service_demo_message = str(result.message)
        return str(result.message)

    def run_missing_service_demo(self) -> str:
        self._ensure_service_demo_installed()
        record = self.records.get("svc_missing")
        if record is None:
            raise RuntimeError("A0.10 服务示例准备失败")
        try:
            self.load("svc_missing")
        except Exception as exc:
            record.error = f"{type(exc).__name__}: {exc}"
            self.last_service_demo_message = "缺失服务已阻止 BLOCKED：" + str(exc)
            return self.last_service_demo_message
        self.last_service_demo_message = "错误：缺失服务模块意外加载成功"
        return self.last_service_demo_message

    def cleanup_service_demo(self) -> None:
        demo_ids = ("svc_missing", "svc_consumer", "svc_provider")
        for module_id in demo_ids:
            record = self.records.get(module_id)
            if record and self._is_effectively_loaded(module_id, record):
                try:
                    self.unload(module_id)
                except Exception:
                    pass
        if self.external_root:
            for module_id in demo_ids:
                folder = self.external_root / module_id
                if folder.exists():
                    shutil.rmtree(folder, ignore_errors=True)
                sys.modules.pop(f"_lumafold_external_{module_id}", None)
        self.app.services.release_consumer("svc_consumer")
        try:
            self.app.services.unregister_owner("svc_provider")
        except Exception:
            pass
        self.discover()
        self.last_service_demo_order = ()
        self.last_service_demo_message = "A0.10 服务示例已清理"
        self.app.events.emit("service.demo_cleaned", {})

    # ------------------------------------------------------------------
    # A0.9 dependency graph / startup order / fault-boundary demo
    # ------------------------------------------------------------------
    # ------------------------------------------------------------------
    # A0.13 permission / trust model demo
    # ------------------------------------------------------------------
    def install_permission_demo(self) -> None:
        if not self.external_root:
            raise RuntimeError("外部模块目录不可用")
        common = '''[module]
version = "0.13"
category = "A0.13权限测试"
package_format = "1"
api_version = "1"
entry = "register"
hosts = ["embedded", "satellite", "desktop"]
blender_min = "5.2.0"
requires_modules = []
provides_services = []
requires_services = []
'''
        safe_manifest = common + '''id = "perm_readonly"
name = "只读外部模块"
permissions = ["blender.read"]
description = "UNKNOWN 外部模块只申请只读基线权限，应允许加载。"
self_test = "perm_readonly.ping"
'''
        safe_module = '''def register(app):
    module_id = "perm_readonly"
    state = app.store.namespace(module_id, {"count": 0})
    def ping():
        state["count"] = int(state.get("count", 0)) + 1
        return f"只读模块自检 #{state['count']}"
    app.commands.register("perm_readonly.ping", ping)
    app.register_module(module_id=module_id, label="只读外部模块", category="A0.13权限测试", version="0.13", description="UNKNOWN + blender.read", hosts=("embedded","satellite","desktop"), commands=("perm_readonly.ping",))
'''
        sensitive_manifest = common + '''id = "perm_sensitive"
name = "敏感权限外部模块"
permissions = ["blender.write", "files.write"]
description = "UNKNOWN 时必须在 import module.py 之前被阻止；显式信任后才允许加载。"
self_test = "perm_sensitive.ping"
'''
        sensitive_module = '''EXECUTED = True
def register(app):
    module_id = "perm_sensitive"
    state = app.store.namespace("permission_demo", {"sensitive_execution_count": 0})
    state["sensitive_execution_count"] = int(state.get("sensitive_execution_count", 0)) + 1
    def ping():
        return f"敏感模块已执行 #{state.get('sensitive_execution_count', 0)}"
    app.commands.register("perm_sensitive.ping", ping)
    app.register_module(module_id=module_id, label="敏感权限外部模块", category="A0.13权限测试", version="0.13", description="trusted + blender.write/files.write", hosts=("embedded","satellite","desktop"), commands=("perm_sensitive.ping",))
'''
        self._write_external_demo("perm_readonly", safe_manifest, safe_module)
        self._write_external_demo("perm_sensitive", sensitive_manifest, sensitive_module)
        self.app.security.set_trust("perm_readonly", "unknown")
        self.app.security.set_trust("perm_sensitive", "unknown")
        demo = self.app.store.namespace("permission_demo", {"sensitive_execution_count": 0})
        demo["sensitive_execution_count"] = 0
        demo["last_message"] = "A0.13 权限示例已安装；敏感模块仍为 UNKNOWN"
        self.discover()
        try:
            self.load("perm_readonly")
        except Exception:
            pass

    def _ensure_permission_demo(self) -> None:
        """Make A0.13 demo actions order-independent.

        UI actions are intentionally safe to click in any order.  If the demo folders
        were never installed (or were cleaned in an earlier run), prepare them first
        instead of leaking an internal KeyError to the user.
        """
        self.discover()
        if "perm_readonly" in self.records and "perm_sensitive" in self.records:
            return
        self.install_permission_demo()
        self.discover()
        if "perm_sensitive" not in self.records:
            raise RuntimeError("权限测试模块准备失败：未发现 perm_sensitive")

    def run_permission_block_demo(self) -> str:
        self._ensure_permission_demo()
        self.app.security.set_trust("perm_sensitive", "unknown")
        record = self.records.get("perm_sensitive")
        if record and self._is_effectively_loaded("perm_sensitive", record):
            self.unload("perm_sensitive")
        self.discover()
        try:
            self.load("perm_sensitive")
            message = "异常：UNKNOWN 敏感模块竟然加载成功"
        except RuntimeError as exc:
            message = "权限已阻止 PERMISSION BLOCKED：" + str(exc)
        self.app.store.namespace("permission_demo", {})["last_message"] = message
        return message

    def trust_and_load_permission_demo(self) -> str:
        self._ensure_permission_demo()
        self.app.security.set_trust("perm_sensitive", "trusted")
        self.discover()
        self.load("perm_sensitive")
        count = int(self.app.store.namespace("permission_demo", {}).get("sensitive_execution_count", 0))
        message = f"已信任并加载 TRUSTED · 敏感模块执行次数 #{count}"
        self.app.store.namespace("permission_demo", {})["last_message"] = message
        return message

    def revoke_permission_demo(self) -> str:
        self._ensure_permission_demo()
        record = self.records.get("perm_sensitive")
        if record and self._is_effectively_loaded("perm_sensitive", record):
            self.unload("perm_sensitive")
        self.app.security.set_trust("perm_sensitive", "unknown")
        self.discover()
        message = "已撤销信任 REVOKED · perm_sensitive 回到 UNKNOWN"
        self.app.store.namespace("permission_demo", {})["last_message"] = message
        return message

    def cleanup_permission_demo(self) -> None:
        for module_id in ("perm_sensitive", "perm_readonly"):
            record = self.records.get(module_id)
            if record and self._is_effectively_loaded(module_id, record):
                try:
                    self.unload(module_id)
                except Exception:
                    pass
            self.app.security.forget(module_id)
            folder = self.external_root / module_id if self.external_root else None
            if folder and folder.exists():
                shutil.rmtree(folder, ignore_errors=True)
        self.discover()
        self.app.store.namespace("permission_demo", {})["last_message"] = "A0.13 权限示例已清理"

    def _write_external_demo(self, module_id: str, manifest_text: str, module_text: str) -> Path:
        if not self.external_root:
            raise RuntimeError("External module directory is unavailable")
        folder = self.external_root / module_id
        if folder.exists():
            record = self.records.get(module_id)
            if record and record.loaded:
                try:
                    self.unload(module_id)
                except Exception:
                    pass
            shutil.rmtree(folder, ignore_errors=True)
        folder.mkdir(parents=True, exist_ok=True)
        (folder / "manifest.toml").write_text(manifest_text, encoding="utf-8")
        (folder / "module.py").write_text(module_text, encoding="utf-8")
        return folder

    def install_dependency_demo(self) -> None:
        common = '''category = "A0.9依赖测试"
package_format = "1"
api_version = "1"
entry = "register"
hosts = ["embedded", "satellite", "desktop"]
blender_min = "5.2.0"
permissions = ["blender.read"]
'''
        base_manifest = '''[module]
id = "dep_base"
name = "依赖基础模块"
version = "0.9"
''' + common + '''requires_modules = []
description = "A0.9 正常依赖链的基础模块。"
self_test = "dep_base.ping"
'''
        base_module = '''def register(app):
    module_id = "dep_base"
    state = app.store.namespace(module_id, {"ping_count": 0, "lifecycle": "REGISTERED"})
    def ping():
        state["ping_count"] = int(state.get("ping_count", 0)) + 1
        return "基础模块正常 #{}".format(state["ping_count"])
    app.commands.register("dep_base.ping", ping)
    app.register_module(module_id=module_id, label="依赖基础模块", category="A0.9依赖测试", version="0.9", description="正常依赖链基础", hosts=("embedded","satellite","desktop"), modes=(), requires=(), capabilities=("dependency.base",), commands=("dep_base.ping",))
'''
        tool_manifest = '''[module]
id = "dep_tool"
name = "依赖上层模块"
version = "0.9"
''' + common + '''requires_modules = ["dep_base"]
description = "依赖 dep_base；Core 必须先加载基础模块。"
self_test = "dep_tool.ping"
'''
        tool_module = '''def register(app):
    module_id = "dep_tool"
    state = app.store.namespace(module_id, {"ping_count": 0, "lifecycle": "REGISTERED"})
    def ping():
        state["ping_count"] = int(state.get("ping_count", 0)) + 1
        return "上层模块正常 #{}".format(state["ping_count"])
    app.commands.register("dep_tool.ping", ping)
    app.register_module(module_id=module_id, label="依赖上层模块", category="A0.9依赖测试", version="0.9", description="依赖 dep_base", hosts=("embedded","satellite","desktop"), modes=(), requires=(), capabilities=("dependency.tool",), commands=("dep_tool.ping",))
'''
        fault_manifest = '''[module]
id = "dep_fault_base"
name = "故障基础模块"
version = "0.9"
''' + common + '''requires_modules = []
description = "故意加载失败，用于验证故障边界。"
'''
        fault_module = '''def register(app):
    raise RuntimeError("A0.9 预期故障：基础依赖加载失败")
'''
        blocked_manifest = '''[module]
id = "dep_fault_tool"
name = "故障链上层模块"
version = "0.9"
''' + common + '''requires_modules = ["dep_fault_base"]
description = "依赖故障基础模块；应该被 Core 自动阻止。"
'''
        blocked_module = '''def register(app):
    raise RuntimeError("不应该执行：依赖失败后上层模块必须被阻止")
'''
        self._write_external_demo("dep_base", base_manifest, base_module)
        self._write_external_demo("dep_tool", tool_manifest, tool_module)
        self._write_external_demo("dep_fault_base", fault_manifest, fault_module)
        self._write_external_demo("dep_fault_tool", blocked_manifest, blocked_module)
        self.discover()
        self.app.events.emit("module.dependency.demo_installed", {"count": 4})

    def load_dependency_demo(self) -> Tuple[str, ...]:
        self.discover()
        order = tuple(self.resolve_load_order(["dep_tool"]))
        self.load("dep_tool")
        self.app.state.log("dependency.order: " + " -> ".join(order))
        return order

    def run_fault_dependency_demo(self) -> str:
        self.discover()
        for mid in ("dep_fault_base", "dep_fault_tool"):
            rec = self.records.get(mid)
            if rec:
                rec.error = ""
                rec.dependency_blocked_by = ()
                rec.dependency_note = ""
        try:
            self.load("dep_fault_tool")
        except Exception as exc:
            return f"故障链已隔离: {type(exc).__name__}: {exc}"
        return "错误：故障链意外加载成功"

    def cleanup_dependency_demo(self) -> None:
        demo_ids = ("dep_fault_tool", "dep_fault_base", "dep_tool", "dep_base")
        for module_id in demo_ids:
            record = self.records.get(module_id)
            if record and record.loaded:
                try:
                    self.unload(module_id)
                except Exception:
                    pass
        if self.external_root:
            for module_id in demo_ids:
                folder = self.external_root / module_id
                if folder.exists():
                    shutil.rmtree(folder, ignore_errors=True)
                sys.modules.pop(f"_lumafold_external_{module_id}", None)
        self.discover()
        self.app.events.emit("module.dependency.demo_cleaned", {})

    # ------------------------------------------------------------------
    # A0.7 legacy demo folder
    # ------------------------------------------------------------------
    def install_demo_external(self) -> Path:
        if not self.external_root:
            raise RuntimeError("External module directory is unavailable")
        folder = self.external_root / "lumafold_demo"
        folder.mkdir(parents=True, exist_ok=True)
        manifest_text = '''[module]
id = "external_demo"
name = "外部示例模块"
version = "0.1"
category = "示例"
api_version = "1"
package_format = "1"
entry = "register"
hosts = ["embedded", "satellite", "desktop"]
blender_min = "5.2.0"
description = "A0.7 外部模块目录验证：文件位于 Blender 用户目录，不在 LumaFold Core 包内。"
self_test = "external_demo.ping"
'''
        module_text = '''def register(app):
    module_id = "external_demo"
    state = app.store.namespace(module_id, {"ping_count": 0, "lifecycle": "REGISTERED"})

    def ping():
        state["ping_count"] = int(state.get("ping_count", 0)) + 1
        app.events.emit("external_demo.ping", {"count": state["ping_count"]})
        return "外部模块自检成功 #{}".format(state["ping_count"])

    app.commands.register("external_demo.ping", ping)
    app.register_module(
        module_id=module_id,
        label="外部示例模块",
        category="示例",
        version="0.1",
        description="从 Blender 用户目录动态加载的独立模块。",
        hosts=("embedded", "satellite", "desktop"),
        modes=(), requires=(), capabilities=("external.package",),
        commands=("external_demo.ping",),
    )
'''
        (folder / "manifest.toml").write_text(manifest_text, encoding="utf-8")
        (folder / "module.py").write_text(module_text, encoding="utf-8")
        return folder

    def remove_demo_external(self) -> None:
        if not self.external_root:
            return
        record = self.records.get("external_demo")
        if record and record.loaded:
            self.unload("external_demo")
        folder = self.external_root / "lumafold_demo"
        if folder.exists():
            shutil.rmtree(folder)
        sys.modules.pop("_lumafold_external_external_demo", None)
        self.discover()

    # ------------------------------------------------------------------
    # A0.8 .lfmod package gate
    # ------------------------------------------------------------------
    def _safe_zip_members(self, archive: zipfile.ZipFile):
        infos = archive.infolist()
        if len(infos) > MAX_PACKAGE_FILES:
            raise ValueError(f"模块包文件过多（上限 {MAX_PACKAGE_FILES}）")
        unpacked = sum(max(0, int(info.file_size)) for info in infos)
        if unpacked > MAX_PACKAGE_UNCOMPRESSED:
            raise ValueError("模块包解压后体积超过 A0.8 测试上限 16MB")
        for info in infos:
            path = PurePosixPath(info.filename)
            if path.is_absolute() or ".." in path.parts:
                raise ValueError(f"模块包包含不安全路径: {info.filename}")
        return infos, unpacked

    def inspect_package(self, package_path) -> PackageReport:
        path = Path(package_path)
        report = PackageReport(package_path=str(path), status="检查失败")
        try:
            if not path.is_file():
                raise FileNotFoundError(path)
            with zipfile.ZipFile(path, "r") as archive:
                infos, unpacked = self._safe_zip_members(archive)
                names = {PurePosixPath(info.filename).as_posix().rstrip("/") for info in infos}
                if "manifest.toml" not in names or "module.py" not in names:
                    raise ValueError("模块包根目录必须包含 manifest.toml 和 module.py")
                raw_manifest = archive.read("manifest.toml")
                if len(raw_manifest) > 128 * 1024:
                    raise ValueError("manifest.toml 过大")
                manifest = ModuleManifest.from_mapping(tomllib.loads(raw_manifest.decode("utf-8")))
            available = set(self.records)
            available.add(manifest.module_id)
            available_services = set(self.app.services.all_ids())
            for item in self.records.values():
                available_services.update(item.manifest.provides_services)
            available_services.update(manifest.provides_services)
            issues = self._compatibility_issues(manifest, available, available_services)
            report.module_id = manifest.module_id
            report.name = manifest.name
            report.version = manifest.version
            report.compatible = not issues
            report.issues = issues
            report.file_count = len(infos)
            report.unpacked_bytes = unpacked
            report.status = "兼容 COMPATIBLE" if report.compatible else "已阻止 BLOCKED"
        except Exception as exc:
            report.compatible = False
            report.issues = (f"{type(exc).__name__}: {exc}",)
            report.status = "检查失败 INVALID"
        self.last_package_report = report
        return report

    def _installed_manifest(self, module_id: str):
        if not self.external_root:
            return None
        folder = self.external_root / str(module_id)
        if not folder.is_dir():
            return None
        found = self._read_external_manifest(folder)
        return found[0] if found else None

    def install_package(self, package_path, *, allow_downgrade=False, allow_reinstall=False) -> PackageReport:
        """Install a validated .lfmod with A0.14 version-policy checks."""
        if not self.external_root:
            raise RuntimeError("External module directory is unavailable")
        report = self.inspect_package(package_path)
        if not report.compatible:
            report.installed = False
            self.last_package_report = report
            return report

        installed_manifest = self._installed_manifest(report.module_id)
        if installed_manifest is not None:
            report.previous_version = installed_manifest.version
            old_v = _version_tuple(installed_manifest.version)
            new_v = _version_tuple(report.version)
            if new_v < old_v and not allow_downgrade:
                report.installed = False
                report.action = "DOWNGRADE"
                report.status = "降级已阻止 DOWNGRADE BLOCKED"
                report.issues = tuple(report.issues) + (f"已安装 {installed_manifest.version}，待安装 {report.version}；需要显式确认降级",)
                self.last_package_report = report
                return report
            if new_v == old_v and not allow_reinstall:
                report.installed = False
                report.action = "SAME_VERSION"
                report.status = "相同版本已阻止 SAME VERSION"
                report.issues = tuple(report.issues) + (f"版本 {report.version} 已安装；不会无提示覆盖",)
                self.last_package_report = report
                return report
            report.action = "DOWNGRADE" if new_v < old_v else ("UPDATE" if new_v > old_v else "REINSTALL")
        else:
            report.action = "INSTALL"

        package_path = Path(package_path)
        staging = Path(tempfile.mkdtemp(prefix=".lfmod_stage_", dir=str(self.external_root)))
        backup = None
        destination = self.external_root / report.module_id
        was_loaded = False
        try:
            with zipfile.ZipFile(package_path, "r") as archive:
                self._safe_zip_members(archive)
                archive.extractall(staging)
            found = self._read_external_manifest(staging)
            if found is None:
                raise ValueError("解压后的模块缺少 manifest.toml 或 module.py")
            manifest, _ = found
            if manifest.module_id != report.module_id:
                raise ValueError("模块 id 在安装过程中发生变化")
            existing = self.records.get(manifest.module_id)
            was_loaded = bool(existing and self._is_effectively_loaded(manifest.module_id, existing))
            if was_loaded:
                self.unload(manifest.module_id)
            if destination.exists():
                backup = self.external_root / f".{manifest.module_id}.backup"
                if backup.exists():
                    shutil.rmtree(backup)
                destination.rename(backup)
            staging.rename(destination)
            staging = None
            marker = destination / DISABLED_MARKER
            if marker.exists():
                marker.unlink()
            self.discover()
            report.installed = True
            report.enabled = True
            report.status = {
                "INSTALL": "已安装 INSTALLED",
                "UPDATE": "已更新 UPDATED",
                "DOWNGRADE": "已降级 DOWNGRADED",
                "REINSTALL": "已重装 REINSTALLED",
            }.get(report.action, "已安装 INSTALLED")
            self.app.events.emit("module.package.installed", {
                "module": manifest.module_id, "path": str(package_path),
                "action": report.action, "previous_version": report.previous_version,
                "version": manifest.version,
            })
            self.app.state.log(f"module.package.{report.action.lower()}: {manifest.module_id} · {manifest.version}")
            if backup and backup.exists():
                shutil.rmtree(backup)
        except Exception as exc:
            report.installed = False
            report.status = "安装失败 INSTALL FAILED"
            report.issues = tuple(report.issues) + (f"{type(exc).__name__}: {exc}",)
            if backup and backup.exists():
                if destination.exists():
                    shutil.rmtree(destination)
                backup.rename(destination)
                self.discover()
                if was_loaded:
                    try:
                        self.load(report.module_id)
                    except Exception:
                        pass
        finally:
            if staging and Path(staging).exists():
                shutil.rmtree(staging, ignore_errors=True)
        self.last_package_report = report
        return report

    def _demo_package_content(self, kind: str):
        kind = str(kind)
        if kind == "compatible":
            module_id = "package_demo"
            name = "兼容模块包示例"
            api = CORE_API_VERSION
            dependencies = "[]"
            module_body = '''def register(app):\n    module_id = "package_demo"\n    state = app.store.namespace(module_id, {"ping_count": 0, "lifecycle": "REGISTERED"})\n    def ping():\n        state["ping_count"] = int(state.get("ping_count", 0)) + 1\n        return "模块包自检成功 #{}".format(state["ping_count"])\n    app.commands.register("package_demo.ping", ping)\n    app.register_module(module_id=module_id, label="兼容模块包示例", category="示例", version="0.8", description="A0.8 .lfmod 安装测试", hosts=("embedded", "satellite", "desktop"), modes=(), requires=(), capabilities=("external.package",), commands=("package_demo.ping",))\n'''
            self_test = "package_demo.ping"
        elif kind == "incompatible":
            module_id = "package_incompatible"
            name = "不兼容模块包示例"
            api = "99"
            dependencies = '["missing.demo.dependency"]'
            module_body = 'def register(app):\n    raise RuntimeError("这个模块不应该被执行")\n'
            self_test = ""
        elif kind == "faulty":
            module_id = "package_faulty"
            name = "故障隔离模块包示例"
            api = CORE_API_VERSION
            dependencies = "[]"
            module_body = 'def register(app):\n    raise RuntimeError("A0.8 故障隔离测试：这是预期错误")\n'
            self_test = ""
        else:
            raise ValueError(f"Unknown demo package kind: {kind}")

        manifest = f'''[module]\nid = "{module_id}"\nname = "{name}"\nversion = "0.8"\ncategory = "示例"\npackage_format = "{PACKAGE_FORMAT_VERSION}"\napi_version = "{api}"\nentry = "register"\nhosts = ["embedded", "satellite", "desktop"]\nblender_min = "5.2.0"\nrequires_modules = {dependencies}\npermissions = ["blender.read"]\ndescription = "A0.8 模块包安装前检查 / 兼容性 / 错误隔离测试。"\nself_test = "{self_test}"\n'''
        return module_id, manifest, module_body

    def create_demo_package(self, kind: str) -> Path:
        if not self.package_root:
            raise RuntimeError("Package directory is unavailable")
        module_id, manifest, module_body = self._demo_package_content(kind)
        path = self.package_root / f"{module_id}.lfmod"
        with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("manifest.toml", manifest)
            archive.writestr("module.py", module_body)
            archive.writestr("README.txt", "LumaFold Core Alpha A0.8 demo module package\n")
        return path

    def install_demo_package(self, kind: str, *, try_load=True) -> PackageReport:
        package_path = self.create_demo_package(kind)
        report = self.install_package(package_path)
        if report.installed and try_load:
            try:
                self.load(report.module_id)
                report.loaded = True
                report.status = "已安装并加载 LOADED"
            except Exception as exc:
                report.loaded = False
                report.load_error = f"{type(exc).__name__}: {exc}"
                report.status = "加载失败但已隔离 ISOLATED"
        self.last_package_report = report
        return report

    def cleanup_demo_packages(self) -> None:
        demo_ids = ("package_demo", "package_incompatible", "package_faulty")
        for module_id in demo_ids:
            record = self.records.get(module_id)
            if record and record.loaded:
                try:
                    self.unload(module_id)
                except Exception:
                    pass
            if self.external_root:
                folder = self.external_root / module_id
                if folder.exists():
                    shutil.rmtree(folder, ignore_errors=True)
            sys.modules.pop(f"_lumafold_external_{module_id}", None)
            if self.package_root:
                pkg = self.package_root / f"{module_id}.lfmod"
                if pkg.exists():
                    pkg.unlink()
        self.discover()
        self.last_package_report = PackageReport(status="A0.8 测试包已清理", compatible=True)

    # ------------------------------------------------------------------
    # A0.14 package lifecycle / version policy / disable-enable-uninstall
    # ------------------------------------------------------------------
    def _lifecycle_log(self, message: str) -> str:
        self.last_lifecycle_message = str(message)
        self.lifecycle_history.append(str(message))
        del self.lifecycle_history[:-8]
        self.app.state.log("package.lifecycle: " + str(message))
        return str(message)

    def create_lifecycle_package(self, version: str) -> Path:
        if not self.package_root:
            raise RuntimeError("Package directory is unavailable")
        version = str(version)
        module_id = "lifecycle_demo"
        manifest = f'''[module]
id = "{module_id}"
name = "生命周期测试模块"
version = "{version}"
category = "A0.14生命周期测试"
package_format = "{PACKAGE_FORMAT_VERSION}"
api_version = "{CORE_API_VERSION}"
entry = "register"
hosts = ["embedded", "satellite", "desktop"]
blender_min = "5.2.0"
requires_modules = []
permissions = ["blender.read"]
description = "A0.14 安装 / 更新 / 降级 / 禁用 / 卸载生命周期测试。"
self_test = "lifecycle_demo.ping"
'''
        module_body = f'''VERSION = "{version}"

def register(app):
    module_id = "lifecycle_demo"
    state = app.store.namespace(module_id, {{"ping_count": 0, "lifecycle": "REGISTERED", "last_version": VERSION}})
    state["last_version"] = VERSION
    def ping():
        state["ping_count"] = int(state.get("ping_count", 0)) + 1
        return "生命周期模块 v{{}} 自检 #{{}}".format(VERSION, state["ping_count"])
    app.commands.register("lifecycle_demo.ping", ping)
    app.register_module(module_id=module_id, label="生命周期测试模块", category="A0.14生命周期测试", version=VERSION, description="A0.14 Package Lifecycle", hosts=("embedded", "satellite", "desktop"), modes=(), requires=(), capabilities=("external.package.lifecycle",), commands=("lifecycle_demo.ping",))
'''
        safe_version = version.replace(".", "_")
        path = self.package_root / f"{module_id}_{safe_version}.lfmod"
        with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("manifest.toml", manifest)
            archive.writestr("module.py", module_body)
            archive.writestr("README.txt", f"LumaFold A0.14 lifecycle demo {version}\n")
        return path

    def lifecycle_status(self) -> dict:
        record = self.records.get("lifecycle_demo")
        manifest = self._installed_manifest("lifecycle_demo")
        enabled = True
        if self.external_root:
            folder = self.external_root / "lifecycle_demo"
            enabled = not (folder / DISABLED_MARKER).exists() if folder.exists() else True
        return {
            "installed": manifest is not None,
            "version": manifest.version if manifest else "-",
            "enabled": bool(enabled),
            "loaded": bool(record and self._is_effectively_loaded("lifecycle_demo", record)),
            "ping_count": int(self.app.store.namespace("lifecycle_demo", {"ping_count": 0}).get("ping_count", 0)),
        }

    def install_lifecycle_version(self, version: str, *, allow_downgrade=False, allow_reinstall=False) -> PackageReport:
        path = self.create_lifecycle_package(version)
        report = self.install_package(path, allow_downgrade=allow_downgrade, allow_reinstall=allow_reinstall)
        if report.installed:
            self.load("lifecycle_demo")
            report.loaded = True
            report.status += " · 已加载 LOADED"
            previous = (report.previous_version + " → ") if report.previous_version else ""
            self._lifecycle_log(f"{report.action}: {previous}{report.version} · LOADED")
        else:
            self._lifecycle_log(report.status + (" · " + "; ".join(report.issues) if report.issues else ""))
        self.last_package_report = report
        return report

    def ping_lifecycle_demo(self) -> str:
        if not self._is_effectively_loaded("lifecycle_demo"):
            raise RuntimeError("生命周期测试模块当前未加载")
        result = self.app.execute("lifecycle_demo.ping")
        if not result.ok:
            raise RuntimeError(result.message)
        return self._lifecycle_log(str(result.payload))

    def disable_package(self, module_id: str) -> str:
        record = self.records.get(module_id)
        if record is None:
            self.discover()
            record = self.records.get(module_id)
        if record is None or record.source != "external":
            raise RuntimeError("只能禁用已安装的外部模块")
        if self._is_effectively_loaded(module_id, record):
            self.unload(module_id)
        folder = Path(record.source_path).parent
        (folder / DISABLED_MARKER).write_text("disabled by LumaFold Core A0.14\n", encoding="utf-8")
        self.discover()
        self.app.events.emit("module.package.disabled", {"module": module_id})
        return self._lifecycle_log(f"已禁用 DISABLED: {module_id}")

    def enable_package(self, module_id: str, *, load=True) -> str:
        if not self.external_root:
            raise RuntimeError("External module directory is unavailable")
        folder = self.external_root / module_id
        if not folder.is_dir():
            raise RuntimeError("模块尚未安装: " + module_id)
        marker = folder / DISABLED_MARKER
        if marker.exists():
            marker.unlink()
        self.discover()
        if load:
            self.load(module_id)
        self.app.events.emit("module.package.enabled", {"module": module_id})
        return self._lifecycle_log(f"已启用 ENABLED: {module_id}" + (" · LOADED" if load else ""))

    def uninstall_package(self, module_id: str, *, purge_state=False) -> str:
        record = self.records.get(module_id)
        if record is None:
            self.discover()
            record = self.records.get(module_id)
        if record and record.source != "external":
            raise RuntimeError("内置模块不能通过 Package Lifecycle 卸载")
        if record and self._is_effectively_loaded(module_id, record):
            self.unload(module_id)
        if self.external_root:
            folder = self.external_root / module_id
            if folder.exists():
                shutil.rmtree(folder)
        sys.modules.pop(f"_lumafold_external_{module_id}", None)
        try:
            self.app.security.forget(module_id)
        except Exception:
            pass
        if purge_state:
            self.app.store.clear_namespace(module_id)
        self.discover()
        self.app.events.emit("module.package.uninstalled", {"module": module_id, "purge_state": bool(purge_state)})
        return self._lifecycle_log(f"已卸载 UNINSTALLED: {module_id}" + (" · 已清除状态" if purge_state else " · 用户状态保留"))

    def cleanup_lifecycle_demo(self) -> str:
        try:
            self.uninstall_package("lifecycle_demo", purge_state=True)
        except Exception:
            if self.external_root:
                folder = self.external_root / "lifecycle_demo"
                if folder.exists():
                    shutil.rmtree(folder, ignore_errors=True)
            self.app.store.clear_namespace("lifecycle_demo")
            self.discover()
        if self.package_root:
            for pkg in self.package_root.glob("lifecycle_demo_*.lfmod"):
                try:
                    pkg.unlink()
                except Exception:
                    pass
        self.lifecycle_history.clear()
        return self._lifecycle_log("A0.14 生命周期测试已清理")

