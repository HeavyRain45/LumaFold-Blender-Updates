from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import copy
import hashlib
import json
import os
import shutil
import tempfile
import time
from typing import Any, Callable, Dict, Iterable, Mapping, Optional, Tuple


STATE_FILE_SCHEMA = 2
STATE_FORMAT = "lumafold-state"


@dataclass
class PersistenceReport:
    ok: bool
    status: str
    path: str = ""
    message: str = ""
    source_schema: int = STATE_FILE_SCHEMA
    target_schema: int = STATE_FILE_SCHEMA
    migrated: bool = False
    namespaces: Tuple[str, ...] = ()
    issues: Tuple[str, ...] = ()


@dataclass
class NamespaceSchema:
    namespace: str
    version: int = 1
    migrations: Dict[int, Callable[[Dict[str, Any]], Dict[str, Any]]] = field(default_factory=dict)
    exclude_keys: Tuple[str, ...] = ()


class PersistenceManager:
    """Core-owned durable state persistence with migrations and failure isolation.

    A0.12 deliberately stores only host-independent, JSON-safe user state. Runtime
    objects, Blender context snapshots, task workers and lifecycle counters are not
    serialized. Writes are atomic (temp file + os.replace), corrupt files are copied
    aside instead of crashing Blender, and namespace migrations run before state is
    merged back into the live StateStore.
    """

    VOLATILE_NAMESPACES = {"task_demo"}
    CORE_FIELDS = ("shared_counter", "shared_enabled", "shared_value", "shared_text")

    def __init__(self, app):
        self.app = app
        self.schemas: Dict[str, NamespaceSchema] = {}
        self.last_report: Optional[PersistenceReport] = None
        self.last_saved_at: float = 0.0
        self.last_loaded_at: float = 0.0
        self._last_hash: str = ""
        self._loaded_once = False

    def register_namespace(self, namespace: str, version: int = 1, *, migrations=None, exclude_keys=()) -> None:
        namespace = str(namespace or "").strip()
        if not namespace:
            raise ValueError("namespace is required")
        version = max(1, int(version))
        migration_map = dict(migrations or {})
        self.schemas[namespace] = NamespaceSchema(
            namespace=namespace,
            version=version,
            migrations=migration_map,
            exclude_keys=tuple(str(k) for k in (exclude_keys or ())),
        )

    def default_path(self) -> Path:
        import bpy
        root = bpy.utils.user_resource("CONFIG", path="lumafold", create=True)
        return Path(root) / "state.json"

    def probe_path(self) -> Path:
        return self.default_path().with_name("state_migration_probe_v1.json")

    @staticmethod
    def _json_safe(value: Any):
        if value is None or isinstance(value, (bool, int, float, str)):
            return value
        if isinstance(value, Mapping):
            return {str(k): PersistenceManager._json_safe(v) for k, v in value.items()}
        if isinstance(value, (list, tuple)):
            return [PersistenceManager._json_safe(v) for v in value]
        # Unknown runtime objects are intentionally omitted rather than stringified.
        raise TypeError(type(value).__name__)

    def _namespace_payload(self, namespace: str, values: Mapping[str, Any]):
        schema = self.schemas.get(namespace)
        excluded = set(schema.exclude_keys if schema else ())
        data = {}
        for key, value in values.items():
            if str(key) in excluded:
                continue
            try:
                data[str(key)] = self._json_safe(value)
            except TypeError:
                continue
        return {
            "version": int(schema.version if schema else 1),
            "data": data,
        }

    def build_payload(self, *, ui_state: Optional[Mapping[str, Any]] = None) -> Dict[str, Any]:
        if ui_state:
            ui_bucket = self.app.store.namespace("__ui__")
            for key, value in ui_state.items():
                try:
                    ui_bucket[str(key)] = self._json_safe(value)
                except TypeError:
                    pass

        namespaces = {}
        for namespace, values in sorted(self.app.store.snapshot().items()):
            if namespace in self.VOLATILE_NAMESPACES:
                continue
            namespaces[namespace] = self._namespace_payload(namespace, values)

        core = {}
        for field_name in self.CORE_FIELDS:
            core[field_name] = self._json_safe(getattr(self.app.state, field_name))

        return {
            "format": STATE_FORMAT,
            "schema_version": STATE_FILE_SCHEMA,
            "core_version": "0.13",
            "saved_at": time.time(),
            "core": core,
            "namespaces": namespaces,
        }

    @staticmethod
    def _canonical_bytes(payload: Mapping[str, Any]) -> bytes:
        # saved_at is deliberately ignored for change detection.
        stable = copy.deepcopy(dict(payload))
        stable.pop("saved_at", None)
        return json.dumps(stable, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")

    @staticmethod
    def _atomic_write(path: Path, payload: Mapping[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        text = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True)
        fd, tmp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
                handle.write(text)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(tmp_name, path)
        finally:
            try:
                if os.path.exists(tmp_name):
                    os.unlink(tmp_name)
            except Exception:
                pass

    def save(self, path: Optional[Path] = None, *, ui_state: Optional[Mapping[str, Any]] = None, force=True) -> PersistenceReport:
        target = Path(path or self.default_path())
        try:
            payload = self.build_payload(ui_state=ui_state)
            digest = hashlib.sha256(self._canonical_bytes(payload)).hexdigest()
            if not force and digest == self._last_hash and target.exists():
                report = PersistenceReport(True, "UNCHANGED", str(target), "状态没有变化，无需重复写入")
                self.last_report = report
                return report
            self._atomic_write(target, payload)
            self._last_hash = digest
            self.last_saved_at = time.time()
            report = PersistenceReport(
                True, "SAVED", str(target), "状态已原子写入磁盘",
                namespaces=tuple(sorted(payload.get("namespaces", {}).keys())),
            )
        except Exception as exc:
            report = PersistenceReport(False, "SAVE_FAILED", str(target), f"{type(exc).__name__}: {exc}")
        self.last_report = report
        return report

    @staticmethod
    def _legacy_v1_to_v2(payload: Dict[str, Any]) -> Dict[str, Any]:
        """Migrate the intentionally simple A0.12 v1 probe format to v2."""
        legacy_state = dict(payload.get("state") or {})
        legacy_ui = dict(payload.get("ui") or {})
        namespaces = {}
        for namespace, raw_values in legacy_state.items():
            values = dict(raw_values or {})
            if namespace == "sculpt":
                if "size" in values and "brush_size" not in values:
                    values["brush_size"] = values.pop("size")
                if "strength" in values and "brush_strength" not in values:
                    values["brush_strength"] = values.pop("strength")
                if "alpha" in values and "alpha_slot" not in values:
                    values["alpha_slot"] = values.pop("alpha")
            elif namespace == "model":
                if "bevel" in values and "bevel_width" not in values:
                    values["bevel_width"] = values.pop("bevel")
                if "segments" in values and "bevel_segments" not in values:
                    values["bevel_segments"] = values.pop("segments")
            namespaces[str(namespace)] = {"version": 1, "data": values}
        if legacy_ui:
            ui_values = {}
            if "scale" in legacy_ui:
                ui_values["ui_scale"] = legacy_ui["scale"]
                ui_values["requested_scale"] = legacy_ui["scale"]
                ui_values["style_scale"] = legacy_ui["scale"]
            if "page" in legacy_ui:
                ui_values["page"] = legacy_ui["page"]
            namespaces["__ui__"] = {"version": 1, "data": ui_values}
        return {
            "format": STATE_FORMAT,
            "schema_version": 2,
            "core_version": str(payload.get("core_version") or "legacy"),
            "saved_at": float(payload.get("saved_at") or time.time()),
            "core": dict(payload.get("core") or {}),
            "namespaces": namespaces,
        }

    def _migrate_file_payload(self, payload: Dict[str, Any]) -> Tuple[Dict[str, Any], int, bool]:
        source_schema = int(payload.get("schema_version", 1) or 1)
        current = source_schema
        migrated = False
        result = copy.deepcopy(payload)
        while current < STATE_FILE_SCHEMA:
            if current == 1:
                result = self._legacy_v1_to_v2(result)
                current = 2
                migrated = True
            else:
                raise RuntimeError(f"没有从状态 schema {current} 到 {current + 1} 的迁移器")
        if current > STATE_FILE_SCHEMA:
            raise RuntimeError(f"状态文件来自更新版本 schema {current}，当前只支持 {STATE_FILE_SCHEMA}")
        if str(result.get("format", "")) != STATE_FORMAT:
            raise RuntimeError("不是 LumaFold 状态文件")
        return result, source_schema, migrated

    def _migrate_namespace(self, namespace: str, entry: Mapping[str, Any]):
        schema = self.schemas.get(namespace)
        version = max(1, int(entry.get("version", 1) or 1))
        data = dict(entry.get("data") or {})
        issues = []
        if schema is None:
            return data, version, issues
        if version > schema.version:
            issues.append(f"{namespace}: 保存版本 v{version} 高于当前 v{schema.version}，已跳过")
            return None, version, issues
        while version < schema.version:
            migrate = schema.migrations.get(version)
            if migrate is None:
                issues.append(f"{namespace}: 缺少 v{version}→v{version + 1} 迁移器，已跳过")
                return None, version, issues
            data = dict(migrate(dict(data)) or {})
            version += 1
        return data, version, issues

    def apply_payload(self, payload: Mapping[str, Any]) -> Tuple[Tuple[str, ...], Tuple[str, ...]]:
        namespaces = payload.get("namespaces") or {}
        restored = []
        issues = []
        for namespace, entry in namespaces.items():
            if namespace in self.VOLATILE_NAMESPACES:
                continue
            if not isinstance(entry, Mapping):
                issues.append(f"{namespace}: 状态条目无效")
                continue
            data, _version, ns_issues = self._migrate_namespace(str(namespace), entry)
            issues.extend(ns_issues)
            if data is None:
                continue
            self.app.store.restore({str(namespace): data}, merge=True)
            restored.append(str(namespace))

        core = payload.get("core") or {}
        for field_name in self.CORE_FIELDS:
            if field_name in core:
                try:
                    setattr(self.app.state, field_name, core[field_name])
                except Exception:
                    issues.append("Core 字段无法恢复: " + field_name)
        return tuple(sorted(restored)), tuple(issues)

    def _backup_bad_file(self, path: Path, suffix: str) -> str:
        if not path.exists():
            return ""
        stamp = time.strftime("%Y%m%d-%H%M%S")
        backup = path.with_name(f"{path.name}.{suffix}-{stamp}.bak")
        try:
            shutil.copy2(path, backup)
            return str(backup)
        except Exception:
            return ""

    def load(self, path: Optional[Path] = None, *, apply=True, rewrite_migrated=False) -> PersistenceReport:
        source = Path(path or self.default_path())
        if not source.exists():
            report = PersistenceReport(True, "NOT_FOUND", str(source), "还没有持久化状态文件")
            self.last_report = report
            return report
        try:
            payload = json.loads(source.read_text(encoding="utf-8"))
            if not isinstance(payload, dict):
                raise RuntimeError("状态根节点必须是对象")
            migrated_payload, source_schema, migrated = self._migrate_file_payload(payload)
            restored, issues = self.apply_payload(migrated_payload) if apply else ((), ())
            if migrated and rewrite_migrated:
                self._backup_bad_file(source, f"schema{source_schema}")
                self._atomic_write(source, migrated_payload)
            self._last_hash = hashlib.sha256(self._canonical_bytes(migrated_payload)).hexdigest()
            self.last_loaded_at = time.time()
            status = "MIGRATED" if migrated else "LOADED"
            message = f"已恢复 {len(restored)} 个命名空间" if apply else "状态文件检查通过"
            report = PersistenceReport(
                True, status, str(source), message,
                source_schema=source_schema, target_schema=STATE_FILE_SCHEMA,
                migrated=migrated, namespaces=restored, issues=issues,
            )
        except Exception as exc:
            backup = self._backup_bad_file(source, "corrupt")
            message = f"{type(exc).__name__}: {exc}"
            if backup:
                message += " · 已备份隔离到 " + backup
            report = PersistenceReport(False, "LOAD_FAILED_ISOLATED", str(source), message)
        self.last_report = report
        return report

    def load_once(self) -> PersistenceReport:
        if self._loaded_once:
            return self.last_report or PersistenceReport(True, "ALREADY_LOADED", str(self.default_path()))
        self._loaded_once = True
        return self.load(apply=True, rewrite_migrated=True)

    def write_legacy_probe(self) -> Path:
        path = self.probe_path()
        payload = {
            "schema_version": 1,
            "core_version": "A0.11-probe",
            "saved_at": time.time(),
            "core": {"shared_value": 0.44},
            "state": {
                "sculpt": {"size": 91.0, "strength": 0.66, "alpha": 3},
                "model": {"bevel": 0.031, "segments": 6},
                "migration_probe": {"value": 42, "label": "旧版状态"},
            },
            "ui": {"scale": 1.25, "page": 4},
        }
        self._atomic_write(path, payload)
        return path

    def run_migration_probe(self) -> PersistenceReport:
        path = self.write_legacy_probe()
        report = self.load(path, apply=False, rewrite_migrated=False)
        if not report.ok or not report.migrated:
            return report
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
            migrated, source_schema, _ = self._migrate_file_payload(raw)
            sculpt = migrated["namespaces"]["sculpt"]["data"]
            model = migrated["namespaces"]["model"]["data"]
            ok = (
                int(source_schema) == 1
                and float(sculpt.get("brush_size", 0)) == 91.0
                and abs(float(sculpt.get("brush_strength", 0)) - 0.66) < 1e-6
                and abs(float(model.get("bevel_width", 0)) - 0.031) < 1e-6
                and int(model.get("bevel_segments", 0)) == 6
            )
            if not ok:
                return PersistenceReport(False, "MIGRATION_FAILED", str(path), "旧字段没有正确迁移")
            final = PersistenceReport(
                True, "MIGRATED", str(path),
                "v1 → v2 成功：size→brush_size，bevel→bevel_width",
                source_schema=1, target_schema=2, migrated=True,
                namespaces=("sculpt", "model", "migration_probe", "__ui__"),
            )
            self.last_report = final
            return final
        finally:
            pass

    def cleanup_probe(self) -> None:
        try:
            self.probe_path().unlink(missing_ok=True)
        except Exception:
            pass
