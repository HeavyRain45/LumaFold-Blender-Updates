import bpy

from .core.state import STATE
from .runtime import real_machine_trace, update_product


class LUMAFOLD_MT_product_maintenance(bpy.types.Menu):
    bl_label = "LumaFold"
    bl_idname = "LUMAFOLD_MT_product_maintenance"

    def draw(self, context):
        layout = self.layout
        status = layout.column(align=True)
        update = {}

        try:
            update = update_product.menu_snapshot()
            version = str(update.get("version", "") or "")
            channel_label = str(update.get("channel_label", "稳定版 Stable") or "稳定版 Stable")
            has_error = bool(STATE.last_error)
            status.label(
                text=f"LumaFold {'异常' if has_error else '正常'} · v{version} · {channel_label}",
                icon='ERROR' if has_error else 'CHECKMARK',
            )

            transaction_state = str(update.get("update_transaction", "") or "")
            update_error = str(update.get("update_error", "") or "")
            if transaction_state == 'failed':
                message = update_error[:72] if update_error else "上次更新失败，请重试"
                status.label(text=message, icon='ERROR')
            elif transaction_state in {'armed', 'waiting_for_exit', 'installing'}:
                status.label(text="正在更新 LumaFold…", icon='FILE_REFRESH')
            elif not bool(update.get("online_allowed", False)):
                status.label(text="当前未允许联网，无法检查更新", icon='INFO')
            elif not bool(update.get("configured", False)):
                status.label(text="在线更新暂不可用", icon='INFO')
        except Exception:
            if STATE.last_error:
                status.label(text="LumaFold 异常", icon='ERROR')
            else:
                status.label(text="LumaFold 正常", icon='CHECKMARK')

        remote_version = str(update.get("remote_version", "") or "")
        checked = bool(update.get("checked_for_updates", False))
        available = bool(update.get("update_available", False))
        if checked:
            result = layout.column(align=True)
            if available and remote_version:
                result.label(text=f"发现新版本：v{remote_version}", icon='INFO')
            elif remote_version:
                result.label(text="已是最新版本", icon='CHECKMARK')

        layout.separator()
        actions = layout.column(align=True)
        actions.operator("lumafold.update_check", text="检查更新", icon='FILE_REFRESH')
        actions.operator("lumafold.update_install", text="安装更新", icon='IMPORT')

        layout.separator()
        diagnostics = layout.column(align=True)
        diagnostics.label(text="维护 / 诊断", icon='TOOL_SETTINGS')
        trace_visible = bool(real_machine_trace.panel_visible())
        diagnostics.operator(
            "lumafold.toggle_real_machine_trace_panel",
            text="隐藏诊断 N 菜单" if trace_visible else "显示诊断 N 菜单",
            icon='HIDE_ON' if trace_visible else 'HIDE_OFF',
        )


class LUMAFOLD_Preferences(bpy.types.AddonPreferences):
    """Low-frequency maintenance entry shown in Blender Add-on Preferences."""

    bl_idname = __package__

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label(text="LumaFold 维护 / 诊断", icon='TOOL_SETTINGS')

        visible = bool(real_machine_trace.panel_visible())
        row = box.row(align=True)
        row.operator(
            "lumafold.toggle_real_machine_trace_panel",
            text="隐藏诊断 N 菜单" if visible else "显示诊断 N 菜单",
            icon='HIDE_ON' if visible else 'HIDE_OFF',
        )

        row = box.row(align=True)
        row.operator(
            "lumafold.copy_real_machine_trace",
            text="复制实机追踪",
            icon='COPYDOWN',
        )
        row.operator(
            "lumafold.clear_real_machine_trace",
            text="清空追踪",
            icon='TRASH',
        )

        box.label(text="诊断面板默认隐藏；需要排查时可从这里随时开启。", icon='INFO')


def _draw_lumafold_header(self, context):
    """Product launch + low-frequency maintenance entry; no N-panel required."""
    row = self.layout.row(align=True)
    row.separator(factor=0.35)
    embedded_running = bool(
        getattr(STATE, "running", False)
        and str(getattr(STATE, "host_mode", "embedded") or "embedded").lower() == "embedded"
    )
    operator_id = "lumafold.close_embedded_host" if embedded_running else "lumafold.toggle_p0"
    row.operator(
        operator_id,
        text="LumaFold",
        icon='BRUSH_DATA',
        depress=bool(getattr(STATE, "running", False)),
    )


def _tag_view3d_headers_redraw():
    try:
        wm = bpy.context.window_manager
        for window in wm.windows:
            screen = window.screen
            if screen is None:
                continue
            for area in screen.areas:
                if area.type != 'VIEW_3D':
                    continue
                for region in area.regions:
                    if region.type == 'HEADER':
                        region.tag_redraw()
    except Exception:
        pass


CLASSES = (LUMAFOLD_MT_product_maintenance, LUMAFOLD_Preferences)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    try:
        bpy.types.VIEW3D_HT_header.remove(_draw_lumafold_header)
    except Exception:
        pass
    try:
        bpy.types.VIEW3D_HT_header.append(_draw_lumafold_header)
    except Exception:
        pass
    _tag_view3d_headers_redraw()


def unregister():
    try:
        bpy.types.VIEW3D_HT_header.remove(_draw_lumafold_header)
    except Exception:
        pass
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
