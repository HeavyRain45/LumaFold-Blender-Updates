from __future__ import annotations

"""Satellite Primary geometry lifecycle.

The native runtime owns HWND sizing and the shared View owns the actual content
geometry.  This session owns *when* that geometry may be calibrated again.

A Satellite process can start while Blender is still in Object mode and later
enter Sculpt without a Host restart.  Treating the first rendered layout as a
process-lifetime geometry truth locks a short non-Sculpt height and clips the
real Sculpt product.  Geometry truth therefore follows a small layout epoch:
entering Sculpt invalidates the previous calibration exactly once, then the
shared View's real bottom anchor establishes the new deterministic base.

Ordinary frames never remeasure the window.  Quick-row changes remain handled by
the runtime's deterministic primary_surface_geometry contract.
"""

_INSTALLED = False
_ORIGINAL_SYNC = None
_ORIGINAL_CALIBRATE = None
_LAST_MODE = ""
_RECALIBRATE_VISIBLE = False


def _mode_from_snapshot(snapshot) -> str:
    try:
        status = dict((snapshot or {}).get("sculpt_status") or {})
        return str(status.get("mode") or "").strip().upper()
    except Exception:
        return ""


def _calibrate_from_view(runtime, rows) -> bool:
    """One-shot calibration from the shared Primary bottom-action anchor."""
    global _RECALIBRATE_VISIBLE

    if not runtime.hwnd_main:
        return False
    # Do not freeze a non-Sculpt startup placeholder as Primary geometry truth.
    if _LAST_MODE != "SCULPT":
        return False
    # Hidden preflight calibration is always legal.  A visible measurement is
    # legal only for the explicit Object->Sculpt layout epoch transition.
    if runtime.visible and not _RECALIBRATE_VISIBLE:
        return False

    try:
        anchor = dict(runtime.surface_state.get("sculpt_brush_library_anchor") or {})
        bottom = float(anchor.get("button_bottom", 0.0) or 0.0)
        if bottom <= 0.0:
            return False
        window_pos = runtime.imgui.get_window_pos()
        style = runtime.imgui.get_style()
        bottom_padding = float(style.window_padding[1])
        desired_height_px = max(1.0, bottom - float(window_pos[1]) + bottom_padding)
    except Exception:
        return False

    cr = runtime.wintypes.RECT()
    if not runtime.user32.GetClientRect(runtime.hwnd_main, runtime.ctypes.byref(cr)):
        return False
    cw = max(1, int(cr.right - cr.left))
    scale = max(0.01, float(runtime.current_scale))
    width_design = float(cw) / scale
    measured_height_design = float(desired_height_px) / scale

    runtime._primary_width_design = width_design
    runtime._primary_base_height_design = runtime.normalize_base_height_design(
        measured_height_design,
        rows=runtime.clamp_quick_rows(rows),
        width_design=width_design,
    )
    runtime._primary_geometry_ready = True
    runtime._primary_resize_pending = True
    _RECALIBRATE_VISIBLE = False
    return True


def install(runtime) -> None:
    global _INSTALLED, _ORIGINAL_SYNC, _ORIGINAL_CALIBRATE
    global _LAST_MODE, _RECALIBRATE_VISIBLE
    if _INSTALLED:
        return

    _ORIGINAL_SYNC = runtime._sync_local_from_snapshot
    _ORIGINAL_CALIBRATE = runtime._calibrate_primary_surface_from_view

    def sync_with_layout_epoch(snapshot):
        global _LAST_MODE, _RECALIBRATE_VISIBLE
        before_rows = runtime.clamp_quick_rows(runtime.local_sculpt.get("quick_rows", 2))
        result = _ORIGINAL_SYNC(snapshot)
        after_rows = runtime.clamp_quick_rows(runtime.local_sculpt.get("quick_rows", 2))

        mode = _mode_from_snapshot(snapshot)
        if mode and mode != _LAST_MODE:
            if mode == "SCULPT":
                # A real Sculpt layout has become authoritative.  Invalidate any
                # shorter startup/placeholder calibration and allow one visible
                # rebase if the Satellite was already shown.
                runtime._primary_geometry_ready = False
                runtime._primary_resize_pending = True
                _RECALIBRATE_VISIBLE = bool(runtime.visible)
            _LAST_MODE = mode

        # Runtime row synchronization already records _pending_quick_rows; this
        # missing dirty bit is required so the deterministic geometry contract
        # actually commits the new size.
        if after_rows != before_rows or runtime._pending_quick_rows is not None:
            runtime._primary_resize_pending = True
        return result

    def calibrate_with_layout_epoch(rows):
        if runtime._primary_geometry_ready:
            return True
        return _calibrate_from_view(runtime, rows)

    runtime._sync_local_from_snapshot = sync_with_layout_epoch
    runtime._calibrate_primary_surface_from_view = calibrate_with_layout_epoch
    _INSTALLED = True


def uninstall(runtime) -> None:
    global _INSTALLED, _ORIGINAL_SYNC, _ORIGINAL_CALIBRATE
    global _LAST_MODE, _RECALIBRATE_VISIBLE
    if not _INSTALLED:
        return
    if _ORIGINAL_SYNC is not None:
        runtime._sync_local_from_snapshot = _ORIGINAL_SYNC
    if _ORIGINAL_CALIBRATE is not None:
        runtime._calibrate_primary_surface_from_view = _ORIGINAL_CALIBRATE
    _ORIGINAL_SYNC = None
    _ORIGINAL_CALIBRATE = None
    _LAST_MODE = ""
    _RECALIBRATE_VISIBLE = False
    _INSTALLED = False
