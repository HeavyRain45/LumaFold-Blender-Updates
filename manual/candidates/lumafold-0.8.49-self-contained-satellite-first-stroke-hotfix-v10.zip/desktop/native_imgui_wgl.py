from __future__ import annotations

import ctypes
from ctypes import wintypes


# Minimal Win32/WGL + OpenGL 1.1 renderer for Dear ImGui DrawData.
# No GLFW/SDL/PyOpenGL dependency is required.  The product surface is small,
# so compatibility-profile immediate triangles are deliberately used for the
# S0.4 native-host convergence gate; a batched renderer can replace this later
# without touching the shared View/component tree.

PFD_TYPE_RGBA = 0
PFD_MAIN_PLANE = 0
PFD_DRAW_TO_WINDOW = 0x00000004
PFD_SUPPORT_OPENGL = 0x00000020
PFD_DOUBLEBUFFER = 0x00000001

GL_COLOR_BUFFER_BIT = 0x00004000
GL_TRIANGLES = 0x0004
GL_BLEND = 0x0BE2
GL_CULL_FACE = 0x0B44
GL_DEPTH_TEST = 0x0B71
GL_SCISSOR_TEST = 0x0C11
GL_TEXTURE_2D = 0x0DE1
GL_SRC_ALPHA = 0x0302
GL_ONE_MINUS_SRC_ALPHA = 0x0303
GL_PROJECTION = 0x1701
GL_MODELVIEW = 0x1700
GL_RGBA = 0x1908
GL_UNSIGNED_BYTE = 0x1401
GL_TEXTURE_MIN_FILTER = 0x2801
GL_TEXTURE_MAG_FILTER = 0x2800
GL_LINEAR = 0x2601
GL_UNPACK_ALIGNMENT = 0x0CF5


class PIXELFORMATDESCRIPTOR(ctypes.Structure):
    _fields_ = [
        ("nSize", wintypes.WORD),
        ("nVersion", wintypes.WORD),
        ("dwFlags", wintypes.DWORD),
        ("iPixelType", ctypes.c_ubyte),
        ("cColorBits", ctypes.c_ubyte),
        ("cRedBits", ctypes.c_ubyte),
        ("cRedShift", ctypes.c_ubyte),
        ("cGreenBits", ctypes.c_ubyte),
        ("cGreenShift", ctypes.c_ubyte),
        ("cBlueBits", ctypes.c_ubyte),
        ("cBlueShift", ctypes.c_ubyte),
        ("cAlphaBits", ctypes.c_ubyte),
        ("cAlphaShift", ctypes.c_ubyte),
        ("cAccumBits", ctypes.c_ubyte),
        ("cAccumRedBits", ctypes.c_ubyte),
        ("cAccumGreenBits", ctypes.c_ubyte),
        ("cAccumBlueBits", ctypes.c_ubyte),
        ("cAccumAlphaBits", ctypes.c_ubyte),
        ("cDepthBits", ctypes.c_ubyte),
        ("cStencilBits", ctypes.c_ubyte),
        ("cAuxBuffers", ctypes.c_ubyte),
        ("iLayerType", ctypes.c_ubyte),
        ("bReserved", ctypes.c_ubyte),
        ("dwLayerMask", wintypes.DWORD),
        ("dwVisibleMask", wintypes.DWORD),
        ("dwDamageMask", wintypes.DWORD),
    ]


class ImDrawVert(ctypes.Structure):
    _fields_ = [
        ("x", ctypes.c_float),
        ("y", ctypes.c_float),
        ("u", ctypes.c_float),
        ("v", ctypes.c_float),
        ("col", ctypes.c_uint32),
    ]


def _srgb_byte(v: int) -> int:
    x = max(0.0, min(1.0, float(v) / 255.0))
    if x <= 0.0031308:
        y = 12.92 * x
    else:
        y = 1.055 * (x ** (1.0 / 2.4)) - 0.055
    return max(0, min(255, int(round(y * 255.0))))


_SRGB_LUT = tuple(_srgb_byte(i) for i in range(256))


class NativeWGLImguiRenderer:
    def __init__(self, hwnd, imgui, *, clear_linear_rgb=None):
        self.hwnd = hwnd
        self.imgui = imgui
        self.clear_linear_rgb = tuple(clear_linear_rgb or (0.04, 0.04, 0.04))[:3]
        self.user32 = ctypes.WinDLL("user32", use_last_error=True)
        self.gdi32 = ctypes.WinDLL("gdi32", use_last_error=True)
        self.gl = ctypes.WinDLL("opengl32", use_last_error=True)
        self.hdc = None
        self.hglrc = None
        self._textures: set[int] = set()
        self._setup_signatures()
        self._create_context()

    def _setup_signatures(self):
        self.user32.GetDC.argtypes = [wintypes.HWND]
        self.user32.GetDC.restype = wintypes.HDC
        self.user32.ReleaseDC.argtypes = [wintypes.HWND, wintypes.HDC]
        self.user32.ReleaseDC.restype = ctypes.c_int
        self.gdi32.ChoosePixelFormat.argtypes = [wintypes.HDC, ctypes.POINTER(PIXELFORMATDESCRIPTOR)]
        self.gdi32.ChoosePixelFormat.restype = ctypes.c_int
        self.gdi32.SetPixelFormat.argtypes = [wintypes.HDC, ctypes.c_int, ctypes.POINTER(PIXELFORMATDESCRIPTOR)]
        self.gdi32.SetPixelFormat.restype = wintypes.BOOL
        self.gdi32.SwapBuffers.argtypes = [wintypes.HDC]
        self.gdi32.SwapBuffers.restype = wintypes.BOOL

        self.gl.wglCreateContext.argtypes = [wintypes.HDC]
        self.gl.wglCreateContext.restype = ctypes.c_void_p
        self.gl.wglMakeCurrent.argtypes = [wintypes.HDC, ctypes.c_void_p]
        self.gl.wglMakeCurrent.restype = wintypes.BOOL
        self.gl.wglDeleteContext.argtypes = [ctypes.c_void_p]
        self.gl.wglDeleteContext.restype = wintypes.BOOL

        self.gl.glViewport.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int]
        self.gl.glClearColor.argtypes = [ctypes.c_float, ctypes.c_float, ctypes.c_float, ctypes.c_float]
        self.gl.glClear.argtypes = [ctypes.c_uint]
        self.gl.glEnable.argtypes = [ctypes.c_uint]
        self.gl.glDisable.argtypes = [ctypes.c_uint]
        self.gl.glBlendFunc.argtypes = [ctypes.c_uint, ctypes.c_uint]
        self.gl.glScissor.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int]
        self.gl.glMatrixMode.argtypes = [ctypes.c_uint]
        self.gl.glLoadIdentity.argtypes = []
        self.gl.glOrtho.argtypes = [ctypes.c_double, ctypes.c_double, ctypes.c_double, ctypes.c_double, ctypes.c_double, ctypes.c_double]
        self.gl.glBegin.argtypes = [ctypes.c_uint]
        self.gl.glEnd.argtypes = []
        self.gl.glColor4ub.argtypes = [ctypes.c_ubyte, ctypes.c_ubyte, ctypes.c_ubyte, ctypes.c_ubyte]
        self.gl.glTexCoord2f.argtypes = [ctypes.c_float, ctypes.c_float]
        self.gl.glVertex2f.argtypes = [ctypes.c_float, ctypes.c_float]
        self.gl.glBindTexture.argtypes = [ctypes.c_uint, ctypes.c_uint]
        self.gl.glGenTextures.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_uint)]
        self.gl.glDeleteTextures.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_uint)]
        self.gl.glTexParameteri.argtypes = [ctypes.c_uint, ctypes.c_uint, ctypes.c_int]
        self.gl.glPixelStorei.argtypes = [ctypes.c_uint, ctypes.c_int]
        self.gl.glTexImage2D.argtypes = [
            ctypes.c_uint, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
            ctypes.c_int, ctypes.c_uint, ctypes.c_uint, ctypes.c_void_p,
        ]

    def _create_context(self):
        self.hdc = self.user32.GetDC(self.hwnd)
        if not self.hdc:
            raise ctypes.WinError(ctypes.get_last_error())
        pfd = PIXELFORMATDESCRIPTOR()
        pfd.nSize = ctypes.sizeof(PIXELFORMATDESCRIPTOR)
        pfd.nVersion = 1
        pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER
        pfd.iPixelType = PFD_TYPE_RGBA
        pfd.cColorBits = 32
        pfd.cAlphaBits = 8
        pfd.cDepthBits = 0
        pfd.cStencilBits = 0
        pfd.iLayerType = PFD_MAIN_PLANE
        pixel_format = self.gdi32.ChoosePixelFormat(self.hdc, ctypes.byref(pfd))
        if not pixel_format:
            raise RuntimeError("ChoosePixelFormat failed")
        if not self.gdi32.SetPixelFormat(self.hdc, pixel_format, ctypes.byref(pfd)):
            raise RuntimeError("SetPixelFormat failed")
        self.hglrc = self.gl.wglCreateContext(self.hdc)
        if not self.hglrc:
            raise RuntimeError("wglCreateContext failed")
        if not self.gl.wglMakeCurrent(self.hdc, self.hglrc):
            raise RuntimeError("wglMakeCurrent failed")

    def make_current(self):
        if self.hdc and self.hglrc:
            self.gl.wglMakeCurrent(self.hdc, self.hglrc)

    def _delete_texture_id(self, tex_id: int):
        tex_id = int(tex_id or 0)
        if tex_id <= 0:
            return
        value = ctypes.c_uint(tex_id)
        self.gl.glDeleteTextures(1, ctypes.byref(value))
        self._textures.discard(tex_id)

    def register_rgba_texture(self, width: int, height: int, rgba_bytes: bytes) -> int:
        """Upload an application-owned RGBA8 texture for shared UI previews."""
        width = int(width); height = int(height)
        raw = bytes(rgba_bytes)
        if width <= 0 or height <= 0 or len(raw) != width * height * 4:
            raise ValueError("RGBA texture size mismatch")
        self.make_current()
        tex = ctypes.c_uint(0)
        self.gl.glGenTextures(1, ctypes.byref(tex))
        if not tex.value:
            raise RuntimeError("glGenTextures failed")
        buf = ctypes.create_string_buffer(raw)
        self.gl.glBindTexture(GL_TEXTURE_2D, tex.value)
        self.gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
        self.gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
        self.gl.glPixelStorei(GL_UNPACK_ALIGNMENT, 1)
        self.gl.glTexImage2D(
            GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0,
            GL_RGBA, GL_UNSIGNED_BYTE, ctypes.cast(buf, ctypes.c_void_p),
        )
        self._textures.add(int(tex.value))
        return int(tex.value)

    def unregister_texture(self, tex_id: int):
        self.make_current()
        self._delete_texture_id(int(tex_id or 0))

    def _update_texture(self, tex_data):
        status = tex_data.status
        want_create = self.imgui.TextureStatus.WANT_CREATE
        want_updates = self.imgui.TextureStatus.WANT_UPDATES
        want_destroy = self.imgui.TextureStatus.WANT_DESTROY
        if status in (want_create, want_updates):
            old = int(tex_data.get_tex_id() or 0)
            if old:
                self._delete_texture_id(old)
            tex = ctypes.c_uint(0)
            self.gl.glGenTextures(1, ctypes.byref(tex))
            if not tex.value:
                raise RuntimeError("glGenTextures failed")
            pixels = tex_data.get_pixels()
            raw = bytes(pixels)
            expected = int(tex_data.width) * int(tex_data.height) * 4
            if len(raw) != expected:
                raise RuntimeError(f"ImGui texture byte size mismatch: {len(raw)} != {expected}")
            buf = ctypes.create_string_buffer(raw)
            self.gl.glBindTexture(GL_TEXTURE_2D, tex.value)
            self.gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
            self.gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
            self.gl.glPixelStorei(GL_UNPACK_ALIGNMENT, 1)
            self.gl.glTexImage2D(
                GL_TEXTURE_2D, 0, GL_RGBA,
                int(tex_data.width), int(tex_data.height), 0,
                GL_RGBA, GL_UNSIGNED_BYTE, ctypes.cast(buf, ctypes.c_void_p),
            )
            tex_data.set_tex_id(int(tex.value))
            tex_data.set_status(self.imgui.TextureStatus.OK)
            self._textures.add(int(tex.value))
        elif status == want_destroy and tex_data.unused_frames > 0:
            old = int(tex_data.get_tex_id() or 0)
            self._delete_texture_id(old)
            tex_data.set_tex_id(0)
            tex_data.set_status(self.imgui.TextureStatus.DESTROYED)

    def render(self, draw_data, width: int, height: int):
        width = int(width)
        height = int(height)
        if width <= 0 or height <= 0:
            return
        self.make_current()
        if getattr(draw_data, "textures", None) is not None:
            for tex_data in draw_data.textures:
                self._update_texture(tex_data)

        self.gl.glViewport(0, 0, width, height)
        # Native host clear color must match the root ImGui surface token.
        # Values are authored in linear space just like LumaFold theme colors.
        clr = []
        for c in self.clear_linear_rgb:
            idx = max(0, min(255, int(round(float(c) * 255.0))))
            clr.append(_SRGB_LUT[idx] / 255.0)
        while len(clr) < 3:
            clr.append(clr[-1] if clr else 0.0)
        self.gl.glClearColor(clr[0], clr[1], clr[2], 1.0)
        self.gl.glClear(GL_COLOR_BUFFER_BIT)
        self.gl.glEnable(GL_BLEND)
        self.gl.glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        self.gl.glDisable(GL_CULL_FACE)
        self.gl.glDisable(GL_DEPTH_TEST)
        self.gl.glEnable(GL_SCISSOR_TEST)
        self.gl.glEnable(GL_TEXTURE_2D)
        self.gl.glMatrixMode(GL_PROJECTION)
        self.gl.glLoadIdentity()
        self.gl.glOrtho(0.0, float(width), float(height), 0.0, -1.0, 1.0)
        self.gl.glMatrixMode(GL_MODELVIEW)
        self.gl.glLoadIdentity()

        idx_type = ctypes.c_ushort if self.imgui.INDEX_SIZE == 2 else ctypes.c_uint
        display_pos = getattr(draw_data, "display_pos", (0.0, 0.0))
        dp_x, dp_y = float(display_pos[0]), float(display_pos[1])

        for draw_list in draw_data.commands_lists:
            vertices = ctypes.cast(draw_list.vtx_buffer_data, ctypes.POINTER(ImDrawVert))
            indices = ctypes.cast(draw_list.idx_buffer_data, ctypes.POINTER(idx_type))
            for cmd in draw_list.commands:
                tex_id = int(cmd.tex_ref.get_tex_id() or 0)
                if tex_id not in self._textures:
                    continue
                x1, y1, x2, y2 = (float(v) for v in cmd.clip_rect)
                x1 -= dp_x; x2 -= dp_x; y1 -= dp_y; y2 -= dp_y
                sx = max(0, int(x1))
                sy = max(0, int(height - y2))
                sw = max(0, min(width, int(x2)) - sx)
                sh = max(0, min(height, int(height - y1)) - sy)
                if sw <= 0 or sh <= 0:
                    continue
                self.gl.glScissor(sx, sy, sw, sh)
                self.gl.glBindTexture(GL_TEXTURE_2D, tex_id)
                self.gl.glBegin(GL_TRIANGLES)
                try:
                    base = int(cmd.vtx_offset)
                    start = int(cmd.idx_offset)
                    end = start + int(cmd.elem_count)
                    for j in range(start, end):
                        v = vertices[base + int(indices[j])]
                        c = int(v.col)
                        r = _SRGB_LUT[(c >> 0) & 0xFF]
                        g = _SRGB_LUT[(c >> 8) & 0xFF]
                        b = _SRGB_LUT[(c >> 16) & 0xFF]
                        a = (c >> 24) & 0xFF
                        self.gl.glColor4ub(r, g, b, a)
                        self.gl.glTexCoord2f(float(v.u), float(v.v))
                        self.gl.glVertex2f(float(v.x) - dp_x, float(v.y) - dp_y)
                finally:
                    self.gl.glEnd()

        self.gl.glDisable(GL_SCISSOR_TEST)
        self.gdi32.SwapBuffers(self.hdc)

    def shutdown(self):
        try:
            self.make_current()
            for tex_id in tuple(self._textures):
                self._delete_texture_id(tex_id)
        except Exception:
            pass
        try:
            if self.hglrc:
                self.gl.wglMakeCurrent(None, None)
                self.gl.wglDeleteContext(self.hglrc)
        finally:
            self.hglrc = None
        if self.hdc:
            try:
                self.user32.ReleaseDC(self.hwnd, self.hdc)
            except Exception:
                pass
            self.hdc = None
