from __future__ import annotations

"""Runtime RNA capability probes that cannot be trusted from bpy.types alone.

Some Blender collection/properties are available on live RNA instances while
`hasattr(bpy.types.X, name)` returns False. LumaFold's compatibility gate must
therefore probe the actual runtime object before declaring an API missing.
"""

from .blender_compat53 import BlenderCapabilitiesServiceCompat


class BlenderCapabilitiesRuntimeProbe(BlenderCapabilitiesServiceCompat):
    """Capability snapshot backed by both RNA type metadata and live instances."""

    @staticmethod
    def _window_modal_operators_probe():
        import bpy

        # Fast path: current live Blender Window. This is the same property the
        # working LumaFold hot-reload diagnostic reads at runtime.
        window = getattr(bpy.context, "window", None)
        if window is not None:
            try:
                getattr(window, "modal_operators")
                return True, "context.window"
            except Exception:
                pass

        # Operators can occasionally run with no current window context; probe
        # the WindowManager's live windows before falling back to RNA metadata.
        try:
            wm = getattr(bpy.context, "window_manager", None)
            for candidate in tuple(getattr(wm, "windows", ()) or ()):
                try:
                    getattr(candidate, "modal_operators")
                    return True, "window_manager.windows"
                except Exception:
                    continue
        except Exception:
            pass

        # Last resort: query the RNA property collection instead of Python class
        # attribute lookup. Blender can expose an RNA member here even when the
        # class-level hasattr() path is false.
        try:
            window_type = getattr(bpy.types, "Window", None)
            rna = getattr(window_type, "bl_rna", None)
            props = getattr(rna, "properties", None)
            if props is not None and props.get("modal_operators") is not None:
                return True, "Window.bl_rna"
        except Exception:
            pass

        return False, "missing"

    @staticmethod
    def _sculpt_settings_probe():
        """Probe live 5.2/5.3 Sculpt owners instead of only bpy.types metadata.

        Blender 5.2.1 can expose UnifiedPaintSettings flags through the live
        ToolSettings instance even when the Python type object does not advertise
        them through hasattr(). The operational truth is whether LumaFold can read
        the same objects its Sculpt settings bridge already uses successfully.
        """
        import bpy

        tool_settings = getattr(bpy.context, "tool_settings", None)
        sculpt = getattr(tool_settings, "sculpt", None) if tool_settings is not None else None
        brush = getattr(sculpt, "brush", None) if sculpt is not None else None
        ups = getattr(sculpt, "unified_paint_settings", None) if sculpt is not None else None
        if ups is None and tool_settings is not None:
            ups = getattr(tool_settings, "unified_paint_settings", None)

        brush_flags = bool(
            brush is not None
            and hasattr(brush, "use_unified_size")
            and hasattr(brush, "use_unified_strength")
        )
        ups_flags = bool(
            ups is not None
            and hasattr(ups, "use_unified_size")
            and hasattr(ups, "use_unified_strength")
        )
        brush_values = bool(
            brush is not None
            and hasattr(brush, "size")
            and hasattr(brush, "strength")
        )
        ups_values = bool(
            ups is not None
            and hasattr(ups, "size")
            and hasattr(ups, "strength")
        )

        if brush_flags:
            flag_source = "brush"
        elif ups_flags:
            flag_source = "unified_paint_settings"
        else:
            flag_source = "missing"

        if brush_values and ups_values:
            value_source = "brush+unified_paint_settings"
        elif brush_values:
            value_source = "brush"
        elif ups_values:
            value_source = "unified_paint_settings"
        else:
            value_source = "missing"

        return {
            "brush_flags": brush_flags,
            "ups_flags": ups_flags,
            "brush_values": brush_values,
            "ups_values": ups_values,
            "flag_source": flag_source,
            "value_source": value_source,
            "owner_available": bool(brush_values or ups_values),
        }

    def snapshot(self):
        result = dict(super().snapshot() or {})

        modal_available, modal_source = self._window_modal_operators_probe()
        result["window_modal_operators"] = bool(result.get("window_modal_operators")) or bool(modal_available)
        result["window_modal_operators_probe"] = modal_source if modal_available else (
            "type" if result.get("window_modal_operators") else "missing"
        )

        sculpt_probe = self._sculpt_settings_probe()
        # Runtime evidence is authoritative for the compatibility gate. Preserve
        # any positive type-level result but heal false negatives on Blender 5.2.
        result["per_brush_unified_settings"] = bool(result.get("per_brush_unified_settings")) or bool(sculpt_probe["brush_flags"])
        result["legacy_unified_paint_flags"] = bool(result.get("legacy_unified_paint_flags")) or bool(sculpt_probe["ups_flags"])
        result["sculpt_size_strength_owner"] = bool(sculpt_probe["owner_available"])
        result["sculpt_unified_probe"] = str(sculpt_probe["flag_source"])
        result["sculpt_value_owner_probe"] = str(sculpt_probe["value_source"])
        return result
