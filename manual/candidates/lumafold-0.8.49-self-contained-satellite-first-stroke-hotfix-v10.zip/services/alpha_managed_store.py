from __future__ import annotations

"""Filesystem owner for LumaFold-managed Alpha assets.

This service is intentionally separate from Alpha Source Registry / Linked Alpha
Product. Linked sources are external and permanently non-destructive; only this
owner may create or delete files inside Blender's LumaFold user-data Alpha root.

Managed deletion also retires Blender Image datablocks that point at the managed
copy being removed. Otherwise a deleted file can immediately re-enter the Alpha
browser through the generic ``当前文件`` scan even though its disk copy is gone.
"""

from pathlib import Path


class AlphaManagedStore:
    service_id = "alpha.managed_store"
    USER_FOLDER_PREFIX = "alpha|lumafold_user|"

    @staticmethod
    def _root(create=True):
        import bpy

        try:
            raw = bpy.utils.user_resource(
                'DATAFILES', path="lumafold/alphas", create=bool(create),
            )
        except TypeError:
            raw = bpy.utils.user_resource('DATAFILES', path="lumafold/alphas")
        if not raw:
            raise RuntimeError("LumaFold 用户 Alpha 目录不可用")
        root = Path(raw).resolve()
        if create:
            root.mkdir(parents=True, exist_ok=True)
        return root

    @staticmethod
    def _clean_folder_name(value):
        name = str(value or "").strip().strip(". ")
        if not name:
            raise RuntimeError("文件夹名称不能为空")
        if name in {".", ".."} or any(ch in name for ch in '<>:"/\\|?*'):
            raise RuntimeError("文件夹名称包含 Windows 不允许的字符")
        return name

    @classmethod
    def _contained_path(cls, value):
        root = cls._root(create=True)
        path = Path(str(value or "")).resolve()
        try:
            path.relative_to(root)
        except Exception:
            raise RuntimeError("目标不属于 LumaFold 用户 Alpha 目录")
        return root, path

    @staticmethod
    def _normalized_blender_path(value):
        import bpy

        raw = str(value or "")
        if not raw:
            return ""
        try:
            raw = bpy.path.abspath(raw)
        except Exception:
            pass
        try:
            return str(Path(raw).resolve()).replace("\\", "/").casefold()
        except Exception:
            return str(raw).replace("\\", "/").casefold()

    @classmethod
    def _unload_images_for_paths(cls, paths):
        """Remove Blender Image datablocks backed by verified managed paths.

        This is deliberately path-exact. It never touches packed/generated Images
        and never unloads an external source merely because it shares a filename.
        Blender clears Texture/Image users when its Image datablock is removed,
        which prevents a just-deleted managed Alpha from being rediscovered as a
        ``当前文件`` item on the next library refresh.
        """
        import bpy

        wanted = {
            cls._normalized_blender_path(path)
            for path in tuple(paths or ())
            if str(path or "")
        }
        wanted.discard("")
        if not wanted:
            return 0

        removed = 0
        for image in tuple(getattr(bpy.data, "images", ()) or ()):
            try:
                if bool(getattr(image, "packed_file", None)):
                    continue
                raw = str(getattr(image, "filepath", "") or "")
                if not raw:
                    continue
                if cls._normalized_blender_path(raw) not in wanted:
                    continue
                bpy.data.images.remove(image)
                removed += 1
            except Exception:
                continue
        return removed

    def create_folder(self, name):
        root = self._root(create=True)
        name = self._clean_folder_name(name)
        folder = (root / name).resolve()
        try:
            folder.relative_to(root)
        except Exception:
            raise RuntimeError("无法在 LumaFold 用户 Alpha 目录外创建文件夹")
        existed = folder.exists()
        if existed and not folder.is_dir():
            raise RuntimeError("同名文件已存在，无法创建文件夹")
        folder.mkdir(parents=False, exist_ok=True)
        return {
            "path": str(folder),
            "name": name,
            "folder_id": self.USER_FOLDER_PREFIX + name,
            "created": not existed,
        }

    def list_folders(self):
        root = self._root(create=True)
        result = []
        for path in sorted((p for p in root.rglob("*") if p.is_dir()), key=lambda p: str(p).casefold()):
            rel = path.relative_to(root).as_posix()
            if rel in {"", "."}:
                continue
            result.append({
                "id": self.USER_FOLDER_PREFIX + rel,
                "relative": rel,
                "path": str(path),
                "name": path.name,
            })
        return result

    def remove_folder(self, folder_id):
        folder_id = str(folder_id or "")
        if not folder_id.startswith(self.USER_FOLDER_PREFIX):
            raise RuntimeError("不是 LumaFold 用户文件夹")
        suffix = folder_id[len(self.USER_FOLDER_PREFIX):].strip().replace("\\", "/")
        if suffix in {"", ".", "根目录"}:
            raise RuntimeError("LumaFold 根目录不作为可删除文件夹")

        root = self._root(create=True)
        folder = (root / suffix).resolve()
        try:
            folder.relative_to(root)
        except Exception:
            raise RuntimeError("文件夹不属于 LumaFold 用户 Alpha 目录")
        if not folder.exists():
            return {"path": str(folder), "folder_id": folder_id, "removed": False}
        if not folder.is_dir():
            raise RuntimeError("目标不是文件夹")

        # Capture the exact managed files first, then retire their Blender Image
        # datablocks before removing the disk copies. This keeps runtime state and
        # filesystem state from diverging after a folder deletion.
        children = sorted(folder.rglob("*"), key=lambda p: len(p.parts), reverse=True)
        managed_files = [child for child in children if child.is_file() or child.is_symlink()]
        self._unload_images_for_paths(managed_files)

        # Recursive deletion is explicit rather than shutil.rmtree so every
        # mutation remains visibly constrained beneath the verified managed root.
        for child in children:
            self._contained_path(child)
            if child.is_file() or child.is_symlink():
                child.unlink()
            elif child.is_dir():
                child.rmdir()
        folder.rmdir()
        return {"path": str(folder), "folder_id": folder_id, "removed": True}

    def delete_asset(self, filepath):
        _root, path = self._contained_path(filepath)
        if not path.is_file():
            raise RuntimeError("Alpha 文件不存在")
        unloaded = self._unload_images_for_paths((path,))
        path.unlink()
        return {"path": str(path), "removed": True, "unloaded_images": int(unloaded)}
