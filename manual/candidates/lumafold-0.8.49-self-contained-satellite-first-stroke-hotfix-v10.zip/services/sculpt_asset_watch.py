from __future__ import annotations

"""Low-frequency file-backed Sculpt resource watcher.

LumaFold already synchronizes Blender's *active* Brush/Alpha at high frequency.
This service solves the other half of the product workflow: when a user adds,
removes, or replaces Brush/Alpha files inside a registered Blender Asset Library
or the LumaFold user Alpha library, a previously opened LumaFold resource browser
refreshes itself without requiring a manual rescan button.

The watcher is deliberately bounded and low-frequency. It fingerprints only
resource-looking files, caps the number of entries inspected, and does nothing
until a library has actually been opened. This keeps large asset collections
from becoming a per-frame tax.
"""

from pathlib import Path
import time


_WATCH_NS_KEY = "LUMAFOLD_SCULPT_ASSET_WATCH_V1"
_IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".tga", ".exr", ".hdr"}
_RESOURCE_EXTS = _IMAGE_EXTS | {".blend"}


class SculptAssetWatchService:
    service_id = "blender.sculpt_asset_watch"

    def __init__(self):
        self._generation = 0
        self._status = "IDLE"
        self._serial = 0
        self._last_scan = 0.0
        self._last_change = 0.0
        self._last_reason = ""
        self._root_count = 0
        self._entry_count = 0
        self._fingerprint = None
        self._refresh_brush = 0
        self._refresh_alpha = 0
        self._errors = []

    @staticmethod
    def _roots():
        import bpy

        roots = []
        seen = set()

        def add(value):
            try:
                raw = str(value or "")
                if not raw:
                    return
                path = Path(bpy.path.abspath(raw)).resolve()
                key = str(path).casefold()
                if key in seen or not path.is_dir():
                    return
                seen.add(key)
                roots.append(path)
            except Exception:
                return

        try:
            for library in tuple(getattr(bpy.context.preferences.filepaths, "asset_libraries", ()) or ()):
                if bool(getattr(library, "enabled", True)):
                    add(getattr(library, "path", ""))
        except Exception:
            pass

        # LumaFold's persistent user Alpha source is intentionally independent
        # from Blender's registered Asset Library list, so include it explicitly.
        try:
            add(bpy.utils.user_resource('DATAFILES', path="lumafold/alphas", create=False))
        except TypeError:
            try:
                add(bpy.utils.user_resource('DATAFILES', path="lumafold/alphas"))
            except Exception:
                pass
        except Exception:
            pass

        # The bundled development Alpha seed is a real file-backed source too;
        # watching it also keeps development previews honest across hot reloads.
        try:
            add(Path(__file__).resolve().parent.parent / "assets" / "test_alphas")
        except Exception:
            pass
        return tuple(roots)

    @staticmethod
    def _fingerprint_roots(roots, max_entries=768):
        rows = []
        errors = []
        count = 0
        limit = max(32, int(max_entries))

        for root in roots:
            if count >= limit:
                break
            try:
                rows.append(("ROOT", str(root).casefold(), int(root.stat().st_mtime_ns)))
            except Exception as exc:
                errors.append(f"{root}: {type(exc).__name__}: {exc}")
                continue
            try:
                for path in root.rglob("*"):
                    if count >= limit:
                        break
                    try:
                        if not path.is_file() or path.suffix.casefold() not in _RESOURCE_EXTS:
                            continue
                        stat = path.stat()
                        try:
                            rel = path.relative_to(root).as_posix().casefold()
                        except Exception:
                            rel = str(path).casefold()
                        rows.append((rel, int(stat.st_mtime_ns), int(stat.st_size)))
                        count += 1
                    except Exception:
                        continue
            except Exception as exc:
                errors.append(f"{root}: {type(exc).__name__}: {exc}")

        rows.sort(key=lambda item: str(item[0]))
        return tuple(rows), count, errors[-6:]

    def _refresh_loaded_libraries(self, app):
        state = app.store.namespace("sculpt")
        brush_status = str(state.get("brush_library_status") or "NOT_LOADED")
        alpha_status = str(state.get("alpha_library_status") or "NOT_LOADED")

        # Do not wake resource scanners that the user has never opened. Once a
        # library is loaded, an external disk change should self-heal its index.
        if brush_status not in {"NOT_LOADED", "SCANNING"}:
            result = app.execute("sculpt.brush.library_refresh")
            if result.ok:
                self._refresh_brush += 1
        if alpha_status not in {"NOT_LOADED", "SCANNING"}:
            result = app.execute("sculpt.alpha.library_refresh")
            if result.ok:
                self._refresh_alpha += 1

    def snapshot(self):
        return {
            "status": str(self._status),
            "serial": int(self._serial),
            "last_scan": float(self._last_scan),
            "last_change": float(self._last_change),
            "last_reason": str(self._last_reason),
            "root_count": int(self._root_count),
            "entry_count": int(self._entry_count),
            "brush_refreshes": int(self._refresh_brush),
            "alpha_refreshes": int(self._refresh_alpha),
            "errors": list(self._errors),
        }

    def start_watch(self, app, interval: float = 1.50):
        import bpy

        generation = int(bpy.app.driver_namespace.get(_WATCH_NS_KEY, 0) or 0) + 1
        bpy.app.driver_namespace[_WATCH_NS_KEY] = generation
        self._generation = generation
        self._fingerprint = None
        interval = max(0.75, min(5.0, float(interval)))

        def tick():
            if int(bpy.app.driver_namespace.get(_WATCH_NS_KEY, 0) or 0) != generation:
                return None
            try:
                roots = self._roots()
                fingerprint, count, errors = self._fingerprint_roots(roots)
                self._root_count = len(roots)
                self._entry_count = int(count)
                self._last_scan = time.monotonic()
                self._errors = list(errors)

                if self._fingerprint is None:
                    self._fingerprint = fingerprint
                    self._status = "WATCHING"
                elif fingerprint != self._fingerprint:
                    self._fingerprint = fingerprint
                    self._serial += 1
                    self._last_change = time.monotonic()
                    self._last_reason = "file-backed Sculpt resource set changed"
                    self._status = "REFRESHING"
                    self._refresh_loaded_libraries(app)
                    self._status = "WATCHING"
                else:
                    self._status = "WATCHING"
            except Exception as exc:
                self._status = f"ERROR: {type(exc).__name__}: {exc}"
            return interval

        bpy.app.timers.register(tick, first_interval=0.80, persistent=True)
        return generation
