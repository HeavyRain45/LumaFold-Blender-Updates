from __future__ import annotations

"""Durable product store for linked Alpha sources.

Persistent metadata lives in the Blender user profile, outside the extension
installation directory. File mutations are limited to this small registry JSON;
user Alpha folders and images are never written, moved, renamed or deleted.
"""

import json
from pathlib import Path

from .alpha_source_registry import AlphaSourceRegistryService


class AlphaSourceStore:
    service_id = "alpha.source_registry"
    FORMAT = 1

    def __init__(self):
        self._state = {
            AlphaSourceRegistryService.SOURCES_KEY: [],
            AlphaSourceRegistryService.HIDDEN_KEY: {},
        }
        self._loaded = False

    @staticmethod
    def _storage_path() -> Path:
        import bpy
        try:
            raw = bpy.utils.user_resource('CONFIG', path="lumafold", create=True)
        except TypeError:
            raw = bpy.utils.user_resource('CONFIG', path="lumafold")
        root = Path(raw) if raw else (Path.home() / ".config" / "lumafold")
        root.mkdir(parents=True, exist_ok=True)
        return root / "alpha_sources_v1.json"

    def _ensure_loaded(self):
        if self._loaded:
            return
        self._loaded = True
        try:
            data = json.loads(self._storage_path().read_text(encoding="utf-8"))
        except Exception:
            return
        if int(data.get("format", -1)) != self.FORMAT:
            return
        self._state[AlphaSourceRegistryService.SOURCES_KEY] = list(data.get("sources") or ())
        self._state[AlphaSourceRegistryService.HIDDEN_KEY] = dict(data.get("hidden") or {})
        self._state[AlphaSourceRegistryService.SOURCES_KEY] = AlphaSourceRegistryService.list_sources(self._state)

    def _save(self):
        self._ensure_loaded()
        payload = {
            "format": self.FORMAT,
            "sources": AlphaSourceRegistryService.list_sources(self._state),
            "hidden": dict(self._state.get(AlphaSourceRegistryService.HIDDEN_KEY) or {}),
        }
        path = self._storage_path()
        temp = path.with_suffix(path.suffix + ".tmp")
        temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        temp.replace(path)

    def list_sources(self):
        self._ensure_loaded()
        return AlphaSourceRegistryService.list_sources(self._state)

    def add_folder(self, path):
        self._ensure_loaded()
        record, created = AlphaSourceRegistryService.add_folder(self._state, path)
        self._save()
        return {"source": record, "created": bool(created)}

    def remove_folder(self, source_id: str):
        self._ensure_loaded()
        record = AlphaSourceRegistryService.remove_folder(self._state, source_id)
        self._save()
        return {"source": record, "removed": True}

    def hide_identity(self, source_id: str, identity: str):
        self._ensure_loaded()
        AlphaSourceRegistryService.hide_identity(self._state, source_id, identity)
        self._save()
        return {"source_id": str(source_id), "identity": str(identity), "hidden": True}

    def unhide_identity(self, source_id: str, identity: str):
        self._ensure_loaded()
        AlphaSourceRegistryService.unhide_identity(self._state, source_id, identity)
        self._save()
        return {"source_id": str(source_id), "identity": str(identity), "hidden": False}

    def restore_hidden(self, source_id: str):
        self._ensure_loaded()
        AlphaSourceRegistryService.clear_hidden(self._state, source_id)
        self._save()
        return {"source_id": str(source_id), "restored": True}

    def hidden_identities(self, source_id: str):
        self._ensure_loaded()
        return AlphaSourceRegistryService.hidden_identities(self._state, source_id)

    def all_hidden_identities(self):
        self._ensure_loaded()
        result = set()
        for source in AlphaSourceRegistryService.list_sources(self._state):
            result.update(AlphaSourceRegistryService.hidden_identities(self._state, str(source.get("id") or "")))
        return tuple(sorted(result))

    def scan(self, image_exts, max_files: int = 512):
        self._ensure_loaded()
        return AlphaSourceRegistryService.scan(self._state, image_exts, max_files=max_files)
