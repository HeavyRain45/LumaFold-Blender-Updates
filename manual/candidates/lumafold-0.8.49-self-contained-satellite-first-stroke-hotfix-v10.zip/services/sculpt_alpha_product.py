from __future__ import annotations

"""Product-level Alpha library behavior layered over Blender compatibility.

The compatibility service knows how to read Blender Images and registered Asset
Libraries. This layer owns LumaFold-managed Alpha files and reliable product
thumbnails. Thumbnail generation reads real Blender image pixels and never
writes, scales or otherwise mutates the user's source file on disk.

Performance invariant:
Repeated queries for the currently active Alpha must be memory-only while the
underlying Blender Brush/Texture/Image IDs are unchanged. Canonical path work,
file loading, pixel sampling and Base64 encoding are change-time work only.
"""

from pathlib import Path
import filecmp
import shutil

from .blender_compat53 import BlenderAlphaServiceCompat


class BlenderAlphaServiceProduct(BlenderAlphaServiceCompat):
    service_id = "blender.alpha"
    USER_SOURCE_LABEL = "LumaFold 用户 Alpha"
    USER_FOLDER_PREFIX = "alpha|lumafold_user|"

    def __init__(self):
        super().__init__()
        self._active_alpha_token = None
        self._active_alpha_snapshot = None
        self._active_preview_token = None
        self._active_preview_payload = None

    @staticmethod
    def _pointer(value):
        if value is None:
            return 0
        try:
            return int(value.as_pointer())
        except Exception:
            return id(value)

    def _active_native_token(self):
        """Return a Blender-resident token without file-system access."""
        brush = self._sculpt_brush()
        slot = getattr(brush, "texture_slot", None) if brush is not None else None
        texture = self._assigned_texture(brush)
        image = getattr(texture, "image", None) if texture is not None and str(getattr(texture, "type", "")) == "IMAGE" else None
        return (
            self._pointer(brush),
            self._pointer(texture),
            self._pointer(image),
            str(getattr(image, "name", "") or "") if image is not None else "",
            str(getattr(image, "filepath", "") or "") if image is not None else "",
            str(getattr(slot, "map_mode", "") or "") if slot is not None else "",
        )

    def current_sculpt_alpha(self):
        """Return the canonical active Alpha snapshot with a native-token cache."""
        token = self._active_native_token()
        if token == self._active_alpha_token and isinstance(self._active_alpha_snapshot, dict):
            return dict(self._active_alpha_snapshot)
        snapshot = dict(super().current_sculpt_alpha() or {})
        self._active_alpha_token = token
        self._active_alpha_snapshot = dict(snapshot)
        return snapshot

    @staticmethod
    def _safe_name(path: Path):
        name = str(path.name or "Alpha")
        return name if name else "Alpha"

    def user_library_root(self, create=True):
        import bpy

        try:
            raw = bpy.utils.user_resource(
                'DATAFILES',
                path="lumafold/alphas",
                create=bool(create),
            )
        except TypeError:
            raw = bpy.utils.user_resource('DATAFILES', path="lumafold/alphas")
        if not raw:
            return None
        path = Path(raw)
        if create:
            path.mkdir(parents=True, exist_ok=True)
        return path

    @staticmethod
    def _dedupe_destination(root: Path, source: Path):
        candidate = root / source.name
        try:
            if candidate.exists() and source.resolve() == candidate.resolve():
                return candidate
        except Exception:
            pass
        if not candidate.exists():
            return candidate
        # Re-importing the same image should be idempotent. Only create a
        # duplicate-safe suffix when a different file already owns that name.
        try:
            if filecmp.cmp(str(source), str(candidate), shallow=False):
                return candidate
        except Exception:
            pass
        stem = source.stem or "Alpha"
        suffix = source.suffix
        for index in range(2, 1000):
            alt = root / f"{stem}_{index}{suffix}"
            if not alt.exists():
                return alt
            try:
                if filecmp.cmp(str(source), str(alt), shallow=False):
                    return alt
            except Exception:
                pass
        raise RuntimeError(f"无法为 Alpha 生成唯一文件名: {source.name}")

    def import_alpha_files(self, paths, *, load_current=True):
        import bpy

        root = self.user_library_root(create=True)
        if root is None:
            raise RuntimeError("无法创建 LumaFold 用户 Alpha 目录")

        imported = []
        errors = []
        for raw in list(paths or ()):
            try:
                source = Path(str(raw)).resolve()
                if not source.is_file():
                    raise FileNotFoundError(str(source))
                if source.suffix.casefold() not in self.IMAGE_EXTS:
                    raise RuntimeError("不支持的 Alpha 图片格式")

                destination = self._dedupe_destination(root, source)
                try:
                    same_file = source.resolve() == destination.resolve()
                except Exception:
                    same_file = False
                if not same_file and not destination.exists():
                    shutil.copy2(str(source), str(destination))

                if load_current:
                    bpy.data.images.load(str(destination), check_existing=True)
                imported.append(str(destination))
            except Exception as exc:
                name = self._safe_name(Path(str(raw)))
                errors.append(f"{name}: {type(exc).__name__}: {exc}")

        return {
            "root": str(root),
            "files": list(dict.fromkeys(imported)),
            "count": len(set(imported)),
            "errors": errors[-8:],
        }

    # ------------------------------------------------------------------
    # Product Alpha thumbnails
    # ------------------------------------------------------------------
    @staticmethod
    def _target_size(width: int, height: int, max_edge: int):
        width = max(1, int(width))
        height = max(1, int(height))
        max_edge = max(1, int(max_edge))
        longest = max(width, height)
        if longest <= max_edge:
            return width, height
        scale = float(max_edge) / float(longest)
        return max(1, int(round(width * scale))), max(1, int(round(height * scale)))

    @staticmethod
    def _to_display_byte(value, *, gamma_encode: bool):
        try:
            value = float(value)
        except Exception:
            value = 0.0
        value = max(0.0, min(1.0, value))
        if gamma_encode:
            if value <= 0.0031308:
                value = 12.92 * value
            else:
                value = 1.055 * (value ** (1.0 / 2.4)) - 0.055
        return max(0, min(255, int(round(value * 255.0))))

    @classmethod
    def _image_pixels_payload(cls, image, max_edge=64, *, scaled=False):
        """Read a small display-space RGBA payload from a Blender Image.

        ``scaled=True`` is used only for a disposable temporary Image datablock
        that LumaFold created from a file. Real project Images are never scaled.
        For packed/generated Images we sample at most ``max_edge²`` source pixels
        directly, so preview generation does not mutate project data.
        """
        import base64

        if image is None:
            return {}
        try:
            width, height = (int(v) for v in tuple(image.size)[:2])
        except Exception:
            return {}
        if width <= 0 or height <= 0:
            return {}

        target_w, target_h = cls._target_size(width, height, max_edge)
        if scaled and (width, height) != (target_w, target_h):
            try:
                image.scale(target_w, target_h)
                width, height = target_w, target_h
            except Exception:
                scaled = False

        try:
            pixels = image.pixels
            colorspace = str(getattr(getattr(image, "colorspace_settings", None), "name", "") or "").casefold()
        except Exception:
            return {}
        # Image.pixels is scene-linear for ordinary color images. Re-encode RGB
        # to display/sRGB bytes because PreviewTextureCache explicitly expects
        # display-space artwork. Data/Non-Color images already represent raw
        # numeric values and therefore bypass the transfer curve.
        gamma_encode = not (
            "non-color" in colorspace
            or colorspace in {"raw", "data", "linear", "linear rec.709"}
        )

        out_w, out_h = cls._target_size(width, height, max_edge)
        raw = bytearray(out_w * out_h * 4)
        cursor = 0
        try:
            for y in range(out_h):
                src_y = min(height - 1, int((y + 0.5) * height / out_h))
                for x in range(out_w):
                    src_x = min(width - 1, int((x + 0.5) * width / out_w))
                    base = (src_y * width + src_x) * 4
                    raw[cursor] = cls._to_display_byte(pixels[base], gamma_encode=gamma_encode)
                    raw[cursor + 1] = cls._to_display_byte(pixels[base + 1], gamma_encode=gamma_encode)
                    raw[cursor + 2] = cls._to_display_byte(pixels[base + 2], gamma_encode=gamma_encode)
                    raw[cursor + 3] = cls._to_display_byte(pixels[base + 3], gamma_encode=False)
                    cursor += 4
        except Exception:
            return {}
        if not raw:
            return {}
        return {
            "width": out_w,
            "height": out_h,
            "rgba_b64": base64.b64encode(bytes(raw)).decode("ascii"),
            "source": "image_pixels",
        }

    @classmethod
    def _file_pixels_payload(cls, path, max_edge=64):
        """Load/scale a disposable Blender Image for a fast real-file thumbnail."""
        import bpy

        path = Path(str(path or ""))
        if not path.is_file():
            return {}
        temp = None
        try:
            # check_existing=False is essential: scaling this temporary datablock
            # must never resize an Image already used by the user's .blend.
            temp = bpy.data.images.load(str(path), check_existing=False)
            return cls._image_pixels_payload(temp, max_edge=max_edge, scaled=True)
        except Exception:
            return {}
        finally:
            if temp is not None:
                try:
                    bpy.data.images.remove(temp)
                except Exception:
                    pass

    def current_sculpt_alpha_preview(self, max_edge=64):
        import bpy

        brush = self._sculpt_brush()
        texture = self._assigned_texture(brush)
        image = getattr(texture, "image", None) if texture is not None and str(getattr(texture, "type", "")) == "IMAGE" else None
        if image is None:
            self._active_preview_token = None
            self._active_preview_payload = None
            return {}

        token = (self._active_native_token(), int(max_edge))
        if token == self._active_preview_token and isinstance(self._active_preview_payload, dict):
            return dict(self._active_preview_payload)

        filepath = ""
        try:
            raw = str(getattr(image, "filepath", "") or "")
            filepath = self._norm_path(bpy.path.abspath(raw)) if raw else ""
        except Exception:
            filepath = ""

        payload = {}
        if filepath:
            payload = self._file_pixels_payload(filepath, max_edge=max_edge)
        if not payload:
            payload = self._image_pixels_payload(image, max_edge=max_edge, scaled=False)
        if not payload:
            payload = dict(super().current_sculpt_alpha_preview(max_edge=max_edge) or {})

        self._active_preview_token = token
        self._active_preview_payload = dict(payload) if payload else {}
        return dict(self._active_preview_payload)

    def alpha_previews(self, specs, max_edge=64):
        """Generate deterministic thumbnails from real pixels, not async previews."""
        import bpy

        results = {}
        fallback = []
        for raw in list(specs or ()):
            spec = dict(raw or {})
            identity = str(spec.get("identity") or "")
            if not identity:
                continue

            payload = {}
            filepath = str(spec.get("filepath") or "").strip()
            if filepath:
                payload = self._file_pixels_payload(filepath, max_edge=max_edge)

            if not payload:
                image_name = str(spec.get("image_name") or "")
                image = bpy.data.images.get(image_name) if image_name else None
                if image is not None:
                    payload = self._image_pixels_payload(image, max_edge=max_edge, scaled=False)

            if payload:
                payload["key"] = identity
                results[identity] = payload
            else:
                fallback.append(spec)

        # Preserve compatibility for unusual Blender image sources where direct
        # pixel access is unavailable. The legacy ImagePreview path is fallback
        # only; normal file-backed Alpha thumbnails never depend on it anymore.
        if fallback:
            try:
                legacy = dict(super().alpha_previews(fallback, max_edge=max_edge) or {})
            except Exception:
                legacy = {}
            for identity, payload_raw in legacy.items():
                if str(identity) in results:
                    continue
                payload = dict(payload_raw or {})
                if payload.get("rgba_b64"):
                    payload["key"] = str(identity)
                    results[str(identity)] = payload
        return results

    def list_sculpt_alphas(self, max_files=512):
        result = dict(super().list_sculpt_alphas(max_files=max_files) or {})
        assets = [dict(item or {}) for item in list(result.get("assets") or ())]
        folders = [dict(item or {}) for item in list(result.get("folders") or ())]
        errors = list(result.get("errors") or ())

        root = self.user_library_root(create=True)
        if root is None or not root.is_dir():
            return result

        by_identity = {
            str(item.get("identity") or ""): item
            for item in assets
            if str(item.get("identity") or "")
        }
        folder_map = {
            str(item.get("id") or ""): item
            for item in folders
            if str(item.get("id") or "")
        }

        try:
            paths = sorted(
                (path for path in root.rglob("*") if path.is_file() and path.suffix.casefold() in self.IMAGE_EXTS),
                key=lambda path: str(path).casefold(),
            )
        except Exception as exc:
            errors.append(f"{self.USER_SOURCE_LABEL}: {type(exc).__name__}: {exc}")
            paths = []

        # User-owned Alphas have product priority. Scan them independently of
        # how many records the compatibility layer already returned, then sort
        # user records first and apply the public max_files cap once at the end.
        for path in paths[:max(1, int(max_files))]:
            try:
                identity = self._identity_from_path(path)
                rel_parent = path.parent.relative_to(root).as_posix()
                suffix = rel_parent if rel_parent not in {"", "."} else "根目录"
                folder_id = self.USER_FOLDER_PREFIX + suffix
                folder_label = self.USER_SOURCE_LABEL if suffix == "根目录" else f"{self.USER_SOURCE_LABEL} / {suffix}"
                folder = folder_map.get(folder_id)
                if folder is None:
                    folder = {
                        "id": folder_id,
                        "label": folder_label,
                        "source": self.USER_SOURCE_LABEL,
                        "path": str(path.parent),
                        "readonly": False,
                        "count": 0,
                    }
                    folders.append(folder)
                    folder_map[folder_id] = folder

                existing = by_identity.get(identity)
                if existing is not None:
                    # A file imported into the user library may already be loaded
                    # as a Blender Image. Canonical disk ownership wins over the
                    # temporary "当前文件" classification.
                    existing["folder_id"] = folder_id
                    existing["folder_label"] = folder_label
                    existing["source_label"] = self.USER_SOURCE_LABEL
                    existing["readonly"] = False
                    existing["filepath"] = self._norm_path(path)
                else:
                    item = {
                        "name": path.stem,
                        "identity": identity,
                        "filepath": self._norm_path(path),
                        "image_name": "",
                        "folder_id": folder_id,
                        "folder_label": folder_label,
                        "source_label": self.USER_SOURCE_LABEL,
                        "readonly": False,
                        "loaded": False,
                    }
                    assets.append(item)
                    by_identity[identity] = item
            except Exception as exc:
                errors.append(f"{path.name}: {type(exc).__name__}: {exc}")

        assets.sort(key=lambda item: (
            0 if str(item.get("folder_id") or "").startswith(self.USER_FOLDER_PREFIX) else 1,
            str(item.get("folder_label") or "").casefold(),
            str(item.get("name") or "").casefold(),
        ))
        assets = assets[:max(1, int(max_files))]

        counts = {}
        for item in assets:
            folder_id = str(item.get("folder_id") or "")
            if folder_id:
                counts[folder_id] = counts.get(folder_id, 0) + 1
        for folder in folders:
            folder["count"] = int(counts.get(str(folder.get("id") or ""), 0))

        folders = [folder for folder in folders if int(folder.get("count", 0) or 0) > 0]
        folders.sort(key=lambda folder: (
            0 if str(folder.get("id") or "").startswith(self.USER_FOLDER_PREFIX) else 1,
            str(folder.get("label") or "").casefold(),
        ))

        result.update({
            "assets": assets,
            "folders": folders,
            "errors": errors[-8:],
            "asset_count": len(assets),
            "folder_count": len(folders),
            "user_library_root": str(root),
        })
        return result
