from .blender import BlenderContextService, BlenderLightService, BlenderObjectService, BlenderRenderService
from .blender_mode_undo import BlenderModeUndoSafeService
from .sculpt_settings import BlenderSculptSettingsService
from .sculpt_proxy import BlenderBrushProxyLifecycleService
from .sculpt_brush_preview_product import BlenderBrushServiceProduct
from .sculpt_alpha_linked_product import BlenderAlphaLinkedProduct
from .alpha_source_store import AlphaSourceStore
from .alpha_managed_store import AlphaManagedStore
from .blender_capability_probe import BlenderCapabilitiesRuntimeProbe
from .blender_compat_gate_runtime import BlenderCompatibilityRuntimeGateService
from .sculpt_resource_sync import SculptResourceSyncService
from .sculpt_asset_watch import SculptAssetWatchService
from .sculpt_shortcuts import SculptShortcutSyncService


def register_services(app):
    app.services.register("blender.context", BlenderContextService())
    app.services.register("blender.object", BlenderObjectService())
    app.services.register("blender.mode", BlenderModeUndoSafeService())

    brush_service = BlenderBrushServiceProduct()
    alpha_source_store = AlphaSourceStore()
    alpha_managed_store = AlphaManagedStore()
    alpha_service = BlenderAlphaLinkedProduct(alpha_source_store, alpha_managed_store)
    # Temporary public-facade compatibility for the native create-folder
    # operator and existing real gate. Filesystem ownership still resides solely
    # in alpha.managed_store; blender.alpha only forwards this one request.
    alpha_service.create_user_folder = alpha_managed_store.create_folder
    app.services.register("blender.brush", brush_service)
    app.services.register("alpha.source_registry", alpha_source_store)
    app.services.register("alpha.managed_store", alpha_managed_store)
    app.services.register("blender.alpha", alpha_service)

    app.services.register("blender.light", BlenderLightService())
    app.services.register("blender.render", BlenderRenderService())

    capabilities = BlenderCapabilitiesRuntimeProbe()
    compat_gate = BlenderCompatibilityRuntimeGateService(capabilities)
    sculpt_settings = BlenderSculptSettingsService()
    brush_proxy = BlenderBrushProxyLifecycleService()
    resource_sync = SculptResourceSyncService()
    asset_watch = SculptAssetWatchService()
    shortcut_sync = SculptShortcutSyncService()
    app.services.register("blender.capabilities", capabilities)
    app.services.register("blender.compat_gate", compat_gate)
    app.services.register("blender.sculpt_settings", sculpt_settings)
    app.services.register("blender.brush_proxy", brush_proxy)
    app.services.register("blender.sculpt_resource_sync", resource_sync)
    app.services.register("blender.sculpt_asset_watch", asset_watch)
    app.services.register("blender.sculpt_shortcuts", shortcut_sync)

    app.capabilities.register("object.active", lambda c: c.has_active_object)
    app.capabilities.register("object.mesh", lambda c: c.has_active_object and c.active_object_type == "MESH")
    app.capabilities.register("object.light", lambda c: c.has_active_object and c.active_object_type == "LIGHT")
    app.capabilities.register("mode.object", lambda c: c.mode == "OBJECT")
    app.capabilities.register("mode.sculpt", lambda c: c.mode == "SCULPT")
    app.capabilities.register("mode.edit_mesh", lambda c: c.mode == "EDIT_MESH")
    app.capabilities.register("host.embedded", lambda c: c.host_id == "embedded")
    app.capabilities.register("host.satellite", lambda c: c.host_id == "satellite")
    app.capabilities.register("host.desktop", lambda c: c.host_id == "desktop")

    app.commands.register(
        "blender.object.rename_active",
        lambda name="LumaFold_Object": app.services.require("blender.object").rename_active(name),
    )
    app.commands.register(
        "blender.object.nudge_x",
        lambda delta=0.10: app.services.require("blender.object").nudge_active_x(delta),
    )

    # Linked-source registry and LumaFold-managed filesystem ownership remain
    # separate. UI/Host only sees public commands; external sources never reach
    # alpha.managed_store mutation methods.
    def _refresh_alpha_library():
        try:
            result = app.execute("sculpt.alpha.library_refresh")
            return bool(getattr(result, "ok", False)), str(getattr(result, "message", ""))
        except Exception as exc:
            return False, str(exc)

    def _alpha_identities_for_source(source_id=""):
        source_id = str(source_id or "")
        if not source_id:
            return ()
        sculpt = app.store.namespace("sculpt")
        return tuple(
            str((item or {}).get("identity") or "")
            for item in list(sculpt.get("alpha_library_assets") or ())
            if str((item or {}).get("linked_source_id") or "") == source_id
            and str((item or {}).get("identity") or "")
        )

    def _alpha_identities_for_folder(folder_id=""):
        folder_id = str(folder_id or "")
        if not folder_id:
            return ()
        sculpt = app.store.namespace("sculpt")
        return tuple(
            str((item or {}).get("identity") or "")
            for item in list(sculpt.get("alpha_library_assets") or ())
            if str((item or {}).get("folder_id") or "") == folder_id
            and str((item or {}).get("identity") or "")
        )

    def _prune_alpha_preview_identities(identities):
        identities = {str(item) for item in tuple(identities or ()) if str(item or "")}
        if not identities:
            return
        sculpt = app.store.namespace("sculpt")
        for key in ("alpha_library_preview_cache", "primary_alpha_preview_cache"):
            cache = sculpt.get(key)
            if not isinstance(cache, dict):
                continue
            for identity in identities:
                cache.pop(identity, None)

    def _alpha_source_add(path=""):
        result = dict(alpha_source_store.add_folder(path) or {})
        source = dict(result.get("source") or {})
        _refresh_alpha_library()
        return ("已添加" if result.get("created") else "已存在") + " Alpha 文件夹：" + str(source.get("label") or path)

    def _alpha_source_remove(source_id=""):
        identities = _alpha_identities_for_source(source_id)
        result = dict(alpha_source_store.remove_folder(source_id) or {})
        source = dict(result.get("source") or {})
        _prune_alpha_preview_identities(identities)
        _refresh_alpha_library()
        return "已从 LumaFold 移除文件夹（本地文件未删除）：" + str(source.get("label") or source_id)

    def _alpha_folder_remove(folder_id=""):
        folder_id = str(folder_id or "")
        if folder_id.startswith(alpha_service.LINKED_PREFIX):
            return _alpha_source_remove(folder_id)
        if folder_id.startswith(alpha_managed_store.USER_FOLDER_PREFIX):
            identities = _alpha_identities_for_folder(folder_id)
            result = dict(alpha_managed_store.remove_folder(folder_id) or {})
            _prune_alpha_preview_identities(identities)
            _refresh_alpha_library()
            return "已删除 LumaFold Alpha 文件夹：" + str(result.get("path") or folder_id)
        raise RuntimeError("该文件夹不属于可管理的 Alpha 来源")

    def _alpha_asset_hide(source_id="", identity=""):
        alpha_source_store.hide_identity(source_id, identity)
        _prune_alpha_preview_identities((identity,))
        _refresh_alpha_library()
        return "已从 LumaFold 隐藏 Alpha；本地文件未删除"

    def _alpha_asset_delete(identity="", filepath="", folder_id="", source_id=""):
        identity = str(identity or "")
        folder_id = str(folder_id or "")
        source_id = str(source_id or "")
        if folder_id.startswith(alpha_managed_store.USER_FOLDER_PREFIX):
            alpha_managed_store.delete_asset(filepath)
            _prune_alpha_preview_identities((identity,))
            _refresh_alpha_library()
            return "已删除 LumaFold 管理的 Alpha"
        if source_id.startswith(alpha_service.LINKED_PREFIX):
            return _alpha_asset_hide(source_id=source_id, identity=identity)
        raise RuntimeError("该 Alpha 不属于可删除的 LumaFold 资源")

    def _alpha_source_restore_hidden(source_id=""):
        alpha_source_store.restore_hidden(source_id)
        _refresh_alpha_library()
        return "已恢复该文件夹中隐藏的 Alpha"

    def _invoke_blender_window_operator(operator, *, label="Blender 窗口"):
        """Invoke a UI operator against a real Blender Window, not caller focus.

        Native Satellite commands arrive through DesktopBridge while the Win32
        child may own foreground focus. In that situation bpy.context can be a
        poor source for INVOKE_DEFAULT. Resolve an actual Blender Window/Area
        explicitly and keep the operator lifecycle on Blender's main thread.
        """
        import bpy

        windows = list(getattr(getattr(bpy.context, "window_manager", None), "windows", ()) or ())
        if not windows:
            raise RuntimeError(f"{label}打开失败：没有可用的 Blender Window")

        last_error = None
        for window in windows:
            screen = getattr(window, "screen", None)
            areas = list(getattr(screen, "areas", ()) or ()) if screen is not None else []
            # Prefer a normal VIEW_3D WINDOW region because it is always valid
            # for LumaFold's floating Sculpt UI. Fall back to any WINDOW region.
            ordered_areas = sorted(areas, key=lambda area: 0 if str(getattr(area, "type", "")) == "VIEW_3D" else 1)
            for area in ordered_areas:
                regions = list(getattr(area, "regions", ()) or ())
                region = next((item for item in regions if str(getattr(item, "type", "")) == "WINDOW"), None)
                try:
                    override = {"window": window, "screen": screen, "area": area}
                    if region is not None:
                        override["region"] = region
                    with bpy.context.temp_override(**override):
                        result = operator('INVOKE_DEFAULT')
                    if 'RUNNING_MODAL' in result or 'FINISHED' in result:
                        return result
                    last_error = RuntimeError(f"operator returned {result!r}")
                except Exception as exc:
                    last_error = exc

        if last_error is not None:
            raise RuntimeError(f"{label}打开失败：{type(last_error).__name__}: {last_error}")
        raise RuntimeError(f"{label}打开失败：没有可用的 Blender Area")

    def _alpha_source_add_dialog():
        import bpy

        sculpt_state = app.store.namespace("sculpt")

        def _invoke():
            try:
                _invoke_blender_window_operator(
                    bpy.ops.lumafold.add_alpha_folder,
                    label="Alpha 添加窗口",
                )
                sculpt_state["alpha_action_status"] = "Alpha 添加窗口已打开"
            except Exception as exc:
                sculpt_state["alpha_action_status"] = str(exc)
                try:
                    from ..core.state import STATE
                    STATE.last_error = "Satellite Alpha picker invoke failed: " + str(exc)
                except Exception:
                    pass
            return None

        try:
            bpy.app.timers.register(_invoke, first_interval=0.0)
        except Exception as exc:
            raise RuntimeError("Alpha 添加窗口调度失败: " + str(exc))
        return "正在打开 Alpha 添加窗口"

    def _alpha_user_folder_create_dialog():
        import bpy

        sculpt_state = app.store.namespace("sculpt")

        def _invoke():
            try:
                _invoke_blender_window_operator(
                    bpy.ops.lumafold.create_alpha_folder,
                    label="新建 Alpha 文件夹窗口",
                )
                sculpt_state["alpha_action_status"] = "新建 Alpha 文件夹窗口已打开"
            except Exception as exc:
                sculpt_state["alpha_action_status"] = str(exc)
                try:
                    from ..core.state import STATE
                    STATE.last_error = "Satellite Alpha folder dialog invoke failed: " + str(exc)
                except Exception:
                    pass
            return None

        try:
            bpy.app.timers.register(_invoke, first_interval=0.0)
        except Exception as exc:
            raise RuntimeError("新建 Alpha 文件夹窗口调度失败: " + str(exc))
        return "正在打开新建 Alpha 文件夹窗口"

    def _alpha_user_folder_create(name=""):
        result = dict(alpha_managed_store.create_folder(name) or {})
        _refresh_alpha_library()
        return result

    app.commands.register("sculpt.alpha.source_add", _alpha_source_add)
    app.commands.register("sculpt.alpha.source_remove", _alpha_source_remove)
    app.commands.register("sculpt.alpha.folder_remove", _alpha_folder_remove)
    app.commands.register("sculpt.alpha.asset_hide", _alpha_asset_hide)
    app.commands.register("sculpt.alpha.asset_delete", _alpha_asset_delete)
    app.commands.register("sculpt.alpha.source_restore_hidden", _alpha_source_restore_hidden)
    app.commands.register("sculpt.alpha.source_add_dialog", _alpha_source_add_dialog)
    app.commands.register("sculpt.alpha.user_folder_create_dialog", _alpha_user_folder_create_dialog)
    app.commands.register("sculpt.alpha.user_folder_create", _alpha_user_folder_create)

    sculpt_settings.start_watch(app)
    brush_proxy.start_watch(app)
    resource_sync.start_watch(app)
    shortcut_sync.start_watch(app)
    asset_watch.start_watch(app)
