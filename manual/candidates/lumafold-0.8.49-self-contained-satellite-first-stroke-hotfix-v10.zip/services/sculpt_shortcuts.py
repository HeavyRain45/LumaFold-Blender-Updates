from __future__ import annotations

"""Blender Keymap -> LumaFold Quick Brush shortcut truth.

The UI never invents shortcut labels. This service reads the effective exact
Sculpt keymap and mirrors active bindings for lumafold.quick_brush_slot into the
host-independent Sculpt state used by Embedded and Satellite.
"""


_WATCH_NS_KEY = "LUMAFOLD_SCULPT_SHORTCUT_SYNC_V1"
_OPERATOR_ID = "lumafold.quick_brush_slot"
_SLOT_COUNT = 16
_KEYMAP_NAME = "Sculpt"
_SPACE_TYPE = "EMPTY"
_REGION_TYPE = "WINDOW"


_KEY_LABELS = {
    "ZERO": "0", "ONE": "1", "TWO": "2", "THREE": "3", "FOUR": "4",
    "FIVE": "5", "SIX": "6", "SEVEN": "7", "EIGHT": "8", "NINE": "9",
    "NUMPAD_0": "Num0", "NUMPAD_1": "Num1", "NUMPAD_2": "Num2", "NUMPAD_3": "Num3",
    "NUMPAD_4": "Num4", "NUMPAD_5": "Num5", "NUMPAD_6": "Num6", "NUMPAD_7": "Num7",
    "NUMPAD_8": "Num8", "NUMPAD_9": "Num9",
}


def _slot_from_kmi(kmi):
    try:
        return int(getattr(kmi.properties, "slot", -1))
    except Exception:
        return -1


def _label_for_kmi(kmi):
    parts = []
    try:
        if bool(getattr(kmi, "ctrl", False)):
            parts.append("Ctrl")
        if bool(getattr(kmi, "alt", False)):
            parts.append("Alt")
        if bool(getattr(kmi, "shift", False)):
            parts.append("Shift")
        if bool(getattr(kmi, "oskey", False)):
            parts.append("OS")
        key_modifier = str(getattr(kmi, "key_modifier", "NONE") or "NONE")
        if key_modifier != "NONE":
            parts.append(_KEY_LABELS.get(key_modifier, key_modifier.title().replace("_", " ")))
        event = str(getattr(kmi, "type", "") or "")
        parts.append(_KEY_LABELS.get(event, event.title().replace("_", " ")))
    except Exception:
        return ""
    return "+".join(part for part in parts if part)


class SculptShortcutSyncService:
    service_id = "blender.sculpt_shortcuts"

    def __init__(self):
        self._generation = 0
        self._labels = [""] * _SLOT_COUNT
        self._status = "IDLE"

    @staticmethod
    def _candidate_keymaps():
        import bpy

        wm = getattr(bpy.context, "window_manager", None)
        keyconfigs = getattr(wm, "keyconfigs", None) if wm is not None else None
        if keyconfigs is None:
            return []

        result = []
        for name in ("user", "addon"):
            kc = getattr(keyconfigs, name, None)
            if kc is None:
                continue
            try:
                km = kc.keymaps.find(
                    _KEYMAP_NAME,
                    space_type=_SPACE_TYPE,
                    region_type=_REGION_TYPE,
                )
            except Exception:
                km = None
            if km is not None:
                result.append(km)
        return result

    def snapshot(self):
        labels = [""] * _SLOT_COUNT
        seen = set()
        for km in self._candidate_keymaps():
            for kmi in tuple(getattr(km, "keymap_items", ()) or ()):
                try:
                    if str(getattr(kmi, "idname", "") or "") != _OPERATOR_ID:
                        continue
                    if not bool(getattr(kmi, "active", True)):
                        continue
                except Exception:
                    continue
                slot = _slot_from_kmi(kmi)
                if slot < 0 or slot >= _SLOT_COUNT or slot in seen:
                    continue
                seen.add(slot)
                labels[slot] = _label_for_kmi(kmi)
        self._labels = labels
        self._status = "READY" if any(labels) else "NO_BINDINGS"
        return {"status": self._status, "labels": list(labels)}

    def start_watch(self, app, interval: float = 0.50):
        import bpy

        generation = int(bpy.app.driver_namespace.get(_WATCH_NS_KEY, 0) or 0) + 1
        bpy.app.driver_namespace[_WATCH_NS_KEY] = generation
        self._generation = generation
        interval = max(0.20, min(2.0, float(interval)))

        def tick():
            if int(bpy.app.driver_namespace.get(_WATCH_NS_KEY, 0) or 0) != generation:
                return None
            try:
                snap = self.snapshot()
                state = app.store.namespace("sculpt")
                labels = list(snap.get("labels") or ())[:_SLOT_COUNT]
                labels += [""] * (_SLOT_COUNT - len(labels))
                if labels != list(state.get("quick_shortcuts") or ())[:_SLOT_COUNT]:
                    state["quick_shortcuts"] = labels
                    state["quick_shortcuts_status"] = str(snap.get("status") or "READY")
                    app.events.emit("sculpt.quick_shortcuts.changed", {"shortcuts": list(labels)})
                else:
                    state["quick_shortcuts_status"] = str(snap.get("status") or "READY")
            except Exception as exc:
                try:
                    state = app.store.namespace("sculpt")
                    state["quick_shortcuts_status"] = f"ERROR: {type(exc).__name__}: {exc}"
                except Exception:
                    pass
            return interval

        bpy.app.timers.register(tick, first_interval=0.20, persistent=True)
        return generation
