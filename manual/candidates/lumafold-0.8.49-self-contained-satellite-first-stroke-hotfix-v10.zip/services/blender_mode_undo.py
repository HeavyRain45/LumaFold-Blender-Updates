from __future__ import annotations

"""Blender-native Mode bridge for LumaFold.

Blender 5.2 needs its native Sculpt-entry Undo step so the first real Sculpt
stroke has a stable Sculpt-mode floor beneath it. Normal LumaFold entry therefore
opts the final Sculpt mode operator into Blender Undo. LumaFold's serialized
Ctrl+Z clamp treats that native entry step as the session floor and prevents the
user from undoing past it into Object-mode history.

Internal recovery after a clamped cross-session Undo explicitly disables creation
of another Sculpt-entry floor.

LumaFold adds no manual Undo boundary and no global Undo repair handler.

After Sculpt is active, one narrow cleanup remains: if Blender's remembered
workspace tool is a temporary Mask/Hide/Trim tool used by LumaFold modifier
sessions, normalize only that stale tool back to builtin.brush.
"""


_TRANSIENT_SCULPT_TOOL_IDS = frozenset(
    {
        "builtin.box_mask",
        "builtin.lasso_mask",
        "builtin.line_mask",
        "builtin.polyline_mask",
        "builtin.box_hide",
        "builtin.lasso_hide",
        "builtin.line_hide",
        "builtin.polyline_hide",
        "builtin.box_trim",
        "builtin.lasso_trim",
        "builtin.line_trim",
        "builtin.polyline_trim",
    }
)


class BlenderModeUndoSafeService:
    service_id = "blender.mode"

    def __init__(self):
        self._transition_count = 0
        self._last_transition = "idle"
        self._last_boundary = "not-run"
        self._last_tool_normalization = "not-run"

    @staticmethod
    def current_mode() -> str:
        import bpy
        return str(getattr(bpy.context, "mode", "UNKNOWN"))

    @staticmethod
    def _set_native_mode(mode: str, *, undo: bool):
        import bpy

        result = bpy.ops.object.mode_set("EXEC_DEFAULT", bool(undo), mode=str(mode))
        if "FINISHED" not in set(result):
            raise RuntimeError(f"Blender Mode 切换失败: {mode} · {result!r}")
        return result

    @staticmethod
    def _normalize_sculpt_entry_tool() -> str:
        import bpy

        workspace = getattr(bpy.context, "workspace", None)
        if workspace is None:
            return "no-workspace"

        try:
            tool = workspace.tools.from_space_view3d_mode("SCULPT", create=False)
            active_id = str(getattr(tool, "idname", "") or "")
        except Exception:
            return "tool-read-failed"

        if active_id not in _TRANSIENT_SCULPT_TOOL_IDS:
            return f"preserved:{active_id or 'unknown'}"

        window = getattr(bpy.context, "window", None)
        area = getattr(bpy.context, "area", None)
        region = getattr(bpy.context, "region", None)

        if window is None:
            return f"stale:{active_id}:no-window"

        if area is None or getattr(area, "type", "") != "VIEW_3D":
            screen = getattr(window, "screen", None)
            area = next(
                (
                    item
                    for item in tuple(getattr(screen, "areas", ()) or ())
                    if getattr(item, "type", "") == "VIEW_3D"
                ),
                None,
            )
        if area is None:
            return f"stale:{active_id}:no-view3d"

        if region is None or getattr(region, "type", "") != "WINDOW":
            region = next(
                (
                    item
                    for item in tuple(getattr(area, "regions", ()) or ())
                    if getattr(item, "type", "") == "WINDOW"
                ),
                None,
            )

        try:
            if region is not None:
                with bpy.context.temp_override(window=window, area=area, region=region):
                    result = set(
                        bpy.ops.wm.tool_set_by_id(
                            "EXEC_DEFAULT",
                            name="builtin.brush",
                            space_type="VIEW_3D",
                        )
                        or ()
                    )
            else:
                with bpy.context.temp_override(window=window, area=area):
                    result = set(
                        bpy.ops.wm.tool_set_by_id(
                            "EXEC_DEFAULT",
                            name="builtin.brush",
                            space_type="VIEW_3D",
                        )
                        or ()
                    )
        except (RuntimeError, TypeError, AttributeError):
            return f"stale:{active_id}:restore-failed"

        if "FINISHED" not in result:
            return f"stale:{active_id}:{sorted(result)!r}"
        return f"normalized:{active_id}->builtin.brush"

    def set_mode(self, mode: str, *, sculpt_entry_undo: bool = True):
        import bpy

        obj = getattr(bpy.context.view_layer.objects, "active", None)
        if obj is None:
            raise RuntimeError("No active Blender object")

        requested = str(mode or "OBJECT").upper()
        if obj.type != "MESH" and requested == "SCULPT":
            raise RuntimeError("Sculpt Mode requires an active mesh")

        current = str(getattr(bpy.context, "mode", "OBJECT"))
        if current == requested:
            if requested == "SCULPT":
                self._last_tool_normalization = self._normalize_sculpt_entry_tool()
            self._last_transition = f"{current} -> {requested} · unchanged"
            return f"mode = {current}"

        if current != "OBJECT":
            self._set_native_mode("OBJECT", undo=False)
        if requested != "OBJECT":
            self._set_native_mode(
                requested,
                undo=bool(requested == "SCULPT" and sculpt_entry_undo),
            )

        actual = str(getattr(bpy.context, "mode", "UNKNOWN"))
        if actual != requested:
            raise RuntimeError(f"Blender Mode 真值不一致: requested={requested}, actual={actual}")

        # Tool cleanup is state hygiene only; Blender owns the mode/Undo step.
        if requested == "SCULPT":
            self._last_tool_normalization = self._normalize_sculpt_entry_tool()
        else:
            self._last_tool_normalization = "not-sculpt"

        self._transition_count += 1
        created_sculpt_floor = bool(
            requested == "SCULPT"
            and sculpt_entry_undo
        )
        self._last_boundary = (
            "blender-sculpt-entry-floor"
            if created_sculpt_floor
            else "lumafold-mode-nonundo"
        )
        self._last_transition = f"{current} -> {actual}"
        suffix = (
            "blender-sculpt-entry-floor"
            if created_sculpt_floor
            else "session-mode-nonundo"
        )
        return f"mode = {actual} · {suffix}"

    def snapshot(self):
        return {
            "mode": self.current_mode(),
            "transition_count": int(self._transition_count),
            "last_transition": str(self._last_transition),
            "last_boundary": str(self._last_boundary),
            "last_tool_normalization": str(self._last_tool_normalization),
            "profile": "Blender Sculpt entry floor + native Sculpt edit Undo",
        }
