from __future__ import annotations

import traceback

import bpy

from .core.app import APP
from .core.state import STATE
from .core.build_info import BUILD_ID, BUILD_LABEL
from .core.host_control import HOST_CONTROL


_NS_KEY = "LUMAFOLD_DEV_SMOKE_V5"


def _ns():
    data = bpy.app.driver_namespace.get(_NS_KEY)
    if not isinstance(data, dict):
        data = {"sequence": 0, "status": "not run", "passed": 0, "total": 0, "details": [], "error": ""}
        bpy.app.driver_namespace[_NS_KEY] = data
    return data


def smoke_status_text():
    data = _ns()
    seq = int(data.get("sequence", 0) or 0)
    status = str(data.get("status", "not run") or "not run")
    passed = int(data.get("passed", 0) or 0)
    total = int(data.get("total", 0) or 0)
    return f"#{seq} · {status} · {passed}/{total}"


def smoke_details():
    return list(_ns().get("details") or ())


def _run_smoke():
    checks = []

    def check(name, ok, detail=""):
        checks.append({"name": str(name), "ok": bool(ok), "detail": str(detail or "")})

    # Concentrated non-destructive gate. It validates active registration and
    # Blender truth without changing Mode, Brush, Alpha or Host ownership.
    check("build_freshness", bool(BUILD_ID) and "dev" in BUILD_ID, BUILD_LABEL)

    required_commands = (
        "sculpt.brush.activate_slot",
        "sculpt.brush.library_refresh",
        "sculpt.brush.library_activate",
        "sculpt.brush.library_assign_slot",
        "sculpt.alpha.library_refresh",
        "sculpt.alpha.library_activate",
        "sculpt.alpha.library_import_dialog",
    )
    missing_commands = [command_id for command_id in required_commands if not APP.commands.has(command_id)]
    check("command_contract", not missing_commands, "missing=" + ",".join(missing_commands) if missing_commands else "registered")

    # Phase B.5 runtime authorities. These checks make sure the code paths that
    # passed CI are actually the ones installed in this live Blender process.
    try:
        from .runtime import runtime_core
        runtime_installed = bool(getattr(runtime_core, "_INSTALLED", False))
        check("runtime_core_authority", runtime_installed, f"installed={runtime_installed}")
    except Exception as exc:
        check("runtime_core_authority", False, f"{type(exc).__name__}: {exc}")

    try:
        subscriber_count = len(tuple(getattr(HOST_CONTROL, "_subscribers", ()) or ()))
        check("host_transition_observer", subscriber_count >= 1, f"subscribers={subscriber_count}")
    except Exception as exc:
        check("host_transition_observer", False, f"{type(exc).__name__}: {exc}")

    try:
        from .runtime import sculpt_input_core
        region_fn = getattr(sculpt_input_core, "_view3d_region_under_pointer", None)
        region_module = str(getattr(region_fn, "__module__", "") or "")
        check("concrete_region_authority", "runtime_core" in region_module, region_module or "unknown")
    except Exception as exc:
        check("concrete_region_authority", False, f"{type(exc).__name__}: {exc}")

    try:
        from .desktop.bridge_server import BRIDGE
        snapshot_fn = getattr(BRIDGE, "_snapshot", None)
        snapshot_module = str(getattr(snapshot_fn, "__module__", "") or "")
        check("satellite_bridge_authority", "satellite_bridge_authority" in snapshot_module, snapshot_module or "unknown")
    except Exception as exc:
        check("satellite_bridge_authority", False, f"{type(exc).__name__}: {exc}")

    try:
        choose = getattr(APP.commands, "_commands", {}).get("sculpt.brush.library_activate")
        choose_module = str(getattr(choose, "__module__", "") or "")
        check("brush_library_policy", "sculpt_library_actions" in choose_module, choose_module or "unknown")
    except Exception as exc:
        check("brush_library_policy", False, f"{type(exc).__name__}: {exc}")

    host = getattr(STATE, "host", None)
    host_ok = (not bool(STATE.running)) or (host is not None and not bool(getattr(host, "closed", True)))
    check("host_runtime", host_ok, f"running={bool(STATE.running)} host={type(host).__name__ if host is not None else 'none'}")

    lease = HOST_CONTROL.snapshot()
    lease_ok = str(lease.get("state") or "") in {"EMBEDDED", "DETACHING", "SATELLITE", "ATTACHING", "RECOVERING"}
    check("host_lease_state", lease_ok, f"{lease.get('state')} · {lease.get('owner')} · G{lease.get('generation')}")

    gate = dict(APP.services.require("blender.compat_gate").snapshot() or {})
    missing_api = list(gate.get("missing") or ())
    check(
        "compat_gate",
        gate.get("status") == "READY",
        f"{gate.get('status')} · {gate.get('profile')} · missing={','.join(str(x) for x in missing_api) or 'none'}",
    )

    resource_sync = dict(APP.services.require("blender.sculpt_resource_sync").snapshot() or {})
    resource_status = str(resource_sync.get("status") or "")
    check("resource_sync", not resource_status.startswith("ERROR"), resource_status)

    asset_watch = dict(APP.services.require("blender.sculpt_asset_watch").snapshot() or {})
    watch_status = str(asset_watch.get("status") or "")
    check(
        "asset_watch",
        watch_status in {"IDLE", "WATCHING", "REFRESHING"},
        f"{watch_status} · roots={asset_watch.get('root_count', 0)} entries={asset_watch.get('entry_count', 0)} serial={asset_watch.get('serial', 0)}",
    )

    alpha_service = APP.services.require("blender.alpha")
    alpha_root = None
    try:
        root_fn = getattr(alpha_service, "user_library_root", None)
        alpha_root = root_fn(create=True) if root_fn is not None else None
    except Exception:
        alpha_root = None
    check(
        "alpha_user_library",
        bool(alpha_root is not None and alpha_root.is_dir()),
        str(alpha_root or "unavailable"),
    )

    proxy = dict(APP.services.require("blender.brush_proxy").snapshot() or {})
    proxy_count = int(proxy.get("proxy_count", 0) or 0)
    check("alpha_proxy_lifecycle", proxy_count <= 1, f"{proxy.get('status')} · count={proxy_count}")

    mode = str(getattr(bpy.context, "mode", ""))
    if mode == "SCULPT":
        brush = dict(APP.services.require("blender.brush").current_sculpt_brush() or {})
        check("active_sculpt_brush", bool(brush.get("available")), str(brush.get("name") or ""))

        settings = dict(APP.services.require("blender.sculpt_settings").snapshot() or {})
        size = float(settings.get("size", 0.0) or 0.0)
        strength = float(settings.get("strength", -1.0) or 0.0)
        settings_ok = bool(settings.get("available")) and size >= 1.0 and 0.0 <= strength <= 1.0
        check(
            "sculpt_size_strength",
            settings_ok,
            f"size={size} [{settings.get('size_source')}] strength={strength} [{settings.get('strength_source')}]",
        )

        alpha = dict(alpha_service.current_sculpt_alpha() or {})
        check("sculpt_alpha", bool(alpha.get("identity")), str(alpha.get("name") or "默认"))
    else:
        check("sculpt_context", True, f"SKIP · mode={mode or 'UNKNOWN'}")

    passed = sum(1 for item in checks if item["ok"])
    return checks, passed, len(checks)


class LUMAFOLD_OT_dev_smoke(bpy.types.Operator):
    bl_idname = "lumafold.dev_smoke"
    bl_label = "运行 LumaFold 快速自检"
    bl_description = "运行非破坏性集中回归：Runtime Authority、Host/Bridge、命令契约、兼容层、资源同步、Alpha 生命周期和 Sculpt 真值链"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        data = _ns()
        data["sequence"] = int(data.get("sequence", 0) or 0) + 1
        data["status"] = "running"
        data["error"] = ""
        try:
            checks, passed, total = _run_smoke()
            data["details"] = checks
            data["passed"] = passed
            data["total"] = total
            data["status"] = "PASS" if passed == total else "FAIL"
            if passed == total:
                STATE.last_error = ""
                self.report({'INFO'}, f"LumaFold 快速自检通过 {passed}/{total}")
                return {'FINISHED'}
            failed = [item["name"] for item in checks if not item["ok"]]
            STATE.last_error = "Smoke gate failed: " + ", ".join(failed)
            self.report({'WARNING'}, f"LumaFold 快速自检未通过 {passed}/{total}")
            return {'FINISHED'}
        except Exception:
            data["status"] = "ERROR"
            data["error"] = traceback.format_exc()
            STATE.last_error = data["error"]
            self.report({'ERROR'}, "LumaFold 快速自检运行失败")
            return {'CANCELLED'}


CLASSES = (LUMAFOLD_OT_dev_smoke,)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
