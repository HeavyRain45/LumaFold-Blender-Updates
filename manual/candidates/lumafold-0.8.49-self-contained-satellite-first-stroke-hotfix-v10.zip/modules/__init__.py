"""LumaFold built-in + external module discovery entry point."""
from pathlib import Path
import bpy

from ..core.modulesdk import ModuleLoader

_LOADER = None


def _external_module_root():
    base = bpy.utils.user_resource('SCRIPTS', path='lumafold/modules', create=True)
    return Path(base)


def register_modules(app):
    global _LOADER
    if _LOADER is None:
        import sys
        package = sys.modules[__name__]
        _LOADER = ModuleLoader(app, package, external_root=_external_module_root())
    app.module_loader = _LOADER
    _LOADER.load_all()
    return _LOADER
