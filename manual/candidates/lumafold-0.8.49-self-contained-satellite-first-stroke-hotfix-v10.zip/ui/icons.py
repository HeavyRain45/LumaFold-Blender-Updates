"""LumaFold icon atlas foundation.

P0.4 tests the production icon path: one centrally managed anti-aliased atlas,
shared by every module. Business modules never draw their own GPU line-art.
The atlas is authored at 64 px per cell and displayed at smaller integer sizes.
"""
from __future__ import annotations

import json
from pathlib import Path

from . import theme as T
from .design import px

_ATLAS_TEX_ID = 0
_META = None


def _asset_dir() -> Path:
    return Path(__file__).resolve().parent.parent / "assets"


def _load_meta():
    global _META
    if _META is None:
        _META = json.loads((_asset_dir() / "icons_meta.json").read_text(encoding="utf-8"))
    return _META


def ensure_icon_atlas(renderer) -> int:
    global _ATLAS_TEX_ID
    if _ATLAS_TEX_ID:
        return _ATLAS_TEX_ID
    meta = _load_meta()
    rgba = (_asset_dir() / "icons_rgba.bin").read_bytes()
    expected = int(meta["width"]) * int(meta["height"]) * 4
    if len(rgba) != expected:
        raise RuntimeError(f"Icon atlas byte size mismatch: {len(rgba)} != {expected}")
    _ATLAS_TEX_ID = renderer.register_rgba_texture(int(meta["width"]), int(meta["height"]), rgba)
    return _ATLAS_TEX_ID


def reset_icon_state(renderer=None):
    global _ATLAS_TEX_ID, _META
    if renderer is not None and _ATLAS_TEX_ID:
        try:
            renderer.unregister_texture(_ATLAS_TEX_ID)
        except Exception:
            pass
    _ATLAS_TEX_ID = 0
    _META = None


def get_icon_info():
    meta = _load_meta()
    return {
        "atlas": f"{meta['width']}x{meta['height']}",
        "cell": int(meta["cell"]),
        "count": len(meta["order"]),
        "names": tuple(meta["order"]),
        "ready": bool(_ATLAS_TEX_ID),
    }


def _uv(name: str):
    meta = _load_meta()
    try:
        i = meta["order"].index(name)
    except ValueError as exc:
        raise KeyError(f"Unknown LumaFold icon: {name}") from exc
    cols = int(meta["columns"])
    rows = int(meta["rows"])
    col = i % cols
    row = i // cols
    return ((col / cols, row / rows), ((col + 1) / cols, (row + 1) / rows))


def icon(imgui, name: str, scale=1.0, size=18.0, color=None):
    if not _ATLAS_TEX_ID:
        return
    uv0, uv1 = _uv(name)
    s = px(size, scale)
    imgui.image_with_bg(
        _ATLAS_TEX_ID,
        (s, s),
        uv0,
        uv1,
        (0.0, 0.0, 0.0, 0.0),
        color or T.TEXT_PRIMARY,
    )


def icon_button(imgui, name: str, ident: str, scale=1.0, size=18.0, *, selected=False, tooltip=None):
    if not _ATLAS_TEX_ID:
        return False
    uv0, uv1 = _uv(name)
    if selected:
        imgui.push_style_color(imgui.Col.BUTTON, T.SELECTED)
        imgui.push_style_color(imgui.Col.BUTTON_HOVERED, T.SELECTED_HOVER)
        imgui.push_style_color(imgui.Col.BUTTON_ACTIVE, T.SELECTED_SOFT)
    else:
        imgui.push_style_color(imgui.Col.BUTTON, T.TOOL_BG)
        imgui.push_style_color(imgui.Col.BUTTON_HOVERED, T.TOOL_HOVER)
        imgui.push_style_color(imgui.Col.BUTTON_ACTIVE, T.TOOL_ACTIVE)
    imgui.push_style_color(imgui.Col.BORDER, T.TOOL_BORDER)
    try:
        s = px(size, scale)
        clicked = imgui.image_button(
            f"##icon_{ident}",
            _ATLAS_TEX_ID,
            (s, s),
            uv0,
            uv1,
            (0.0, 0.0, 0.0, 0.0),
            T.TEXT_PRIMARY,
        )
        if tooltip and imgui.is_item_hovered():
            imgui.set_tooltip(tooltip)
        return clicked
    finally:
        imgui.pop_style_color(4)
