from contextlib import contextmanager

from . import theme as T
from .design import font_scope, px
from .layout_system import PRIMARY


def text(imgui, value, scale=1.0, *, kind="body", color=None):
    with font_scope(imgui, kind, scale):
        if color is None:
            imgui.text(value)
        else:
            imgui.text_colored(color, value)


def muted(imgui, value, scale=1.0):
    text(imgui, value, scale, kind="small", color=T.TEXT_SECONDARY)


def section(imgui, title, subtitle=None, scale=1.0):
    text(imgui, title, scale, kind="section")
    if subtitle:
        muted(imgui, subtitle, scale)
    imgui.separator()


@contextmanager
def frame_style(imgui):
    """Use Blender's numeric/slider widget family for one framed control."""
    imgui.push_style_color(imgui.Col.FRAME_BG, T.FRAME_BG)
    imgui.push_style_color(imgui.Col.FRAME_BG_HOVERED, T.FRAME_HOVER)
    imgui.push_style_color(imgui.Col.FRAME_BG_ACTIVE, T.FRAME_ACTIVE)
    imgui.push_style_color(imgui.Col.BORDER, T.FRAME_BORDER)
    try:
        yield
    finally:
        imgui.pop_style_color(4)


def _push_button_style(imgui, *, selected=False):
    if selected:
        imgui.push_style_color(imgui.Col.BUTTON, T.SELECTED)
        imgui.push_style_color(imgui.Col.BUTTON_HOVERED, T.SELECTED_HOVER)
        imgui.push_style_color(imgui.Col.BUTTON_ACTIVE, T.SELECTED_SOFT)
    else:
        imgui.push_style_color(imgui.Col.BUTTON, T.BUTTON_BG)
        imgui.push_style_color(imgui.Col.BUTTON_HOVERED, T.BUTTON_HOVER)
        imgui.push_style_color(imgui.Col.BUTTON_ACTIVE, T.BUTTON_ACTIVE)
    imgui.push_style_color(imgui.Col.BORDER, T.BUTTON_BORDER)


def button(imgui, label, scale=1.0, width=0.0, *, selected=False, disabled=False, kind="body", height=None):
    button_h = T.BUTTON_H if height is None else float(height)
    size = (px(width, scale) if width else 0.0, px(button_h, scale))
    _push_button_style(imgui, selected=selected)
    if disabled:
        imgui.begin_disabled(True)
    try:
        with font_scope(imgui, kind, scale):
            return imgui.button(label, size)
    finally:
        if disabled:
            imgui.end_disabled()
        imgui.pop_style_color(4)


def square_button(imgui, label, scale=1.0, size=38.0, *, selected=False, disabled=False, kind="small"):
    """Square product tile with the same typography/state contract as button()."""
    side = px(size, scale)
    _push_button_style(imgui, selected=selected)
    if disabled:
        imgui.begin_disabled(True)
    try:
        with font_scope(imgui, kind, scale):
            return imgui.button(label, (side, side))
    finally:
        if disabled:
            imgui.end_disabled()
        imgui.pop_style_color(4)


def image_square_button(imgui, ident, tex_id, scale=1.0, size=38.0, *, selected=False, tooltip=None):
    """Blender-style asset tile whose preview nearly fills the exact tile box.

    Global LumaFold FramePadding is 5 design units, which is appropriate for
    text buttons but much wider than Blender's Asset Shelf thumbnail inset.
    Temporarily use a narrow 1.5-unit frame for image tiles *and* shrink the
    image by that exact amount so the outer geometry remains ``size``. This
    enlarges the artwork without breaking the frozen 8-column grid.
    """
    outer = px(size, scale)
    pad = px(1.5, scale)
    image_side = max(1.0, outer - 2.0 * pad)
    old_frame_padding = None
    try:
        style = imgui.get_style()
        old_frame_padding = tuple(style.frame_padding)
        style.frame_padding = (pad, pad)
    except Exception:
        old_frame_padding = None
    _push_button_style(imgui, selected=selected)
    try:
        clicked = imgui.image_button(
            f"##image_tile_{ident}", int(tex_id), (image_side, image_side),
            (0.0, 0.0), (1.0, 1.0),
            (0.0, 0.0, 0.0, 0.0), (1.0, 1.0, 1.0, 1.0),
        )
        if tooltip and imgui.is_item_hovered():
            imgui.set_tooltip(tooltip)
        return bool(clicked)
    finally:
        imgui.pop_style_color(4)
        if old_frame_padding is not None:
            try:
                imgui.get_style().frame_padding = old_frame_padding
            except Exception:
                pass


def square_action_button(imgui, label, scale=1.0, size=24.0, *, disabled=False, tooltip=None):
    """Standard action box used by Secondary toolbars (+ / − fallbacks)."""
    side = px(size, scale)
    _push_button_style(imgui, selected=False)
    if disabled:
        imgui.begin_disabled(True)
    try:
        with font_scope(imgui, "body", scale):
            clicked = imgui.button(label, (side, side))
        if tooltip and imgui.is_item_hovered():
            imgui.set_tooltip(tooltip)
        return bool(clicked)
    finally:
        if disabled:
            imgui.end_disabled()
        imgui.pop_style_color(4)


def segmented(imgui, labels, current, scale=1.0, width=0.0):
    count = max(1, len(labels))
    if width <= 0.0:
        width = max(82.0, (imgui.get_content_region_avail()[0] / count) / scale - 4.0)
    new_value = current
    for i, label in enumerate(labels):
        if i:
            imgui.same_line()
        if button(imgui, f"{label}##seg{i}", scale, width, selected=(i == current)):
            new_value = i
    return new_value


def property_slider(imgui, label, value, min_value, max_value, scale=1.0, fmt="%.2f"):
    if label:
        text(imgui, label, scale, kind="small", color=T.TEXT_SECONDARY)
        imgui.same_line()
        value_text = fmt % value
        with font_scope(imgui, "value", scale):
            available = imgui.get_content_region_avail()[0]
            value_w = imgui.calc_text_size(value_text)[0]
            if available > value_w:
                imgui.set_cursor_pos_x(imgui.get_cursor_pos_x() + available - value_w)
            imgui.text(value_text)
    imgui.set_next_item_width(-1.0)
    with frame_style(imgui):
        with font_scope(imgui, "body", scale):
            changed, new_value = imgui.slider_float(f"##{label or 'value'}", value, min_value, max_value, fmt)
    return new_value if changed else value


def compact_value_row(imgui, label, value, scale=1.0):
    text(imgui, label, scale, kind="small", color=T.TEXT_SECONDARY)
    imgui.same_line()
    with font_scope(imgui, "value", scale):
        avail = imgui.get_content_region_avail()[0]
        value_w = imgui.calc_text_size(value)[0]
        if avail > value_w:
            imgui.set_cursor_pos_x(imgui.get_cursor_pos_x() + avail - value_w)
        imgui.text(value)


def thumbnail_button(imgui, label, index, selected, scale=1.0, width=88.0):
    _push_button_style(imgui, selected=bool(selected))
    try:
        with font_scope(imgui, "small", scale):
            caption = f"{label}\n\n{index:02d}##thumb{index}"
            return imgui.button(caption, (px(width, scale), px(T.THUMB_H, scale)))
    finally:
        imgui.pop_style_color(4)
