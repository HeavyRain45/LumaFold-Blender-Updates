from __future__ import annotations

"""Small floating-depth layer for Embedded Sculpt surfaces.

This stays deliberately outside Host/Input code. It reads Blender's current
menu-shadow theme settings when available, draws only outside the current ImGui
window bounds, and restores every temporary imgui callable immediately.

V1.9 scopes shadow to the primary floating workbench plus named Embedded popup
surfaces. Native OS-level Satellite windows keep their own platform chrome.
"""

from contextlib import contextmanager


_INSTALLED = False
_ORIGINAL_SCULPT_DRAW = None

_SHADOW_POPUPS = frozenset({
    "LumaFold Brush Library##foundation",
    "LumaFold Alpha Library##foundation",
    "Quick Brush Slot##context",
    "Brush Asset##library_context",
    "Alpha Asset##library_context",
    "Alpha Add##product_context",
    "Alpha Folder##product_context",
})


def _clamp(value, low, high):
    return max(float(low), min(float(high), float(value)))


def _theme_shadow_settings():
    """Return Blender-authored shadow width/factor, with a quiet fallback."""
    try:
        import bpy

        themes = bpy.context.preferences.themes
        if themes:
            ui = themes[0].user_interface
            width = float(getattr(ui, "menu_shadow_width", 0.0) or 0.0)
            factor = float(getattr(ui, "menu_shadow_fac", 0.0) or 0.0)
            return _clamp(width, 0.0, 24.0), _clamp(factor, 0.0, 1.0)
    except Exception:
        pass
    return 8.0, 0.32


def _shadow_u32(alpha: float) -> int:
    """Pack neutral-black ImGui color. RGB is zero, so linear/sRGB is identical."""
    a = int(round(_clamp(alpha, 0.0, 1.0) * 255.0)) & 255
    return a << 24


def _draw_ring_stack(
    draw,
    *,
    x0: float,
    y0: float,
    x1: float,
    y1: float,
    rounding: float,
    width_px: float,
    peak_alpha: float,
    base_x: float,
    base_y: float,
    drift_x: float,
    drift_y: float,
    falloff: float,
    thickness: float = 1.0,
) -> None:
    """Approximate a soft directional blur with many very low-alpha outlines.

    V1.9a/b used one symmetric high-contrast ring stack. That read as a dark
    outline halo rather than a natural Blender/OS-style floating shadow. Splitting
    the result into an ambient stack and a directional contact stack lets the
    top/left remain quiet while the bottom/right carries most of the depth.
    """
    width_px = max(1.0, float(width_px))
    steps = max(6, min(28, int(round(width_px * 2.0))))
    for i in range(steps, 0, -1):
        outer_frac = (float(i) - 1.0) / max(1.0, float(steps - 1))
        alpha = peak_alpha * ((1.0 - outer_frac) ** float(falloff))
        if alpha <= 0.001:
            continue

        expand = 0.8 + width_px * (float(i) / float(steps))
        x_off = float(base_x) + expand * float(drift_x)
        y_off = float(base_y) + expand * float(drift_y)
        draw.add_rect(
            (x0 - expand + x_off, y0 - expand + y_off),
            (x1 + expand + x_off, y1 + expand + y_off),
            _shadow_u32(alpha),
            rounding + expand,
            thickness=float(thickness),
        )


def _draw_current_window_shadow(imgui, scale: float, *, popup: bool) -> None:
    """Draw a soft Blender-like floating depth layer outside the current window.

    The shadow intentionally has two components:
    - a broad, very faint ambient lift;
    - a tighter directional contact shadow biased down/right.

    That avoids the uniform "black frame" look produced by the older single ring
    stack while preserving the already-approved Theme Follow colors and borders.
    """
    width, factor = _theme_shadow_settings()
    if width <= 0.0 or factor <= 0.0:
        return

    try:
        pos = imgui.get_window_pos()
        size = imgui.get_window_size()
        x0, y0 = float(pos[0]), float(pos[1])
        x1, y1 = x0 + float(size[0]), y0 + float(size[1])
        if x1 <= x0 or y1 <= y0:
            return

        io = imgui.get_io()
        display = tuple(io.display_size)
        # A native Secondary/Satellite window usually fills almost the complete
        # ImGui display. Let the OS own depth there; this layer is for Embedded
        # floating surfaces sitting over the 3D View.
        if not popup and display[0] > 0.0 and display[1] > 0.0:
            fills_display = (
                x0 <= 2.0 and y0 <= 2.0
                and x1 >= float(display[0]) - 2.0
                and y1 >= float(display[1]) - 2.0
            )
            if fills_display:
                return

        draw = imgui.get_window_draw_list()
        style = imgui.get_style()
        rounding = float(style.popup_rounding if popup else style.window_rounding)
    except Exception:
        return

    s = _clamp(scale, 0.85, 2.0)
    theme_width = _clamp(width * s, 3.0, 18.0)

    # Popup shadows should feel closer to their parent than full workbench/library
    # surfaces, so keep them a little tighter and slightly less ambient.
    if popup:
        ambient_width = _clamp(theme_width * 0.72, 3.0, 12.0)
        contact_width = _clamp(theme_width * 0.48, 2.0, 8.0)
        ambient_alpha = min(0.032, factor * 0.060)
        contact_alpha = min(0.070, factor * 0.135)
        base_x, base_y = 0.25 * s, 0.75 * s
    else:
        ambient_width = _clamp(theme_width * 1.05, 4.0, 18.0)
        contact_width = _clamp(theme_width * 0.58, 2.5, 10.0)
        ambient_alpha = min(0.040, factor * 0.075)
        contact_alpha = min(0.082, factor * 0.155)
        base_x, base_y = 0.35 * s, 0.95 * s

    pushed_clip = False
    try:
        draw.push_clip_rect_full_screen()
        pushed_clip = True

        # Broad ambient lift: almost centered and extremely faint. This creates a
        # soft transition against the viewport without looking like another border.
        _draw_ring_stack(
            draw,
            x0=x0,
            y0=y0,
            x1=x1,
            y1=y1,
            rounding=rounding,
            width_px=ambient_width,
            peak_alpha=ambient_alpha,
            base_x=0.0,
            base_y=0.15 * s,
            drift_x=0.10,
            drift_y=0.22,
            falloff=1.20,
            thickness=0.85,
        )

        # Directional contact depth: tighter, with most of the energy below/right.
        # Spread-dependent drift suppresses the top/left "halo" that made V1.9b
        # feel synthetic, while the low peak alpha keeps Blender's restrained look.
        _draw_ring_stack(
            draw,
            x0=x0,
            y0=y0,
            x1=x1,
            y1=y1,
            rounding=rounding,
            width_px=contact_width,
            peak_alpha=contact_alpha,
            base_x=base_x,
            base_y=base_y,
            drift_x=0.28,
            drift_y=0.52,
            falloff=1.55,
            thickness=0.95,
        )
    except Exception:
        # Presentation-only layer: never let a missing draw-list method affect
        # product behavior, input, previews, or popup lifetime.
        pass
    finally:
        if pushed_clip:
            try:
                draw.pop_clip_rect()
            except Exception:
                pass


@contextmanager
def _popup_shadow_scope(imgui, scale: float):
    """Add depth only after one of the named Embedded popups actually opens."""
    original = getattr(imgui, "begin_popup", None)
    patched = False
    if callable(original):
        def begin_popup_with_shadow(name, *args, _original=original, **kwargs):
            opened = bool(_original(name, *args, **kwargs))
            if opened and str(name or "") in _SHADOW_POPUPS:
                _draw_current_window_shadow(imgui, scale, popup=True)
            return opened

        try:
            setattr(imgui, "begin_popup", begin_popup_with_shadow)
            patched = True
        except Exception:
            patched = False
    try:
        yield
    finally:
        if patched:
            try:
                setattr(imgui, "begin_popup", original)
            except Exception:
                pass


def install(alpha_product, sculpt_view):
    """Layer visual depth above the already-stable Theme Follow wrappers."""
    global _INSTALLED, _ORIGINAL_SCULPT_DRAW
    if _INSTALLED:
        return

    foundation = alpha_product.foundation
    _ORIGINAL_SCULPT_DRAW = foundation.draw_sculpt_compact

    def draw_sculpt_with_depth(imgui, *args, **kwargs):
        try:
            scale = float(args[2] if len(args) > 2 else kwargs.get("scale", 1.0))
        except Exception:
            scale = 1.0

        # We are already inside the primary Embedded ImGui window here.
        _draw_current_window_shadow(imgui, scale, popup=False)
        with _popup_shadow_scope(imgui, scale):
            return _ORIGINAL_SCULPT_DRAW(imgui, *args, **kwargs)

    foundation.draw_sculpt_compact = draw_sculpt_with_depth
    # Do not replace sculpt_view.draw_sculpt_compact: the public product layer
    # owns preview warming, Brush Library opening, shortcut editing and caches.
    _INSTALLED = True


def uninstall(alpha_product, sculpt_view):
    global _INSTALLED, _ORIGINAL_SCULPT_DRAW
    if not _INSTALLED:
        return
    foundation = alpha_product.foundation
    if _ORIGINAL_SCULPT_DRAW is not None:
        foundation.draw_sculpt_compact = _ORIGINAL_SCULPT_DRAW
    _ORIGINAL_SCULPT_DRAW = None
    _INSTALLED = False