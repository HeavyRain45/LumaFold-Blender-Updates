import math
from contextlib import contextmanager

from . import theme as T
from .fonts import get_ui_font
from .layout_system import PRIMARY, BRUSH_LIBRARY
from .theme_policy import style_metrics


def px(value: float, scale: float) -> float:
    """Snap a design unit to a whole UI pixel."""
    return float(max(1, int(math.floor(value * scale + 0.5))))


def vec2(x: float, y: float, scale: float):
    return (px(x, scale), px(y, scale))


def font_px(kind: str, scale: float) -> float:
    base = {
        "small": T.FONT_SMALL,
        "body": T.FONT_BODY,
        "value": T.FONT_VALUE,
        "section": T.FONT_SECTION,
        "title": T.FONT_TITLE,
    }.get(kind, T.FONT_BODY)
    # Dear ImGui 1.92 supports dynamic font sizes. Whole pixels keep rasterization
    # and baselines predictable across the four P0 scale presets.
    return px(base, scale)


@contextmanager
def font_scope(imgui, kind: str, scale: float):
    """Safe dynamic font-size scope.

    slimgui 0.8.2 exposes ImGui 1.92 push_font(font, font_size_base). LumaFold
    supplies one shared UI font when P0.3 finds Blender/system font resources.
    If a future binding rejects the call, the component falls back to the
    current font instead of killing the UI host.
    """
    pushed = False
    try:
        imgui.push_font(get_ui_font(), font_px(kind, scale))
        pushed = True
    except (AttributeError, TypeError, RuntimeError):
        pushed = False
    try:
        yield
    finally:
        if pushed:
            try:
                imgui.pop_font()
            except Exception:
                pass


def _try_set(style, name: str, value, skipped: list[str]) -> None:
    try:
        setattr(style, name, value)
    except (AttributeError, TypeError):
        skipped.append(name)


def apply_style(imgui, scale: float):
    """Apply geometry + color tokens at frame boundaries only."""
    s = max(0.85, min(2.0, float(scale)))
    style = imgui.get_style()
    skipped: list[str] = []

    _try_set(style, "window_padding", vec2(PRIMARY.outer_padding, PRIMARY.outer_padding, s), skipped)
    _try_set(style, "frame_padding", vec2(5.0, 5.0, s), skipped)
    _try_set(style, "item_spacing", vec2(PRIMARY.gap, PRIMARY.gap, s), skipped)
    _try_set(style, "item_inner_spacing", vec2(5.0, 4.0, s), skipped)
    _try_set(style, "window_rounding", px(T.RADIUS_L, s), skipped)
    _try_set(style, "child_rounding", px(T.RADIUS_M, s), skipped)
    _try_set(style, "frame_rounding", px(T.RADIUS_S, s), skipped)
    _try_set(style, "popup_rounding", px(T.RADIUS_M, s), skipped)
    _try_set(style, "scrollbar_rounding", px(T.RADIUS_M, s), skipped)
    _try_set(style, "grab_rounding", px(T.RADIUS_S, s), skipped)

    # One host-neutral contract owns the edge hierarchy for Embedded, Satellite
    # and Secondary. Light neutral stacks use a 1 px widget frame; Dark stacks
    # rely on fill contrast. Window/popup outlines remain present in both modes.
    policy = style_metrics(T.SURFACE_0)
    _try_set(style, "window_border_size", policy["window_border_size"], skipped)
    _try_set(style, "frame_border_size", policy["frame_border_size"], skipped)
    _try_set(style, "cell_padding", vec2(7.0, 5.0, s), skipped)
    _try_set(style, "child_border_size", policy["child_border_size"], skipped)
    _try_set(style, "popup_border_size", policy["popup_border_size"], skipped)
    _try_set(style, "scrollbar_size", px(BRUSH_LIBRARY.scrollbar_size, s), skipped)
    _try_set(style, "grab_min_size", px(10.0, s), skipped)
    _try_set(style, "indent_spacing", px(17.0, s), skipped)

    colors = style.colors
    colors[imgui.Col.WINDOW_BG] = T.SURFACE_0
    colors[imgui.Col.CHILD_BG] = T.SURFACE_1
    colors[imgui.Col.POPUP_BG] = T.SECONDARY_SURFACE_BG
    # Global Border is reserved for floating chrome. Individual component
    # helpers temporarily swap in BUTTON/TOOL/FRAME_BORDER when drawing widgets.
    colors[imgui.Col.BORDER] = T.WINDOW_BORDER
    colors[imgui.Col.BORDER_SHADOW] = (0.0, 0.0, 0.0, 0.0)
    colors[imgui.Col.TEXT] = T.TEXT_PRIMARY
    colors[imgui.Col.TEXT_DISABLED] = T.TEXT_MUTED

    colors[imgui.Col.FRAME_BG] = T.FRAME_BG
    colors[imgui.Col.FRAME_BG_HOVERED] = T.FRAME_HOVER
    colors[imgui.Col.FRAME_BG_ACTIVE] = T.FRAME_ACTIVE
    colors[imgui.Col.TITLE_BG] = T.SURFACE_0
    colors[imgui.Col.TITLE_BG_ACTIVE] = T.SURFACE_1
    colors[imgui.Col.TITLE_BG_COLLAPSED] = T.SURFACE_0
    colors[imgui.Col.MENU_BAR_BG] = T.SURFACE_1

    colors[imgui.Col.BUTTON] = T.BUTTON_BG
    colors[imgui.Col.BUTTON_HOVERED] = T.BUTTON_HOVER
    colors[imgui.Col.BUTTON_ACTIVE] = T.BUTTON_ACTIVE
    colors[imgui.Col.HEADER] = T.SELECTED
    colors[imgui.Col.HEADER_HOVERED] = T.SELECTED_HOVER
    colors[imgui.Col.HEADER_ACTIVE] = T.SELECTED
    colors[imgui.Col.SLIDER_GRAB] = T.SELECTED
    colors[imgui.Col.SLIDER_GRAB_ACTIVE] = T.SELECTED_HOVER
    colors[imgui.Col.CHECK_MARK] = T.SELECTED_HOVER
    colors[imgui.Col.SEPARATOR] = T.BORDER_SOFT
    colors[imgui.Col.RESIZE_GRIP] = (0.0, 0.0, 0.0, 0.0)
    colors[imgui.Col.RESIZE_GRIP_HOVERED] = T.SELECTED_SOFT
    colors[imgui.Col.RESIZE_GRIP_ACTIVE] = T.SELECTED

    if hasattr(imgui.Col, "SCROLLBAR_BG"):
        colors[imgui.Col.SCROLLBAR_BG] = T.SURFACE_0
        colors[imgui.Col.SCROLLBAR_GRAB] = T.SURFACE_3
        colors[imgui.Col.SCROLLBAR_GRAB_HOVERED] = T.SURFACE_HOVER
        colors[imgui.Col.SCROLLBAR_GRAB_ACTIVE] = T.SELECTED_SOFT

    return s, tuple(skipped)
