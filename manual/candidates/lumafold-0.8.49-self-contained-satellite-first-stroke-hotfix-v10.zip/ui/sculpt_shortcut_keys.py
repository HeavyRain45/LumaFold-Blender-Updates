from __future__ import annotations

"""Keyboard mapping helpers for Quick Brush shortcut editing.

Input ownership is intentionally NOT handled here.  Embedded ownership belongs
exclusively to runtime.runtime_core; Satellite Win32 ownership stays in the
native Satellite window procedure.  This module only supplies key translation.
"""

_DIGIT_EVENT_TO_CHAR = {
    "ZERO": "0", "ONE": "1", "TWO": "2", "THREE": "3", "FOUR": "4",
    "FIVE": "5", "SIX": "6", "SEVEN": "7", "EIGHT": "8", "NINE": "9",
}


def _capture_active():
    try:
        from . import sculpt_interactions
        return bool(sculpt_interactions.shortcut_capture_active())
    except Exception:
        return False


def install_embedded(host_module):
    if bool(getattr(host_module, "_lumafold_b4_keybridge_installed", False)):
        return
    host_module._lumafold_b4_keybridge_installed = True
    original_make = host_module.UIHost._make_key_map

    def make_key_map(imgui):
        mapping = dict(original_make(imgui))
        for event_name, ch in _DIGIT_EVENT_TO_CHAR.items():
            mapping[event_name] = getattr(imgui.Key, f"KEY_{ch}")
        return mapping

    host_module.UIHost._make_key_map = staticmethod(make_key_map)


def feed_win32_key(imgui, io, msg: int, wparam: int) -> bool:
    """Feed A-Z / 0-9 / modifiers / Esc from the native Satellite WndProc."""
    WM_KEYDOWN, WM_KEYUP = 0x0100, 0x0101
    WM_SYSKEYDOWN, WM_SYSKEYUP = 0x0104, 0x0105
    down = int(msg) in {WM_KEYDOWN, WM_SYSKEYDOWN}
    if int(msg) not in {WM_KEYDOWN, WM_KEYUP, WM_SYSKEYDOWN, WM_SYSKEYUP}:
        return False

    vk = int(wparam)
    key = None
    if 0x30 <= vk <= 0x39:
        key = getattr(imgui.Key, f"KEY_{chr(vk)}", None)
    elif 0x41 <= vk <= 0x5A:
        key = getattr(imgui.Key, f"KEY_{chr(vk)}", None)
    elif vk == 0x1B:
        key = getattr(imgui.Key, "KEY_ESCAPE", None)
    elif vk == 0x10:
        key = getattr(imgui.Key, "MOD_SHIFT", None)
    elif vk == 0x11:
        key = getattr(imgui.Key, "MOD_CTRL", None)
    elif vk == 0x12:
        key = getattr(imgui.Key, "MOD_ALT", None)
    if key is None:
        return False
    try:
        io.add_key_event(key, bool(down))
        return True
    except Exception:
        return False
