from __future__ import annotations

"""Local Blender widget theming for the small Sculpt controls being validated.

This module is intentionally narrower than the reverted V1.8 semantic adapter.
It never installs persistent slimgui replacements and never changes Host/Input
behavior. Brush/Alpha library draws receive a temporary text/search style, and
the frozen Sculpt foundation receives a temporary wrapper that styles only the
existing ``##quick_rows`` combo plus named compact context menus. Every temporary
callable/style value is restored in ``finally`` before control returns to the
Host.

Important: the public ``sculpt_view.draw_sculpt_compact`` composition must never
be replaced here. It owns preview warming, visual Quick Brush tiles, targeted
Brush Library opening and other product behavior. Styling the foundation is
enough because that public composition calls ``foundation.draw_sculpt_compact``.
"""

from contextlib import contextmanager

from . import theme as T


_INSTALLED = False
_ORIGINAL_BRUSH_DRAW = None
_ORIGINAL_ALPHA_DRAW = None
_ORIGINAL_ALPHA_PRODUCT_DRAW = None
_ORIGINAL_FOUNDATION_SCULPT_DRAW = None

_COMPACT_MENU_POPUPS = frozenset({
    "Quick Brush Slot##context",
    "Brush Asset##library_context",
    "Alpha Asset##library_context",
    "Alpha Add##product_context",
    "Alpha Folder##product_context",
})


def _linear_luminance(value) -> float:
    try:
        r, g, b = (float(value[0]), float(value[1]), float(value[2]))
    except Exception:
        return 0.0
    return max(0.0, 0.2126 * r + 0.7152 * g + 0.0722 * b)


def _contrast_ratio(a, b) -> float:
    la = _linear_luminance(a)
    lb = _linear_luminance(b)
    lighter = max(la, lb)
    darker = min(la, lb)
    return (lighter + 0.05) / (darker + 0.05)


def _readable_text_color(background, preferred=None):
    """Keep the theme foreground when readable, otherwise choose a neutral one."""
    preferred = tuple(preferred or T.TEXT_PRIMARY)
    background = tuple(background)
    if _contrast_ratio(preferred, background) >= 4.0:
        return preferred
    if _linear_luminance(background) < 0.30:
        # Display-space ~#D9D9D9 after Blender's linear framebuffer transform.
        return (0.69, 0.69, 0.69, 1.0)
    return (0.018, 0.018, 0.018, 1.0)


def _search_text_color():
    """Repair only themes whose normal panel text disappears in wcol_text."""
    return _readable_text_color(T.TEXT_INPUT_BG)


def _pulldown_text_color():
    """Use Blender's normal text unless the pulldown fill needs contrast repair."""
    return _readable_text_color(T.PULLDOWN_BG)


@contextmanager
def _text_input_frame_scope(imgui):
    """Temporarily map ImGui FrameBg to Blender's text/search widget family."""
    style = imgui.get_style()
    colors = style.colors
    slots = (
        imgui.Col.FRAME_BG,
        imgui.Col.FRAME_BG_HOVERED,
        imgui.Col.FRAME_BG_ACTIVE,
    )
    previous = tuple(tuple(colors[index]) for index in slots)
    colors[slots[0]] = T.TEXT_INPUT_BG
    colors[slots[1]] = T.TEXT_INPUT_HOVER
    colors[slots[2]] = T.TEXT_INPUT_ACTIVE
    try:
        yield
    finally:
        for index, value in zip(slots, previous):
            colors[index] = value


@contextmanager
def _local_input_text_scope(imgui):
    """Style only input_text calls during one library draw, then restore them."""
    original = getattr(imgui, "input_text", None)
    patched = False
    if callable(original):
        text_color = _search_text_color()

        def themed_input_text(*args, _original=original, **kwargs):
            imgui.push_style_color(imgui.Col.TEXT, text_color)
            try:
                return _original(*args, **kwargs)
            finally:
                imgui.pop_style_color(1)

        try:
            setattr(imgui, "input_text", themed_input_text)
            patched = True
        except Exception:
            patched = False
    try:
        yield
    finally:
        if patched:
            try:
                setattr(imgui, "input_text", original)
            except Exception:
                pass


@contextmanager
def _quick_rows_combo_style(imgui):
    """Blender pulldown control with a popup that mirrors the primary surface."""
    pushed = 0
    text_color = _pulldown_text_color()
    styles = (
        (imgui.Col.FRAME_BG, T.PULLDOWN_BG),
        (imgui.Col.FRAME_BG_HOVERED, T.PULLDOWN_HOVER),
        (imgui.Col.FRAME_BG_ACTIVE, T.PULLDOWN_ACTIVE),
        (imgui.Col.BORDER, T.PULLDOWN_BORDER),
        (imgui.Col.TEXT, text_color),
        # Dropdown contents stay in the same visual family as the primary host:
        # host surface first, regular button rows second.
        (imgui.Col.POPUP_BG, T.SURFACE_0),
        (imgui.Col.HEADER, T.BUTTON_BG),
        (imgui.Col.HEADER_HOVERED, T.BUTTON_HOVER),
        (imgui.Col.HEADER_ACTIVE, T.BUTTON_ACTIVE),
    )
    try:
        for slot, value in styles:
            imgui.push_style_color(slot, value)
            pushed += 1
        yield
    finally:
        if pushed:
            try:
                imgui.pop_style_color(pushed)
            except Exception:
                pass


@contextmanager
def _local_quick_rows_combo_scope(imgui):
    """Intercept only ``##quick_rows`` while the frozen foundation is drawn."""
    original = getattr(imgui, "combo", None)
    patched = False
    if callable(original):
        def themed_combo(label, *args, _original=original, **kwargs):
            if str(label) != "##quick_rows":
                return _original(label, *args, **kwargs)
            with _quick_rows_combo_style(imgui):
                return _original(label, *args, **kwargs)

        try:
            setattr(imgui, "combo", themed_combo)
            patched = True
        except Exception:
            patched = False
    try:
        yield
    finally:
        if patched:
            try:
                setattr(imgui, "combo", original)
            except Exception:
                pass


@contextmanager
def _local_compact_menu_scope(imgui, foundation):
    """Style only named compact popups without touching large secondary panels.

    Context menus intentionally mirror the primary LumaFold visual hierarchy:
    the popup shell uses the same root surface as the main floating workbench,
    and every action row uses the same regular Button family as first-level
    controls. Only the popup's outer edge and a local 1 px row outline express
    that it is a secondary floating layer.

    The wrapper is deliberately installed *outside* sculpt_product_cleanup. That
    layer captures this themed button as its active button, so its injected
    "编辑快捷键" action keeps working while inheriting the same menu semantics.
    """
    original_begin = getattr(imgui, "begin_popup", None)
    original_end = getattr(imgui, "end_popup", None)
    original_button = getattr(foundation, "button", None)
    stack = []
    state = {"menu_depth": 0}
    patched_begin = patched_end = patched_button = False

    def _push_popup_colors():
        pushed = 0
        styles = (
            # Match the primary workbench before adding popup depth. This keeps
            # Dark and Light menus in the same family instead of switching to
            # Blender's much darker wcol_menu_back palette.
            (imgui.Col.POPUP_BG, T.SURFACE_0),
            (imgui.Col.BORDER, T.WINDOW_BORDER),
            (imgui.Col.TEXT, T.TEXT_PRIMARY),
            (imgui.Col.HEADER, T.BUTTON_BG),
            (imgui.Col.HEADER_HOVERED, T.BUTTON_HOVER),
            (imgui.Col.HEADER_ACTIVE, T.BUTTON_ACTIVE),
        )
        for slot, value in styles:
            imgui.push_style_color(slot, value)
            pushed += 1
        return pushed

    if callable(original_begin) and callable(original_end):
        def themed_begin_popup(name, *args, _original=original_begin, **kwargs):
            popup_name = str(name or "")
            target = popup_name in _COMPACT_MENU_POPUPS
            pushed = 0
            if target:
                try:
                    pushed = _push_popup_colors()
                except Exception:
                    if pushed:
                        try:
                            imgui.pop_style_color(pushed)
                        except Exception:
                            pass
                    pushed = 0
            try:
                opened = bool(_original(name, *args, **kwargs))
            except Exception:
                if pushed:
                    try:
                        imgui.pop_style_color(pushed)
                    except Exception:
                        pass
                raise
            if opened:
                stack.append((target, pushed))
                if target:
                    state["menu_depth"] += 1
            elif pushed:
                try:
                    imgui.pop_style_color(pushed)
                except Exception:
                    pass
            return opened

        def themed_end_popup(*args, _original=original_end, **kwargs):
            try:
                return _original(*args, **kwargs)
            finally:
                if stack:
                    target, pushed = stack.pop()
                    if target:
                        state["menu_depth"] = max(0, int(state["menu_depth"]) - 1)
                    if pushed:
                        try:
                            imgui.pop_style_color(pushed)
                        except Exception:
                            pass

        try:
            setattr(imgui, "begin_popup", themed_begin_popup)
            patched_begin = True
            setattr(imgui, "end_popup", themed_end_popup)
            patched_end = True
        except Exception:
            if patched_begin:
                try:
                    setattr(imgui, "begin_popup", original_begin)
                except Exception:
                    pass
                patched_begin = False
            if patched_end:
                try:
                    setattr(imgui, "end_popup", original_end)
                except Exception:
                    pass
                patched_end = False

    if callable(original_button):
        def themed_button(imgui_arg, label, scale=1.0, width=0.0, _original=original_button, **kwargs):
            if int(state.get("menu_depth", 0) or 0) <= 0:
                return _original(imgui_arg, label, scale, width, **kwargs)

            # Do not recolor the action row into a separate menu family. The
            # normal Foundation button already reads BUTTON_BG/HOVER/ACTIVE and
            # BUTTON_BORDER, exactly matching first-level LumaFold controls.
            kwargs = dict(kwargs)
            kwargs["selected"] = False

            # Dark themes intentionally suppress ordinary frame borders globally.
            # Context-menu action rows still need a quiet local 1 px outline so
            # their click targets remain legible; restore the global policy as
            # soon as the row has been drawn.
            style = imgui_arg.get_style()
            previous_frame_border_size = None
            try:
                previous_frame_border_size = float(style.frame_border_size)
                style.frame_border_size = 1.0
            except Exception:
                previous_frame_border_size = None

            imgui_arg.push_style_color(imgui_arg.Col.TEXT, T.TEXT_PRIMARY)
            try:
                return _original(imgui_arg, label, scale, width, **kwargs)
            finally:
                imgui_arg.pop_style_color(1)
                if previous_frame_border_size is not None:
                    try:
                        style.frame_border_size = previous_frame_border_size
                    except Exception:
                        pass

        try:
            setattr(foundation, "button", themed_button)
            patched_button = True
        except Exception:
            patched_button = False

    try:
        yield
    finally:
        # A draw exception must not leak popup colors or temporary callables into
        # the next frame. Normal paths leave the stack empty via end_popup.
        while stack:
            target, pushed = stack.pop()
            if pushed:
                try:
                    imgui.pop_style_color(pushed)
                except Exception:
                    pass
        state["menu_depth"] = 0
        if patched_button:
            try:
                setattr(foundation, "button", original_button)
            except Exception:
                pass
        if patched_end:
            try:
                setattr(imgui, "end_popup", original_end)
            except Exception:
                pass
        if patched_begin:
            try:
                setattr(imgui, "begin_popup", original_begin)
            except Exception:
                pass


def _draw_with_search_theme(imgui, foundation, draw, *args, **kwargs):
    with _text_input_frame_scope(imgui):
        with _local_input_text_scope(imgui):
            with _local_compact_menu_scope(imgui, foundation):
                return draw(imgui, *args, **kwargs)


def _draw_with_quick_rows_theme(imgui, foundation, draw, *args, **kwargs):
    with _local_compact_menu_scope(imgui, foundation):
        with _local_quick_rows_combo_scope(imgui):
            return draw(imgui, *args, **kwargs)


def install(alpha_product, sculpt_view):
    """Install local search, pulldown and named context-menu presentation."""
    global _INSTALLED, _ORIGINAL_BRUSH_DRAW, _ORIGINAL_ALPHA_DRAW
    global _ORIGINAL_ALPHA_PRODUCT_DRAW, _ORIGINAL_FOUNDATION_SCULPT_DRAW
    if _INSTALLED:
        return

    foundation = alpha_product.foundation
    _ORIGINAL_BRUSH_DRAW = foundation.draw_brush_library_foundation
    _ORIGINAL_ALPHA_DRAW = foundation.draw_alpha_library_foundation
    _ORIGINAL_ALPHA_PRODUCT_DRAW = alpha_product.draw_alpha_library_product
    _ORIGINAL_FOUNDATION_SCULPT_DRAW = foundation.draw_sculpt_compact

    def draw_brush_library_text_theme(imgui, *args, **kwargs):
        return _draw_with_search_theme(imgui, foundation, _ORIGINAL_BRUSH_DRAW, *args, **kwargs)

    def draw_alpha_library_text_theme(imgui, *args, **kwargs):
        return _draw_with_search_theme(imgui, foundation, _ORIGINAL_ALPHA_DRAW, *args, **kwargs)

    def draw_foundation_quick_rows_theme(imgui, *args, **kwargs):
        return _draw_with_quick_rows_theme(imgui, foundation, _ORIGINAL_FOUNDATION_SCULPT_DRAW, *args, **kwargs)

    foundation.draw_brush_library_foundation = draw_brush_library_text_theme
    foundation.draw_alpha_library_foundation = draw_alpha_library_text_theme
    sculpt_view.draw_brush_library_foundation = draw_brush_library_text_theme
    sculpt_view.draw_alpha_library_foundation = draw_alpha_library_text_theme
    alpha_product.draw_alpha_library_product = draw_alpha_library_text_theme

    # Do NOT assign sculpt_view.draw_sculpt_compact here. The public Sculpt view
    # owns preview warming, the visual tile renderer, targeted library opening,
    # shortcut editing and cache preparation. It already delegates to this
    # foundation function, so wrapping only the foundation styles compact menus
    # without bypassing any product behavior.
    foundation.draw_sculpt_compact = draw_foundation_quick_rows_theme
    _INSTALLED = True


def uninstall(alpha_product, sculpt_view):
    global _INSTALLED, _ORIGINAL_BRUSH_DRAW, _ORIGINAL_ALPHA_DRAW
    global _ORIGINAL_ALPHA_PRODUCT_DRAW, _ORIGINAL_FOUNDATION_SCULPT_DRAW
    if not _INSTALLED:
        return

    foundation = alpha_product.foundation
    if _ORIGINAL_BRUSH_DRAW is not None:
        foundation.draw_brush_library_foundation = _ORIGINAL_BRUSH_DRAW
        sculpt_view.draw_brush_library_foundation = _ORIGINAL_BRUSH_DRAW
    if _ORIGINAL_ALPHA_DRAW is not None:
        foundation.draw_alpha_library_foundation = _ORIGINAL_ALPHA_DRAW
        sculpt_view.draw_alpha_library_foundation = _ORIGINAL_ALPHA_DRAW
    if _ORIGINAL_ALPHA_PRODUCT_DRAW is not None:
        alpha_product.draw_alpha_library_product = _ORIGINAL_ALPHA_PRODUCT_DRAW
    if _ORIGINAL_FOUNDATION_SCULPT_DRAW is not None:
        foundation.draw_sculpt_compact = _ORIGINAL_FOUNDATION_SCULPT_DRAW

    _ORIGINAL_BRUSH_DRAW = None
    _ORIGINAL_ALPHA_DRAW = None
    _ORIGINAL_ALPHA_PRODUCT_DRAW = None
    _ORIGINAL_FOUNDATION_SCULPT_DRAW = None
    _INSTALLED = False