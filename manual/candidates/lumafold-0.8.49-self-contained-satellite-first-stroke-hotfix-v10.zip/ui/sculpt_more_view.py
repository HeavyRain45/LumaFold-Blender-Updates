from __future__ import annotations

from pathlib import Path
from typing import Callable, MutableMapping, Optional

from .components import button, muted, text
from .design import px
from .layout_system import SECONDARY


_QUICK_ROWS = (2, 3, 4)
_USER_ALPHA_PREFIX = "alpha|lumafold_user|"


def _equal_cells(imgui, scale: float, count: int):
    count = max(1, int(count))
    available = max(1.0, float(imgui.get_content_region_avail()[0]))
    gap = px(SECONDARY.gap_small, scale)
    width = max(px(48.0, scale), (available - gap * (count - 1)) / count)
    return width, gap


def _full_width_design(imgui, scale: float):
    return max(1.0, float(imgui.get_content_region_avail()[0])) / max(0.01, float(scale))


def _user_alpha_summary(sculpt: MutableMapping):
    """Recover the real Blender-returned user root from indexed folder records."""
    folders = [dict(item or {}) for item in list(sculpt.get("alpha_library_folders") or ())]
    assets = [dict(item or {}) for item in list(sculpt.get("alpha_library_assets") or ())]
    user_folders = [item for item in folders if str(item.get("id") or "").startswith(_USER_ALPHA_PREFIX)]
    user_assets = [item for item in assets if str(item.get("folder_id") or "").startswith(_USER_ALPHA_PREFIX)]
    root = ""
    for folder in user_folders:
        raw_path = str(folder.get("path") or "").strip()
        folder_id = str(folder.get("id") or "")
        if not raw_path or not folder_id.startswith(_USER_ALPHA_PREFIX):
            continue
        try:
            path = Path(raw_path)
            suffix = folder_id[len(_USER_ALPHA_PREFIX):]
            if suffix and suffix != "根目录":
                for _part in [part for part in suffix.replace("\\", "/").split("/") if part]:
                    path = path.parent
            root = str(path)
            break
        except Exception:
            continue
    return len(user_assets), len(user_folders), root


def _path_line(imgui, scale: float, root: str):
    if not root:
        muted(imgui, "资源目录：Blender DATAFILES/lumafold/alphas", scale)
        return
    display = root if len(root) <= 42 else ("…" + root[-41:])
    muted(imgui, "资源目录：" + display, scale)
    try:
        if imgui.is_item_hovered():
            imgui.set_tooltip(root)
    except Exception:
        pass


def draw_more_foundation(
    imgui,
    sculpt: MutableMapping,
    scale: float,
    *,
    on_set_quick_rows: Optional[Callable[[int], None]] = None,
    on_reset_quick_slots: Optional[Callable[[], None]] = None,
    on_refresh_brush_library: Optional[Callable[[], None]] = None,
    on_refresh_alpha_library: Optional[Callable[[], None]] = None,
    on_import_alpha_files: Optional[Callable[[], None]] = None,
):
    """Shared S0.8 Sculpt More Secondary Surface.

    The view owns no Blender data. It only exposes existing Sculpt commands and
    reads Core state, so Embedded and Satellite keep one business/UI contract.
    """
    rows = max(2, min(4, int(sculpt.get("quick_rows", 2) or 2)))
    brush_assets = list(sculpt.get("brush_library_assets") or ())
    alpha_assets = list(sculpt.get("alpha_library_assets") or ())
    brush_status = str(sculpt.get("brush_library_status") or "NOT_LOADED")
    alpha_status = str(sculpt.get("alpha_library_status") or "NOT_LOADED")
    user_alpha_count, user_folder_count, user_root = _user_alpha_summary(sculpt)

    text(imgui, "更多 / More", scale, kind="section")
    muted(imgui, "快捷布局与资源维护 · Sculpt Product Pass 2", scale)
    imgui.separator()

    text(imgui, "快捷笔刷 / Quick Brush", scale, kind="body")
    muted(imgui, f"当前：{rows} 行 × 4 列 · 缩行不会删除隐藏槽位", scale)
    cell_w, gap = _equal_cells(imgui, scale, len(_QUICK_ROWS))
    for index, value in enumerate(_QUICK_ROWS):
        if index:
            imgui.same_line(spacing=gap)
        if button(
            imgui,
            f"{value} 行##more_quick_rows_{value}",
            scale,
            cell_w / max(0.01, scale),
            selected=(rows == value),
            kind="body",
            height=SECONDARY.row_h,
        ):
            if on_set_quick_rows is not None:
                on_set_quick_rows(value)

    if button(
        imgui,
        "恢复默认快捷笔刷",
        scale,
        _full_width_design(imgui, scale),
        kind="body",
        height=SECONDARY.row_h,
    ):
        if on_reset_quick_slots is not None:
            on_reset_quick_slots()

    imgui.separator()
    text(imgui, "资源维护 / Resources", scale, kind="body")
    muted(
        imgui,
        f"笔刷：{len(brush_assets)} · {brush_status}    Alpha：{len(alpha_assets)} · {alpha_status}",
        scale,
    )

    cell_w, gap = _equal_cells(imgui, scale, 2)
    if button(
        imgui,
        "重新扫描笔刷 / Rescan",
        scale,
        cell_w / max(0.01, scale),
        kind="body",
        height=SECONDARY.row_h,
    ):
        if on_refresh_brush_library is not None:
            on_refresh_brush_library()
    imgui.same_line(spacing=gap)
    if button(
        imgui,
        "重新扫描 Alpha / Rescan",
        scale,
        cell_w / max(0.01, scale),
        kind="body",
        height=SECONDARY.row_h,
    ):
        if on_refresh_alpha_library is not None:
            on_refresh_alpha_library()

    folder_suffix = f" · {user_folder_count} 个文件夹" if user_folder_count else ""
    muted(imgui, f"LumaFold 用户 Alpha：{user_alpha_count} 个{folder_suffix}", scale)
    if button(
        imgui,
        "导入 Alpha 到用户库…",
        scale,
        _full_width_design(imgui, scale),
        kind="body",
        height=SECONDARY.row_h,
    ):
        if on_import_alpha_files is not None:
            on_import_alpha_files()

    _path_line(imgui, scale, user_root)
    muted(imgui, "雕刻交互逻辑已移到顶部 Z / B 高频切换；UI Scale 后置。", scale)
