"""LumaFold visual tokens — P0.2.3 calibration pass.

All color values in this file are LINEAR RGB because Blender's viewport target
converts shader output to display/sRGB.  P0.2.2 authored the values as if they
were already display-space colors, which made the custom surface much lighter
than Blender's own N-panel.  This pass calibrates the neutral stack against the
actual Blender 5.2.1 screenshot captured on the target machine.

Business modules must not hard-code visual values. Everything visible should
flow through this file or ui.components.
"""

# Neutral stack. Desired displayed values are approximately:
#  Surface0 56, Surface1 63, Surface2 71, Surface3 81, Hover 91 sRGB.
#  The linear values below are what the Blender GPU framebuffer expects.
SURFACE_0 = (0.040, 0.040, 0.042, 0.985)
SURFACE_1 = (0.050, 0.050, 0.052, 1.000)
SURFACE_2 = (0.064, 0.064, 0.067, 1.000)
SURFACE_3 = (0.082, 0.082, 0.086, 1.000)
SURFACE_HOVER = (0.105, 0.108, 0.114, 1.000)

# Secondary surfaces (Embedded popup and Native Satellite secondary host)
# must share exactly one root background layer.
SECONDARY_SURFACE_BG = SURFACE_1

# Typography: slightly softer than pure white so it sits with Blender UI.
TEXT_PRIMARY = (0.715, 0.725, 0.740, 1.000)
TEXT_SECONDARY = (0.365, 0.380, 0.405, 1.000)
TEXT_MUTED = (0.205, 0.215, 0.230, 1.000)

# Blender-like selection blue, authored in linear RGB.
SELECTED = (0.075, 0.255, 0.650, 1.000)
SELECTED_HOVER = (0.105, 0.330, 0.770, 1.000)
SELECTED_SOFT = (0.055, 0.160, 0.330, 1.000)

# Floating-surface edge. Widget-specific edges live below so the Host outline
# can stay readable without forcing the same contrast onto every control.
BORDER = (0.095, 0.100, 0.108, 0.800)
WINDOW_BORDER = BORDER
BORDER_SOFT = (0.073, 0.078, 0.085, 0.600)

# Semantic widget tokens. Before Theme Follow has sampled Blender these aliases
# intentionally collapse to the proven neutral stack. runtime.theme_follow then
# replaces them with the matching Blender wcol_* families.
BUTTON_BG = SURFACE_2
BUTTON_HOVER = SURFACE_HOVER
BUTTON_ACTIVE = SELECTED_SOFT
BUTTON_BORDER = BORDER

TOOL_BG = SURFACE_2
TOOL_HOVER = SURFACE_HOVER
TOOL_ACTIVE = SELECTED_SOFT
TOOL_BORDER = BORDER

FRAME_BG = SURFACE_2
FRAME_HOVER = SURFACE_HOVER
FRAME_ACTIVE = SELECTED_SOFT
FRAME_BORDER = BORDER

# Text/search fields are a separate Blender widget family (wcol_text). They are
# deliberately not aliases of numeric sliders once Theme Follow is active.
TEXT_INPUT_BG = SURFACE_2
TEXT_INPUT_HOVER = SURFACE_HOVER
TEXT_INPUT_ACTIVE = SELECTED_SOFT
TEXT_INPUT_BORDER = BORDER

# Combos / pulldowns use Blender's wcol_pulldown family.
PULLDOWN_BG = SURFACE_2
PULLDOWN_HOVER = SURFACE_HOVER
PULLDOWN_ACTIVE = SELECTED_SOFT
PULLDOWN_BORDER = BORDER

# Compact menus have two distinct Blender semantics: wcol_menu_back owns the
# popup shell, while wcol_menu_item owns rows inside it. Keeping these separate
# is what prevents a context menu from reading as one flat slab.
MENU_BG = SURFACE_0
MENU_BORDER = BORDER
MENU_TEXT = TEXT_PRIMARY
MENU_ITEM_BG = SURFACE_1
MENU_ITEM_HOVER = SURFACE_HOVER
MENU_ITEM_ACTIVE = SELECTED_SOFT
MENU_ITEM_TEXT = TEXT_PRIMARY
MENU_ITEM_TEXT_SELECTED = TEXT_PRIMARY

DANGER = (0.555, 0.070, 0.070, 1.000)
SUCCESS = (0.095, 0.430, 0.145, 1.000)

# Unscaled design units.  Font sizes are applied per component using the
# supported ImGui 1.92 PushFont(None, size) path; we never mutate read-only
# Style.font_size_base from Python.
FONT_SMALL = 11.5
FONT_BODY = 13.5
FONT_VALUE = 13.5
FONT_SECTION = 14.5
FONT_TITLE = 16.0

SPACING_XS = 4.0
SPACING_S = 7.0
SPACING_M = 11.0
SPACING_L = 16.0
SPACING_XL = 22.0

RADIUS_S = 3.0
RADIUS_M = 5.0
RADIUS_L = 6.0

BUTTON_H = 28.0
COMPACT_H = 25.0
TOOLBAR_H = 32.0
THUMB_H = 76.0
HUD_WIDTH = 276.0
