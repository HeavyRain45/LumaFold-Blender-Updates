from __future__ import annotations

"""Process-safe Theme Follow wire contract.

Blender is the only theme authority. The parent process serializes already-derived
LumaFold semantic color tokens; Satellite/Secondary children only validate and
apply those tokens to their local ``ui.theme`` module. No child process imports
``bpy`` or tries to reconstruct Blender theme semantics independently.
"""

import hashlib
import json


WIRE_VERSION = 1

TOKEN_NAMES = (
    "SURFACE_0",
    "SURFACE_1",
    "SURFACE_2",
    "SURFACE_3",
    "SURFACE_HOVER",
    "SECONDARY_SURFACE_BG",
    "TEXT_PRIMARY",
    "TEXT_SECONDARY",
    "TEXT_MUTED",
    "SELECTED",
    "SELECTED_HOVER",
    "SELECTED_SOFT",
    "BORDER",
    "WINDOW_BORDER",
    "BORDER_SOFT",
    "BUTTON_BG",
    "BUTTON_HOVER",
    "BUTTON_ACTIVE",
    "BUTTON_BORDER",
    "TOOL_BG",
    "TOOL_HOVER",
    "TOOL_ACTIVE",
    "TOOL_BORDER",
    "FRAME_BG",
    "FRAME_HOVER",
    "FRAME_ACTIVE",
    "FRAME_BORDER",
    "TEXT_INPUT_BG",
    "TEXT_INPUT_HOVER",
    "TEXT_INPUT_ACTIVE",
    "TEXT_INPUT_BORDER",
    "PULLDOWN_BG",
    "PULLDOWN_HOVER",
    "PULLDOWN_ACTIVE",
    "PULLDOWN_BORDER",
    "MENU_BG",
    "MENU_BORDER",
    "MENU_TEXT",
    "MENU_ITEM_BG",
    "MENU_ITEM_HOVER",
    "MENU_ITEM_ACTIVE",
    "MENU_ITEM_TEXT",
    "MENU_ITEM_TEXT_SELECTED",
)

_LAST_APPLIED_SIGNATURE = ""


def _rgba(value):
    values = tuple(float(v) for v in value)
    if len(values) != 4:
        raise ValueError("Theme wire token must contain exactly four channels")
    return tuple(max(0.0, min(1.0, v)) for v in values)


def _signature(tokens: dict) -> str:
    normalized = {
        name: [round(float(v), 7) for v in tokens[name]]
        for name in TOKEN_NAMES
        if name in tokens
    }
    raw = json.dumps(normalized, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha1(raw).hexdigest()


def build_payload(tokens: dict, *, source: str = "Blender Preferences Theme") -> dict:
    """Serialize semantic tokens into a compact JSON-safe bridge payload."""
    clean = {}
    for name in TOKEN_NAMES:
        if name not in tokens:
            continue
        clean[name] = list(_rgba(tokens[name]))
    if len(clean) != len(TOKEN_NAMES):
        return {}
    return {
        "version": int(WIRE_VERSION),
        "source": str(source),
        "signature": _signature(clean),
        "tokens": clean,
    }


def apply_payload(payload, theme_module) -> tuple[str, bool]:
    """Validate/apply one payload to a process-local ``ui.theme`` module.

    Returns ``(signature, changed)``. Invalid or incomplete payloads are ignored
    atomically so a partial bridge frame can never leave the child half-themed.
    """
    global _LAST_APPLIED_SIGNATURE
    if not isinstance(payload, dict):
        return "", False
    if int(payload.get("version", 0) or 0) != int(WIRE_VERSION):
        return "", False
    raw_tokens = payload.get("tokens")
    if not isinstance(raw_tokens, dict):
        return "", False

    clean = {}
    try:
        for name in TOKEN_NAMES:
            if name not in raw_tokens or not hasattr(theme_module, name):
                return "", False
            clean[name] = _rgba(raw_tokens[name])
    except Exception:
        return "", False

    signature = str(payload.get("signature") or "").strip()
    computed = _signature(clean)
    if not signature or signature != computed:
        return "", False
    if signature == _LAST_APPLIED_SIGNATURE:
        return signature, False

    for name, value in clean.items():
        setattr(theme_module, name, value)
    _LAST_APPLIED_SIGNATURE = signature
    return signature, True


def reset_applied_signature() -> None:
    global _LAST_APPLIED_SIGNATURE
    _LAST_APPLIED_SIGNATURE = ""
