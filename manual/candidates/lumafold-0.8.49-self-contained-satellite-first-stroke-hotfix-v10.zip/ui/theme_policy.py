from __future__ import annotations

"""Host-neutral Theme Follow visual policy.

Colors come from ``ui.theme``. This module owns only the tiny style decisions
that must remain identical in Embedded, Satellite and Secondary hosts: border
thickness and the luminance threshold used by Blender-like Dark/Light stacks.
It deliberately contains no imgui, bpy, Host or input dependencies so CI can
exercise the policy directly.
"""


THEME_FOLLOW_BASELINE = "V2.0"
THEME_FOLLOW_FROZEN = True

LIGHT_NEUTRAL_THRESHOLD = 0.18
WINDOW_BORDER_SIZE = 1.0
CHILD_BORDER_SIZE = 0.0
POPUP_BORDER_SIZE = 1.0
COMPACT_MENU_ROW_BORDER_SIZE = 1.0


def neutral_luminance(value) -> float:
    try:
        r, g, b = (float(value[0]), float(value[1]), float(value[2]))
    except Exception:
        return 0.0
    return max(0.0, 0.2126 * r + 0.7152 * g + 0.0722 * b)


def style_metrics(surface_0) -> dict:
    """Return the shared border contract for one semantic neutral stack."""
    light_neutral_stack = neutral_luminance(surface_0) >= LIGHT_NEUTRAL_THRESHOLD
    return {
        "light_neutral_stack": bool(light_neutral_stack),
        "window_border_size": float(WINDOW_BORDER_SIZE),
        "frame_border_size": 1.0 if light_neutral_stack else 0.0,
        "child_border_size": float(CHILD_BORDER_SIZE),
        "popup_border_size": float(POPUP_BORDER_SIZE),
        "compact_menu_row_border_size": float(COMPACT_MENU_ROW_BORDER_SIZE),
    }


# Semantic state ownership is listed here as a review/CI contract. Components
# still resolve the actual RGBA tuples from ui.theme at draw time.
SELECTED_STATE_TOKENS = {
    "fill": "SELECTED",
    "hover": "SELECTED_HOVER",
    "active": "SELECTED_SOFT",
    "border": "BUTTON_BORDER",
}

ROOT_SURFACE_TOKENS = {
    "primary": "SURFACE_0",
    "secondary": "SECONDARY_SURFACE_BG",
    "popup": "SURFACE_0",
}
