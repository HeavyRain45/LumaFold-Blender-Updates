from __future__ import annotations

from . import sculpt_control_icons as control_icons
from . import sculpt_view_foundation as foundation

_INSTALLED = False


def install():
    global _INSTALLED
    if _INSTALLED:
        return

    def host_switch(imgui, scale: float, host_label: str, on_toggle_host):
        satellite = str(host_label or "").strip() == "卫星"
        glyph = "embedded" if satellite else "satellite"
        tooltip = "返回 Blender 浮台" if satellite else "切换到卫星窗口"
        clicked = control_icons.icon_button(
            imgui, glyph, "host_switch_b4_final", scale,
            box=24.0, glyph=19.0,
            selected=False,
            tooltip=tooltip,
        )
        if clicked and on_toggle_host is not None:
            on_toggle_host()
        return bool(clicked)

    foundation._host_switch_button = host_switch
    _INSTALLED = True
