"""LumaFold product UI layout contract.

S0.6.10 freezes the alignment geometry language used by product surfaces; S0.7.2 reuses it unchanged for Alpha Library.  Business views
must consume these tokens instead of inventing local margins, icon boxes, row
heights or typography sizes.  Host-specific code may place/resize a surface,
but it must not restyle the surface contents.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class SurfaceMetrics:
    outer_padding: float
    gap: float
    gap_small: float
    row_h: float
    icon_glyph: float
    icon_box: float
    divider_gap: float


@dataclass(frozen=True)
class SculptPrimaryMetrics:
    min_content_w: float
    alpha_card_w: float
    current_card_h: float
    current_preview: float
    quick_combo_w: float
    quick_tile_min: float
    bottom_button_min: float
    slider_label_w: float
    grid_gap: float


@dataclass(frozen=True)
class BrushLibraryMetrics:
    width: float
    height: float
    nav_w: float
    split_gap: float
    row_h: float
    toolbar_h: float
    tile: float
    tile_gap: float
    scrollbar_gutter: float
    scrollbar_size: float
    scrollbar_side_gap_min: float
    scrollbar_bottom_gap: float
    meta_h: float
    header_h: float
    footer_bottom_gap: float


@dataclass(frozen=True)
class ContextMenuMetrics:
    width: float
    row_h: float
    gap: float


# Primary product surface: the always-on Sculpt 浮台 / Satellite content.
PRIMARY = SurfaceMetrics(
    outer_padding=12.0,
    gap=6.0,
    gap_small=4.0,
    row_h=28.0,
    icon_glyph=14.0,
    icon_box=24.0,
    divider_gap=8.0,
)

# Secondary product surfaces: Brush/Alpha libraries, settings, etc.  These are
# denser than the primary surface, but retain the same outer padding and icon
# grammar so the relationship is visually obvious.
SECONDARY = SurfaceMetrics(
    outer_padding=12.0,
    gap=6.0,
    gap_small=4.0,
    row_h=24.0,
    icon_glyph=14.0,
    icon_box=24.0,
    divider_gap=8.0,
)

BRUSH_LIBRARY = BrushLibraryMetrics(
    width=462.0,
    height=286.0,
    nav_w=72.0,
    split_gap=12.0,
    row_h=24.0,
    toolbar_h=24.0,
    tile=38.0,
    tile_gap=4.0,
    scrollbar_gutter=14.0,
    scrollbar_size=10.0,
    scrollbar_side_gap_min=12.0,
    scrollbar_bottom_gap=0.0,
    meta_h=18.0,
    header_h=24.0,
    footer_bottom_gap=0.0,
)

CONTEXT_MENU = ContextMenuMetrics(
    width=136.0,
    row_h=22.0,
    gap=4.0,
)

SCULPT_PRIMARY = SculptPrimaryMetrics(
    min_content_w=232.0,
    alpha_card_w=72.0,
    current_card_h=76.0,
    current_preview=64.0,
    quick_combo_w=58.0,
    quick_tile_min=48.0,
    bottom_button_min=84.0,
    slider_label_w=70.0,
    grid_gap=6.0,
)

# Backward-compatible aliases used by existing product code.
PRIMARY_GRID_GAP = SCULPT_PRIMARY.grid_gap
PRIMARY_SLIDER_LABEL_W = SCULPT_PRIMARY.slider_label_w

# Typography contract (mapped to theme font kinds by ui.components):
# - title/major section: "section"
# - normal nav/action:   "body"
# - metadata/tile label: "small"
SECONDARY_TITLE_KIND = "section"
SECONDARY_NAV_KIND = "body"
SECONDARY_META_KIND = "small"
SECONDARY_TILE_KIND = "small"


def centered_group_geometry(container_w: float, desired_group_w: float) -> tuple[float, float, float]:
    """Return (side_space, group_width, opposite_side_space) for a centered toolbar.

    Alignment Contract: toolbar placement is resolved against the *actual* content
    rect, not a nominal column width.  The two remainders are mathematically equal
    so DPI/window padding cannot bias the group to one side.
    """
    container = max(0.0, float(container_w))
    group = min(max(0.0, float(desired_group_w)), container)
    side = max(0.0, (container - group) * 0.5)
    return side, group, side
