from __future__ import annotations

from . import sculpt_interactions as patch
from . import sculpt_view
from . import sculpt_view_foundation as foundation
from .design import px

_INSTALLED = False


def _release_capture_keys(imgui):
    try:
        io = imgui.get_io()
    except Exception:
        return
    for ch in "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ":
        try:
            io.add_key_event(getattr(imgui.Key, f"KEY_{ch}"), False)
        except Exception:
            pass
    for name in ("MOD_CTRL", "MOD_ALT", "MOD_SHIFT", "MOD_SUPER"):
        try:
            io.add_key_event(getattr(imgui.Key, name), False)
        except Exception:
            pass


def _set_active(value: bool):
    patch._SHORTCUT_CAPTURE_ACTIVE = bool(value)


def _draw_prompt(imgui, surface_state, sculpt, scale, on_state_changed):
    popup = "编辑快捷键##quick_shortcut_product"
    if bool(surface_state.pop("_quick_shortcut_editor_open_requested", False)):
        try:
            imgui.open_popup(popup)
        except Exception:
            pass

    try:
        imgui.set_next_window_size((px(218.0, scale), 0.0), imgui.Cond.APPEARING)
    except Exception:
        pass
    if not imgui.begin_popup(popup):
        if patch.shortcut_capture_active():
            _release_capture_keys(imgui)
        _set_active(False)
        surface_state["_quick_shortcut_capture_armed"] = False
        return

    _set_active(True)
    slot = int(surface_state.get("_quick_shortcut_editor_slot", 0) or 0)
    labels = list(sculpt.get("quick_shortcuts") or ())
    current = str(labels[slot] or "未绑定") if 0 <= slot < len(labels) else "未绑定"
    foundation.text(imgui, f"槽位 {slot + 1} · 当前 {current}", scale, kind="small", color=foundation.T.TEXT_SECONDARY)
    foundation.text(imgui, "请直接按新的快捷键", scale, kind="body", color=foundation.T.SELECTED)
    foundation.muted(imgui, "例如 Alt+1 / Ctrl+Q · Esc 取消", scale)

    cancel = False
    try:
        cancel = bool(imgui.is_key_pressed(imgui.Key.KEY_ESCAPE))
    except Exception:
        pass
    if cancel:
        _release_capture_keys(imgui)
        _set_active(False)
        try:
            imgui.close_current_popup()
        except Exception:
            pass
    else:
        key = patch._pressed_main_key(imgui)
        if key:
            sculpt_view._emit_shortcut_request(
                surface_state, sculpt, on_state_changed,
                slot=slot, modifier=patch._modifier_now(imgui), key=key,
            )
            _release_capture_keys(imgui)
            _set_active(False)
            try:
                imgui.close_current_popup()
            except Exception:
                pass
    imgui.end_popup()


def install():
    global _INSTALLED
    if _INSTALLED:
        return
    sculpt_view._draw_shortcut_editor = _draw_prompt
    _INSTALLED = True
