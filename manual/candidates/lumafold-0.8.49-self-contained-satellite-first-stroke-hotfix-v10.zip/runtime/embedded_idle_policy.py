from __future__ import annotations

"""Low-frequency Embedded idle pulse policy.

Mouse/keyboard events already redraw the owning View3D immediately. The modal TIMER
therefore only needs to keep low-frequency context/status synchronization alive.
Keeping both the *pulse work* and Blender's event-timer dispatch at 10 Hz prevents
LumaFold from generating 60 otherwise-useless modal TIMER events every second.

The UI draw handler is still Blender-redraw driven: orbit/sculpt/input redraws stay
immediate and are not limited to 10 Hz. This policy only removes idle/event-loop
pressure from the persistent Embedded modal host.
"""

import time


_INSTALLED = False
_ORIGINAL = None
_ORIGINAL_INVOKE = None
_OPERATORS = None
_IDLE_INTERVAL = 0.10


def install(operators_module) -> None:
    global _INSTALLED, _ORIGINAL, _ORIGINAL_INVOKE, _OPERATORS
    if _INSTALLED:
        return
    original = getattr(operators_module, "_context_pulse", None)
    toggle_cls = getattr(operators_module, "LUMAFOLD_OT_toggle_p0", None)
    original_invoke = getattr(toggle_cls, "invoke", None) if toggle_cls is not None else None
    if not callable(original) or not callable(original_invoke):
        return
    _OPERATORS = operators_module
    _ORIGINAL = original
    _ORIGINAL_INVOKE = original_invoke

    def idle_context_pulse(operator, host, host_id):
        now = time.perf_counter()
        last = float(getattr(operator, "_lumafold_idle_pulse_at", 0.0) or 0.0)
        if now - last < _IDLE_INTERVAL:
            return None
        operator._lumafold_idle_pulse_at = now
        return original(operator, host, host_id)

    def invoke_with_idle_timer(self, context, event):
        result = original_invoke(self, context, event)
        # The authoritative operator historically created a 60 Hz timer while
        # this policy throttled the actual context pulse to 10 Hz. Re-arm that
        # same timer at the policy cadence so Blender no longer dispatches fifty
        # no-op modal TIMER events per second. Normal mouse/key redraws are
        # independent of this timer and remain immediate.
        if "RUNNING_MODAL" in set(result or ()):
            old_timer = getattr(self, "_timer", None)
            if old_timer is not None:
                try:
                    new_timer = context.window_manager.event_timer_add(
                        _IDLE_INTERVAL,
                        window=context.window,
                    )
                except Exception:
                    new_timer = None
                if new_timer is not None:
                    try:
                        context.window_manager.event_timer_remove(old_timer)
                    except Exception:
                        pass
                    self._timer = new_timer
                    self._lumafold_idle_pulse_at = 0.0
        return result

    operators_module._context_pulse = idle_context_pulse
    toggle_cls.invoke = invoke_with_idle_timer
    _INSTALLED = True


def uninstall() -> None:
    global _INSTALLED, _ORIGINAL, _ORIGINAL_INVOKE, _OPERATORS
    if _INSTALLED and _OPERATORS is not None:
        if callable(_ORIGINAL):
            _OPERATORS._context_pulse = _ORIGINAL
        toggle_cls = getattr(_OPERATORS, "LUMAFOLD_OT_toggle_p0", None)
        if toggle_cls is not None and callable(_ORIGINAL_INVOKE):
            toggle_cls.invoke = _ORIGINAL_INVOKE
    _INSTALLED = False
    _ORIGINAL = None
    _ORIGINAL_INVOKE = None
    _OPERATORS = None


def snapshot():
    return {
        "installed": bool(_INSTALLED),
        "idle_interval": float(_IDLE_INTERVAL),
        "modal_timer_hz": round(1.0 / _IDLE_INTERVAL, 3),
    }