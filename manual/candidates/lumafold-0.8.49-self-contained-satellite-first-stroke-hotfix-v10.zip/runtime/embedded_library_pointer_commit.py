from __future__ import annotations

"""Deterministic Embedded Brush Library pointer commit bridge.

Why this exists
---------------
Blender delivers mouse events to the long-lived Embedded modal operator, while
Dear ImGui resolves button clicks during a later draw frame. Real-machine
telemetry in dev45 proved that the Brush popup received LEFTMOUSE PRESS/RELEASE
but no Brush tile produced a click/command. The command and Slot layers were
never reached.

Runtime Core remains the *only* input-ownership authority. This adapter does
not decide capture, popup lifetime, or Blender pass-through. It only latches a
LEFTMOUSE RELEASE that Runtime Core already accepted while the Embedded Brush
Library is open, then resolves that release against the *actual ImGui item rect*
on the next draw frame.

Important regression guard
--------------------------
The fallback is valid only for releases inside the actual Brush popup window.
dev46 latched every release while the popup snapshot was open; that repaired
Brush tile activation but could interfere with Dear ImGui's native outside-click
dismissal. The popup's real ImGui window rect is sampled during draw and used
only to decide whether this fallback may exist. Outside clicks remain owned by
Runtime Core + Dear ImGui and never become synthetic Brush commits.
"""

from ..core.runtime_session import RUNTIME_SESSION


_POPUP_NAME = "LumaFold Brush Library##foundation"
_COMMIT_KEY = "_embedded_brush_pointer_commit"
_CONSUMED_KEY = "_embedded_brush_pointer_commit_consumed"
_SERIAL_KEY = "_embedded_brush_pointer_commit_serial"
_POPUP_RECT_KEY = "_embedded_brush_popup_actual_rect"

_INSTALLED = False
_HOST_CLASS = None
_FOUNDATION = None
_ORIGINAL_FEED = None
_ORIGINAL_DRAW_LIBRARY = None


def _event_local(event, region):
    if region is None:
        return None
    try:
        rx = float(event.mouse_x - region.x)
        ry = float(event.mouse_y - region.y)
        return (rx, float(region.height - 1) - ry)
    except Exception:
        return None


def _rect_contains(rect, point) -> bool:
    if not isinstance(rect, dict) or point is None:
        return False
    try:
        x, y = float(point[0]), float(point[1])
        return bool(
            float(rect["left"]) <= x < float(rect["right"])
            and float(rect["top"]) <= y < float(rect["bottom"])
        )
    except Exception:
        return False


def _publish_popup_rect(imgui, ui) -> None:
    if not isinstance(ui, dict):
        return
    try:
        pos = imgui.get_window_pos()
        size = imgui.get_window_size()
        left = float(pos[0])
        top = float(pos[1])
        width = max(0.0, float(size[0]))
        height = max(0.0, float(size[1]))
        ui[_POPUP_RECT_KEY] = {
            "left": left,
            "top": top,
            "right": left + width,
            "bottom": top + height,
        }
    except Exception:
        # No guessed geometry. If the actual ImGui rect cannot be sampled, the
        # fallback simply stays disabled for that frame; normal ImGui input is
        # still authoritative.
        ui.pop(_POPUP_RECT_KEY, None)


def _commit_pending(ui):
    raw = dict((ui or {}).get(_COMMIT_KEY) or {})
    try:
        serial = int(raw.get("serial", 0) or 0)
        consumed = int((ui or {}).get(_CONSUMED_KEY, 0) or 0)
    except Exception:
        return None
    if serial <= 0 or serial <= consumed:
        return None
    if str(raw.get("button") or "") != "LEFT":
        return None
    try:
        raw["x"] = float(raw["x"])
        raw["y"] = float(raw["y"])
    except Exception:
        return None
    raw["serial"] = serial
    return raw


def _item_contains(imgui, commit) -> bool:
    if not commit:
        return False
    try:
        rmin = imgui.get_item_rect_min()
        rmax = imgui.get_item_rect_max()
        x = float(commit["x"])
        y = float(commit["y"])
        return bool(
            float(rmin[0]) <= x < float(rmax[0])
            and float(rmin[1]) <= y < float(rmax[1])
        )
    except Exception:
        return False


def install(host_class, foundation_module) -> None:
    global _INSTALLED, _HOST_CLASS, _FOUNDATION, _ORIGINAL_FEED, _ORIGINAL_DRAW_LIBRARY
    if _INSTALLED:
        return

    original_feed = getattr(host_class, "feed_event", None)
    original_draw = getattr(foundation_module, "draw_brush_library_foundation", None)
    if not callable(original_feed) or not callable(original_draw):
        raise RuntimeError("Embedded Brush pointer commit dependencies are incomplete")

    _HOST_CLASS = host_class
    _FOUNDATION = foundation_module
    _ORIGINAL_FEED = original_feed
    _ORIGINAL_DRAW_LIBRARY = original_draw

    def feed_with_brush_commit(self, event, *, region=None):
        result = original_feed(self, event, region=region)
        try:
            if str(getattr(event, "type", "") or "") != "LEFTMOUSE":
                return result
            if str(getattr(event, "value", "") or "").upper() != "RELEASE":
                return result
            if not RUNTIME_SESSION.popup_named("embedded", _POPUP_NAME):
                return result
            if region is None:
                region = self._window_region()
            local = _event_local(event, region)
            if local is None:
                return result
            state = getattr(self, "state", None)
            if not isinstance(state, dict):
                return result

            # Critical dev47 rule: an outside release belongs exclusively to
            # Dear ImGui's popup dismissal. Never turn it into a Brush fallback.
            if not _rect_contains(state.get(_POPUP_RECT_KEY), local):
                return result

            serial = int(state.get(_SERIAL_KEY, 0) or 0) + 1
            state[_SERIAL_KEY] = serial
            state[_COMMIT_KEY] = {
                "serial": serial,
                "button": "LEFT",
                "x": float(local[0]),
                "y": float(local[1]),
            }
        except Exception:
            # This adapter is never allowed to destabilize the established input
            # route. The normal ImGui event path remains authoritative first.
            pass
        return result

    def draw_library_with_commit(
        imgui,
        sculpt,
        scale,
        *,
        library_ui_state=None,
        on_refresh_library=None,
        on_activate_asset=None,
        on_toggle_favorite=None,
        on_assign_asset_to_slot=None,
        on_request_preview=None,
        resolve_preview_texture=None,
    ):
        ui = library_ui_state if library_ui_state is not None else {}
        # We are called from inside begin_popup(), so this is the real displayed
        # popup rect after ImGui's DPI/clamping/placement decisions.
        _publish_popup_rect(imgui, ui)
        commit = _commit_pending(ui)
        hit = {"value": False, "item": ""}

        original_square = foundation_module.square_button
        original_image = foundation_module.image_square_button

        def square_with_commit(imgui_arg, label, *args, **kwargs):
            clicked = bool(original_square(imgui_arg, label, *args, **kwargs))
            label_text = str(label or "")
            if (
                commit is not None
                and not hit["value"]
                and "##library_asset_" in label_text
                and _item_contains(imgui_arg, commit)
            ):
                hit["value"] = True
                hit["item"] = label_text
                return True
            return clicked

        def image_with_commit(imgui_arg, ident, *args, **kwargs):
            clicked = bool(original_image(imgui_arg, ident, *args, **kwargs))
            ident_text = str(ident or "")
            if (
                commit is not None
                and not hit["value"]
                and ident_text.startswith("library_asset_")
                and _item_contains(imgui_arg, commit)
            ):
                hit["value"] = True
                hit["item"] = ident_text
                return True
            return clicked

        foundation_module.square_button = square_with_commit
        foundation_module.image_square_button = image_with_commit
        try:
            return original_draw(
                imgui,
                sculpt,
                scale,
                library_ui_state=ui,
                on_refresh_library=on_refresh_library,
                on_activate_asset=on_activate_asset,
                on_toggle_favorite=on_toggle_favorite,
                on_assign_asset_to_slot=on_assign_asset_to_slot,
                on_request_preview=on_request_preview,
                resolve_preview_texture=resolve_preview_texture,
            )
        finally:
            foundation_module.square_button = original_square
            foundation_module.image_square_button = original_image
            if commit is not None:
                ui[_CONSUMED_KEY] = int(commit["serial"])
                ui["_embedded_brush_pointer_commit_hit"] = {
                    "serial": int(commit["serial"]),
                    "hit": bool(hit["value"]),
                    "item": str(hit["item"]),
                }

    host_class.feed_event = feed_with_brush_commit
    foundation_module.draw_brush_library_foundation = draw_library_with_commit
    _INSTALLED = True


def uninstall() -> None:
    global _INSTALLED, _HOST_CLASS, _FOUNDATION, _ORIGINAL_FEED, _ORIGINAL_DRAW_LIBRARY
    if not _INSTALLED:
        return
    if _HOST_CLASS is not None and callable(_ORIGINAL_FEED):
        _HOST_CLASS.feed_event = _ORIGINAL_FEED
    if _FOUNDATION is not None and callable(_ORIGINAL_DRAW_LIBRARY):
        _FOUNDATION.draw_brush_library_foundation = _ORIGINAL_DRAW_LIBRARY
    _HOST_CLASS = None
    _FOUNDATION = None
    _ORIGINAL_FEED = None
    _ORIGINAL_DRAW_LIBRARY = None
    _INSTALLED = False
