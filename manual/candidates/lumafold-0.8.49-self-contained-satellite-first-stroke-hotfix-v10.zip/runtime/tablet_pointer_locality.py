from __future__ import annotations

"""Read-only Windows tablet/multi-monitor pointer locality diagnostics.

This module never warps, clips, captures, or remaps the system pointer. It only
records Windows cursor/monitor truth beside Blender tablet event coordinates so
real-machine reports can distinguish a stale Blender brush cursor from genuine
cross-monitor event delivery.
"""

import ctypes
from ctypes import wintypes
import os
import time


_LAST_TRACE_AT = 0.0
_TRACE_INTERVAL = 0.12


class POINT(ctypes.Structure):
    _fields_ = [("x", wintypes.LONG), ("y", wintypes.LONG)]


def _win32_pointer_state():
    try:
        user32 = ctypes.WinDLL("user32", use_last_error=True)
        user32.GetCursorPos.argtypes = [ctypes.POINTER(POINT)]
        user32.GetCursorPos.restype = wintypes.BOOL
        user32.WindowFromPoint.argtypes = [POINT]
        user32.WindowFromPoint.restype = wintypes.HWND
        user32.MonitorFromPoint.argtypes = [POINT, wintypes.DWORD]
        user32.MonitorFromPoint.restype = wintypes.HANDLE
        user32.GetForegroundWindow.restype = wintypes.HWND
        user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
        user32.GetWindowThreadProcessId.restype = wintypes.DWORD
        user32.MonitorFromWindow.argtypes = [wintypes.HWND, wintypes.DWORD]
        user32.MonitorFromWindow.restype = wintypes.HANDLE

        point = POINT()
        if not user32.GetCursorPos(ctypes.byref(point)):
            return {"cursor_error": int(ctypes.get_last_error() or 0)}

        foreground = int(user32.GetForegroundWindow() or 0)
        foreground_pid = wintypes.DWORD(0)
        if foreground:
            user32.GetWindowThreadProcessId(wintypes.HWND(foreground), ctypes.byref(foreground_pid))
        cursor_monitor = int(user32.MonitorFromPoint(point, 0x00000002) or 0)
        foreground_monitor = int(
            user32.MonitorFromWindow(wintypes.HWND(foreground), 0x00000002) or 0
        ) if foreground else 0
        process_id = int(os.getpid())
        blender_foreground = bool(foreground and int(foreground_pid.value) == process_id)

        return {
            "cursor_x": int(point.x),
            "cursor_y": int(point.y),
            "window_under_cursor": int(user32.WindowFromPoint(point) or 0),
            "monitor_under_cursor": cursor_monitor,
            "foreground_hwnd": foreground,
            "foreground_pid": int(foreground_pid.value),
            "process_pid": process_id,
            "foreground_monitor": foreground_monitor,
            "blender_foreground": blender_foreground,
            "cursor_foreground_monitor_mismatch": bool(
                blender_foreground
                and cursor_monitor
                and foreground_monitor
                and cursor_monitor != foreground_monitor
            ),
        }
    except Exception as exc:
        return {"win32_error": f"{type(exc).__name__}: {exc}"}


def observe(context, event, real_machine_trace=None):
    global _LAST_TRACE_AT
    if real_machine_trace is None:
        return
    try:
        if not bool(getattr(event, "is_tablet", False)):
            return
    except Exception:
        return

    event_type = str(getattr(event, "type", "") or "").upper()
    event_value = str(getattr(event, "value", "") or "").upper()
    now = time.monotonic()
    edge = event_type in {"LEFTMOUSE", "RIGHTMOUSE"} and event_value in {"PRESS", "RELEASE"}
    motion = event_type in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}
    if not edge and not motion:
        return
    if motion and now - _LAST_TRACE_AT < _TRACE_INTERVAL:
        return
    _LAST_TRACE_AT = now

    payload = {
        "event": event_type,
        "value": event_value,
        "pressure": float(getattr(event, "pressure", 0.0) or 0.0),
        "blender_mouse_x": int(getattr(event, "mouse_x", 0) or 0),
        "blender_mouse_y": int(getattr(event, "mouse_y", 0) or 0),
        "blender_region_x": int(getattr(event, "mouse_region_x", 0) or 0),
        "blender_region_y": int(getattr(event, "mouse_region_y", 0) or 0),
        "window_ptr": 0,
        "area_type": str(getattr(getattr(context, "area", None), "type", "") or ""),
        "region_type": str(getattr(getattr(context, "region", None), "type", "") or ""),
        "tablet_api": "",
    }
    try:
        window = getattr(context, "window", None)
        payload["window_ptr"] = int(window.as_pointer()) if window is not None else 0
    except Exception:
        pass
    try:
        payload["tablet_api"] = str(getattr(context.preferences.inputs, "tablet_api", "") or "")
    except Exception:
        pass

    payload.update(_win32_pointer_state())

    if "cursor_x" in payload:
        payload["event_cursor_dx"] = int(payload["blender_mouse_x"] - payload["cursor_x"])
        payload["event_cursor_dy"] = int(payload["blender_mouse_y"] - payload["cursor_y"])

    try:
        real_machine_trace.trace("TABLET_POINTER_LOCALITY", **payload)
    except Exception:
        pass
