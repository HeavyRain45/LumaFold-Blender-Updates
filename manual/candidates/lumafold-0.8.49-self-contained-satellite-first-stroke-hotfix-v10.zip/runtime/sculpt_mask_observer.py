from __future__ import annotations

"""Post-native Mask completion observer.

Blender owns the live Box/Lasso/Line/Polyline modal gesture. LumaFold never
runs a second modal operator beside it. This module only watches Blender's
registered operator history after the native gesture finishes, reads the
geometry Blender already stored on that operator, and conservatively decides
whether the finished gesture could have affected the active sculpt object.

The observer never mutates Mask data, tool state, keymaps, Theme or
Preferences. If classification is uncertain it reports "may affect" so the
caller will not clear the mask by mistake.
"""

import time

import bpy
from bpy_extras import view3d_utils
from mathutils import Vector


BOX_TOOL_ID = "builtin.box_mask"
LASSO_TOOL_ID = "builtin.lasso_mask"
LINE_TOOL_ID = "builtin.line_mask"
POLYLINE_TOOL_ID = "builtin.polyline_mask"

_TOOL_TO_BL_IDNAME = {
    BOX_TOOL_ID: "PAINT_OT_mask_box_gesture",
    LASSO_TOOL_ID: "PAINT_OT_mask_lasso_gesture",
    LINE_TOOL_ID: "PAINT_OT_mask_line_gesture",
    POLYLINE_TOOL_ID: "PAINT_OT_mask_polyline_gesture",
}

_POLL_INTERVAL = 0.025
_WATCH_TIMEOUT = 30.0
_INSTALLED = False
_TRACE = None
_GENERATION = 0
_WATCHERS = set()


def _trace(reason: str, **extra) -> None:
    if _TRACE is None:
        return
    try:
        payload = {"reason": str(reason)}
        payload.update(extra)
        _TRACE.trace("ZBRUSH_MASK_POST_NATIVE", **payload)
    except Exception:
        pass


def _ptr(value) -> int:
    try:
        return int(value.as_pointer())
    except Exception:
        return 0


def _view3d_target(context):
    window = getattr(context, "window", None)
    area = getattr(context, "area", None)
    region = getattr(context, "region", None)
    if (
        window is None
        or area is None
        or region is None
        or getattr(area, "type", "") != "VIEW_3D"
        or getattr(region, "type", "") != "WINDOW"
    ):
        return None
    return window, area, region


def _active_sculpt_mesh(context):
    obj = getattr(context, "sculpt_object", None)
    if obj is None:
        objects = getattr(getattr(context, "view_layer", None), "objects", None)
        obj = getattr(objects, "active", None) if objects is not None else None
    if obj is None or getattr(obj, "type", "") != "MESH":
        return None
    return obj


def _projected_bounds(context, obj):
    """Conservative 2D bounds of the evaluated object in region coordinates."""
    if obj is None:
        return None
    region = getattr(context, "region", None)
    rv3d = getattr(context, "region_data", None)
    if region is None or rv3d is None:
        return None

    try:
        depsgraph = context.evaluated_depsgraph_get()
        eval_obj = obj.evaluated_get(depsgraph)
    except Exception:
        eval_obj = obj

    points = []
    try:
        matrix = eval_obj.matrix_world
        corners = tuple(getattr(eval_obj, "bound_box", ()) or ())
        if not corners:
            corners = tuple(getattr(obj, "bound_box", ()) or ())
            matrix = obj.matrix_world
        for corner in corners:
            point = view3d_utils.location_3d_to_region_2d(
                region, rv3d, matrix @ Vector(corner)
            )
            if point is not None:
                points.append((float(point.x), float(point.y)))
    except Exception:
        return None

    if not points:
        return None
    return (
        min(point[0] for point in points),
        min(point[1] for point in points),
        max(point[0] for point in points),
        max(point[1] for point in points),
    )


def _point_in_rect(point, rect) -> bool:
    x, y = point
    xmin, ymin, xmax, ymax = rect
    return xmin <= x <= xmax and ymin <= y <= ymax


def _rects_overlap(a, b) -> bool:
    ax0, ay0, ax1, ay1 = a
    bx0, by0, bx1, by1 = b
    return not (ax1 < bx0 or ax0 > bx1 or ay1 < by0 or ay0 > by1)


def _orientation(a, b, c) -> float:
    return (float(b[0]) - float(a[0])) * (float(c[1]) - float(a[1])) - (
        float(b[1]) - float(a[1])
    ) * (float(c[0]) - float(a[0]))


def _on_segment(a, b, point) -> bool:
    return bool(
        min(a[0], b[0]) - 1.0e-6 <= point[0] <= max(a[0], b[0]) + 1.0e-6
        and min(a[1], b[1]) - 1.0e-6 <= point[1] <= max(a[1], b[1]) + 1.0e-6
        and abs(_orientation(a, b, point)) <= 1.0e-6
    )


def _segments_intersect(a, b, c, d) -> bool:
    o1 = _orientation(a, b, c)
    o2 = _orientation(a, b, d)
    o3 = _orientation(c, d, a)
    o4 = _orientation(c, d, b)
    if (o1 > 0.0 > o2 or o2 > 0.0 > o1) and (o3 > 0.0 > o4 or o4 > 0.0 > o3):
        return True
    return bool(
        _on_segment(a, b, c)
        or _on_segment(a, b, d)
        or _on_segment(c, d, a)
        or _on_segment(c, d, b)
    )


def _rect_corners(rect):
    xmin, ymin, xmax, ymax = rect
    return (
        (xmin, ymin),
        (xmax, ymin),
        (xmax, ymax),
        (xmin, ymax),
    )


def _segment_intersects_rect(a, b, rect) -> bool:
    if _point_in_rect(a, rect) or _point_in_rect(b, rect):
        return True
    corners = _rect_corners(rect)
    edges = tuple(zip(corners, corners[1:] + corners[:1]))
    return any(_segments_intersect(a, b, c, d) for c, d in edges)


def _point_in_polygon(point, polygon) -> bool:
    if len(polygon) < 3:
        return False
    x, y = point
    inside = False
    previous = polygon[-1]
    for current in polygon:
        x1, y1 = float(current[0]), float(current[1])
        x0, y0 = float(previous[0]), float(previous[1])
        if ((y1 > y) != (y0 > y)) and (
            x < (x0 - x1) * (y - y1) / ((y0 - y1) or 1.0e-12) + x1
        ):
            inside = not inside
        previous = current
    return inside


def _polygon_intersects_rect(polygon, rect) -> bool:
    if len(polygon) < 3:
        return False
    corners = _rect_corners(rect)
    if any(_point_in_polygon(corner, polygon) for corner in corners):
        return True
    if any(_point_in_rect(point, rect) for point in polygon):
        return True
    closed = tuple(polygon) + (polygon[0],)
    return any(
        _segment_intersects_rect(closed[index], closed[index + 1], rect)
        for index in range(len(polygon))
    )


def _path_points(props):
    try:
        points = []
        for item in props.path:
            loc = item.loc
            points.append((float(loc[0]), float(loc[1])))
        return points
    except Exception:
        return None


def _geometry_ready(tool_id: str, props) -> bool:
    try:
        if tool_id == BOX_TOOL_ID:
            return int(props.xmin) != int(props.xmax) and int(props.ymin) != int(props.ymax)
        if tool_id == LINE_TOOL_ID:
            return (int(props.xstart), int(props.ystart)) != (
                int(props.xend),
                int(props.yend),
            )
        if tool_id in {LASSO_TOOL_ID, POLYLINE_TOOL_ID}:
            points = _path_points(props)
            return bool(points is not None and len(points) >= 3)
    except Exception:
        return False
    return False


def _line_may_affect_rect(context, props, rect) -> bool:
    """Conservative screen-space equivalent of Blender's line gesture volume."""
    try:
        start = (float(props.xstart), float(props.ystart))
        end = (float(props.xend), float(props.yend))
        flip = bool(props.flip)
        use_limit = bool(props.use_limit_to_segment)
    except Exception:
        return True

    dx = end[0] - start[0]
    dy = end[1] - start[1]
    length_sq = dx * dx + dy * dy
    if length_sq <= 1.0e-8:
        return True

    rv3d = getattr(context, "region_data", None)
    try:
        is_perspective = bool(rv3d.is_perspective)
    except Exception:
        return True

    # sculpt_gesture.cc flips the line plane for orthographic views.
    effective_flip = bool(flip) ^ (not is_perspective)
    corners = _rect_corners(rect)

    def side(point):
        return dx * (point[1] - start[1]) - dy * (point[0] - start[0])

    def affected(value):
        epsilon = 1.0e-5
        return value <= epsilon if effective_flip else value >= -epsilon

    side_values = [side(point) for point in corners]
    if not use_limit:
        return any(affected(value) for value in side_values)

    projections = [
        ((point[0] - start[0]) * dx + (point[1] - start[1]) * dy) / length_sq
        for point in corners
    ]
    if max(projections) < 0.0 or min(projections) > 1.0:
        return False
    if _segment_intersects_rect(start, end, rect):
        return True
    return any(affected(value) for value in side_values)


def _surface_hit_xy(context, obj, x: float, y: float):
    """Return True/False for a real surface ray hit; None when classification is uncertain."""
    if obj is None:
        return None
    region = getattr(context, "region", None)
    rv3d = getattr(context, "region_data", None)
    scene = getattr(context, "scene", None)
    if region is None or rv3d is None:
        return None

    try:
        origin = view3d_utils.region_2d_to_origin_3d(
            region, rv3d, (float(x), float(y))
        )
        direction = view3d_utils.region_2d_to_vector_3d(
            region, rv3d, (float(x), float(y))
        )
        depsgraph = context.evaluated_depsgraph_get()

        if scene is not None:
            hit, _loc, _normal, _index, hit_obj, _matrix = scene.ray_cast(
                depsgraph, origin, direction
            )
            if hit and hit_obj is not None:
                original = getattr(hit_obj, "original", hit_obj)
                obj_original = getattr(obj, "original", obj)
                if hit_obj == obj or original == obj or hit_obj == obj_original or original == obj_original:
                    return True

        eval_obj = obj.evaluated_get(depsgraph)
        inv = eval_obj.matrix_world.inverted_safe()
        hit, _loc, _normal, _index = eval_obj.ray_cast(
            inv @ origin,
            inv.to_3x3() @ direction,
        )
        return bool(hit)
    except Exception:
        return None


def _box_may_affect_object(context, obj, rect, bounds) -> bool:
    """Use real surface hits when a Box overlaps only the projected object bounds."""
    if not _rects_overlap(rect, bounds):
        return False

    rx0, ry0, rx1, ry1 = rect
    bx0, by0, bx1, by1 = bounds
    intersection = (
        max(min(rx0, rx1), min(bx0, bx1)),
        max(min(ry0, ry1), min(by0, by1)),
        min(max(rx0, rx1), max(bx0, bx1)),
        min(max(ry0, ry1), max(by0, by1)),
    )
    ix0, iy0, ix1, iy1 = intersection
    if ix1 < ix0 or iy1 < iy0:
        return False

    # This is intentionally the same narrow real-surface strategy as the
    # accepted 2026-09-16 reliability fix: dense enough for ordinary tablet
    # Box gestures while remaining cheap and read-only.
    steps = 9
    for iy in range(steps):
        y = iy0 if steps <= 1 else iy0 + (iy1 - iy0) * (iy / float(steps - 1))
        for ix in range(steps):
            x = ix0 if steps <= 1 else ix0 + (ix1 - ix0) * (ix / float(steps - 1))
            hit = _surface_hit_xy(context, obj, x, y)
            if hit is None:
                # Classification uncertainty must never erase the user's mask.
                return True
            if hit:
                return True
    return False


def _shape_may_affect_object(context, obj, tool_id: str, props) -> bool:
    bounds = _projected_bounds(context, obj)
    if bounds is None:
        return True

    if tool_id == BOX_TOOL_ID:
        try:
            rect = (
                float(props.xmin),
                float(props.ymin),
                float(props.xmax),
                float(props.ymax),
            )
        except Exception:
            return True
        return _box_may_affect_object(context, obj, rect, bounds)

    if tool_id in {LASSO_TOOL_ID, POLYLINE_TOOL_ID}:
        points = _path_points(props)
        if points is None or len(points) < 3:
            return True
        return _polygon_intersects_rect(points, bounds)

    if tool_id == LINE_TOOL_ID:
        return _line_may_affect_rect(context, props, bounds)

    return True


class _WatchState:
    __slots__ = (
        "tool_id",
        "expected_bl_idname",
        "wm",
        "window",
        "area",
        "region",
        "obj",
        "before_ops",
        "deadline",
        "callback",
        "generation",
        "timer",
        "active",
    )

    def __init__(self, context, tool_id: str, callback):
        target = _view3d_target(context)
        if target is None:
            raise RuntimeError("VIEW_3D target unavailable")
        self.tool_id = str(tool_id)
        self.expected_bl_idname = _TOOL_TO_BL_IDNAME[self.tool_id]
        self.wm = context.window_manager
        self.window, self.area, self.region = target
        self.obj = _active_sculpt_mesh(context)
        self.before_ops = frozenset(_ptr(op) for op in tuple(self.wm.operators))
        self.deadline = time.monotonic() + _WATCH_TIMEOUT
        self.callback = callback
        self.generation = int(_GENERATION)
        self.timer = None
        self.active = True


def _finish_state(state: _WatchState) -> None:
    state.active = False
    timer = state.timer
    if timer is not None:
        try:
            if bpy.app.timers.is_registered(timer):
                bpy.app.timers.unregister(timer)
        except Exception:
            pass
    _WATCHERS.discard(state)


def _find_completed_operator(state: _WatchState):
    try:
        operators = tuple(state.wm.operators)
    except Exception:
        return None
    for operator in reversed(operators):
        pointer = _ptr(operator)
        if pointer in state.before_ops:
            continue
        try:
            if str(operator.bl_idname) != state.expected_bl_idname:
                continue
            props = operator.properties
        except Exception:
            continue
        if not _geometry_ready(state.tool_id, props):
            continue
        return operator
    return None


def _poll_state(state: _WatchState):
    if (
        not _INSTALLED
        or not state.active
        or state.generation != int(_GENERATION)
        or time.monotonic() >= state.deadline
    ):
        _trace("post_native_watch_expired", tool=state.tool_id)
        _finish_state(state)
        return None

    operator = _find_completed_operator(state)
    if operator is None:
        return _POLL_INTERVAL

    try:
        with bpy.context.temp_override(
            window=state.window,
            area=state.area,
            region=state.region,
        ):
            may_affect = _shape_may_affect_object(
                bpy.context,
                state.obj,
                state.tool_id,
                operator.properties,
            )
    except Exception:
        may_affect = True

    should_clear = not bool(may_affect)
    _trace(
        "post_native_classified",
        tool=state.tool_id,
        operator=str(getattr(operator, "bl_idname", "") or ""),
        should_clear=bool(should_clear),
    )

    callback = state.callback
    _finish_state(state)
    if callable(callback):
        try:
            callback(bool(should_clear))
        except Exception:
            pass
    return None


def arm(context, tool_id: str, callback):
    """Watch one Blender-native gesture completion without owning its events."""
    tool_id = str(tool_id or "")
    if not _INSTALLED or tool_id not in _TOOL_TO_BL_IDNAME:
        return None
    try:
        state = _WatchState(context, tool_id, callback)
    except Exception:
        return None

    def timer():
        return _poll_state(state)

    state.timer = timer
    _WATCHERS.add(state)
    try:
        bpy.app.timers.register(timer, first_interval=_POLL_INTERVAL, persistent=False)
    except Exception:
        _WATCHERS.discard(state)
        state.active = False
        return None

    _trace(
        "post_native_watch_started",
        tool=tool_id,
        expected_operator=state.expected_bl_idname,
    )
    return state


def cancel(state) -> None:
    if state is None:
        return
    try:
        _finish_state(state)
    except Exception:
        pass


def install(real_machine_trace=None) -> None:
    global _INSTALLED, _TRACE, _GENERATION
    if _INSTALLED:
        return
    _GENERATION += 1
    _TRACE = real_machine_trace
    _INSTALLED = True


def uninstall() -> None:
    global _INSTALLED, _TRACE, _GENERATION
    _GENERATION += 1
    _INSTALLED = False
    for state in tuple(_WATCHERS):
        _finish_state(state)
    _WATCHERS.clear()
    _TRACE = None
