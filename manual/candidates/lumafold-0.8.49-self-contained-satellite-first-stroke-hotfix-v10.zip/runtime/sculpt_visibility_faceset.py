from __future__ import annotations

"""ZBrush-style visibility and Face Set gestures for Sculpt Mode.

Product contract:
- Ctrl+Shift + pen/mouse drag: SelectRect-style isolate. Only geometry
  inside the rectangle remains visible.
- Ctrl+Shift+Alt + drag, or pressing Alt during the drag: inverse gesture.
  Geometry inside the rectangle is hidden.
- Ctrl+Shift click on empty canvas: reveal all hidden sculpt geometry.
- Ctrl+Shift+Alt click on empty canvas: same reveal-all behavior as ZBrush.
- Ctrl+Shift background drag reverses visible/hidden geometry only when the
  Sculpt mesh is already partially hidden. On a fully visible mesh the marquee
  may be previewed, but releasing it is intentionally a no-op. Ctrl+Shift+Alt
  follows the same background rule.
- Ctrl+Shift click a visible Face Set: use Blender's native Face Set visibility
  toggle to isolate that group; clicking again while geometry is hidden shows all.
- Ctrl+W: when a meaningful Sculpt mask exists, create a Face Set from the mask
  and clear the mask; otherwise keep the existing Group Visible behavior.

The actual mesh mutations stay Blender-native:
``bpy.ops.paint.hide_show`` / ``hide_show_all`` / ``visibility_invert`` own
general visibility; ``bpy.ops.sculpt.face_set_change_visibility`` owns Face Set
isolation; ``bpy.ops.sculpt.face_sets_create`` owns grouping; and
``bpy.ops.paint.mask_flood_fill`` owns mask clearing. LumaFold only owns shortcut
priority, ZBrush gesture policy, and the green/red preview. This module remains
separate from the frozen Sculpt input core and navigation routes.
"""

import bpy
import gpu
from bpy_extras import view3d_utils
from mathutils import Vector
from gpu_extras.batch import batch_for_shader


VISIBILITY_OPERATOR_ID = "lumafold.sculpt_visibility_rect"
VISIBILITY_LASSO_OPERATOR_ID = "lumafold.sculpt_visibility_lasso"
VISIBILITY_LINE_OPERATOR_ID = "lumafold.sculpt_visibility_line"
VISIBILITY_POLYLINE_OPERATOR_ID = "lumafold.sculpt_visibility_polyline"
GROUP_VISIBLE_OPERATOR_ID = "lumafold.sculpt_group_visible"
_KEYMAP_NAME = "Sculpt"
_SPACE_TYPE = "EMPTY"
_REGION_TYPE = "WINDOW"
_ADDON_KEYMAPS = []
_OPERATORS = None
_SESSION_BRIDGE = None
_INSTALLED = False
_MOVE_EVENTS = {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}

# Blender's WindowManager gesture renderer uses these fixed values for Box/Lasso.
# The internal renderer is not exposed through bpy, so policy-owned gestures mirror
# its public-facing appearance without touching the final Blender mutation path.
_NATIVE_GESTURE_DARK = (0.4, 0.4, 0.4, 1.0)
_NATIVE_GESTURE_LIGHT = (1.0, 1.0, 1.0, 1.0)
_NATIVE_GESTURE_BOX_FILL = (1.0, 1.0, 1.0, 0.05)


def _lumafold_active() -> bool:
    operators = _OPERATORS
    if operators is None:
        return False
    try:
        return bool(getattr(operators.STATE, "running", False))
    except Exception:
        return False


def _policy_tool_values(context, operator_id: str, property_names) -> dict:
    bridge = _SESSION_BRIDGE
    getter = getattr(bridge, "policy_tool_values", None) if bridge is not None else None
    if not callable(getter):
        return {}
    try:
        return dict(getter(context, operator_id, tuple(property_names or ())) or {})
    except Exception:
        return {}


def _policy_trace(context, reason: str, **extra) -> None:
    bridge = _SESSION_BRIDGE
    trace = getattr(bridge, "policy_trace", None) if bridge is not None else None
    if not callable(trace):
        return
    try:
        trace(context, reason, **extra)
    except Exception:
        pass


def _policy_session_begin(context) -> bool:
    bridge = _SESSION_BRIDGE
    begin = getattr(bridge, "policy_gesture_begin", None) if bridge is not None else None
    if not callable(begin):
        return False
    try:
        return bool(begin(context))
    except Exception:
        return False


def _policy_session_end(context, *, cancelled: bool) -> None:
    bridge = _SESSION_BRIDGE
    end = getattr(bridge, "policy_gesture_end", None) if bridge is not None else None
    if not callable(end):
        return
    try:
        end(context, cancelled=bool(cancelled))
    except Exception:
        pass


def _valid_sculpt_context(context) -> bool:
    objects = getattr(getattr(context, "view_layer", None), "objects", None)
    active = getattr(objects, "active", None) if objects is not None else None
    return bool(
        str(getattr(context, "mode", "") or "").upper() == "SCULPT"
        and getattr(getattr(context, "area", None), "type", "") == "VIEW_3D"
        and getattr(getattr(context, "region", None), "type", "") == "WINDOW"
        and active is not None
        and getattr(active, "type", "") == "MESH"
    )


def _region_xy(event):
    try:
        return float(event.mouse_region_x), float(event.mouse_region_y)
    except Exception:
        return 0.0, 0.0


def _drag_threshold(context) -> float:
    try:
        inputs = context.preferences.inputs
        values = []
        for name in ("drag_threshold_tablet", "drag_threshold_mouse", "drag_threshold"):
            value = getattr(inputs, name, None)
            if value is not None and float(value) > 0.0:
                values.append(float(value))
        if values:
            return max(2.0, min(values))
    except Exception:
        pass
    return 4.0


def _active_sculpt_mesh(context):
    obj = getattr(context, "sculpt_object", None)
    if obj is None:
        objects = getattr(getattr(context, "view_layer", None), "objects", None)
        obj = getattr(objects, "active", None) if objects is not None else None
    if obj is None or getattr(obj, "type", "") != "MESH":
        return None
    return obj


def _face_is_hidden(mesh, face_index: int) -> bool:
    """Read Blender's native per-face hidden attribute when it is available."""
    try:
        index = int(face_index)
    except (TypeError, ValueError):
        return False
    if index < 0 or mesh is None:
        return False
    try:
        attributes = getattr(mesh, "attributes", None)
        hidden = attributes.get(".hide_poly") if attributes is not None else None
        if hidden is None or str(getattr(hidden, "domain", "") or "") != "FACE":
            return False
        data = getattr(hidden, "data", None)
        if data is None or index >= len(data):
            return False
        return bool(getattr(data[index], "value", False))
    except Exception:
        return False


def _has_hidden_geometry(context) -> bool:
    """Return whether the active Sculpt mesh already contains hidden faces."""
    obj = _active_sculpt_mesh(context)
    mesh = getattr(obj, "data", None) if obj is not None else None
    try:
        attributes = getattr(mesh, "attributes", None)
        hidden = attributes.get(".hide_poly") if attributes is not None else None
        if hidden is None or str(getattr(hidden, "domain", "") or "") != "FACE":
            return False
        return any(bool(getattr(item, "value", False)) for item in hidden.data)
    except Exception:
        return False


def _has_effective_mask(context) -> bool:
    """Match Blender's Face Set from Masked threshold (> 0.5)."""
    obj = _active_sculpt_mesh(context)
    mesh = getattr(obj, "data", None) if obj is not None else None
    try:
        attributes = getattr(mesh, "attributes", None)
        mask = attributes.get(".sculpt_mask") if attributes is not None else None
        if mask is None or str(getattr(mask, "domain", "") or "") != "POINT":
            return False
        return any(float(getattr(item, "value", 0.0)) > 0.5 for item in mask.data)
    except Exception:
        return False


def _surface_hit_xy(context, x: float, y: float) -> bool:
    """Return true only when the pointer hits currently visible Sculpt geometry.

    Sculpt hiding is stored by Blender in the native ``.hide_poly`` face
    attribute. Ray casts can still resolve a face that is hidden from the
    viewport, so hidden-face hits must be treated as visual background. This
    keeps Ctrl+Shift background gestures deterministic without changing the
    green/red rectangle gesture itself.
    """
    obj = _active_sculpt_mesh(context)
    region = getattr(context, "region", None)
    rv3d = getattr(context, "region_data", None)
    scene = getattr(context, "scene", None)
    if obj is None or region is None or rv3d is None:
        return False
    try:
        origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, (float(x), float(y)))
        direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, (float(x), float(y)))
        depsgraph = context.evaluated_depsgraph_get()
        if scene is not None:
            hit, _loc, _normal, face_index, hit_obj, _matrix = scene.ray_cast(
                depsgraph, origin, direction
            )
            if hit and hit_obj is not None:
                original = getattr(hit_obj, "original", hit_obj)
                if hit_obj == obj or original == obj:
                    if _face_is_hidden(getattr(hit_obj, "data", None), face_index):
                        return False
                    if original == obj and _face_is_hidden(getattr(obj, "data", None), face_index):
                        return False
                    return True
        eval_obj = obj.evaluated_get(depsgraph)
        inv = eval_obj.matrix_world.inverted_safe()
        hit, _loc, _normal, face_index = eval_obj.ray_cast(
            inv @ origin, inv.to_3x3() @ direction
        )
        if not hit:
            return False
        if _face_is_hidden(getattr(eval_obj, "data", None), face_index):
            return False
        if _face_is_hidden(getattr(obj, "data", None), face_index):
            return False
        return True
    except Exception:
        return False


def _box_has_visible_surface(context, x0, y0, x1, y1) -> bool:
    """Return whether the finished screen-space box covers visible Sculpt surface.

    Path-only hit testing is insufficient: a user can draw entirely around the
    model without the pointer itself crossing the mesh. Keep this probe bounded
    by intersecting the final box with the active object's projected bounds,
    then ray-casting a small fixed grid through that overlap. This is policy
    classification only; Blender still owns the final visibility mutation.
    """
    obj = _active_sculpt_mesh(context)
    region = getattr(context, "region", None)
    rv3d = getattr(context, "region_data", None)
    if obj is None or region is None or rv3d is None:
        return False

    xmin, xmax = sorted((float(x0), float(x1)))
    ymin, ymax = sorted((float(y0), float(y1)))
    if xmax - xmin < 2.0 or ymax - ymin < 2.0:
        return False

    try:
        projected = []
        for corner in tuple(getattr(obj, "bound_box", ()) or ()):
            world = obj.matrix_world @ Vector(corner)
            screen = view3d_utils.location_3d_to_region_2d(region, rv3d, world)
            if screen is not None:
                projected.append((float(screen.x), float(screen.y)))
        if not projected:
            return False

        obj_xmin = min(x for x, _y in projected)
        obj_xmax = max(x for x, _y in projected)
        obj_ymin = min(y for _x, y in projected)
        obj_ymax = max(y for _x, y in projected)

        sample_xmin = max(xmin, obj_xmin)
        sample_xmax = min(xmax, obj_xmax)
        sample_ymin = max(ymin, obj_ymin)
        sample_ymax = min(ymax, obj_ymax)
        if sample_xmax <= sample_xmin or sample_ymax <= sample_ymin:
            return False

        depsgraph = context.evaluated_depsgraph_get()
        eval_obj = obj.evaluated_get(depsgraph)
        inv = eval_obj.matrix_world.inverted_safe()
        sample_count = 7

        for iy in range(sample_count):
            fy = (iy + 0.5) / sample_count
            y = sample_ymin + (sample_ymax - sample_ymin) * fy
            for ix in range(sample_count):
                fx = (ix + 0.5) / sample_count
                x = sample_xmin + (sample_xmax - sample_xmin) * fx
                origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, (x, y))
                direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, (x, y))
                hit, _loc, _normal, face_index = eval_obj.ray_cast(
                    inv @ origin,
                    inv.to_3x3() @ direction,
                )
                if not hit:
                    continue
                if _face_is_hidden(getattr(eval_obj, "data", None), face_index):
                    continue
                if _face_is_hidden(getattr(obj, "data", None), face_index):
                    continue
                return True
    except Exception:
        return False
    return False


def _execute_native_visibility(context, x0, y0, x1, y1, *, invert: bool):
    xmin, xmax = sorted((int(round(x0)), int(round(x1))))
    ymin, ymax = sorted((int(round(y0)), int(round(y1))))
    if xmax - xmin < 2 or ymax - ymin < 2:
        return {"CANCELLED"}

    # Green isolate = hide OUTSIDE. Red inverse = hide Inside.
    kwargs = {
        "xmin": xmin,
        "xmax": xmax,
        "ymin": ymin,
        "ymax": ymax,
        "wait_for_input": False,
        "action": "HIDE",
        "area": "Inside" if invert else "OUTSIDE",
        "use_front_faces_only": False,
    }
    window = getattr(context, "window", None)
    area = getattr(context, "area", None)
    region = getattr(context, "region", None)
    try:
        if window is not None and area is not None and region is not None:
            with bpy.context.temp_override(window=window, area=area, region=region):
                result = set(bpy.ops.paint.hide_show("EXEC_REGION_WIN", **kwargs) or ())
        else:
            result = set(bpy.ops.paint.hide_show("EXEC_REGION_WIN", **kwargs) or ())
        if area is not None:
            area.tag_redraw()
        return result
    except (RuntimeError, TypeError, AttributeError):
        kwargs.pop("use_front_faces_only", None)
        try:
            if window is not None and area is not None and region is not None:
                with bpy.context.temp_override(window=window, area=area, region=region):
                    return set(bpy.ops.paint.hide_show("EXEC_REGION_WIN", **kwargs) or ())
            return set(bpy.ops.paint.hide_show("EXEC_REGION_WIN", **kwargs) or ())
        except (RuntimeError, TypeError, AttributeError):
            return {"CANCELLED"}


def _line_hits_visible_surface(context, x0, y0, x1, y1) -> bool:
    """Classify the finished straight line, not the freehand pointer trajectory."""
    dx = float(x1) - float(x0)
    dy = float(y1) - float(y0)
    length_sq = dx * dx + dy * dy
    if length_sq < 4.0:
        return _surface_hit_xy(context, x0, y0)

    sample_count = 32
    for index in range(sample_count + 1):
        t = index / sample_count
        x = float(x0) + dx * t
        y = float(y0) + dy * t
        if _surface_hit_xy(context, x, y):
            return True
    return False


def _execute_native_line_visibility(
    context,
    x0,
    y0,
    x1,
    y1,
    *,
    flip: bool,
    use_limit_to_segment: bool,
):
    if abs(float(x1) - float(x0)) < 1.0 and abs(float(y1) - float(y0)) < 1.0:
        return {"CANCELLED"}

    kwargs = {
        "xstart": int(round(x0)),
        "ystart": int(round(y0)),
        "xend": int(round(x1)),
        "yend": int(round(y1)),
        "flip": bool(flip),
        "use_limit_to_segment": bool(use_limit_to_segment),
        "action": "HIDE",
        "use_front_faces_only": False,
    }
    window = getattr(context, "window", None)
    area = getattr(context, "area", None)
    region = getattr(context, "region", None)
    try:
        if window is not None and area is not None and region is not None:
            with bpy.context.temp_override(window=window, area=area, region=region):
                result = set(
                    bpy.ops.paint.hide_show_line_gesture(
                        "EXEC_REGION_WIN",
                        **kwargs,
                    )
                    or ()
                )
        else:
            result = set(
                bpy.ops.paint.hide_show_line_gesture(
                    "EXEC_REGION_WIN",
                    **kwargs,
                )
                or ()
            )
        if area is not None:
            area.tag_redraw()
        return result
    except (RuntimeError, TypeError, AttributeError):
        kwargs.pop("use_front_faces_only", None)
        try:
            if window is not None and area is not None and region is not None:
                with bpy.context.temp_override(window=window, area=area, region=region):
                    return set(
                        bpy.ops.paint.hide_show_line_gesture(
                            "EXEC_REGION_WIN",
                            **kwargs,
                        )
                        or ()
                    )
            return set(
                bpy.ops.paint.hide_show_line_gesture(
                    "EXEC_REGION_WIN",
                    **kwargs,
                )
                or ()
            )
        except (RuntimeError, TypeError, AttributeError):
            return {"CANCELLED"}


def _point_in_polygon_2d(x: float, y: float, points) -> bool:
    points = tuple((float(px), float(py)) for px, py in tuple(points or ()))
    if len(points) < 3:
        return False
    inside = False
    j = len(points) - 1
    for i in range(len(points)):
        xi, yi = points[i]
        xj, yj = points[j]
        crosses = (yi > y) != (yj > y)
        if crosses:
            denom = yj - yi
            if abs(denom) > 1.0e-9:
                x_cross = (xj - xi) * (y - yi) / denom + xi
                if x < x_cross:
                    inside = not inside
        j = i
    return inside


def _polygon_has_visible_surface(context, points) -> bool:
    """Return whether a completed polygon encloses or crosses visible Sculpt surface."""
    points = tuple((float(x), float(y)) for x, y in tuple(points or ()))
    if len(points) < 3:
        return False

    # Boundary crossings count even when the polygon interior is very small.
    for index, (x0, y0) in enumerate(points):
        x1, y1 = points[(index + 1) % len(points)]
        if _line_hits_visible_surface(context, x0, y0, x1, y1):
            return True

    obj = _active_sculpt_mesh(context)
    region = getattr(context, "region", None)
    rv3d = getattr(context, "region_data", None)
    if obj is None or region is None or rv3d is None:
        return False

    try:
        projected = []
        for corner in tuple(getattr(obj, "bound_box", ()) or ()):
            world = obj.matrix_world @ Vector(corner)
            screen = view3d_utils.location_3d_to_region_2d(region, rv3d, world)
            if screen is not None:
                projected.append((float(screen.x), float(screen.y)))
        if not projected:
            return False

        poly_xmin = min(x for x, _y in points)
        poly_xmax = max(x for x, _y in points)
        poly_ymin = min(y for _x, y in points)
        poly_ymax = max(y for _x, y in points)
        obj_xmin = min(x for x, _y in projected)
        obj_xmax = max(x for x, _y in projected)
        obj_ymin = min(y for _x, y in projected)
        obj_ymax = max(y for _x, y in projected)

        sample_xmin = max(poly_xmin, obj_xmin)
        sample_xmax = min(poly_xmax, obj_xmax)
        sample_ymin = max(poly_ymin, obj_ymin)
        sample_ymax = min(poly_ymax, obj_ymax)
        if sample_xmax <= sample_xmin or sample_ymax <= sample_ymin:
            return False

        sample_count = 11
        for iy in range(sample_count):
            fy = (iy + 0.5) / sample_count
            y = sample_ymin + (sample_ymax - sample_ymin) * fy
            for ix in range(sample_count):
                fx = (ix + 0.5) / sample_count
                x = sample_xmin + (sample_xmax - sample_xmin) * fx
                if not _point_in_polygon_2d(x, y, points):
                    continue
                if _surface_hit_xy(context, x, y):
                    return True
    except Exception:
        return False
    return False


def _execute_native_polyline_visibility(context, points, *, invert: bool):
    path = [
        {
            "name": "",
            "loc": (int(round(x)), int(round(y))),
            "time": float(index),
        }
        for index, (x, y) in enumerate(tuple(points or ()))
    ]
    if len(path) < 3:
        return {"CANCELLED"}

    kwargs = {
        "path": path,
        "action": "HIDE",
        "area": "Inside" if invert else "OUTSIDE",
        "use_front_faces_only": False,
    }
    window = getattr(context, "window", None)
    area = getattr(context, "area", None)
    region = getattr(context, "region", None)
    try:
        if window is not None and area is not None and region is not None:
            with bpy.context.temp_override(window=window, area=area, region=region):
                result = set(
                    bpy.ops.paint.hide_show_polyline_gesture(
                        "EXEC_REGION_WIN",
                        **kwargs,
                    )
                    or ()
                )
        else:
            result = set(
                bpy.ops.paint.hide_show_polyline_gesture(
                    "EXEC_REGION_WIN",
                    **kwargs,
                )
                or ()
            )
        if area is not None:
            area.tag_redraw()
        return result
    except (RuntimeError, TypeError, AttributeError):
        kwargs.pop("use_front_faces_only", None)
        try:
            if window is not None and area is not None and region is not None:
                with bpy.context.temp_override(window=window, area=area, region=region):
                    return set(
                        bpy.ops.paint.hide_show_polyline_gesture(
                            "EXEC_REGION_WIN",
                            **kwargs,
                        )
                        or ()
                    )
            return set(
                bpy.ops.paint.hide_show_polyline_gesture(
                    "EXEC_REGION_WIN",
                    **kwargs,
                )
                or ()
            )
        except (RuntimeError, TypeError, AttributeError):
            return {"CANCELLED"}


def _execute_native_lasso_visibility(context, points, *, invert: bool):
    path = [
        {
            "name": "",
            "loc": (int(round(x)), int(round(y))),
            "time": float(index),
        }
        for index, (x, y) in enumerate(tuple(points or ()))
    ]
    if len(path) < 3:
        return {"CANCELLED"}

    kwargs = {
        "path": path,
        "use_smooth_stroke": False,
        "action": "HIDE",
        "area": "Inside" if invert else "OUTSIDE",
        "use_front_faces_only": False,
    }
    window = getattr(context, "window", None)
    area = getattr(context, "area", None)
    region = getattr(context, "region", None)
    try:
        if window is not None and area is not None and region is not None:
            with bpy.context.temp_override(window=window, area=area, region=region):
                result = set(
                    bpy.ops.paint.hide_show_lasso_gesture(
                        "EXEC_REGION_WIN",
                        **kwargs,
                    )
                    or ()
                )
        else:
            result = set(
                bpy.ops.paint.hide_show_lasso_gesture(
                    "EXEC_REGION_WIN",
                    **kwargs,
                )
                or ()
            )
        if area is not None:
            area.tag_redraw()
        return result
    except (RuntimeError, TypeError, AttributeError):
        kwargs.pop("use_front_faces_only", None)
        try:
            if window is not None and area is not None and region is not None:
                with bpy.context.temp_override(window=window, area=area, region=region):
                    return set(
                        bpy.ops.paint.hide_show_lasso_gesture(
                            "EXEC_REGION_WIN",
                            **kwargs,
                        )
                        or ()
                    )
            return set(
                bpy.ops.paint.hide_show_lasso_gesture(
                    "EXEC_REGION_WIN",
                    **kwargs,
                )
                or ()
            )
        except (RuntimeError, TypeError, AttributeError):
            return {"CANCELLED"}


def _show_all_hidden(context):
    """ZBrush empty-canvas click: reveal every hidden face on active Sculpt mesh."""
    window = getattr(context, "window", None)
    area = getattr(context, "area", None)
    region = getattr(context, "region", None)
    try:
        if window is not None and area is not None and region is not None:
            with bpy.context.temp_override(window=window, area=area, region=region):
                result = set(bpy.ops.paint.hide_show_all("EXEC_DEFAULT", action="SHOW") or ())
        else:
            result = set(bpy.ops.paint.hide_show_all("EXEC_DEFAULT", action="SHOW") or ())
        if area is not None:
            area.tag_redraw()
        return result
    except (RuntimeError, TypeError, AttributeError):
        return {"CANCELLED"}


def _invert_visibility(context):
    """Reverse the current Sculpt visibility using Blender's native operator."""
    window = getattr(context, "window", None)
    area = getattr(context, "area", None)
    region = getattr(context, "region", None)
    try:
        if window is not None and area is not None and region is not None:
            with bpy.context.temp_override(window=window, area=area, region=region):
                result = set(bpy.ops.paint.visibility_invert("EXEC_DEFAULT") or ())
        else:
            result = set(bpy.ops.paint.visibility_invert("EXEC_DEFAULT") or ())
        if area is not None:
            area.tag_redraw()
        return result
    except (RuntimeError, TypeError, AttributeError):
        return {"CANCELLED"}


def _toggle_face_set_under_cursor(context):
    """Ctrl+Shift surface click: let Blender isolate the Face Set under the cursor."""
    window = getattr(context, "window", None)
    area = getattr(context, "area", None)
    region = getattr(context, "region", None)
    try:
        if window is not None and area is not None and region is not None:
            with bpy.context.temp_override(window=window, area=area, region=region):
                result = set(
                    bpy.ops.sculpt.face_set_change_visibility(
                        "INVOKE_REGION_WIN",
                        mode="TOGGLE",
                    )
                    or ()
                )
        else:
            result = set(
                bpy.ops.sculpt.face_set_change_visibility(
                    "INVOKE_DEFAULT",
                    mode="TOGGLE",
                )
                or ()
            )
        if area is not None:
            area.tag_redraw()
        return result
    except (RuntimeError, TypeError, AttributeError):
        return {"CANCELLED"}


def _clear_mask(context):
    """ZBrush Ctrl+W semantics: Group Masked and Clear Mask."""
    window = getattr(context, "window", None)
    area = getattr(context, "area", None)
    region = getattr(context, "region", None)
    kwargs = {"mode": "VALUE", "value": 0.0}
    try:
        if window is not None and area is not None and region is not None:
            with bpy.context.temp_override(window=window, area=area, region=region):
                result = set(bpy.ops.paint.mask_flood_fill("EXEC_DEFAULT", **kwargs) or ())
        else:
            result = set(bpy.ops.paint.mask_flood_fill("EXEC_DEFAULT", **kwargs) or ())
        if area is not None:
            area.tag_redraw()
        return result
    except (RuntimeError, TypeError, AttributeError):
        return {"CANCELLED"}


def _create_face_set_from_mask_or_visible(context):
    """Ctrl+W: prefer Blender's native MASKED mode, otherwise Group Visible."""
    from_mask = _has_effective_mask(context)
    mode = "MASKED" if from_mask else "VISIBLE"
    window = getattr(context, "window", None)
    area = getattr(context, "area", None)
    region = getattr(context, "region", None)
    try:
        if window is not None and area is not None and region is not None:
            with bpy.context.temp_override(window=window, area=area, region=region):
                result = set(bpy.ops.sculpt.face_sets_create("EXEC_DEFAULT", mode=mode) or ())
        else:
            result = set(bpy.ops.sculpt.face_sets_create("EXEC_DEFAULT", mode=mode) or ())
        if "FINISHED" in result and from_mask:
            _clear_mask(context)
        if area is not None:
            area.tag_redraw()
        return result
    except (RuntimeError, TypeError, AttributeError):
        return {"CANCELLED"}


def _draw_native_gesture_dashed(points, *, loop: bool, dash_width: float) -> None:
    points = tuple((float(x), float(y)) for x, y in tuple(points or ()))
    if len(points) < 2:
        return
    edges = list(zip(points, points[1:]))
    if loop and len(points) > 2:
        edges.append((points[-1], points[0]))

    dark_segments = []
    light_segments = []
    color_index = 0
    width = max(1.0, float(dash_width))
    phase_width = max(0.5, width * 0.5)
    for (x0, y0), (x1, y1) in edges:
        dx = x1 - x0
        dy = y1 - y0
        length = (dx * dx + dy * dy) ** 0.5
        if length <= 0.0001:
            continue
        distance = 0.0
        while distance < length:
            end = min(length, distance + phase_width)
            t0 = distance / length
            t1 = end / length
            segment = (
                (x0 + dx * t0, y0 + dy * t0),
                (x0 + dx * t1, y0 + dy * t1),
            )
            (light_segments if color_index else dark_segments).extend(segment)
            color_index ^= 1
            distance = end

    shader = gpu.shader.from_builtin("UNIFORM_COLOR")
    try:
        gpu.state.line_width_set(1.0)
    except Exception:
        pass
    for vertices, color in (
        (dark_segments, _NATIVE_GESTURE_DARK),
        (light_segments, _NATIVE_GESTURE_LIGHT),
    ):
        if not vertices:
            continue
        batch = batch_for_shader(shader, "LINES", {"pos": vertices})
        shader.bind()
        shader.uniform_float("color", color)
        batch.draw(shader)


def _draw_visibility_box(self):
    if not bool(getattr(self, "_box_visible", False)):
        return
    x0, y0 = self._start_x, self._start_y
    x1, y1 = self._last_x, self._last_y
    fill = ((x0, y0), (x1, y0), (x1, y1), (x0, y0), (x1, y1), (x0, y1))
    outline = ((x0, y0), (x1, y0), (x1, y1), (x0, y1))
    try:
        shader = gpu.shader.from_builtin("UNIFORM_COLOR")
        gpu.state.blend_set("ALPHA")
        batch = batch_for_shader(shader, "TRIS", {"pos": fill})
        shader.bind()
        shader.uniform_float("color", _NATIVE_GESTURE_BOX_FILL)
        batch.draw(shader)
        gpu.state.blend_set("NONE")
        _draw_native_gesture_dashed(outline, loop=True, dash_width=8.0)
    except Exception:
        pass
    finally:
        try:
            gpu.state.blend_set("NONE")
        except Exception:
            pass


def _draw_visibility_line(self):
    if not bool(getattr(self, "_line_visible", False)):
        return
    x0, y0 = float(self._start_x), float(self._start_y)
    x1, y1 = float(self._last_x), float(self._last_y)
    dx = x1 - x0
    dy = y1 - y0
    length = (dx * dx + dy * dy) ** 0.5
    if length < 1.0:
        return

    nx = -dy / length
    ny = dx / length
    if not bool(getattr(self, "_invert", False)):
        nx = -nx
        ny = -ny
    gradient_length = 150.0 * max(0.5, float(getattr(self, "_ui_scale", 1.0)))
    gx = nx * gradient_length
    gy = ny * gradient_length

    positions = (
        (x0, y0),
        (x1, y1),
        (x1 + gx, y1 + gy),
        (x0, y0),
        (x1 + gx, y1 + gy),
        (x0 + gx, y0 + gy),
    )
    near = (0.2, 0.2, 0.2, 0.4)
    far = (0.0, 0.0, 0.0, 0.0)
    colors = (near, near, far, near, far, far)

    try:
        shader = gpu.shader.from_builtin("SMOOTH_COLOR")
        gpu.state.blend_set("ALPHA")
        batch = batch_for_shader(shader, "TRIS", {"pos": positions, "color": colors})
        shader.bind()
        batch.draw(shader)
    except Exception:
        pass
    finally:
        try:
            gpu.state.blend_set("NONE")
        except Exception:
            pass

    try:
        _draw_native_gesture_dashed(((x0, y0), (x1, y1)), loop=False, dash_width=8.0)
    except Exception:
        pass


def _draw_visibility_polyline(self):
    if not bool(getattr(self, "_polyline_visible", False)):
        return
    points = list(tuple(getattr(self, "_points", ()) or ()))
    current = (
        float(getattr(self, "_current_x", 0.0)),
        float(getattr(self, "_current_y", 0.0)),
    )
    if not points:
        return

    preview = list(points)
    if not preview or (
        abs(preview[-1][0] - current[0]) > 0.5
        or abs(preview[-1][1] - current[1]) > 0.5
    ):
        preview.append(current)

    try:
        _draw_native_gesture_dashed(preview, loop=True, dash_width=2.0)
    except Exception:
        pass

    if len(points) < 3:
        return
    start_x, start_y = points[0]
    dx = current[0] - start_x
    dy = current[1] - start_y
    close_radius = float(getattr(self, "_close_radius", 15.0))
    if dx * dx + dy * dy > close_radius * close_radius:
        return

    segments = 20
    radius = max(2.0, close_radius * 0.35)
    circle = []
    for index in range(segments):
        angle = 6.283185307179586 * index / segments
        circle.append(
            (
                start_x + radius * __import__("math").cos(angle),
                start_y + radius * __import__("math").sin(angle),
            )
        )
    try:
        _draw_native_gesture_dashed(circle, loop=True, dash_width=2.0)
    except Exception:
        pass


def _draw_visibility_lasso(self):
    if not bool(getattr(self, "_lasso_visible", False)):
        return
    points = tuple(getattr(self, "_path", ()) or ())
    if len(points) < 2:
        return
    try:
        _draw_native_gesture_dashed(points, loop=True, dash_width=2.0)
    except Exception:
        pass


class LUMAFOLD_OT_sculpt_visibility_rect(bpy.types.Operator):
    bl_idname = VISIBILITY_OPERATOR_ID
    bl_label = "LumaFold ZBrush SelectRect"
    bl_description = "Ctrl+Shift isolates Face Sets or box regions; background drag reverses only partial visibility"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        return _valid_sculpt_context(context)

    def invoke(self, context, event):
        if not _lumafold_active():
            return {"PASS_THROUGH"}
        if not bool(getattr(event, "ctrl", False)) or not bool(getattr(event, "shift", False)):
            return {"PASS_THROUGH"}

        self._start_x, self._start_y = _region_xy(event)
        self._last_x, self._last_y = self._start_x, self._start_y
        self._start_on_surface = _surface_hit_xy(context, self._start_x, self._start_y)
        self._path_hits_surface = bool(self._start_on_surface)
        self._invert = bool(getattr(event, "alt", False))
        self._dragging = False
        self._box_visible = False
        self._draw_handle = None
        self._policy_session_active = False
        threshold = _drag_threshold(context)
        self._threshold_sq = threshold * threshold
        if not _policy_session_begin(context):
            return {"CANCELLED"}
        self._policy_session_active = True
        try:
            context.window_manager.modal_handler_add(self)
        except Exception:
            self._finish_policy(context, {"CANCELLED"})
            return {"CANCELLED"}
        return {"RUNNING_MODAL"}

    def _finish_preview(self, context):
        handle = getattr(self, "_draw_handle", None)
        if handle is not None:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(handle, "WINDOW")
            except Exception:
                pass
            self._draw_handle = None
        self._box_visible = False
        try:
            context.area.tag_redraw()
        except Exception:
            pass

    def _finish_policy(self, context, result):
        outcome = set(result or ())
        active = bool(getattr(self, "_policy_session_active", False))
        self._policy_session_active = False
        if active:
            _policy_session_end(context, cancelled="FINISHED" not in outcome)
        return outcome

    def modal(self, context, event):
        event_type = str(getattr(event, "type", "") or "").upper()
        event_value = str(getattr(event, "value", "") or "").upper()

        if event_type in {"ESC", "WINDOW_DEACTIVATE"}:
            self._finish_preview(context)
            return self._finish_policy(context, {"CANCELLED"})

        if event_type in {"LEFT_ALT", "RIGHT_ALT"}:
            self._invert = event_value != "RELEASE"
            try:
                context.area.tag_redraw()
            except Exception:
                pass
            return {"RUNNING_MODAL"}

        if event_type in _MOVE_EVENTS:
            self._invert = bool(getattr(event, "alt", self._invert))
            x, y = _region_xy(event)
            self._last_x, self._last_y = x, y
            if not bool(getattr(self, "_path_hits_surface", False)) and _surface_hit_xy(context, x, y):
                self._path_hits_surface = True
            dx = x - self._start_x
            dy = y - self._start_y
            if not self._dragging and dx * dx + dy * dy >= self._threshold_sq:
                self._dragging = True
                self._box_visible = True
                try:
                    self._draw_handle = bpy.types.SpaceView3D.draw_handler_add(
                        _draw_visibility_box, (self,), "WINDOW", "POST_PIXEL"
                    )
                except Exception:
                    self._draw_handle = None
            if self._box_visible:
                try:
                    context.area.tag_redraw()
                except Exception:
                    pass
            return {"RUNNING_MODAL"}

        if event_type == "LEFTMOUSE" and event_value == "RELEASE":
            self._invert = bool(getattr(event, "alt", self._invert))
            if not self._dragging:
                self._finish_preview(context)
                if not bool(getattr(self, "_start_on_surface", False)):
                    result = _show_all_hidden(context)
                    outcome = {"FINISHED"} if "FINISHED" in result else {"CANCELLED"}
                    return self._finish_policy(context, outcome)
                if bool(getattr(self, "_invert", False)):
                    return self._finish_policy(context, {"CANCELLED"})
                result = _toggle_face_set_under_cursor(context)
                outcome = {"FINISHED"} if "FINISHED" in result else {"CANCELLED"}
                return self._finish_policy(context, outcome)

            self._finish_preview(context)
            path_hits_surface = bool(getattr(self, "_path_hits_surface", self._start_on_surface))
            area_hits_surface = path_hits_surface or _box_has_visible_surface(
                context,
                self._start_x,
                self._start_y,
                self._last_x,
                self._last_y,
            )
            if not area_hits_surface:
                _policy_trace(
                    context,
                    "visibility_policy_background_reverse",
                    start_on_surface=bool(self._start_on_surface),
                    path_hits_surface=path_hits_surface,
                    area_hits_surface=False,
                    invert=bool(self._invert),
                )
                # ZBrush-style reverse visibility is only meaningful for a
                # partially hidden mesh. Prevent Blender's native invert from
                # turning an entirely visible model into an entirely hidden one.
                if _has_hidden_geometry(context):
                    result = _invert_visibility(context)
                else:
                    result = {"FINISHED"}
            else:
                if bool(self._start_on_surface):
                    reason = "visibility_policy_surface_box_select"
                elif path_hits_surface:
                    reason = "visibility_policy_surface_cross_box_select"
                else:
                    reason = "visibility_policy_area_box_select"
                _policy_trace(
                    context,
                    reason,
                    start_on_surface=bool(self._start_on_surface),
                    path_hits_surface=path_hits_surface,
                    area_hits_surface=bool(area_hits_surface),
                    invert=bool(self._invert),
                )
                result = _execute_native_visibility(
                    context,
                    self._start_x,
                    self._start_y,
                    self._last_x,
                    self._last_y,
                    invert=bool(self._invert),
                )
            outcome = {"FINISHED"} if "FINISHED" in result else {"CANCELLED"}
            return self._finish_policy(context, outcome)

        return {"RUNNING_MODAL"}


class LUMAFOLD_OT_sculpt_visibility_lasso(bpy.types.Operator):
    bl_idname = VISIBILITY_LASSO_OPERATOR_ID
    bl_label = "LumaFold ZBrush SelectLasso"
    bl_description = "Ctrl+Shift uses a completed lasso path while preserving ZBrush background visibility semantics"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        return _valid_sculpt_context(context)

    def invoke(self, context, event):
        if not _lumafold_active():
            return {"PASS_THROUGH"}
        if not bool(getattr(event, "ctrl", False)) or not bool(getattr(event, "shift", False)):
            return {"PASS_THROUGH"}

        self._start_x, self._start_y = _region_xy(event)
        self._last_x, self._last_y = self._start_x, self._start_y
        self._path = [(self._start_x, self._start_y)]
        self._start_on_surface = _surface_hit_xy(context, self._start_x, self._start_y)
        self._path_hits_surface = bool(self._start_on_surface)
        self._invert = bool(getattr(event, "alt", False))
        self._dragging = False
        self._lasso_visible = False
        self._draw_handle = None
        self._policy_session_active = False
        threshold = _drag_threshold(context)
        self._threshold_sq = threshold * threshold
        if not _policy_session_begin(context):
            return {"CANCELLED"}
        self._policy_session_active = True
        try:
            context.window_manager.modal_handler_add(self)
        except Exception:
            self._finish_policy(context, {"CANCELLED"})
            return {"CANCELLED"}
        return {"RUNNING_MODAL"}

    def _finish_preview(self, context):
        handle = getattr(self, "_draw_handle", None)
        if handle is not None:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(handle, "WINDOW")
            except Exception:
                pass
            self._draw_handle = None
        self._lasso_visible = False
        try:
            context.area.tag_redraw()
        except Exception:
            pass

    def _finish_policy(self, context, result):
        outcome = set(result or ())
        active = bool(getattr(self, "_policy_session_active", False))
        self._policy_session_active = False
        if active:
            _policy_session_end(context, cancelled="FINISHED" not in outcome)
        return outcome

    def _append_path_point(self, x: float, y: float) -> None:
        path = self._path
        if path:
            last_x, last_y = path[-1]
            dx = x - last_x
            dy = y - last_y
            if dx * dx + dy * dy < 1.0:
                return
        path.append((x, y))

    def modal(self, context, event):
        event_type = str(getattr(event, "type", "") or "").upper()
        event_value = str(getattr(event, "value", "") or "").upper()

        if event_type in {"ESC", "WINDOW_DEACTIVATE"}:
            self._finish_preview(context)
            return self._finish_policy(context, {"CANCELLED"})

        if event_type in {"LEFT_ALT", "RIGHT_ALT"}:
            self._invert = event_value != "RELEASE"
            try:
                context.area.tag_redraw()
            except Exception:
                pass
            return {"RUNNING_MODAL"}

        if event_type in _MOVE_EVENTS:
            self._invert = bool(getattr(event, "alt", self._invert))
            x, y = _region_xy(event)
            self._last_x, self._last_y = x, y
            self._append_path_point(x, y)
            if not bool(getattr(self, "_path_hits_surface", False)) and _surface_hit_xy(context, x, y):
                self._path_hits_surface = True
            dx = x - self._start_x
            dy = y - self._start_y
            if not self._dragging and dx * dx + dy * dy >= self._threshold_sq:
                self._dragging = True
                self._lasso_visible = True
                try:
                    self._draw_handle = bpy.types.SpaceView3D.draw_handler_add(
                        _draw_visibility_lasso,
                        (self,),
                        "WINDOW",
                        "POST_PIXEL",
                    )
                except Exception:
                    self._draw_handle = None
            if self._lasso_visible:
                try:
                    context.area.tag_redraw()
                except Exception:
                    pass
            return {"RUNNING_MODAL"}

        if event_type == "LEFTMOUSE" and event_value == "RELEASE":
            self._invert = bool(getattr(event, "alt", self._invert))
            x, y = _region_xy(event)
            self._last_x, self._last_y = x, y
            self._append_path_point(x, y)

            if not self._dragging:
                self._finish_preview(context)
                if not bool(getattr(self, "_start_on_surface", False)):
                    result = _show_all_hidden(context)
                    outcome = {"FINISHED"} if "FINISHED" in result else {"CANCELLED"}
                    return self._finish_policy(context, outcome)
                if bool(getattr(self, "_invert", False)):
                    return self._finish_policy(context, {"CANCELLED"})
                result = _toggle_face_set_under_cursor(context)
                outcome = {"FINISHED"} if "FINISHED" in result else {"CANCELLED"}
                return self._finish_policy(context, outcome)

            self._finish_preview(context)
            if not bool(getattr(self, "_path_hits_surface", self._start_on_surface)):
                _policy_trace(
                    context,
                    "visibility_policy_background_reverse",
                    shape="LASSO",
                    start_on_surface=bool(self._start_on_surface),
                    path_hits_surface=bool(self._path_hits_surface),
                    invert=bool(self._invert),
                )
                if _has_hidden_geometry(context):
                    result = _invert_visibility(context)
                else:
                    result = {"FINISHED"}
            else:
                reason = (
                    "visibility_policy_surface_lasso_select"
                    if bool(self._start_on_surface)
                    else "visibility_policy_surface_cross_lasso_select"
                )
                _policy_trace(
                    context,
                    reason,
                    start_on_surface=bool(self._start_on_surface),
                    path_hits_surface=bool(self._path_hits_surface),
                    invert=bool(self._invert),
                    path_points=len(self._path),
                )
                result = _execute_native_lasso_visibility(
                    context,
                    self._path,
                    invert=bool(self._invert),
                )
                _policy_trace(
                    context,
                    "visibility_policy_lasso_native_result",
                    result=",".join(sorted(result)),
                    path_points=len(self._path),
                )
            outcome = {"FINISHED"} if "FINISHED" in result else {"CANCELLED"}
            return self._finish_policy(context, outcome)

        return {"RUNNING_MODAL"}


class LUMAFOLD_OT_sculpt_visibility_line(bpy.types.Operator):
    bl_idname = VISIBILITY_LINE_OPERATOR_ID
    bl_label = "LumaFold ZBrush SelectLine"
    bl_description = "Ctrl+Shift uses a completed Blender Line Hide gesture with ZBrush background semantics"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        return _valid_sculpt_context(context)

    def invoke(self, context, event):
        if not _lumafold_active():
            return {"PASS_THROUGH"}
        if not bool(getattr(event, "ctrl", False)) or not bool(getattr(event, "shift", False)):
            return {"PASS_THROUGH"}

        self._start_x, self._start_y = _region_xy(event)
        self._last_x, self._last_y = self._start_x, self._start_y
        self._start_on_surface = _surface_hit_xy(context, self._start_x, self._start_y)
        self._invert = bool(getattr(event, "alt", False))
        self._dragging = False
        self._line_visible = False
        self._draw_handle = None
        self._policy_session_active = False
        try:
            self._ui_scale = float(context.preferences.system.ui_scale)
        except Exception:
            self._ui_scale = 1.0

        values = _policy_tool_values(
            context,
            "paint.hide_show_line_gesture",
            ("use_limit_to_segment",),
        )
        self._use_limit_to_segment = bool(values.get("use_limit_to_segment", False))

        threshold = _drag_threshold(context)
        self._threshold_sq = threshold * threshold
        if not _policy_session_begin(context):
            return {"CANCELLED"}
        self._policy_session_active = True
        try:
            context.window_manager.modal_handler_add(self)
        except Exception:
            self._finish_policy(context, {"CANCELLED"})
            return {"CANCELLED"}
        return {"RUNNING_MODAL"}

    def _finish_preview(self, context):
        handle = getattr(self, "_draw_handle", None)
        if handle is not None:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(handle, "WINDOW")
            except Exception:
                pass
            self._draw_handle = None
        self._line_visible = False
        try:
            context.area.tag_redraw()
        except Exception:
            pass

    def _finish_policy(self, context, result):
        outcome = set(result or ())
        active = bool(getattr(self, "_policy_session_active", False))
        self._policy_session_active = False
        if active:
            _policy_session_end(context, cancelled="FINISHED" not in outcome)
        return outcome

    def modal(self, context, event):
        event_type = str(getattr(event, "type", "") or "").upper()
        event_value = str(getattr(event, "value", "") or "").upper()

        if event_type in {"ESC", "WINDOW_DEACTIVATE"}:
            self._finish_preview(context)
            return self._finish_policy(context, {"CANCELLED"})

        if event_type in {"LEFT_ALT", "RIGHT_ALT"}:
            self._invert = event_value != "RELEASE"
            try:
                context.area.tag_redraw()
            except Exception:
                pass
            return {"RUNNING_MODAL"}

        if event_type in _MOVE_EVENTS:
            self._invert = bool(getattr(event, "alt", self._invert))
            x, y = _region_xy(event)
            self._last_x, self._last_y = x, y
            dx = x - self._start_x
            dy = y - self._start_y
            if not self._dragging and dx * dx + dy * dy >= self._threshold_sq:
                self._dragging = True
                self._line_visible = True
                try:
                    self._draw_handle = bpy.types.SpaceView3D.draw_handler_add(
                        _draw_visibility_line,
                        (self,),
                        "WINDOW",
                        "POST_PIXEL",
                    )
                except Exception:
                    self._draw_handle = None
            if self._line_visible:
                try:
                    context.area.tag_redraw()
                except Exception:
                    pass
            return {"RUNNING_MODAL"}

        if event_type == "LEFTMOUSE" and event_value == "RELEASE":
            self._invert = bool(getattr(event, "alt", self._invert))
            self._last_x, self._last_y = _region_xy(event)

            if not self._dragging:
                self._finish_preview(context)
                if not bool(getattr(self, "_start_on_surface", False)):
                    result = _show_all_hidden(context)
                    outcome = {"FINISHED"} if "FINISHED" in result else {"CANCELLED"}
                    return self._finish_policy(context, outcome)
                if bool(getattr(self, "_invert", False)):
                    return self._finish_policy(context, {"CANCELLED"})
                result = _toggle_face_set_under_cursor(context)
                outcome = {"FINISHED"} if "FINISHED" in result else {"CANCELLED"}
                return self._finish_policy(context, outcome)

            self._finish_preview(context)
            line_hits_surface = _line_hits_visible_surface(
                context,
                self._start_x,
                self._start_y,
                self._last_x,
                self._last_y,
            )
            if not line_hits_surface:
                _policy_trace(
                    context,
                    "visibility_policy_background_reverse",
                    shape="LINE",
                    start_on_surface=bool(self._start_on_surface),
                    line_hits_surface=False,
                    invert=bool(self._invert),
                )
                if _has_hidden_geometry(context):
                    result = _invert_visibility(context)
                else:
                    result = {"FINISHED"}
            else:
                reason = (
                    "visibility_policy_surface_line_select"
                    if bool(self._start_on_surface)
                    else "visibility_policy_surface_cross_line_select"
                )
                _policy_trace(
                    context,
                    reason,
                    start_on_surface=bool(self._start_on_surface),
                    line_hits_surface=True,
                    invert=bool(self._invert),
                    use_limit_to_segment=bool(self._use_limit_to_segment),
                )
                result = _execute_native_line_visibility(
                    context,
                    self._start_x,
                    self._start_y,
                    self._last_x,
                    self._last_y,
                    flip=bool(self._invert),
                    use_limit_to_segment=bool(self._use_limit_to_segment),
                )
                _policy_trace(
                    context,
                    "visibility_policy_line_native_result",
                    result=",".join(sorted(result)),
                    flip=bool(self._invert),
                )
            outcome = {"FINISHED"} if "FINISHED" in result else {"CANCELLED"}
            return self._finish_policy(context, outcome)

        return {"RUNNING_MODAL"}


class LUMAFOLD_OT_sculpt_visibility_polyline(bpy.types.Operator):
    bl_idname = VISIBILITY_POLYLINE_OPERATOR_ID
    bl_label = "LumaFold ZBrush SelectPolyline"
    bl_description = "Ctrl+Shift uses a completed Blender Polyline Hide path with ZBrush background semantics"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        return _valid_sculpt_context(context)

    def invoke(self, context, event):
        if not _lumafold_active():
            return {"PASS_THROUGH"}
        if not bool(getattr(event, "ctrl", False)) or not bool(getattr(event, "shift", False)):
            return {"PASS_THROUGH"}

        x, y = _region_xy(event)
        self._points = [(x, y)]
        self._current_x, self._current_y = x, y
        self._start_on_surface = _surface_hit_xy(context, x, y)
        self._invert = bool(getattr(event, "alt", False))
        self._polyline_visible = True
        self._draw_handle = None
        self._policy_session_active = False
        try:
            ui_scale = float(context.preferences.system.ui_scale)
        except Exception:
            ui_scale = 1.0
        self._close_radius = 15.0 * max(0.5, ui_scale)

        if not _policy_session_begin(context):
            return {"CANCELLED"}
        self._policy_session_active = True
        try:
            self._draw_handle = bpy.types.SpaceView3D.draw_handler_add(
                _draw_visibility_polyline,
                (self,),
                "WINDOW",
                "POST_PIXEL",
            )
            context.window_manager.modal_handler_add(self)
            context.area.tag_redraw()
        except Exception:
            self._finish_preview(context)
            self._finish_policy(context, {"CANCELLED"})
            return {"CANCELLED"}
        return {"RUNNING_MODAL"}

    def _finish_preview(self, context):
        handle = getattr(self, "_draw_handle", None)
        if handle is not None:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(handle, "WINDOW")
            except Exception:
                pass
            self._draw_handle = None
        self._polyline_visible = False
        try:
            context.area.tag_redraw()
        except Exception:
            pass

    def _finish_policy(self, context, result):
        outcome = set(result or ())
        active = bool(getattr(self, "_policy_session_active", False))
        self._policy_session_active = False
        if active:
            _policy_session_end(context, cancelled="FINISHED" not in outcome)
        return outcome

    def _confirmed_points(self, *, include_current: bool):
        points = list(tuple(getattr(self, "_points", ()) or ()))
        if include_current and points:
            current = (float(self._current_x), float(self._current_y))
            last = points[-1]
            if abs(last[0] - current[0]) > 0.5 or abs(last[1] - current[1]) > 0.5:
                points.append(current)
        return points

    def _complete(self, context, points):
        points = list(tuple(points or ()))
        if len(points) < 3:
            self._finish_preview(context)
            return self._finish_policy(context, {"CANCELLED"})

        self._finish_preview(context)
        area_hits_surface = _polygon_has_visible_surface(context, points)
        if not area_hits_surface:
            _policy_trace(
                context,
                "visibility_policy_background_reverse",
                shape="POLYLINE",
                start_on_surface=bool(self._start_on_surface),
                area_hits_surface=False,
                invert=bool(self._invert),
                path_points=len(points),
            )
            if _has_hidden_geometry(context):
                result = _invert_visibility(context)
            else:
                result = {"FINISHED"}
        else:
            reason = (
                "visibility_policy_surface_polyline_select"
                if bool(self._start_on_surface)
                else "visibility_policy_surface_cross_polyline_select"
            )
            _policy_trace(
                context,
                reason,
                start_on_surface=bool(self._start_on_surface),
                area_hits_surface=True,
                invert=bool(self._invert),
                path_points=len(points),
            )
            result = _execute_native_polyline_visibility(
                context,
                points,
                invert=bool(self._invert),
            )
            _policy_trace(
                context,
                "visibility_policy_polyline_native_result",
                result=",".join(sorted(result)),
                path_points=len(points),
            )

        outcome = {"FINISHED"} if "FINISHED" in result else {"CANCELLED"}
        return self._finish_policy(context, outcome)

    def _finish_single_point_tap(self, context):
        self._finish_preview(context)
        if not bool(getattr(self, "_start_on_surface", False)):
            result = _show_all_hidden(context)
            outcome = {"FINISHED"} if "FINISHED" in result else {"CANCELLED"}
            return self._finish_policy(context, outcome)
        if bool(getattr(self, "_invert", False)):
            return self._finish_policy(context, {"CANCELLED"})
        result = _toggle_face_set_under_cursor(context)
        outcome = {"FINISHED"} if "FINISHED" in result else {"CANCELLED"}
        return self._finish_policy(context, outcome)

    def modal(self, context, event):
        event_type = str(getattr(event, "type", "") or "").upper()
        event_value = str(getattr(event, "value", "") or "").upper()

        if event_type in {"ESC", "WINDOW_DEACTIVATE"}:
            self._finish_preview(context)
            return self._finish_policy(context, {"CANCELLED"})

        if event_type in {"LEFT_ALT", "RIGHT_ALT"}:
            self._invert = event_value != "RELEASE"
            try:
                context.area.tag_redraw()
            except Exception:
                pass
            return {"RUNNING_MODAL"}

        if event_type in _MOVE_EVENTS:
            self._invert = bool(getattr(event, "alt", self._invert))
            self._current_x, self._current_y = _region_xy(event)
            try:
                context.area.tag_redraw()
            except Exception:
                pass
            return {"RUNNING_MODAL"}

        if event_type == "LEFTMOUSE" and event_value in {"PRESS", "DOUBLE_CLICK"}:
            self._invert = bool(getattr(event, "alt", self._invert))
            x, y = _region_xy(event)
            self._current_x, self._current_y = x, y
            points = self._points

            if event_value == "DOUBLE_CLICK":
                return self._complete(context, self._confirmed_points(include_current=True))

            if len(points) >= 3:
                dx = x - points[0][0]
                dy = y - points[0][1]
                if dx * dx + dy * dy <= self._close_radius * self._close_radius:
                    return self._complete(context, points)

            last_x, last_y = points[-1]
            if abs(last_x - x) > 0.5 or abs(last_y - y) > 0.5:
                points.append((x, y))
                _policy_trace(
                    context,
                    "visibility_policy_polyline_point_added",
                    path_points=len(points),
                )
            try:
                context.area.tag_redraw()
            except Exception:
                pass
            return {"RUNNING_MODAL"}

        if event_type in {"RET", "NUMPAD_ENTER", "SPACE"} and event_value == "PRESS":
            return self._complete(context, self._confirmed_points(include_current=True))

        if (
            event_type in {"LEFT_CTRL", "RIGHT_CTRL", "LEFT_SHIFT", "RIGHT_SHIFT"}
            and event_value == "RELEASE"
        ):
            points = self._confirmed_points(include_current=True)
            if len(points) >= 3:
                return self._complete(context, points)
            if len(self._points) == 1:
                return self._finish_single_point_tap(context)
            self._finish_preview(context)
            return self._finish_policy(context, {"CANCELLED"})

        # Releases between vertex clicks are intentionally ignored. The same
        # policy modal owns the entire multi-click gesture until close/confirm.
        if event_type == "LEFTMOUSE" and event_value == "RELEASE":
            return {"RUNNING_MODAL"}

        return {"RUNNING_MODAL"}


class LUMAFOLD_OT_sculpt_group_visible(bpy.types.Operator):
    bl_idname = GROUP_VISIBLE_OPERATOR_ID
    bl_label = "LumaFold Group Masked / Visible"
    bl_description = "Ctrl+W groups the masked region and clears the mask; without a mask, group visible geometry"
    bl_options = {"INTERNAL", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _valid_sculpt_context(context)

    def invoke(self, context, event):
        if not _lumafold_active():
            return {"PASS_THROUGH"}
        result = _create_face_set_from_mask_or_visible(context)
        if "FINISHED" in result:
            return {"FINISHED"}
        self.report({"WARNING"}, "无法从当前遮罩或可见模型创建面组")
        return {"CANCELLED"}


def _addon_keyconfig():
    try:
        return bpy.context.window_manager.keyconfigs.addon
    except Exception:
        return None


def _exact_sculpt_map(kc, *, create=True):
    if kc is None:
        return None
    try:
        km = kc.keymaps.find(_KEYMAP_NAME, space_type=_SPACE_TYPE, region_type=_REGION_TYPE)
    except Exception:
        km = None
    if km is None and create:
        try:
            km = kc.keymaps.new(
                name=_KEYMAP_NAME,
                space_type=_SPACE_TYPE,
                region_type=_REGION_TYPE,
            )
        except Exception:
            km = None
    return km


def _remove_stale_items(kc):
    if kc is None:
        return
    # Keep both ids here so upgrading from older builds removes any stale
    # Ctrl+Shift pointer items even though pointer routing no longer registers
    # them in the add-on keyconfig.
    ids = {
        VISIBILITY_OPERATOR_ID,
        VISIBILITY_LASSO_OPERATOR_ID,
        VISIBILITY_LINE_OPERATOR_ID,
        VISIBILITY_POLYLINE_OPERATOR_ID,
        GROUP_VISIBLE_OPERATOR_ID,
    }
    try:
        maps = tuple(kc.keymaps)
    except Exception:
        maps = ()
    for km in maps:
        if str(getattr(km, "name", "") or "") != _KEYMAP_NAME:
            continue
        for kmi in tuple(getattr(km, "keymap_items", ()) or ()):
            if str(getattr(kmi, "idname", "") or "") in ids:
                try:
                    km.keymap_items.remove(kmi)
                except Exception:
                    pass


def _register_keymaps():
    kc = _addon_keyconfig()
    km = _exact_sculpt_map(kc, create=True)
    if km is None:
        return
    _remove_stale_items(kc)
    _ADDON_KEYMAPS.clear()

    # Ctrl+Shift LMB is owned exclusively by the central Sculpt route. Keeping
    # the same pointer binding here created two possible owners for one press.
    # Ctrl+W remains a runtime add-on keymap until that keyboard shortcut is
    # intentionally migrated to the route.
    bindings = ((GROUP_VISIBLE_OPERATOR_ID, "W", {"ctrl": True}),)
    for operator_id, event_type, modifiers in bindings:
        try:
            kmi = km.keymap_items.new(
                operator_id,
                event_type,
                "PRESS",
                head=True,
                **modifiers,
            )
            kmi.active = True
            _ADDON_KEYMAPS.append((km, kmi))
        except Exception:
            pass


def _unregister_keymaps():
    while _ADDON_KEYMAPS:
        km, kmi = _ADDON_KEYMAPS.pop()
        try:
            km.keymap_items.remove(kmi)
        except Exception:
            pass
    _remove_stale_items(_addon_keyconfig())


def install(operators, session_bridge=None):
    global _OPERATORS, _SESSION_BRIDGE, _INSTALLED
    if _INSTALLED:
        return
    _OPERATORS = operators
    _SESSION_BRIDGE = session_bridge
    for cls in (
        LUMAFOLD_OT_sculpt_visibility_rect,
        LUMAFOLD_OT_sculpt_visibility_lasso,
        LUMAFOLD_OT_sculpt_visibility_line,
        LUMAFOLD_OT_sculpt_visibility_polyline,
        LUMAFOLD_OT_sculpt_group_visible,
    ):
        try:
            bpy.utils.register_class(cls)
        except RuntimeError:
            try:
                bpy.utils.unregister_class(cls)
            except Exception:
                pass
            bpy.utils.register_class(cls)
    _register_keymaps()
    _INSTALLED = True


def uninstall():
    global _OPERATORS, _SESSION_BRIDGE, _INSTALLED
    if not _INSTALLED:
        return
    _unregister_keymaps()
    for cls in reversed((
        LUMAFOLD_OT_sculpt_visibility_rect,
        LUMAFOLD_OT_sculpt_visibility_lasso,
        LUMAFOLD_OT_sculpt_visibility_line,
        LUMAFOLD_OT_sculpt_visibility_polyline,
        LUMAFOLD_OT_sculpt_group_visible,
    )):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    _OPERATORS = None
    _SESSION_BRIDGE = None
    _INSTALLED = False
