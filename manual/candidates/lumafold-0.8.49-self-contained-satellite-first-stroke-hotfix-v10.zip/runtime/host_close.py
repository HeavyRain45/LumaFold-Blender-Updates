from __future__ import annotations

"""Deterministic close path for the Embedded LumaFold host.

The long-lived Embedded host operator only owns opening/hosting. While Embedded
is running, Blender's Header uses this separate one-shot close operator so the
active modal never needs to re-enter itself just to shut down.
"""

import bpy

from ..core.state import STATE


_INSTALLED = False
_ORIGINAL_HEADER_DRAW = None
_OPERATORS = None


class LUMAFOLD_OT_close_embedded_host(bpy.types.Operator):
    bl_idname = "lumafold.close_embedded_host"
    bl_label = "关闭 LumaFold 浮台"
    bl_description = "关闭当前 Blender 内嵌 LumaFold 浮台"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        return bool(
            getattr(STATE, "running", False)
            and str(getattr(STATE, "host_mode", "embedded") or "embedded").lower()
            == "embedded"
        )

    def execute(self, context):
        if _OPERATORS is None:
            return {"CANCELLED"}
        try:
            _OPERATORS.shutdown_active_runtime()
            return {"FINISHED"}
        except Exception as exc:
            try:
                self.report({"ERROR"}, str(exc))
            except Exception:
                pass
            return {"CANCELLED"}


def _safe_header_draw(self, context):
    row = self.layout.row(align=True)
    row.separator(factor=0.35)
    embedded_running = bool(
        getattr(STATE, "running", False)
        and str(getattr(STATE, "host_mode", "embedded") or "embedded").lower()
        == "embedded"
    )
    operator_id = (
        "lumafold.close_embedded_host"
        if embedded_running
        else "lumafold.toggle_p0"
    )
    row.operator(
        operator_id,
        text="LumaFold",
        icon="BRUSH_DATA",
        depress=bool(getattr(STATE, "running", False)),
    )


def configure(operators_module):
    global _OPERATORS
    _OPERATORS = operators_module


def install(panels_module):
    global _INSTALLED, _ORIGINAL_HEADER_DRAW
    if _INSTALLED:
        return
    _ORIGINAL_HEADER_DRAW = getattr(panels_module, "_draw_lumafold_header", None)
    panels_module._draw_lumafold_header = _safe_header_draw
    _INSTALLED = True


def uninstall(panels_module):
    global _INSTALLED, _ORIGINAL_HEADER_DRAW, _OPERATORS
    if callable(_ORIGINAL_HEADER_DRAW):
        panels_module._draw_lumafold_header = _ORIGINAL_HEADER_DRAW
    _ORIGINAL_HEADER_DRAW = None
    _OPERATORS = None
    _INSTALLED = False


def register():
    try:
        bpy.utils.register_class(LUMAFOLD_OT_close_embedded_host)
    except RuntimeError:
        try:
            bpy.utils.unregister_class(LUMAFOLD_OT_close_embedded_host)
        except Exception:
            pass
        bpy.utils.register_class(LUMAFOLD_OT_close_embedded_host)


def unregister():
    try:
        bpy.utils.unregister_class(LUMAFOLD_OT_close_embedded_host)
    except RuntimeError:
        pass
