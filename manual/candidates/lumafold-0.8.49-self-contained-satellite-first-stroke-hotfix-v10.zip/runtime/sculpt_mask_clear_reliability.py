from __future__ import annotations

"""Narrow reliability fix for Ctrl background-drag mask clearing.

The existing mask gesture used a projected object bounding-box intersection as
a fallback when deciding whether a background rectangle actually touched the
mesh. On irregular silhouettes that produces false positives: a rectangle can
be entirely over empty canvas but still overlap the projected bbox, so LumaFold
runs box-mask instead of Clear Mask.

This adapter replaces only that classifier. It samples real ray hits through
the mask module's existing `_surface_hit_xy`; no input ownership, drawing,
navigation, Host, or mask mutation logic changes.
"""

_MASK = None
_ORIGINAL = None


def _actual_surface_rect_hit(context, x0, y0, x1, y1) -> bool:
    mask = _MASK
    if mask is None:
        return False
    xmin, xmax = sorted((float(x0), float(x1)))
    ymin, ymax = sorted((float(y0), float(y1)))
    # Denser than the old 5x5 probe but still tiny compared with a sculpt
    # stroke. Exact ray hits avoid the projected-bbox false positive.
    steps = 9
    for iy in range(steps):
        y = ymin + (ymax - ymin) * (iy / float(steps - 1))
        for ix in range(steps):
            x = xmin + (xmax - xmin) * (ix / float(steps - 1))
            try:
                if bool(mask._surface_hit_xy(context, x, y)):
                    return True
            except Exception:
                return False
    return False


def install(mask_module):
    global _MASK, _ORIGINAL
    if _MASK is not None:
        return
    _MASK = mask_module
    _ORIGINAL = getattr(mask_module, "_rect_hits_active", None)
    mask_module._rect_hits_active = _actual_surface_rect_hit


def uninstall():
    global _MASK, _ORIGINAL
    if _MASK is not None and _ORIGINAL is not None:
        try:
            _MASK._rect_hits_active = _ORIGINAL
        except Exception:
            pass
    _MASK = None
    _ORIGINAL = None
