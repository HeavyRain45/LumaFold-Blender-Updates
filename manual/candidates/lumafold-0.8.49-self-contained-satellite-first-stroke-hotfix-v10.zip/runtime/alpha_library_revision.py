from __future__ import annotations

"""Authoritative Alpha library publication after real Blender mutations.

Native file selectors are asynchronous: opening a selector is not the mutation.
This module publishes the complete Alpha library only after the Blender operator
actually finishes importing/linking. Secondary hosts consume Store snapshots and
never rescan files themselves.
"""

from ..core.app import APP
from ..core.state import STATE

_INSTALLED = False
_WRAPPED = []


def _publish_full_library(reason: str = "mutation"):
    state = APP.store.namespace("sculpt")
    service = APP.services.require("blender.alpha")
    result = dict(service.list_sculpt_alphas() or {})
    state["alpha_library_assets"] = list(result.get("assets") or ())
    state["alpha_library_folders"] = list(result.get("folders") or ())
    state["alpha_library_errors"] = list(result.get("errors") or ())
    state["alpha_library_scan_serial"] = int(state.get("alpha_library_scan_serial", 0) or 0) + 1
    state["alpha_library_revision"] = int(state.get("alpha_library_revision", 0) or 0) + 1
    count = len(state["alpha_library_assets"])
    state["alpha_library_status"] = "READY" if count else "EMPTY"
    state["alpha_library_publish_reason"] = str(reason or "mutation")
    return count


def _wrap_operator_execute(cls, label: str):
    original = getattr(cls, "execute", None)
    if not callable(original):
        return

    def execute(self, context):
        result = original(self, context)
        tokens = set(result or ())
        if "FINISHED" in tokens:
            try:
                count = _publish_full_library(label)
                APP.store.namespace("sculpt")["alpha_action_status"] = (
                    f"Alpha 库已发布：{count} 个资源"
                )
            except Exception as exc:
                STATE.last_error = (
                    f"Alpha library publish failed: {type(exc).__name__}: {exc}"
                )
        return result

    cls.execute = execute
    _WRAPPED.append((cls, original))


def install(operators_module, alpha_import_product_module):
    global _INSTALLED
    if _INSTALLED:
        return

    # The mixed picker class lives in alpha_import_product and is appended to
    # operators.CLASSES before Blender registration. Wrap it now so publication
    # occurs after the user's real File Browser confirmation, not after the
    # earlier command that merely opened the selector.
    mixed = getattr(alpha_import_product_module, "LUMAFOLD_OT_add_alpha_folder", None)
    if mixed is not None:
        _wrap_operator_execute(mixed, "mixed_picker_finished")

    legacy = getattr(operators_module, "LUMAFOLD_OT_import_alpha_images", None)
    if legacy is not None:
        _wrap_operator_execute(legacy, "legacy_import_finished")

    _INSTALLED = True


def uninstall():
    global _INSTALLED
    if not _INSTALLED:
        return
    for cls, original in reversed(_WRAPPED):
        try:
            cls.execute = original
        except Exception:
            pass
    _WRAPPED.clear()
    _INSTALLED = False
