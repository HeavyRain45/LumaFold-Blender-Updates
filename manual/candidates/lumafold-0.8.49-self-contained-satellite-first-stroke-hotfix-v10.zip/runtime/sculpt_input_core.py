from __future__ import annotations

"""LumaFold Sculpt input core.

Post-dev76 architecture rules:
- one long-lived broker per Blender Window for both Embedded and Satellite;
- Host activity comes from HOST_CONTROL lease truth;
- route policy is injected explicitly through ``set_route_handler``;
- ordinary Sculpt and Rotate are Blender-native and never implemented here;
- this file owns only broker lifetime, Quick Brush routing helpers, mode-command
  deferral, and the small set of intentional ZBrush-specific modifier gestures.

There is deliberately no custom orbit quaternion, axis-snap state, rotate
keymap mutation, or parallel ordinary-navigation state machine in this module.
"""

import math
import time

import bpy
import gpu
from bpy_extras import view3d_utils
from gpu_extras.batch import batch_for_shader
from mathutils import Vector

from ..core.host_control import HOST_CONTROL, EMBEDDED, DETACHING, SATELLITE
from ..core.state import STATE


_APP = None
_SCULPT = None
_SHORTCUT_PRODUCT = None
_UI_PATCH = None
_OPERATORS = None

_INSTALLED = False
_ORIGINAL_ENTER = None
_ORIGINAL_EXIT = None

_SAT_BROKER_ID = "lumafold.sculpt_satellite_input_v4"
_LEFT_ID = "lumafold.sculpt_z_left_runtime_v4"
_RIGHT_ID = "lumafold.sculpt_z_right_runtime_v4"

_GENERATION_KEY = "LUMAFOLD_SCULPT_INPUT_RUNTIME_V5"
_OLD_GENERATION_KEYS = (
    "LUMAFOLD_SCULPT_INPUT_RUNTIME_V4",
    "LUMAFOLD_SCULPT_INPUT_RUNTIME_V3",
    "LUMAFOLD_SCULPT_INPUT_AUTHORITY_V2",
    "LUMAFOLD_SCULPT_INPUT_BROKER_V1",
)

_RUNNING_SAT_WINDOWS = set()
_MODE_REQUEST_SERIAL = 0

_LAST_ALT_PRESS = -1.0
_LAST_ALT_RELEASE = -1.0
_ALT_HELD = False
_ALT_GRACE_SECONDS = 1.0

_GESTURE_SERIAL = 0
_ACTIVE_GESTURE_BY_WINDOW = {}

_ROUTE_HANDLER = None
_NAVIGATION_HANDLER = None
_INPUT_OBSERVER = None
_VIEW3D_REGION_RESOLVER = None

_MOVE_EVENTS = {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}
_ALT_KEYS = {"LEFT_ALT", "RIGHT_ALT"}
_POINTER_BUTTONS = {"LEFTMOUSE", "RIGHTMOUSE"}
_OLD_POINTER_IDS = {
    "lumafold.sculpt_z_left_mouse",
    "lumafold.sculpt_z_right_mouse",
    "lumafold.sculpt_z_modifier_watch",
}


def set_route_handler(handler):
    """Install the single event-route authority without monkey-patching symbols."""
    global _ROUTE_HANDLER
    _ROUTE_HANDLER = handler if callable(handler) else None


def set_navigation_handler(handler):
    """Install the stateless Blender-native navigation handoff."""
    global _NAVIGATION_HANDLER
    _NAVIGATION_HANDLER = handler if callable(handler) else None


def set_input_observer(observer):
    """Install an optional diagnostic observer. It never decides input results."""
    global _INPUT_OBSERVER
    _INPUT_OBSERVER = observer if callable(observer) else None


def set_view3d_region_resolver(resolver):
    """Install the authoritative Blender-region resolver used by routing."""
    global _VIEW3D_REGION_RESOLVER
    _VIEW3D_REGION_RESOLVER = resolver if callable(resolver) else None


def _notify_input_observer(phase: str, context, event, result=None):
    observer = _INPUT_OBSERVER
    if observer is None:
        return
    try:
        observer(str(phase), context, event, result=result)
    except Exception:
        pass


def _generation_now() -> int:
    try:
        return int(bpy.app.driver_namespace.get(_GENERATION_KEY, 0) or 0)
    except Exception:
        return 0


def _bump_generation() -> int:
    value = _generation_now() + 1
    try:
        bpy.app.driver_namespace[_GENERATION_KEY] = int(value)
    except Exception:
        pass
    for key in _OLD_GENERATION_KEYS:
        try:
            bpy.app.driver_namespace[key] = int(
                bpy.app.driver_namespace.get(key, 0) or 0
            ) + 1
        except Exception:
            pass
    return int(value)


def _lease_snapshot() -> dict:
    try:
        return dict(HOST_CONTROL.snapshot() or {})
    except Exception:
        return {}


def _product_active() -> bool:
    """One activity truth: HostControl lease, never STATE.running."""
    lease = _lease_snapshot()
    state = str(lease.get("state") or "")
    owner = str(lease.get("owner") or "")
    if state == SATELLITE and owner == "satellite":
        return True
    if state in {EMBEDDED, DETACHING} and owner == "embedded":
        host = getattr(STATE, "host", None)
        return bool(host is not None and not bool(getattr(host, "closed", False)))
    return False


def _host_mode() -> str:
    lease = _lease_snapshot()
    if str(lease.get("state") or "") == SATELLITE and str(lease.get("owner") or "") == "satellite":
        return "satellite"
    return "embedded"


def activity_snapshot() -> dict:
    lease = _lease_snapshot()
    return {
        "active": bool(_product_active()),
        "lease_state": str(lease.get("state") or ""),
        "lease_owner": str(lease.get("owner") or ""),
        "state_running": bool(getattr(STATE, "running", False)),
        "state_host_mode": str(getattr(STATE, "host_mode", "") or ""),
        "has_embedded_host": bool(getattr(STATE, "host", None) is not None),
    }


def _profile() -> str:
    try:
        return str(_SCULPT._profile() if _SCULPT is not None else "blender")
    except Exception:
        return "blender"


def _shortcut_capture_active() -> bool:
    try:
        return bool(_UI_PATCH is not None and _UI_PATCH.shortcut_capture_active())
    except Exception:
        return False


def _ptr(value) -> int:
    try:
        return int(value.as_pointer())
    except Exception:
        return 0


def _screen_ptr(window) -> int:
    return _ptr(getattr(window, "screen", None))


def _window_by_ptr(pointer: int):
    try:
        for window in tuple(bpy.context.window_manager.windows):
            if _ptr(window) == int(pointer or 0):
                return window
    except Exception:
        pass
    return None


def _reset_transient_input(host=None):
    global _ALT_HELD, _LAST_ALT_PRESS, _LAST_ALT_RELEASE
    _ALT_HELD = False
    _LAST_ALT_PRESS = -1.0
    _LAST_ALT_RELEASE = -1.0
    STATE.capture_mouse = False
    STATE.capture_keyboard = False
    STATE.capture_text = False
    if host is not None:
        try:
            reset = getattr(host, "_reset_transient_input", None)
            if callable(reset):
                reset()
            else:
                host._release_owned_input()
        except Exception:
            pass


def _note_alt(event):
    global _LAST_ALT_PRESS, _LAST_ALT_RELEASE, _ALT_HELD
    event_type = str(getattr(event, "type", "") or "")
    if event_type not in _ALT_KEYS:
        return
    value = str(getattr(event, "value", "") or "").upper()
    now = time.monotonic()
    if value == "PRESS":
        _LAST_ALT_PRESS = now
        _ALT_HELD = True
    elif value == "RELEASE":
        _LAST_ALT_RELEASE = now
        _ALT_HELD = False


def _recent_alt() -> bool:
    last = max(float(_LAST_ALT_PRESS), float(_LAST_ALT_RELEASE))
    return last >= 0.0 and (time.monotonic() - last) <= _ALT_GRACE_SECONDS


def _claim_gesture(window) -> int:
    global _GESTURE_SERIAL
    ptr = _ptr(window)
    if not ptr:
        return 0
    _GESTURE_SERIAL += 1
    serial = int(_GESTURE_SERIAL)
    _ACTIVE_GESTURE_BY_WINDOW[ptr] = serial
    return serial


def _gesture_is_owner(window_ptr: int, serial: int) -> bool:
    return bool(
        window_ptr
        and serial
        and int(_ACTIVE_GESTURE_BY_WINDOW.get(int(window_ptr), 0) or 0) == int(serial)
    )


def _release_gesture(window_ptr: int, serial: int):
    if _gesture_is_owner(window_ptr, serial):
        _ACTIVE_GESTURE_BY_WINDOW.pop(int(window_ptr), None)


def _clear_gesture_registry():
    _ACTIVE_GESTURE_BY_WINDOW.clear()


def _default_view3d_region_under_pointer(context, event):
    window = getattr(context, "window", None)
    screen = getattr(window, "screen", None) if window is not None else None
    if screen is None:
        return None
    try:
        mx, my = float(event.mouse_x), float(event.mouse_y)
    except Exception:
        return None
    for area in tuple(getattr(screen, "areas", ()) or ()):
        if getattr(area, "type", "") != "VIEW_3D":
            continue
        for region in tuple(getattr(area, "regions", ()) or ()):
            if getattr(region, "type", "") != "WINDOW":
                continue
            try:
                if (
                    float(region.x) <= mx < float(region.x + region.width)
                    and float(region.y) <= my < float(region.y + region.height)
                ):
                    return window, area, region
            except Exception:
                continue
    return None


def _view3d_region_under_pointer(context, event):
    resolver = _VIEW3D_REGION_RESOLVER
    if resolver is not None:
        try:
            return resolver(context, event)
        except Exception:
            return None
    return _default_view3d_region_under_pointer(context, event)


def _best_view3d_context(window=None):
    try:
        windows = tuple(bpy.context.window_manager.windows)
    except Exception:
        return None
    current = getattr(bpy.context, "window", None)
    ordered = (
        [window]
        if window is not None
        else ([current] if current is not None else [])
        + [w for w in windows if w is not current]
    )
    best = None
    best_score = -1
    for candidate in ordered:
        screen = getattr(candidate, "screen", None) if candidate is not None else None
        if screen is None:
            continue
        for area in tuple(getattr(screen, "areas", ()) or ()):
            if getattr(area, "type", "") != "VIEW_3D":
                continue
            region = next(
                (r for r in tuple(getattr(area, "regions", ()) or ()) if getattr(r, "type", "") == "WINDOW"),
                None,
            )
            if region is None:
                continue
            score = int(getattr(area, "width", 0) or 0) * int(getattr(area, "height", 0) or 0)
            if score > best_score:
                best_score = score
                best = (candidate, area, region)
    return best


def _host_region(host):
    if host is None:
        return None
    window = _window_by_ptr(int(getattr(host, "window_pointer", 0) or 0))
    if window is None:
        return None
    screen = getattr(window, "screen", None)
    if screen is None:
        return None
    for area in tuple(getattr(screen, "areas", ()) or ()):
        if _ptr(area) != int(getattr(host, "area_pointer", 0) or 0):
            continue
        region = next((r for r in area.regions if getattr(r, "type", "") == "WINDOW"), None)
        if region is not None:
            return window, area, region
    return _best_view3d_context(window)


def _pointer_over_host(host, event) -> bool:
    target = _host_region(host)
    state = getattr(host, "state", None)
    if target is None or not isinstance(state, dict):
        return False
    _window, _area, region = target
    try:
        px = float(state.get("embedded_window_pos_x", state.get("embedded_last_valid_pos_x", -1.0)))
        py = float(state.get("embedded_window_pos_y", state.get("embedded_last_valid_pos_y", -1.0)))
        scale = max(0.01, float(state.get("style_scale", state.get("ui_scale", 1.0)) or 1.0))
        width = float(state.get("compact_surface_w", 0.0) or 0.0) * scale
        height = float(state.get("compact_surface_h", 0.0) or 0.0) * scale
        if px < 0.0 or py < 0.0 or width <= 1.0 or height <= 1.0:
            return False
        local_x = float(event.mouse_x) - float(region.x)
        local_y = float(region.height - 1) - (float(event.mouse_y) - float(region.y))
        margin = 3.0
        return bool(
            px - margin <= local_x <= px + width + margin
            and py - margin <= local_y <= py + height + margin
        )
    except Exception:
        return False


def _event_region_xy(context, event):
    region = getattr(context, "region", None)
    if region is None:
        return 0.0, 0.0
    try:
        return float(event.mouse_x) - float(region.x), float(event.mouse_y) - float(region.y)
    except Exception:
        try:
            return float(event.mouse_region_x), float(event.mouse_region_y)
        except Exception:
            return 0.0, 0.0


def _active_hit_xy(context, obj, x: float, y: float) -> bool:
    """Hit test used only by custom mask semantics, never plain Sculpt-vs-Rotate."""
    if obj is None:
        return False
    region = getattr(context, "region", None)
    rv3d = getattr(context, "region_data", None)
    if region is None or rv3d is None:
        return False
    try:
        coord = (float(x), float(y))
        origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
        direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
        depsgraph = context.evaluated_depsgraph_get()
        eval_obj = obj.evaluated_get(depsgraph)
        inv = eval_obj.matrix_world.inverted_safe()
        hit, _loc, _normal, _index = eval_obj.ray_cast(inv @ origin, inv.to_3x3() @ direction)
        if hit:
            return True
        scene = getattr(context, "scene", None)
        if scene is None:
            return False
        result, _loc, _nor, _idx, hit_obj, _matrix = scene.ray_cast(depsgraph, origin, direction)
        return bool(
            result
            and hit_obj is not None
            and (
                hit_obj == obj
                or getattr(hit_obj, "original", None) == obj
                or getattr(obj, "original", None) == hit_obj
            )
        )
    except Exception:
        return False


def _evaluated_active_hit(context, event, obj) -> bool:
    x, y = _event_region_xy(context, event)
    return _active_hit_xy(context, obj, x, y)


def _projected_bbox_intersects(context, obj, xmin, ymin, xmax, ymax) -> bool:
    region = getattr(context, "region", None)
    rv3d = getattr(context, "region_data", None)
    if region is None or rv3d is None or obj is None:
        return False
    points = []
    try:
        matrix = obj.matrix_world
        for corner in tuple(getattr(obj, "bound_box", ()) or ()):
            p = view3d_utils.location_3d_to_region_2d(region, rv3d, matrix @ Vector(corner))
            if p is not None:
                points.append((float(p.x), float(p.y)))
    except Exception:
        return False
    if not points:
        return False
    bx0, bx1 = min(p[0] for p in points), max(p[0] for p in points)
    by0, by1 = min(p[1] for p in points), max(p[1] for p in points)
    return not (xmax < bx0 or xmin > bx1 or ymax < by0 or ymin > by1)


def _rect_hits_active(context, obj, x0, y0, x1, y1) -> bool:
    xmin, xmax = sorted((float(x0), float(x1)))
    ymin, ymax = sorted((float(y0), float(y1)))
    for iy in range(5):
        y = ymin + (ymax - ymin) * (iy / 4.0)
        for ix in range(5):
            x = xmin + (xmax - xmin) * (ix / 4.0)
            if _active_hit_xy(context, obj, x, y):
                return True
    return _projected_bbox_intersects(context, obj, xmin, ymin, xmax, ymax)


def _execute_box_mask(x0, y0, x1, y1, *, erase: bool):
    xmin, xmax = sorted((int(x0), int(x1)))
    ymin, ymax = sorted((int(y0), int(y1)))
    if xmax - xmin < 2 or ymax - ymin < 2:
        return {"CANCELLED"}
    kwargs = {
        "xmin": xmin,
        "xmax": xmax,
        "ymin": ymin,
        "ymax": ymax,
        "wait_for_input": False,
        "use_front_faces_only": False,
        "mode": "VALUE",
        "value": 0.0 if erase else 1.0,
    }
    try:
        return bpy.ops.paint.mask_box_gesture("EXEC_REGION_WIN", **kwargs)
    except (RuntimeError, TypeError):
        kwargs.pop("use_front_faces_only", None)
        try:
            return bpy.ops.paint.mask_box_gesture("EXEC_REGION_WIN", **kwargs)
        except (RuntimeError, TypeError):
            return {"CANCELLED"}


def _zoom_step(context, current_y: float, previous_y: float):
    """Intentional ZBrush-style custom zoom exception; ordinary navigation is native."""
    rv3d = getattr(context, "region_data", None)
    if rv3d is None:
        return
    dy = float(current_y) - float(previous_y)
    if abs(dy) < 0.01:
        return
    try:
        distance = max(1.0e-7, float(rv3d.view_distance))
        rv3d.view_distance = max(1.0e-7, min(1.0e12, distance * math.exp(dy * 0.012)))
        rv3d.update()
        context.area.tag_redraw()
    except Exception:
        pass


def _pan_step(context, current_x, current_y, previous_x, previous_y):
    """Intentional ZBrush-style custom pan exception; ordinary navigation is native."""
    region = getattr(context, "region", None)
    rv3d = getattr(context, "region_data", None)
    if region is None or rv3d is None:
        return
    try:
        depth = rv3d.view_location.copy()
        prev = view3d_utils.region_2d_to_location_3d(region, rv3d, (float(previous_x), float(previous_y)), depth)
        curr = view3d_utils.region_2d_to_location_3d(region, rv3d, (float(current_x), float(current_y)), depth)
        rv3d.view_location += prev - curr
        rv3d.update()
        context.area.tag_redraw()
    except Exception:
        pass


def _draw_box_preview(self):
    if not bool(getattr(self, "_box_preview", False)):
        return
    x0, y0 = float(self._start_x), float(self._start_y)
    x1, y1 = self._box_end
    if abs(x1 - x0) < 1.0 and abs(y1 - y0) < 1.0:
        return
    erase = bool(getattr(self, "_alt", False))
    if erase:
        fill_color = (0.72, 0.72, 0.72, 0.18)
        line_color = (0.94, 0.94, 0.94, 0.92)
    else:
        fill_color = (0.24, 0.24, 0.24, 0.44)
        line_color = (0.50, 0.50, 0.50, 0.98)
    fill = ((x0, y0), (x1, y0), (x1, y1), (x0, y0), (x1, y1), (x0, y1))
    outline = ((x0, y0), (x1, y0), (x1, y1), (x0, y1), (x0, y0))
    try:
        shader = gpu.shader.from_builtin("UNIFORM_COLOR")
        gpu.state.blend_set("ALPHA")
        fill_batch = batch_for_shader(shader, "TRIS", {"pos": fill})
        shader.bind()
        shader.uniform_float("color", fill_color)
        fill_batch.draw(shader)
        line_batch = batch_for_shader(shader, "LINE_STRIP", {"pos": outline})
        gpu.state.line_width_set(1.4)
        shader.uniform_float("color", line_color)
        line_batch.draw(shader)
    except Exception:
        pass
    finally:
        try:
            gpu.state.line_width_set(1.0)
        except Exception:
            pass
        try:
            gpu.state.blend_set("NONE")
        except Exception:
            pass


class _GestureBase:
    _box_handle = None

    def _begin(self, context, event, initiating_button: str):
        _SCULPT.note_interaction()
        x, y = _event_region_xy(context, event)
        self._start_x = int(x)
        self._start_y = int(y)
        self._last_x = float(x)
        self._last_y = float(y)
        threshold = float(_SCULPT._drag_threshold(context))
        self._threshold_sq = threshold * threshold
        self._moved = False
        self._box_preview = False
        self._box_handle = None
        self._box_end = (float(x), float(y))
        self._window_ptr = _ptr(getattr(context, "window", None))
        self._screen_ptr = _screen_ptr(getattr(context, "window", None))
        self._generation = _generation_now()
        self._initiating_button = str(initiating_button)
        self._gesture_serial = _claim_gesture(getattr(context, "window", None))

    def _same_screen(self, context) -> bool:
        window = getattr(context, "window", None)
        return bool(
            self._window_ptr
            and _ptr(window) == self._window_ptr
            and _screen_ptr(window) == self._screen_ptr
        )

    def _still_owner(self) -> bool:
        return bool(
            int(getattr(self, "_generation", -1)) == _generation_now()
            and _gesture_is_owner(
                int(getattr(self, "_window_ptr", 0) or 0),
                int(getattr(self, "_gesture_serial", 0) or 0),
            )
        )

    def _release_owner(self):
        _release_gesture(
            int(getattr(self, "_window_ptr", 0) or 0),
            int(getattr(self, "_gesture_serial", 0) or 0),
        )

    def _tag_redraw(self, context):
        try:
            context.area.tag_redraw()
        except Exception:
            pass

    def _start_box_preview(self, context):
        self._box_preview = True
        try:
            self._box_handle = bpy.types.SpaceView3D.draw_handler_add(self._draw_box_preview, (), "WINDOW", "POST_PIXEL")
        except Exception:
            self._box_handle = None
        self._tag_redraw(context)

    def _stop_box_preview(self, context):
        self._box_preview = False
        handle = getattr(self, "_box_handle", None)
        if handle is not None:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(handle, "WINDOW")
            except Exception:
                pass
            self._box_handle = None
        self._tag_redraw(context)

    def _cleanup(self, context):
        self._stop_box_preview(context)
        self._release_owner()

    def _lifecycle_invalid(self, context) -> bool:
        return bool(
            not self._still_owner()
            or not self._same_screen(context)
            or not _product_active()
            or _profile() != "zbrush"
            or str(getattr(context, "mode", "") or "").upper() != "SCULPT"
        )

    def _stale_new_pointer_press(self, event) -> bool:
        event_type = str(getattr(event, "type", "") or "")
        event_value = str(getattr(event, "value", "") or "").upper()
        return bool(event_type in _POINTER_BUTTONS and event_value == "PRESS")

    @staticmethod
    def _running_passthrough():
        return {"RUNNING_MODAL", "PASS_THROUGH"}

    @staticmethod
    def _cancel_passthrough():
        return {"CANCELLED", "PASS_THROUGH"}


class LUMAFOLD_OT_sculpt_z_left_runtime_v4(bpy.types.Operator, _GestureBase):
    bl_idname = _LEFT_ID
    bl_label = "LumaFold Z Sculpt Left Runtime v4"
    bl_options = {"INTERNAL"}
    _draw_box_preview = _draw_box_preview

    @classmethod
    def poll(cls, context):
        return bool(
            _product_active()
            and _profile() == "zbrush"
            and str(getattr(context, "mode", "") or "").upper() == "SCULPT"
            and getattr(context, "region", None) is not None
            and getattr(context.region, "type", "") == "WINDOW"
        )

    def invoke(self, context, event):
        if _SCULPT._should_pass_special_tool(context):
            return {"PASS_THROUGH"}

        ctrl = bool(getattr(event, "ctrl", False))
        alt = bool(getattr(event, "alt", False))
        if not (ctrl or alt or _ALT_HELD or _recent_alt()):
            return {"PASS_THROUGH"}

        self._begin(context, event, "LEFTMOUSE")
        self._ctrl = ctrl
        self._alt = alt
        self._shift = bool(getattr(event, "shift", False))
        self._zoom_last_y = float(self._start_y)
        self._zoom_tablet = bool(getattr(event, "is_tablet", False))

        sculpt_obj = _SCULPT._active_sculpt_mesh(context)
        self._hit_current = _evaluated_active_hit(context, event, sculpt_obj)

        # Custom modifier strokes on the model are handed immediately to Blender.
        if self._hit_current:
            self._release_owner()
            if self._ctrl:
                _SCULPT._invoke_brush_stroke(invert=bool(self._alt), smooth=False, mask=True)
            else:
                _SCULPT._invoke_brush_stroke(
                    invert=bool(self._alt),
                    smooth=bool(self._shift and not self._alt),
                    mask=False,
                )
            return {"FINISHED"}

        recent_alt = _recent_alt()
        self._zoom_armed = bool(
            not self._ctrl
            and not self._shift
            and (self._alt or _ALT_HELD or recent_alt)
        )
        self._zoom_ready = bool(self._zoom_armed and not (self._alt or _ALT_HELD))

        if self._ctrl:
            self._start_box_preview(context)

        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        _SCULPT.note_interaction()
        event_type = str(getattr(event, "type", "") or "")
        event_value = str(getattr(event, "value", "") or "").upper()

        if self._stale_new_pointer_press(event):
            self._cleanup(context)
            return self._cancel_passthrough()
        if event_type == "WINDOW_DEACTIVATE":
            self._cleanup(context)
            return self._cancel_passthrough()
        if event_type == "ESC":
            self._cleanup(context)
            return {"CANCELLED"}
        if self._lifecycle_invalid(context):
            self._cleanup(context)
            return self._cancel_passthrough()

        if self._zoom_armed:
            if self._zoom_tablet and _SCULPT._tablet_contact_lost(event):
                self._cleanup(context)
                return {"FINISHED"}
            if event_type == "LEFTMOUSE" and event_value == "RELEASE":
                self._cleanup(context)
                return {"FINISHED"}
            if event_type in _ALT_KEYS:
                if event_value == "RELEASE":
                    self._zoom_ready = True
                    _x, y = _event_region_xy(context, event)
                    self._zoom_last_y = float(y)
                return {"RUNNING_MODAL"}
            if event_type in _MOVE_EVENTS:
                x, y = _event_region_xy(context, event)
                alt_now = bool(getattr(event, "alt", False))
                if not self._zoom_ready and alt_now:
                    _pan_step(context, x, y, self._last_x, self._last_y)
                else:
                    self._zoom_ready = True
                    _zoom_step(context, y, self._zoom_last_y)
                    self._zoom_last_y = float(y)
                self._last_x, self._last_y = float(x), float(y)
                self._moved = True
                return {"RUNNING_MODAL"}
            return self._running_passthrough()

        if self._ctrl:
            if event_type in _MOVE_EVENTS:
                x, y = _event_region_xy(context, event)
                self._box_end = (float(x), float(y))
                dx, dy = float(x) - self._start_x, float(y) - self._start_y
                if dx * dx + dy * dy >= self._threshold_sq:
                    self._moved = True
                self._tag_redraw(context)
                return {"RUNNING_MODAL"}
            if event_type == "LEFTMOUSE" and event_value == "RELEASE":
                self._stop_box_preview(context)
                if self._moved:
                    x, y = _event_region_xy(context, event)
                    obj = _SCULPT._active_sculpt_mesh(context)
                    hits_model = _rect_hits_active(context, obj, self._start_x, self._start_y, x, y)
                    erase = bool(self._alt or getattr(event, "alt", False))
                    if hits_model:
                        _execute_box_mask(self._start_x, self._start_y, x, y, erase=erase)
                    elif not erase:
                        _SCULPT._clear_mask()
                else:
                    _SCULPT._invert_mask()
                self._release_owner()
                return {"FINISHED"}
            if event_type in {"LEFT_CTRL", "RIGHT_CTRL", "LEFT_ALT", "RIGHT_ALT"}:
                return {"RUNNING_MODAL"}
            return self._running_passthrough()

        # No custom ordinary orbit path exists. Alt-click object transfer remains
        # the only non-pan/zoom left-button custom completion behavior.
        if event_type == "LEFTMOUSE" and event_value == "RELEASE":
            if self._alt and not self._moved:
                try:
                    sculpt_obj = _SCULPT._active_sculpt_mesh(context)
                    hit_obj = _SCULPT._scene_hit_object(context, event)
                    if (
                        hit_obj is not None
                        and getattr(hit_obj, "type", "") == "MESH"
                        and not _SCULPT._same_object(hit_obj, sculpt_obj)
                    ):
                        _SCULPT._transfer_sculpt_object()
                except Exception:
                    pass
            self._cleanup(context)
            return {"FINISHED"}

        return self._running_passthrough()


class LUMAFOLD_OT_sculpt_z_right_runtime_v4(bpy.types.Operator, _GestureBase):
    bl_idname = _RIGHT_ID
    bl_label = "LumaFold Z Sculpt Right Runtime v4"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        return bool(
            _product_active()
            and _profile() == "zbrush"
            and str(getattr(context, "mode", "") or "").upper() == "SCULPT"
            and getattr(context, "region", None) is not None
            and getattr(context.region, "type", "") == "WINDOW"
        )

    def invoke(self, context, event):
        if _SCULPT._should_pass_special_tool(context):
            return {"PASS_THROUGH"}
        self._alt = bool(getattr(event, "alt", False))
        self._ctrl = bool(getattr(event, "ctrl", False))
        if not (self._alt or self._ctrl):
            return {"PASS_THROUGH"}
        self._begin(context, event, "RIGHTMOUSE")
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        _SCULPT.note_interaction()
        event_type = str(getattr(event, "type", "") or "")
        event_value = str(getattr(event, "value", "") or "").upper()

        if self._stale_new_pointer_press(event):
            self._cleanup(context)
            return self._cancel_passthrough()
        if event_type == "WINDOW_DEACTIVATE":
            self._cleanup(context)
            return self._cancel_passthrough()
        if event_type == "ESC":
            self._cleanup(context)
            return {"CANCELLED"}
        if self._lifecycle_invalid(context):
            self._cleanup(context)
            return self._cancel_passthrough()

        if event_type in _MOVE_EVENTS:
            x, y = _event_region_xy(context, event)
            total_dx = float(x) - self._start_x
            total_dy = float(y) - self._start_y
            if (
                not self._moved
                and total_dx * total_dx + total_dy * total_dy < self._threshold_sq
            ):
                self._last_x, self._last_y = float(x), float(y)
                return {"RUNNING_MODAL"}

            self._moved = True
            if bool(getattr(event, "alt", False) or self._alt):
                _pan_step(context, x, y, self._last_x, self._last_y)
            elif bool(getattr(event, "ctrl", False) or self._ctrl):
                _zoom_step(context, y, self._last_y)
            self._last_x, self._last_y = float(x), float(y)
            return {"RUNNING_MODAL"}

        if event_type == "RIGHTMOUSE" and event_value == "RELEASE":
            self._cleanup(context)
            return {"FINISHED"}

        if event_type in {"LEFT_ALT", "RIGHT_ALT", "LEFT_CTRL", "RIGHT_CTRL"}:
            return {"RUNNING_MODAL"}
        return self._running_passthrough()


def _cleanup_legacy_pointer_keymaps():
    try:
        kc = bpy.context.window_manager.keyconfigs.addon
    except Exception:
        kc = None
    if kc is None:
        return
    try:
        maps = tuple(kc.keymaps)
    except Exception:
        maps = ()
    for km in maps:
        if str(getattr(km, "name", "") or "") != "Sculpt":
            continue
        for item in tuple(getattr(km, "keymap_items", ()) or ()):
            if str(getattr(item, "idname", "") or "") in _OLD_POINTER_IDS:
                try:
                    km.keymap_items.remove(item)
                except Exception:
                    pass


def _modifier_match(event, binding) -> bool:
    return bool(
        bool(getattr(event, "alt", False)) == bool(binding.get("alt", False))
        and bool(getattr(event, "ctrl", False)) == bool(binding.get("ctrl", False))
        and bool(getattr(event, "shift", False)) == bool(binding.get("shift", False))
        and bool(getattr(event, "oskey", False)) == bool(binding.get("oskey", False))
    )


def _quick_slot_for_event(event):
    if _SHORTCUT_PRODUCT is None:
        return None
    if str(getattr(event, "value", "") or "").upper() != "PRESS":
        return None
    event_type = str(getattr(event, "type", "") or "").upper()
    try:
        bindings = list(_SHORTCUT_PRODUCT.bindings_from_state() or ())
    except Exception:
        return None
    for slot, binding in enumerate(bindings[:16]):
        if event_type == str(binding.get("type") or "").upper() and _modifier_match(event, binding):
            return int(slot)
    return None


def _activate_quick_slot(slot: int) -> bool:
    try:
        result = _APP.execute("sculpt.brush.activate_slot", slot=int(slot))
        state = _APP.store.namespace("sculpt")
        state["input_runtime_status"] = (
            f"Quick Brush {slot + 1}"
            if bool(getattr(result, "ok", False))
            else str(getattr(result, "message", "Quick Brush failed"))
        )
    except Exception as exc:
        try:
            _APP.store.namespace("sculpt")["input_runtime_status"] = (
                f"Quick Brush ERROR: {type(exc).__name__}: {exc}"
            )
        except Exception:
            pass
    return True


def _invoke_transient(operator_name: str, target) -> bool:
    if target is None:
        return False
    window, area, region = target
    try:
        with bpy.context.temp_override(window=window, area=area, region=region):
            op = getattr(bpy.ops.lumafold, operator_name)
            result = op("INVOKE_DEFAULT")
        return bool(set(result or ()) & {"RUNNING_MODAL", "FINISHED"})
    except (RuntimeError, TypeError, AttributeError):
        return False


def _route_event(context, event, *, host=None) -> bool:
    handler = _ROUTE_HANDLER
    if handler is None:
        return False
    try:
        return bool(handler(context, event, host=host))
    except Exception:
        return False


def _native_navigation_handoff(context, event, target, *, host=None):
    handler = _NAVIGATION_HANDLER
    if handler is None:
        return None
    try:
        return handler(context, event, target, host=host)
    except Exception:
        return False


class LUMAFOLD_OT_sculpt_satellite_input_v4(bpy.types.Operator):
    """Universal per-Blender-Window input broker retained under its stable idname."""

    bl_idname = _SAT_BROKER_ID
    bl_label = "LumaFold Universal Sculpt Input v4"
    bl_options = {"INTERNAL"}

    def invoke(self, context, event):
        self._generation = _generation_now()
        self._window_ptr = _ptr(getattr(context, "window", None))
        if not self._window_ptr:
            return {"CANCELLED"}
        _RUNNING_SAT_WINDOWS.add(self._window_ptr)
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        _notify_input_observer("before", context, event)
        if int(getattr(self, "_generation", -1)) != _generation_now():
            _RUNNING_SAT_WINDOWS.discard(int(getattr(self, "_window_ptr", 0) or 0))
            result = {"FINISHED"}
            _notify_input_observer("after", context, event, result)
            return result

        host = None
        if _host_mode() != "satellite":
            candidate = getattr(STATE, "host", None)
            if candidate is not None and not bool(getattr(candidate, "closed", False)):
                host = candidate

        result = {"RUNNING_MODAL"} if _route_event(context, event, host=host) else {"PASS_THROUGH"}
        _notify_input_observer("after", context, event, result)
        return result


def _ensure_satellite_brokers():
    """Ensure one universal broker for each live Blender Window."""
    if not _INSTALLED:
        return None
    try:
        windows = tuple(bpy.context.window_manager.windows)
        live = {_ptr(window) for window in windows}
        _RUNNING_SAT_WINDOWS.intersection_update(live)
    except Exception:
        return 0.25

    for window in windows:
        ptr = _ptr(window)
        if not ptr or ptr in _RUNNING_SAT_WINDOWS:
            continue
        target = _best_view3d_context(window)
        if target is None:
            continue
        w, area, region = target
        try:
            with bpy.context.temp_override(window=w, area=area, region=region):
                result = bpy.ops.lumafold.sculpt_satellite_input_v4("INVOKE_DEFAULT")
            if "RUNNING_MODAL" in set(result or ()):
                _RUNNING_SAT_WINDOWS.add(ptr)
        except Exception:
            pass
    return 0.25


def _install_mode_commands():
    global _ORIGINAL_ENTER, _ORIGINAL_EXIT, _MODE_REQUEST_SERIAL
    if _APP is None:
        return
    commands = getattr(_APP.commands, "_commands", {})
    enter = commands.get("sculpt.enter")
    exit_to_object = commands.get("sculpt.exit_to_object")
    if callable(enter) and _ORIGINAL_ENTER is None:
        _ORIGINAL_ENTER = enter
    if callable(exit_to_object) and _ORIGINAL_EXIT is None:
        _ORIGINAL_EXIT = exit_to_object
    if not callable(_ORIGINAL_ENTER):
        return

    state = _APP.store.namespace("sculpt")
    state.pop("_mode_command_pending", None)

    def queue(command, target_mode: str, label: str):
        global _MODE_REQUEST_SERIAL
        _MODE_REQUEST_SERIAL += 1
        serial = int(_MODE_REQUEST_SERIAL)
        source_window_ptr = _ptr(getattr(bpy.context, "window", None))
        state["mode_request_serial"] = serial
        state["mode_request_status"] = label + " · 请求中"

        def run():
            if serial != int(_MODE_REQUEST_SERIAL):
                return None
            host = getattr(STATE, "host", None)
            _clear_gesture_registry()
            _reset_transient_input(host)
            try:
                current = str(getattr(bpy.context, "mode", "") or "").upper()
                if current != target_mode:
                    window = _window_by_ptr(source_window_ptr)
                    target = _best_view3d_context(window) if window is not None else _best_view3d_context()
                    if target is not None:
                        w, area, region = target
                        with bpy.context.temp_override(window=w, area=area, region=region):
                            command()
                    else:
                        command()
                try:
                    _APP.refresh_context(host_id=_host_mode())
                except Exception:
                    pass
                actual = str(getattr(bpy.context, "mode", "") or "").upper()
                state["mode_request_status"] = (
                    label + " · 完成" if actual == target_mode else f"{label} · Blender 当前={actual}"
                )
                # Mode switching is deferred out of the ImGui draw frame. The
                # command completes after the click frame was already rendered.
                # Refresh the existing Embedded Host and explicitly redraw its
                # View3D so SCULPT/OBJECT is visible without reopening LumaFold.
                try:
                    host = getattr(STATE, "host", None)
                    window = _window_by_ptr(source_window_ptr)
                    redraw_target = _best_view3d_context(window) if window is not None else _best_view3d_context()
                    if redraw_target is not None:
                        redraw_window, redraw_area, _redraw_region = redraw_target
                        if host is not None and not bool(getattr(host, "closed", False)):
                            try:
                                workspace_name = str(getattr(getattr(redraw_window, "workspace", None), "name", "") or "")
                                host.context_transition_pulse(workspace_name=workspace_name, mode=actual)
                            except Exception:
                                pass
                        try:
                            redraw_area.tag_redraw()
                        except Exception:
                            pass
                except Exception:
                    pass
            except Exception as exc:
                state["mode_request_status"] = f"{label}失败: {type(exc).__name__}: {exc}"
                try:
                    _APP.state.log(state["mode_request_status"])
                except Exception:
                    pass
            finally:
                _clear_gesture_registry()
                _reset_transient_input(host)
            return None

        if _host_mode() == "satellite":
            # Satellite commands are already dispatched on Blender's main-thread
            # bridge timer. Complete only this mode transition now so
            # no second timer is left pending behind the child UI.
            run()
            return str(state.get("mode_request_status") or (label + " · 完成"))

        try:
            bpy.app.timers.register(run, first_interval=0.01)
        except Exception:
            run()
        return label + " · 已请求"

    _APP.commands.register("sculpt.enter", lambda: queue(_ORIGINAL_ENTER, "SCULPT", "进入雕刻模式"))
    if callable(_ORIGINAL_EXIT):
        _APP.commands.register(
            "sculpt.exit_to_object",
            lambda: queue(_ORIGINAL_EXIT, "OBJECT", "返回 Object 模式"),
        )


def _restore_mode_commands():
    if _APP is None:
        return
    try:
        if callable(_ORIGINAL_ENTER):
            _APP.commands.register("sculpt.enter", _ORIGINAL_ENTER)
        if callable(_ORIGINAL_EXIT):
            _APP.commands.register("sculpt.exit_to_object", _ORIGINAL_EXIT)
    except Exception:
        pass


_CLASSES = (
    LUMAFOLD_OT_sculpt_z_left_runtime_v4,
    LUMAFOLD_OT_sculpt_z_right_runtime_v4,
    LUMAFOLD_OT_sculpt_satellite_input_v4,
)


def configure(app, sculpt_input_profile, shortcut_product, ui_patch, operators_module):
    global _APP, _SCULPT, _SHORTCUT_PRODUCT, _UI_PATCH, _OPERATORS
    if _APP is not None:
        return
    _APP = app
    _SCULPT = sculpt_input_profile
    _SHORTCUT_PRODUCT = shortcut_product
    _UI_PATCH = ui_patch
    _OPERATORS = operators_module
    _cleanup_legacy_pointer_keymaps()
    _install_mode_commands()


def register():
    global _INSTALLED
    if _INSTALLED:
        return
    _INSTALLED = True
    _RUNNING_SAT_WINDOWS.clear()
    _clear_gesture_registry()
    _bump_generation()
    _cleanup_legacy_pointer_keymaps()

    for cls in _CLASSES:
        try:
            bpy.utils.register_class(cls)
        except RuntimeError:
            try:
                bpy.utils.unregister_class(cls)
            except Exception:
                pass
            bpy.utils.register_class(cls)

    try:
        bpy.app.timers.register(_ensure_satellite_brokers, first_interval=0.20)
    except Exception:
        pass


def unregister():
    global _INSTALLED, _APP, _SCULPT, _SHORTCUT_PRODUCT, _UI_PATCH, _OPERATORS
    global _ORIGINAL_ENTER, _ORIGINAL_EXIT, _MODE_REQUEST_SERIAL
    global _ROUTE_HANDLER, _NAVIGATION_HANDLER, _INPUT_OBSERVER, _VIEW3D_REGION_RESOLVER

    _INSTALLED = False
    _bump_generation()
    _RUNNING_SAT_WINDOWS.clear()
    _clear_gesture_registry()
    _MODE_REQUEST_SERIAL += 1

    _restore_mode_commands()
    _cleanup_legacy_pointer_keymaps()
    _reset_transient_input(getattr(STATE, "host", None))

    for cls in reversed(_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass

    _ORIGINAL_ENTER = None
    _ORIGINAL_EXIT = None
    _ROUTE_HANDLER = None
    _NAVIGATION_HANDLER = None
    _INPUT_OBSERVER = None
    _VIEW3D_REGION_RESOLVER = None
    _APP = None
    _SCULPT = None
    _SHORTCUT_PRODUCT = None
    _UI_PATCH = None
    _OPERATORS = None
