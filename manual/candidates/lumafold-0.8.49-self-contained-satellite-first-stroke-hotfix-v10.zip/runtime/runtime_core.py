from __future__ import annotations

"""LumaFold runtime stability core.

This module is the single authority that bridges Blender Modal input with
transient LumaFold UI state.

Safety contract:
- Blender Modal never queries/draws ImGui popup/window state.
- ImGui popup truth is sampled only while a draw frame is active.
- Modal reads only pure-Python snapshots published by the draw frame.
- While a popup is open, pointer/ESC events are always delivered to the existing
  ImGui input bridge first.
- Popup selection and outside-dismissal share one event path: button events first
  refresh the exact pointer coordinate, then the normal UIHost bridge owns the
  press/release lifecycle.
- Blender consumes the pointer press while a popup is open, so the same click
  cannot both dismiss a popup and manipulate the viewport underneath it.
- Host transitions invalidate transient UI/gesture input only; Sculpt broker
  lifetime belongs exclusively to sculpt_input_core.
- Concrete Blender regions always win over Sculpt View routing.
"""

from ..core.host_control import HOST_CONTROL
from ..core.runtime_session import RUNTIME_SESSION
from ..core.state import STATE

_INSTALLED = False
_HOST_CLASS = None
_SCULPT_CORE = None
_INTERACTIONS = None
_GALLERY = None
_ORIGINAL_FEED = None
_ORIGINAL_CAPTURE = None
_ORIGINAL_DRAW_SCULPT = None
_UNSUBSCRIBE_HOST = None

_MOUSE_TYPES = {"LEFTMOUSE", "RIGHTMOUSE", "MIDDLEMOUSE"}
_CAPTURE_KEYS = set("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789") | {
    "ZERO", "ONE", "TWO", "THREE", "FOUR", "FIVE", "SIX", "SEVEN", "EIGHT", "NINE",
    "LEFT_CTRL", "RIGHT_CTRL", "LEFT_SHIFT", "RIGHT_SHIFT",
    "LEFT_ALT", "RIGHT_ALT", "ESC",
}
_POPUPS = (
    "Quick Brush Slot##context",
    "编辑快捷键##quick_shortcut_product",
    "LumaFold Brush Library##foundation",
    "LumaFold Alpha Library##foundation",
    "LumaFold More##foundation",
    "Brush Asset##library_context",
    "Alpha Asset##library_context",
)
_MAIN_SECONDARIES = {
    "LumaFold Brush Library##foundation": ("brush_library", "sculpt_brush_library_anchor", "sculpt_brush_library_popup_close_requested"),
    "LumaFold Alpha Library##foundation": ("alpha_library", "sculpt_alpha_library_anchor", "sculpt_alpha_library_popup_close_requested"),
    "LumaFold More##foundation": ("more", "sculpt_more_anchor", "sculpt_more_popup_close_requested"),
}
_ESC_PULSE = {"embedded": "idle"}


def _inside(region, mx: float, my: float) -> bool:
    try:
        return bool(
            float(region.x) <= mx < float(region.x + region.width)
            and float(region.y) <= my < float(region.y + region.height)
        )
    except Exception:
        return False


def _secondary_rect_from_surface(surface_state, names, scale: float):
    for popup_name, (kind, anchor_key, _close_key) in _MAIN_SECONDARIES.items():
        if popup_name not in names:
            continue
        anchor = dict(surface_state.get(anchor_key) or {})
        if not anchor:
            return None
        try:
            from ..ui.sculpt_view_foundation import secondary_surface_design_size
            width, height = secondary_surface_design_size(kind)
            left = float(anchor.get("x", 0.0))
            top = float(anchor.get("y", 0.0))
            return {
                "left": left,
                "top": top,
                "right": left + float(width) * float(scale),
                "bottom": top + float(height) * float(scale),
                "popup": popup_name,
            }
        except Exception:
            return None
    return None


def _concrete_view3d_region_under_pointer(context, event):
    """Return View3D WINDOW only when no Blender UI region owns the pointer."""
    window = getattr(context, "window", None)
    if window is None:
        try:
            import bpy
            window = getattr(bpy.context, "window", None)
        except Exception:
            window = None
    screen = getattr(window, "screen", None) if window is not None else None
    if screen is None:
        return None
    try:
        mx = float(event.mouse_x)
        my = float(event.mouse_y)
    except Exception:
        return None

    for area in tuple(getattr(screen, "areas", ()) or ()):
        if getattr(area, "type", "") != "VIEW_3D":
            continue
        regions = tuple(getattr(area, "regions", ()) or ())
        window_region = next((r for r in regions if getattr(r, "type", "") == "WINDOW"), None)
        if window_region is None or not _inside(window_region, mx, my):
            continue
        blocked = False
        for region in regions:
            if getattr(region, "type", "") == "WINDOW":
                continue
            try:
                if int(getattr(region, "width", 0) or 0) <= 0 or int(getattr(region, "height", 0) or 0) <= 0:
                    continue
            except Exception:
                continue
            if _inside(region, mx, my):
                blocked = True
                break
        if not blocked:
            return window, area, window_region
    return None


def _shortcut_popup_open() -> bool:
    return RUNTIME_SESSION.popup_named("embedded", "编辑快捷键##quick_shortcut_product")


def _collect_open_popups(imgui):
    names = []
    for name in _POPUPS:
        try:
            if bool(imgui.is_popup_open(name)):
                names.append(name)
        except Exception:
            continue
    return tuple(names)


def _request_product_secondary_close(surface_state, names) -> bool:
    requested = False
    for popup_name, (_kind, _anchor_key, close_key) in _MAIN_SECONDARIES.items():
        if popup_name in names:
            surface_state[close_key] = True
            requested = True
    return requested


def _prime_popup_pointer(self, event, region) -> None:
    try:
        if getattr(self, "closed", False):
            return
        self.renderer.ensure_context()
        if region is None:
            region = self._window_region()
        if region is None:
            return
        rx = float(event.mouse_x - region.x)
        ry = float(event.mouse_y - region.y)
        self.io.add_mouse_pos_event(rx, float(region.height - 1) - ry)
    except Exception:
        pass


def _draw_contract(imgui, surface_state, sculpt, scale, **kwargs):
    host_label = str(kwargs.get("host_label", "浮台") or "浮台").strip()
    host = "satellite" if host_label == "卫星" else "embedded"

    if host == "embedded" and RUNTIME_SESSION.close_requested(host):
        snapshot = RUNTIME_SESSION.popup_snapshot(host)
        if not _request_product_secondary_close(surface_state, snapshot.names):
            pulse = _ESC_PULSE.get(host, "idle")
            try:
                io = imgui.get_io()
                esc = imgui.Key.KEY_ESCAPE
                if pulse == "press":
                    io.add_key_event(esc, True)
                    _ESC_PULSE[host] = "release"
                elif pulse == "release":
                    io.add_key_event(esc, False)
                    _ESC_PULSE[host] = "idle"
                elif snapshot.names:
                    _ESC_PULSE[host] = "press"
            except Exception:
                _ESC_PULSE[host] = "idle"

    result = _ORIGINAL_DRAW_SCULPT(imgui, surface_state, sculpt, scale, **kwargs)

    if host == "embedded":
        names = _collect_open_popups(imgui)
        RUNTIME_SESSION.publish_popups(host, names)
        surface_state["_runtime_secondary_rect"] = _secondary_rect_from_surface(surface_state, names, scale)
        try:
            if _INTERACTIONS is not None:
                _INTERACTIONS._SHORTCUT_CAPTURE_ACTIVE = (
                    "编辑快捷键##quick_shortcut_product" in names
                )
        except Exception:
            pass
        if RUNTIME_SESSION.close_requested(host) and not names:
            RUNTIME_SESSION.acknowledge_close_request(host)
            _ESC_PULSE[host] = "idle"
            surface_state.pop("_runtime_secondary_rect", None)

    return result


def _on_host_transition(snapshot):
    core = _SCULPT_CORE
    if core is None:
        return
    RUNTIME_SESSION.clear_all()
    _ESC_PULSE["embedded"] = "idle"
    try:
        core._clear_gesture_registry()
    except Exception:
        pass
    try:
        core._reset_transient_input(getattr(STATE, "host", None))
    except Exception:
        pass


def install(host_class, sculpt_core, interactions, gallery_module):
    global _INSTALLED, _HOST_CLASS, _SCULPT_CORE, _INTERACTIONS, _GALLERY
    global _ORIGINAL_FEED, _ORIGINAL_CAPTURE, _ORIGINAL_DRAW_SCULPT, _UNSUBSCRIBE_HOST
    if _INSTALLED:
        return

    original_feed = getattr(host_class, "feed_event", None)
    original_capture = getattr(host_class, "should_capture", None)
    region_setter = getattr(sculpt_core, "set_view3d_region_resolver", None)
    original_draw = getattr(gallery_module, "draw_shared_sculpt_compact", None)
    if not all(callable(x) for x in (original_feed, original_capture, region_setter, original_draw)):
        raise RuntimeError("Runtime Core dependencies are incomplete")

    _HOST_CLASS = host_class
    _SCULPT_CORE = sculpt_core
    _INTERACTIONS = interactions
    _GALLERY = gallery_module
    _ORIGINAL_FEED = original_feed
    _ORIGINAL_CAPTURE = original_capture
    _ORIGINAL_DRAW_SCULPT = original_draw

    def feed_event(self, event, *, region=None):
        event_type = str(getattr(event, "type", "") or "")
        value = str(getattr(event, "value", "") or "").upper()
        popup_open = RUNTIME_SESSION.popup_open("embedded")

        if popup_open and event_type == "ESC" and value in {"PRESS", "RELEASE"}:
            previous = bool(STATE.capture_keyboard)
            STATE.capture_keyboard = True
            try:
                forwarded = _ORIGINAL_FEED(self, event, region=region)
            finally:
                STATE.capture_keyboard = previous
            if value == "PRESS":
                RUNTIME_SESSION.request_popup_close("embedded", reason="escape")
            return forwarded

        if popup_open and event_type in _MOUSE_TYPES and value in {"PRESS", "RELEASE"}:
            _prime_popup_pointer(self, event, region)
            previous = bool(STATE.capture_mouse)
            STATE.capture_mouse = True
            try:
                return _ORIGINAL_FEED(self, event, region=region)
            finally:
                STATE.capture_mouse = previous

        if _shortcut_popup_open():
            previous = bool(STATE.capture_keyboard)
            STATE.capture_keyboard = True
            try:
                return _ORIGINAL_FEED(self, event, region=region)
            finally:
                STATE.capture_keyboard = previous

        return _ORIGINAL_FEED(self, event, region=region)

    def should_capture(self, event):
        event_type = str(getattr(event, "type", "") or "")
        value = str(getattr(event, "value", "") or "").upper()
        if RUNTIME_SESSION.popup_open("embedded"):
            if event_type == "ESC" and value in {"PRESS", "RELEASE"}:
                return True
            if event_type in _MOUSE_TYPES and value in {"PRESS", "RELEASE"}:
                return True
        if _shortcut_popup_open() and event_type in _CAPTURE_KEYS and value in {"PRESS", "RELEASE"}:
            return True
        return _ORIGINAL_CAPTURE(self, event)

    host_class.feed_event = feed_event
    host_class.should_capture = should_capture
    region_setter(_concrete_view3d_region_under_pointer)
    gallery_module.draw_shared_sculpt_compact = _draw_contract
    _UNSUBSCRIBE_HOST = HOST_CONTROL.subscribe(_on_host_transition)
    _INSTALLED = True


def uninstall():
    global _INSTALLED, _HOST_CLASS, _SCULPT_CORE, _INTERACTIONS, _GALLERY
    global _ORIGINAL_FEED, _ORIGINAL_CAPTURE, _ORIGINAL_DRAW_SCULPT, _UNSUBSCRIBE_HOST
    if not _INSTALLED:
        return

    if _HOST_CLASS is not None:
        if callable(_ORIGINAL_FEED):
            _HOST_CLASS.feed_event = _ORIGINAL_FEED
        if callable(_ORIGINAL_CAPTURE):
            _HOST_CLASS.should_capture = _ORIGINAL_CAPTURE
    if _SCULPT_CORE is not None:
        setter = getattr(_SCULPT_CORE, "set_view3d_region_resolver", None)
        if callable(setter):
            setter(None)
    if _GALLERY is not None and callable(_ORIGINAL_DRAW_SCULPT):
        _GALLERY.draw_shared_sculpt_compact = _ORIGINAL_DRAW_SCULPT
    if callable(_UNSUBSCRIBE_HOST):
        try:
            _UNSUBSCRIBE_HOST()
        except Exception:
            pass

    RUNTIME_SESSION.clear_all()
    _ESC_PULSE["embedded"] = "idle"
    _HOST_CLASS = None
    _SCULPT_CORE = None
    _INTERACTIONS = None
    _GALLERY = None
    _ORIGINAL_FEED = None
    _ORIGINAL_CAPTURE = None
    _ORIGINAL_DRAW_SCULPT = None
    _UNSUBSCRIBE_HOST = None
    _INSTALLED = False
