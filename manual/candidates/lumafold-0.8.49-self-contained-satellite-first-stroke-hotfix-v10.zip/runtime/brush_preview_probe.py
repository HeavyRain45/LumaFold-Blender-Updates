from __future__ import annotations

import traceback
from pathlib import Path

import bpy

from ..core.app import APP


_NS_KEY = "LUMAFOLD_BRUSH_PREVIEW_PROBE_V1"


def _store():
    data = bpy.app.driver_namespace.get(_NS_KEY)
    if not isinstance(data, dict):
        data = {"status": "not run", "brush": "", "lines": [], "error": ""}
        bpy.app.driver_namespace[_NS_KEY] = data
    return data


def _preview_stats(preview):
    if preview is None:
        return "preview=None"

    def _safe_size(name):
        try:
            value = tuple(getattr(preview, name) or (0, 0))
            return f"{int(value[0])}x{int(value[1])}"
        except Exception as exc:
            return f"ERR:{type(exc).__name__}"

    def _safe_len(name):
        try:
            return str(len(getattr(preview, name)))
        except Exception as exc:
            return f"ERR:{type(exc).__name__}"

    try:
        icon_id = int(getattr(preview, "icon_id", 0) or 0)
    except Exception:
        icon_id = -1
    return (
        f"image={_safe_size('image_size')}/{_safe_len('image_pixels')} "
        f"icon={_safe_size('icon_size')}/{_safe_len('icon_pixels')} id={icon_id}"
    )


def _current_spec(service):
    try:
        fn = getattr(service, "_spec_for_current", None)
        if callable(fn):
            spec = fn()
            if spec:
                return dict(spec)
    except Exception:
        pass

    current = dict(service.current_sculpt_brush() or {})
    rel = str(current.get("relative_asset_identifier") or "").replace("\\", "/")
    name = rel.rsplit("/Brush/", 1)[-1] if "/Brush/" in rel else str(current.get("name") or "")
    source = ""
    try:
        if str(current.get("asset_library_type") or "") == "ESSENTIALS":
            path = service._essentials_sculpt_blend()
            source = str(path or "")
    except Exception:
        source = ""
    current.update({"name": name, "source_blend": source})
    return current


def _probe_loaded_brush(source: str, name: str, *, assets_only: bool, link: bool):
    loaded = []
    try:
        with bpy.data.libraries.load(source, assets_only=bool(assets_only), link=bool(link)) as (data_src, data_dst):
            available = set(getattr(data_src, "brushes", ()) or ())
            if name not in available:
                return "brush missing in library"
            data_dst.brushes = [name]
        loaded = [item for item in list(data_dst.brushes or ()) if item is not None]
        brush = loaded[0] if loaded else None
        if brush is None:
            return "loaded brush=None"
        try:
            preview = brush.preview_ensure()
        except Exception:
            preview = getattr(brush, "preview", None)
        return _preview_stats(preview)
    except Exception as exc:
        return f"ERR {type(exc).__name__}: {exc}"
    finally:
        for brush in loaded:
            try:
                bpy.data.brushes.remove(brush)
            except Exception:
                pass


def run_probe():
    out = _store()
    out.update({"status": "running", "brush": "", "lines": [], "error": ""})
    lines = []
    try:
        service = APP.services.require("blender.brush")
        current = dict(service.current_sculpt_brush() or {})
        spec = _current_spec(service)
        name = str(spec.get("name") or current.get("name") or "")
        source = str(spec.get("source_blend") or "")
        out["brush"] = name

        lines.append(f"Brush={name or '-'}")
        lines.append(f"Asset={str(current.get('asset_library_type') or '-')}/{str(current.get('relative_asset_identifier') or '-')[-48:]}")
        lines.append(f"Source={'YES' if source and Path(source).is_file() else 'NO'} · {Path(source).name if source else '-'}")

        paint = service._sculpt_paint() if hasattr(service, "_sculpt_paint") else None
        brush = getattr(paint, "brush", None) if paint is not None else None
        try:
            runtime_preview = brush.preview_ensure() if brush is not None else None
        except Exception:
            runtime_preview = getattr(brush, "preview", None) if brush is not None else None
        lines.append("runtime: " + _preview_stats(runtime_preview))

        if source and Path(source).is_file() and name:
            lines.append("assets_only: " + _probe_loaded_brush(source, name, assets_only=True, link=False))
            lines.append("linked_id: " + _probe_loaded_brush(source, name, assets_only=False, link=True))

            import bpy.utils.previews
            pcoll = bpy.utils.previews.new()
            try:
                try:
                    p = pcoll.load("blend_file", source, 'BLEND', force_reload=True)
                    lines.append("thumb .blend: " + _preview_stats(p))
                except Exception as exc:
                    lines.append(f"thumb .blend: ERR {type(exc).__name__}: {exc}")

                id_path = str(Path(source).resolve()).replace("\\", "/") + f"/Brush/{name}"
                try:
                    p = pcoll.load("blend_id", id_path, 'BLEND', force_reload=True)
                    lines.append("thumb /Brush/: " + _preview_stats(p))
                except Exception as exc:
                    lines.append(f"thumb /Brush/: ERR {type(exc).__name__}: {exc}")
            finally:
                try:
                    bpy.utils.previews.remove(pcoll)
                except Exception:
                    pass
        else:
            lines.append("library probes skipped: no source .blend")

        try:
            asset = getattr(bpy.context, "asset", None)
            if asset is None:
                lines.append("context.asset=None")
            else:
                props = []
                for prop in ("name", "id_type", "full_library_path", "full_path", "local_id"):
                    props.append(f"{prop}={'Y' if getattr(asset, prop, None) else '-'}")
                lines.append("context.asset: " + " ".join(props))
        except Exception as exc:
            lines.append(f"context.asset: ERR {type(exc).__name__}: {exc}")

        try:
            debug_fn = getattr(service, "preview_debug_snapshot", None)
            if callable(debug_fn):
                debug = dict(debug_fn() or {})
                lines.append(
                    "service: last={} hits={} misses={} packed={}".format(
                        debug.get("last_preview_path", "-"),
                        debug.get("thumbnail_hits", 0),
                        debug.get("thumbnail_misses", 0),
                        debug.get("packed_decode_hits", 0),
                    )
                )
        except Exception:
            pass

        out.update({"status": "complete", "lines": lines[-12:]})
    except Exception:
        out.update({"status": "failed", "error": traceback.format_exc(), "lines": lines[-12:]})
    return dict(out)


def snapshot():
    data = dict(_store())
    data["lines"] = list(data.get("lines") or ())
    return data


class LUMAFOLD_OT_dev_brush_preview_probe(bpy.types.Operator):
    bl_idname = "lumafold.dev_brush_preview_probe"
    bl_label = "探测 Brush 缩略图链"
    bl_description = "实机检测 Blender 5.2 当前 Brush、Library ID 与 Thumbnail Manager 是否返回真实 Preview 像素"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        result = run_probe()
        if result.get("status") == "complete":
            self.report({'INFO'}, "Brush Preview Probe 完成")
            return {'FINISHED'}
        self.report({'ERROR'}, "Brush Preview Probe 失败")
        return {'CANCELLED'}


CLASSES = (LUMAFOLD_OT_dev_brush_preview_probe,)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
