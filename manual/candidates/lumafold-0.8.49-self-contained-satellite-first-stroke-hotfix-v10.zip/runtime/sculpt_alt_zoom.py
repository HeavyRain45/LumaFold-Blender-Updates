from __future__ import annotations

"""Continuous ZBrush-style Alt zoom adapter.

This module owns only the deliberate ZBrush Scale gesture. Ordinary View3D
zoom/rotate remains Blender-owned elsewhere. Blender's public ``view3d.zoom``
EXEC API accepts an integer delta, which is inherently stepped for tablet
motion; this adapter therefore applies a continuous distance factor only while
an Alt gesture explicitly owns Scale.
"""

import math


# dev79e: +3% from the validated dev79d continuous feel.
ZOOM_LOG_GAIN = 0.0028325
_MIN_VIEW_DISTANCE = 1.0e-6
_MAX_VIEW_DISTANCE = 1.0e12


def _normalized_motion(dx: float, dy: float) -> float:
    """Right/down zoom in; left/up zoom out, with diagonal speed normalized."""
    return (float(dx) - float(dy)) / math.sqrt(2.0)


def apply(context, dx: float, dy: float) -> bool:
    """Apply one smooth tablet zoom sample to the current RegionView3D."""
    rv3d = getattr(context, "region_data", None)
    if rv3d is None:
        return False
    try:
        current = float(rv3d.view_distance)
        if current <= 0.0:
            return False
        motion = _normalized_motion(dx, dy)
        if abs(motion) < 1.0e-6:
            return True
        factor = math.exp(-motion * ZOOM_LOG_GAIN)
        rv3d.view_distance = max(_MIN_VIEW_DISTANCE, min(_MAX_VIEW_DISTANCE, current * factor))
        rv3d.update()
        area = getattr(context, "area", None)
        if area is not None:
            area.tag_redraw()
        return True
    except Exception:
        return False
