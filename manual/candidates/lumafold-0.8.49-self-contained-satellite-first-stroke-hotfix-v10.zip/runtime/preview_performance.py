from __future__ import annotations

"""Main-thread performance guard for Preview prewarm and first Sculpt stroke.

This layer owns *when* preview background work may run. The preview scheduler
owns *what* needs to become resident. Keeping those responsibilities separate
lets Brush and Alpha prewarm share one input-safety policy without either asset
module reaching into Host/Input internals.

Important ownership rule: performance policy may delay preview work, but it must
never silently discard identities accepted by the scheduler. UI request maps use
"requested" as an in-flight truth, so dropping the tail of one request can leave
visible tiles permanently stuck in placeholder state until a later idle prewarm.
"""

import time

import bpy
from mathutils import Vector

_INSTALLED = False
_ORIGINAL_TICK = None
_ORIGINAL_ALPHA_TICK = None
_ORIGINAL_CONSTANTS = None
_INPUT_PROFILE = None
_PREVIEW_MODULE = None
_WARMED_OBJECT_KEY = None
_WARM_TIMER_ACTIVE = False
_CONFIGURED_AT = 0.0


def _user_busy(input_profile) -> bool:
    try:
        if float(input_profile.seconds_since_interaction()) < 0.80:
            return True
    except Exception:
        pass

    # A LumaFold floating host is itself a long-lived modal operator. Treating
    # *any* modal as busy made preview prewarm effectively stay asleep forever.
    # Ignore our own persistent hosts, but still yield to Blender tools and
    # third-party modal operations.
    try:
        window = getattr(bpy.context, "window", None)
        modals = getattr(window, "modal_operators", ()) if window is not None else ()
        for modal in tuple(modals or ()):
            ident = str(getattr(modal, "bl_idname", "") or "").lower()
            if "lumafold" in ident:
                continue
            return True
    except Exception:
        pass
    return False


def _find_view3d_override(obj):
    wm = getattr(bpy.context, "window_manager", None)
    for window in tuple(getattr(wm, "windows", ()) or ()):
        screen = getattr(window, "screen", None)
        for area in tuple(getattr(screen, "areas", ()) or ()):
            if getattr(area, "type", "") != "VIEW_3D":
                continue
            region = next(
                (r for r in tuple(getattr(area, "regions", ()) or ()) if getattr(r, "type", "") == "WINDOW"),
                None,
            )
            if region is not None:
                return window, area, region
    return None


def _warm_object_raycast(obj):
    """Build the regular object-ray BVH without touching mesh geometry."""
    try:
        bounds = [Vector(corner) for corner in obj.bound_box]
        if not bounds:
            return
        center = sum(bounds, Vector((0.0, 0.0, 0.0))) / float(len(bounds))
        xs = [p.x for p in bounds]; ys = [p.y for p in bounds]; zs = [p.z for p in bounds]
        span = max(max(xs) - min(xs), max(ys) - min(ys), max(zs) - min(zs), 1.0)
        origin = center + Vector((0.0, 0.0, span * 2.0 + 1.0))
        direction = Vector((0.0, 0.0, -1.0))
        depsgraph = bpy.context.evaluated_depsgraph_get()
        obj.ray_cast(origin, direction, depsgraph=depsgraph)
    except Exception:
        pass


def _warm_sculpt_tick():
    global _WARMED_OBJECT_KEY, _WARM_TIMER_ACTIVE
    if not _INSTALLED:
        _WARM_TIMER_ACTIVE = False
        return None

    if time.monotonic() - _CONFIGURED_AT < 0.75:
        return 0.20

    try:
        if str(getattr(bpy.context, "mode", "") or "").upper() != "SCULPT":
            return 0.20
    except Exception:
        return 0.20

    if _INPUT_PROFILE is not None and _user_busy(_INPUT_PROFILE):
        return 0.20

    obj = getattr(bpy.context, "sculpt_object", None)
    if obj is None or getattr(obj, "type", "") != "MESH":
        return 0.25
    try:
        key = (int(obj.as_pointer()), int(obj.data.as_pointer()))
    except Exception:
        key = (id(obj), id(getattr(obj, "data", None)))
    if key == _WARMED_OBJECT_KEY:
        return 0.80

    override = _find_view3d_override(obj)
    if override is not None:
        window, area, region = override
        try:
            with bpy.context.temp_override(
                window=window,
                area=area,
                region=region,
                object=obj,
                active_object=obj,
            ):
                bpy.ops.sculpt.optimize("EXEC_DEFAULT")
        except Exception:
            pass
    _warm_object_raycast(obj)
    _WARMED_OBJECT_KEY = key
    return 0.80


def configure(preview_module, input_profile):
    """Configure pacing before preview_module.install() and start idle warm-up.

    Every identity offered to ``preview_module._queue_more`` remains owned by the
    scheduler until processed. The performance layer changes chunk size and time
    spacing only; it never slices request lists.
    """
    global _INSTALLED, _ORIGINAL_TICK, _ORIGINAL_ALPHA_TICK, _ORIGINAL_CONSTANTS
    global _INPUT_PROFILE, _PREVIEW_MODULE, _WARM_TIMER_ACTIVE, _CONFIGURED_AT
    if _INSTALLED:
        return
    _INSTALLED = True
    _INPUT_PROFILE = input_profile
    _PREVIEW_MODULE = preview_module
    _CONFIGURED_AT = time.monotonic()

    _ORIGINAL_CONSTANTS = (
        preview_module._FOREGROUND_CHUNK,
        preview_module._BACKGROUND_CHUNK,
        preview_module._PUMP_INTERVAL,
        preview_module._PREWARM_FIRST_DELAY,
        preview_module._PREWARM_IDLE_POLL,
    )

    # Never perform preview extraction on the library click frame. All visible
    # identities enter the scheduler's lossless queue and are extracted one at a
    # time. 50 ms pacing keeps input frames between jobs while allowing a full
    # visible 16-tile page to become resident in well under a second when native
    # thumbnails are already warm.
    preview_module._FOREGROUND_CHUNK = 0
    preview_module._BACKGROUND_CHUNK = 1
    preview_module._PUMP_INTERVAL = 0.050
    preview_module._PREWARM_FIRST_DELAY = 1.00
    preview_module._PREWARM_IDLE_POLL = 1.00

    _ORIGINAL_TICK = preview_module._brush_prewarm_tick
    _ORIGINAL_ALPHA_TICK = preview_module._alpha_prewarm_tick

    def idle_brush_tick():
        if _user_busy(input_profile):
            return 0.30
        return _ORIGINAL_TICK()

    def idle_alpha_tick():
        if _user_busy(input_profile):
            return 0.30
        return _ORIGINAL_ALPHA_TICK()

    preview_module._brush_prewarm_tick = idle_brush_tick
    preview_module._alpha_prewarm_tick = idle_alpha_tick

    if not _WARM_TIMER_ACTIVE:
        _WARM_TIMER_ACTIVE = True
        try:
            bpy.app.timers.register(_warm_sculpt_tick, first_interval=0.80)
        except Exception:
            _WARM_TIMER_ACTIVE = False


def unconfigure():
    """Stop performance guards and restore the preview module for clean re-register."""
    global _INSTALLED, _ORIGINAL_TICK, _ORIGINAL_ALPHA_TICK, _ORIGINAL_CONSTANTS
    global _INPUT_PROFILE, _PREVIEW_MODULE, _WARMED_OBJECT_KEY
    _INSTALLED = False

    module = _PREVIEW_MODULE
    if module is not None:
        if _ORIGINAL_TICK is not None:
            module._brush_prewarm_tick = _ORIGINAL_TICK
        if _ORIGINAL_ALPHA_TICK is not None:
            module._alpha_prewarm_tick = _ORIGINAL_ALPHA_TICK
        if _ORIGINAL_CONSTANTS is not None:
            (
                module._FOREGROUND_CHUNK,
                module._BACKGROUND_CHUNK,
                module._PUMP_INTERVAL,
                module._PREWARM_FIRST_DELAY,
                module._PREWARM_IDLE_POLL,
            ) = _ORIGINAL_CONSTANTS

    _ORIGINAL_TICK = None
    _ORIGINAL_ALPHA_TICK = None
    _ORIGINAL_CONSTANTS = None
    _INPUT_PROFILE = None
    _PREVIEW_MODULE = None
    _WARMED_OBJECT_KEY = None
