from __future__ import annotations

"""Temporary native Hide / Trim tool-family session for ZBrush Ctrl+Shift.

Proof scope:
- Ctrl+Shift while a normal Sculpt tool is active temporarily activates the
  last selected native Blender Hide / Trim WorkSpaceTool.
- While the chord is held, Blender's own toolbar may switch between Box Hide
  and Trim variants. The active native tool is authoritative.
- The 3D View gesture itself is Blender-owned. LumaFold does not draw a second
  marquee, duplicate trim/hide geometry, or mutate mesh data.
- Releasing either modifier restores the exact pre-session Sculpt tool, but
  restoration is deferred until Blender reports the in-progress native gesture complete.
- Explicitly choosing a native Hide / Trim tool outside a LumaFold session stays
  Blender-owned and is never auto-restored.

All state is runtime-only. No user keymap, Preferences, Theme, startup file, or
persistent Blender configuration is modified.
"""

import time

import bpy


BOX_HIDE_TOOL_ID = "builtin.box_hide"
LASSO_HIDE_TOOL_ID = "builtin.lasso_hide"
LINE_HIDE_TOOL_ID = "builtin.line_hide"
POLYLINE_HIDE_TOOL_ID = "builtin.polyline_hide"

BOX_TRIM_TOOL_ID = "builtin.box_trim"
LASSO_TRIM_TOOL_ID = "builtin.lasso_trim"
LINE_TRIM_TOOL_ID = "builtin.line_trim"
POLYLINE_TRIM_TOOL_ID = "builtin.polyline_trim"

_TOOL_SPECS = {
    BOX_HIDE_TOOL_ID: ("paint.hide_show", ("area",)),
    LASSO_HIDE_TOOL_ID: (
        "paint.hide_show_lasso_gesture",
        ("area", "use_smooth_stroke", "smooth_stroke_radius", "smooth_stroke_factor"),
    ),
    LINE_HIDE_TOOL_ID: ("paint.hide_show_line_gesture", ("use_limit_to_segment",)),
    POLYLINE_HIDE_TOOL_ID: ("paint.hide_show_polyline_gesture", ("area",)),
    BOX_TRIM_TOOL_ID: (
        "sculpt.trim_box_gesture",
        ("trim_solver", "trim_mode", "trim_orientation", "trim_extrude_mode", "use_cursor_depth"),
    ),
    LASSO_TRIM_TOOL_ID: (
        "sculpt.trim_lasso_gesture",
        (
            "trim_solver",
            "trim_mode",
            "trim_orientation",
            "trim_extrude_mode",
            "use_cursor_depth",
            "use_smooth_stroke",
            "smooth_stroke_radius",
            "smooth_stroke_factor",
        ),
    ),
    LINE_TRIM_TOOL_ID: (
        "sculpt.trim_line_gesture",
        (
            "trim_solver",
            "trim_orientation",
            "trim_extrude_mode",
            "use_cursor_depth",
            "use_limit_to_segment",
        ),
    ),
    POLYLINE_TRIM_TOOL_ID: (
        "sculpt.trim_polyline_gesture",
        ("trim_solver", "trim_mode", "trim_orientation", "trim_extrude_mode", "use_cursor_depth"),
    ),
}
NATIVE_VISIBILITY_TOOL_IDS = frozenset(_TOOL_SPECS)
_HIDE_TOOL_IDS = frozenset(
    {BOX_HIDE_TOOL_ID, LASSO_HIDE_TOOL_ID, LINE_HIDE_TOOL_ID, POLYLINE_HIDE_TOOL_ID}
)
_TRIM_TOOL_IDS = frozenset(
    {BOX_TRIM_TOOL_ID, LASSO_TRIM_TOOL_ID, LINE_TRIM_TOOL_ID, POLYLINE_TRIM_TOOL_ID}
)
_POLICY_TOOL_TO_BL_IDNAME = {
    BOX_HIDE_TOOL_ID: "LUMAFOLD_OT_sculpt_visibility_rect",
    LASSO_HIDE_TOOL_ID: "LUMAFOLD_OT_sculpt_visibility_lasso",
    LINE_HIDE_TOOL_ID: "LUMAFOLD_OT_sculpt_visibility_line",
    POLYLINE_HIDE_TOOL_ID: "LUMAFOLD_OT_sculpt_visibility_polyline",
}
_TOOL_TO_BL_IDNAME = {
    BOX_HIDE_TOOL_ID: "PAINT_OT_hide_show",
    LASSO_HIDE_TOOL_ID: "PAINT_OT_hide_show_lasso_gesture",
    LINE_HIDE_TOOL_ID: "PAINT_OT_hide_show_line_gesture",
    POLYLINE_HIDE_TOOL_ID: "PAINT_OT_hide_show_polyline_gesture",
    BOX_TRIM_TOOL_ID: "SCULPT_OT_trim_box_gesture",
    LASSO_TRIM_TOOL_ID: "SCULPT_OT_trim_lasso_gesture",
    LINE_TRIM_TOOL_ID: "SCULPT_OT_trim_line_gesture",
    POLYLINE_TRIM_TOOL_ID: "SCULPT_OT_trim_polyline_gesture",
}

_POLL_INTERVAL = 0.10
_GESTURE_TIMEOUT = 120.0
_INSTALLED = False
_INPUT_CORE = None
_TRACE = None
_MASK_TOOL_BRIDGE = None
_STATES = {}
_TIMER_RUNNING = False


def _trace(reason: str, **extra) -> None:
    trace = _TRACE
    if trace is None:
        return
    try:
        trace.trace("VISIBILITY_NATIVE_TOOL_SESSION", reason=str(reason), **extra)
    except Exception:
        pass


def _trace_state(reason: str, context, state: dict, event=None, **extra) -> None:
    """Capture the whole temporary-tool ownership state without changing behavior."""
    state = state or {}
    workspace = _workspace(context)
    payload = {
        "context_mode": str(getattr(context, "mode", "") or "") if context is not None else "",
        "area_type": str(getattr(getattr(context, "area", None), "type", "") or "") if context is not None else "",
        "region_type": str(getattr(getattr(context, "region", None), "type", "") or "") if context is not None else "",
        "active_tool": _active_tool_id(workspace) if workspace is not None else "",
        "selected_tool": str(state.get("selected_tool") or ""),
        "base_tool": str(state.get("base_tool") or ""),
        "session_tool": str(state.get("session_tool") or ""),
        "restore_tool": str(state.get("restore_tool") or ""),
        "session_active": bool(state.get("session_active")),
        "ctrl_held": bool(state.get("ctrl_held")),
        "shift_held": bool(state.get("shift_held")),
        "pointer_down": bool(state.get("pointer_down")),
        "restore_pending": bool(state.get("restore_pending")),
        "gesture_active": bool(state.get("gesture_active")),
        "gesture_owner": str(state.get("gesture_owner") or ""),
        "gesture_bl_idname": str(state.get("gesture_bl_idname") or ""),
    }
    try:
        operators = tuple(context.window_manager.operators) if context is not None else ()
        payload["newest_operator"] = str(getattr(operators[-1], "bl_idname", "") or "") if operators else ""
    except Exception:
        payload["newest_operator"] = ""
    if event is not None:
        payload.update(
            {
                "event_type": str(getattr(event, "type", "") or "").upper(),
                "event_value": str(getattr(event, "value", "") or "").upper(),
                "event_ctrl": bool(getattr(event, "ctrl", False)),
                "event_shift": bool(getattr(event, "shift", False)),
            }
        )
    payload.update(extra)
    _trace(reason, **payload)


def _ptr(value) -> int:
    try:
        return int(value.as_pointer())
    except Exception:
        return 0


def _workspace(context=None):
    workspace = getattr(context, "workspace", None) if context is not None else None
    if workspace is None:
        try:
            workspace = bpy.context.workspace
        except Exception:
            workspace = None
    return workspace


def _state(workspace) -> dict:
    key = _ptr(workspace) or id(workspace)
    state = _STATES.get(key)
    if state is None:
        state = {
            "selected_tool": BOX_HIDE_TOOL_ID,
            "base_tool": "",
            "session_active": False,
            "session_tool": "",
            "restore_tool": "",
            "ctrl_held": False,
            "shift_held": False,
            "pointer_down": False,
            "restore_pending": False,
            "restore_blocked_signature": "",
            "gesture_active": False,
            "gesture_owner": "",
            "gesture_tool": "",
            "gesture_bl_idname": "",
            "gesture_before_ops": frozenset(),
            "gesture_deadline": 0.0,
            "gesture_cancel_pending": False,
        }
        _STATES[key] = state
    return state


def _active_tool(workspace):
    if workspace is None:
        return None
    try:
        tool = workspace.tools.from_space_view3d_mode("SCULPT", create=False)
        if tool is not None:
            try:
                tool.refresh_from_context()
            except Exception:
                pass
        return tool
    except Exception:
        return None


def _active_tool_id(workspace) -> str:
    try:
        return str(getattr(_active_tool(workspace), "idname", "") or "")
    except Exception:
        return ""


def _context_is_sculpt(context=None) -> bool:
    try:
        mode = str(getattr(context, "mode", "") or "") if context is not None else ""
        if not mode:
            mode = str(getattr(bpy.context, "mode", "") or "")
        return mode.upper() == "SCULPT"
    except Exception:
        return False


def _zbrush_product_active() -> bool:
    core = _INPUT_CORE
    if core is None:
        return False
    try:
        return bool(core._product_active() and core._profile() == "zbrush")
    except Exception:
        return False


def _view3d_target(context=None):
    window = getattr(context, "window", None) if context is not None else None
    area = getattr(context, "area", None) if context is not None else None
    region = getattr(context, "region", None) if context is not None else None

    if window is None:
        try:
            window = bpy.context.window
        except Exception:
            window = None
    if window is None:
        return None

    if area is None or getattr(area, "type", "") != "VIEW_3D":
        screen = getattr(window, "screen", None)
        area = next(
            (
                item
                for item in tuple(getattr(screen, "areas", ()) or ())
                if getattr(item, "type", "") == "VIEW_3D"
            ),
            None,
        )
    if area is None:
        return None

    if region is None or getattr(region, "type", "") != "WINDOW":
        region = next(
            (
                item
                for item in tuple(getattr(area, "regions", ()) or ())
                if getattr(item, "type", "") == "WINDOW"
            ),
            None,
        )
    if region is None:
        return None
    return window, area, region


def _event_over_view3d_window(context, event) -> bool:
    """Use Sculpt Input Core's authoritative resolver so Blender UI regions win."""
    core = _INPUT_CORE
    resolver = getattr(core, "_view3d_region_under_pointer", None) if core is not None else None
    if not callable(resolver):
        return False
    try:
        return resolver(context, event) is not None
    except Exception:
        return False


def _tool_operator_values(workspace, operator_id: str, names) -> dict:
    """Read only public native WorkSpaceTool operator settings."""
    tool = _active_tool(workspace)
    if tool is None:
        return {}
    try:
        props = tool.operator_properties(operator_id)
    except Exception:
        return {}
    values = {}
    for name in names:
        try:
            value = getattr(props, name)
        except Exception:
            continue
        if isinstance(value, (str, bool, int, float)):
            values[str(name)] = value
    return values


def _operator_history_sentinel(context) -> frozenset[int]:
    try:
        return frozenset(_ptr(op) for op in tuple(context.window_manager.operators))
    except Exception:
        return frozenset()


def _gesture_completed(context, state: dict) -> bool:
    if not bool(state.get("gesture_active")):
        return True
    expected = str(state.get("gesture_bl_idname") or "")
    if not expected:
        return False
    before_ops = state.get("gesture_before_ops") or frozenset()
    try:
        operators = tuple(context.window_manager.operators)
    except Exception:
        return False
    for operator in reversed(operators):
        pointer = _ptr(operator)
        if pointer in before_ops:
            continue
        try:
            if str(operator.bl_idname) == expected:
                return True
        except Exception:
            continue
    return False


def _finish_gesture_state(state: dict, *, reason: str) -> None:
    tool_id = str(state.get("gesture_tool") or "")
    owner = str(state.get("gesture_owner") or "")
    state["gesture_active"] = False
    state["gesture_owner"] = ""
    state["gesture_tool"] = ""
    state["gesture_bl_idname"] = ""
    state["gesture_before_ops"] = frozenset()
    state["gesture_deadline"] = 0.0
    state["gesture_cancel_pending"] = False
    state["pointer_down"] = False
    _trace(reason, tool=tool_id, owner=owner)


def _invoke_native_gesture(context, target, tool_id: str) -> bool:
    """Invoke exactly one Blender-native Hide/Trim gesture for the active WorkSpaceTool."""
    if target is None or tool_id not in _TOOL_SPECS:
        return False
    workspace = _workspace(context)
    if workspace is None:
        return False
    operator_id, property_names = _TOOL_SPECS[tool_id]
    kwargs = _tool_operator_values(workspace, operator_id, property_names)
    if tool_id in _HIDE_TOOL_IDS:
        kwargs["action"] = "HIDE"

    window, area, region = target
    try:
        with bpy.context.temp_override(window=window, area=area, region=region):
            if tool_id == BOX_HIDE_TOOL_ID:
                result = set(bpy.ops.paint.hide_show("INVOKE_REGION_WIN", **kwargs) or ())
            elif tool_id == LASSO_HIDE_TOOL_ID:
                result = set(
                    bpy.ops.paint.hide_show_lasso_gesture("INVOKE_REGION_WIN", **kwargs) or ()
                )
            elif tool_id == LINE_HIDE_TOOL_ID:
                result = set(
                    bpy.ops.paint.hide_show_line_gesture("INVOKE_REGION_WIN", **kwargs) or ()
                )
            elif tool_id == POLYLINE_HIDE_TOOL_ID:
                result = set(
                    bpy.ops.paint.hide_show_polyline_gesture("INVOKE_REGION_WIN", **kwargs) or ()
                )
            elif tool_id == BOX_TRIM_TOOL_ID:
                result = set(
                    bpy.ops.sculpt.trim_box_gesture("INVOKE_REGION_WIN", **kwargs) or ()
                )
            elif tool_id == LASSO_TRIM_TOOL_ID:
                result = set(
                    bpy.ops.sculpt.trim_lasso_gesture("INVOKE_REGION_WIN", **kwargs) or ()
                )
            elif tool_id == LINE_TRIM_TOOL_ID:
                result = set(
                    bpy.ops.sculpt.trim_line_gesture("INVOKE_REGION_WIN", **kwargs) or ()
                )
            elif tool_id == POLYLINE_TRIM_TOOL_ID:
                result = set(
                    bpy.ops.sculpt.trim_polyline_gesture("INVOKE_REGION_WIN", **kwargs) or ()
                )
            else:
                return False
        return bool(result & {"RUNNING_MODAL", "FINISHED"})
    except (RuntimeError, TypeError, AttributeError):
        return False

def handle_pointer_press(context, event, target):
    """Bridge the held chord into one Blender-native Hide/Trim modal.

    The physical Ctrl+Shift chord does not match Blender's unmodified gesture
    tool keymaps. LumaFold only starts the active WorkSpaceTool operator and
    then leaves the whole modal lifecycle and mesh mutation to Blender.
    """
    if str(getattr(event, "type", "") or "").upper() != "LEFTMOUSE":
        return None
    if str(getattr(event, "value", "") or "").upper() != "PRESS":
        return None
    workspace = _workspace(context)
    if workspace is None:
        return False
    state = _state(workspace)
    if not state.get("session_active"):
        return None
    if not bool(state.get("ctrl_held") and state.get("shift_held")):
        return None
    if bool(state.get("gesture_active")):
        return False

    active_id = _active_tool_id(workspace)
    if active_id not in NATIVE_VISIBILITY_TOOL_IDS:
        active_id = str(state.get("session_tool") or state.get("selected_tool") or "")
    if active_id not in NATIVE_VISIBILITY_TOOL_IDS:
        return False

    before_ops = _operator_history_sentinel(context)
    ok = _invoke_native_gesture(context, target, active_id)
    if ok:
        _record_selected(state, active_id, reason="native_gesture_tool")
        state["session_tool"] = active_id
        state["pointer_down"] = True
        state["gesture_active"] = True
        state["gesture_owner"] = "NATIVE"
        state["gesture_tool"] = active_id
        state["gesture_bl_idname"] = str(_TOOL_TO_BL_IDNAME.get(active_id, ""))
        state["gesture_before_ops"] = before_ops
        state["gesture_deadline"] = time.monotonic() + _GESTURE_TIMEOUT
        state["gesture_cancel_pending"] = False
        _trace(
            "native_gesture_started",
            tool=active_id,
            operator=str(state["gesture_bl_idname"]),
        )
    else:
        _trace("native_gesture_start_failed", tool=active_id)
    return ok

def _set_tool(context, tool_id: str) -> bool:
    tool_id = str(tool_id or "")
    if not tool_id:
        return False
    target = _view3d_target(context)
    if target is None:
        return False
    window, area, region = target
    try:
        with bpy.context.temp_override(window=window, area=area, region=region):
            result = set(
                bpy.ops.wm.tool_set_by_id(
                    "EXEC_DEFAULT",
                    name=tool_id,
                    space_type="VIEW_3D",
                )
                or ()
            )
        return "FINISHED" in result
    except (RuntimeError, TypeError, AttributeError):
        return False


def _record_selected(state: dict, tool_id: str, *, reason: str) -> None:
    tool_id = str(tool_id or "")
    if tool_id not in NATIVE_VISIBILITY_TOOL_IDS:
        return
    previous = str(state.get("selected_tool") or "")
    state["selected_tool"] = tool_id
    if tool_id != previous:
        _trace(reason, tool=tool_id, previous_tool=previous)


def _clear_session(state: dict, *, context=None, reason: str = "clear_session") -> None:
    _trace_state(reason + "_before_clear", context, state)
    state["session_active"] = False
    state["session_tool"] = ""
    state["restore_tool"] = ""
    state["pointer_down"] = False
    state["restore_pending"] = False
    state["restore_blocked_signature"] = ""
    state["gesture_active"] = False
    state["gesture_owner"] = ""
    state["gesture_tool"] = ""
    state["gesture_bl_idname"] = ""
    state["gesture_before_ops"] = frozenset()
    state["gesture_deadline"] = 0.0
    state["gesture_cancel_pending"] = False


def _observe_native_tool(context=None) -> str:
    workspace = _workspace(context)
    if workspace is None:
        return ""
    state = _state(workspace)
    active_id = _active_tool_id(workspace)

    if state.get("session_active"):
        session_tool = str(state.get("session_tool") or "")
        if active_id == session_tool:
            return active_id

        # Once LumaFold owns a Ctrl+Shift session, any explicit switch inside
        # Blender's native Hide/Trim family is part of that same temporary
        # session. Absorb it even if the toolbar click and modifier-release
        # events arrive in a different order.
        if active_id in NATIVE_VISIBILITY_TOOL_IDS:
            _record_selected(state, active_id, reason="ctrl_shift_tool_changed")
            state["session_tool"] = active_id
            _trace_state(
                "ctrl_shift_session_tool_changed",
                context,
                state,
                previous_tool=session_tool,
                tool=active_id,
            )
            return active_id

        # A switch to any non-family tool is a genuine external choice. Respect
        # it and relinquish ownership instead of forcing our restore target.
        _trace_state(
            "ctrl_shift_session_relinquished",
            context,
            state,
            observed_active_tool=active_id,
        )
        _clear_session(
            state,
            context=context,
            reason="ctrl_shift_session_relinquished",
        )

    if active_id in NATIVE_VISIBILITY_TOOL_IDS:
        _record_selected(state, active_id, reason="explicit_native_tool_selected")
        return active_id

    if active_id:
        previous_base = str(state.get("base_tool") or "")
        state["base_tool"] = active_id
        if active_id != previous_base:
            _trace_state(
                "base_tool_updated",
                context,
                state,
                previous_base_tool=previous_base,
            )
    return active_id

def _suspend_mask_session(context=None) -> None:
    bridge = _MASK_TOOL_BRIDGE
    if bridge is None:
        return
    active = getattr(bridge, "ctrl_session_active", None)
    end = getattr(bridge, "session_end", None)
    if not callable(active) or not callable(end):
        return
    try:
        if active(context):
            end(context, force=True)
            _trace("mask_session_suspended")
    except Exception:
        pass


def _resume_mask_if_needed(context, state: dict) -> None:
    if not bool(state.get("ctrl_held")) or bool(state.get("shift_held")):
        return
    bridge = _MASK_TOOL_BRIDGE
    begin = getattr(bridge, "session_begin", None) if bridge is not None else None
    if not callable(begin):
        return
    try:
        begin(context)
        _trace("mask_session_resumed")
    except Exception:
        pass


def session_begin(context=None) -> dict:
    workspace = _workspace(context)
    if workspace is None:
        return {"tool_id": BOX_HIDE_TOOL_ID, "session_active": False, "passthrough": False}

    state = _state(workspace)
    _trace_state("session_begin_enter", context, state)
    if state.get("session_active"):
        _trace_state("session_begin_reuse_active", context, state)
        return {
            "tool_id": str(state.get("session_tool") or state.get("selected_tool") or BOX_HIDE_TOOL_ID),
            "session_active": True,
            "passthrough": False,
        }

    _suspend_mask_session(context)
    active_id = _observe_native_tool(context)
    _trace_state("session_begin_after_observe", context, state, observed_active_tool=active_id)

    if active_id in NATIVE_VISIBILITY_TOOL_IDS:
        _record_selected(state, active_id, reason="explicit_native_tool_selected")
        _trace_state(
            "session_begin_passthrough_explicit_native",
            context,
            state,
            observed_active_tool=active_id,
        )
        return {"tool_id": active_id, "session_active": False, "passthrough": True}

    tool_id = str(state.get("selected_tool") or BOX_HIDE_TOOL_ID)
    if tool_id not in NATIVE_VISIBILITY_TOOL_IDS:
        tool_id = BOX_HIDE_TOOL_ID

    restore_tool = active_id or str(state.get("base_tool") or "")
    if active_id:
        state["base_tool"] = active_id

    can_begin = bool(
        _zbrush_product_active()
        and _context_is_sculpt(context)
        and restore_tool
    )
    set_tool_ok = bool(_set_tool(context, tool_id)) if can_begin else False
    if not (can_begin and set_tool_ok):
        _trace_state(
            "session_begin_failed",
            context,
            state,
            candidate_tool=tool_id,
            candidate_restore_tool=restore_tool,
            can_begin=can_begin,
            set_tool_ok=set_tool_ok,
        )
        return {"tool_id": tool_id, "session_active": False, "passthrough": False}

    state["session_active"] = True
    state["session_tool"] = tool_id
    state["restore_tool"] = restore_tool
    state["restore_pending"] = False
    state["restore_blocked_signature"] = ""
    _trace_state(
        "ctrl_shift_session_started",
        context,
        state,
        tool=tool_id,
    )
    return {"tool_id": tool_id, "session_active": True, "passthrough": False}


def session_end(context=None, *, force: bool = False, resume_mask: bool = False) -> None:
    workspace = _workspace(context)
    if workspace is None:
        return
    state = _state(workspace)
    _trace_state(
        "session_end_enter",
        context,
        state,
        force=bool(force),
        resume_mask=bool(resume_mask),
    )
    if not state.get("session_active"):
        _trace_state("session_end_skipped_inactive", context, state)
        return
    if bool(state.get("gesture_active")) and not force:
        state["restore_pending"] = True
        _trace_state("session_end_deferred_gesture_active", context, state)
        return
    if bool(state.get("pointer_down")) and not force:
        state["restore_pending"] = True
        _trace_state("session_end_deferred_pointer_down", context, state)
        return
    if bool(state.get("ctrl_held")) and bool(state.get("shift_held")) and not force:
        _trace_state("session_end_skipped_chord_still_held", context, state)
        return

    _trace_state("session_end_before_observe", context, state)
    _observe_native_tool(context)
    if not state.get("session_active"):
        _trace_state("session_end_aborted_after_observe", context, state)
        return

    session_tool = str(state.get("session_tool") or "")
    restore_tool = str(state.get("restore_tool") or state.get("base_tool") or "")
    active_id = _active_tool_id(workspace)

    if active_id == session_tool and restore_tool and restore_tool not in NATIVE_VISIBILITY_TOOL_IDS:
        restore_ok = bool(_set_tool(context, restore_tool))
        _trace_state(
            "ctrl_shift_session_restore_attempt",
            context,
            state,
            restore_ok=restore_ok,
            restore_target=restore_tool,
            native_tool=session_tool,
        )
        if restore_ok:
            _trace_state(
                "ctrl_shift_session_restored",
                context,
                state,
                tool=restore_tool,
                native_tool=session_tool,
            )
    elif active_id != session_tool:
        _trace_state(
            "ctrl_shift_session_restore_skipped_external_change",
            context,
            state,
            observed_active_tool=active_id,
        )
    else:
        _trace_state(
            "ctrl_shift_session_restore_skipped_invalid_target",
            context,
            state,
            restore_target=restore_tool,
        )

    _clear_session(state, context=context, reason="session_end_complete")
    if resume_mask:
        _resume_mask_if_needed(context, state)


def ctrl_shift_session_active(context=None) -> bool:
    workspace = _workspace(context)
    return bool(workspace is not None and _state(workspace).get("session_active"))


def explicit_native_tool_active(context=None) -> bool:
    workspace = _workspace(context)
    if workspace is None:
        return False
    active_id = _observe_native_tool(context)
    state = _state(workspace)
    return bool(active_id in NATIVE_VISIBILITY_TOOL_IDS and not state.get("session_active"))


def current_tool(context=None) -> str:
    workspace = _workspace(context)
    if workspace is None:
        return BOX_HIDE_TOOL_ID
    if _zbrush_product_active() and _context_is_sculpt(context):
        _observe_native_tool(context)
    state = _state(workspace)
    if state.get("session_active"):
        tool_id = str(state.get("session_tool") or "")
        if tool_id in NATIVE_VISIBILITY_TOOL_IDS:
            return tool_id
    tool_id = str(state.get("selected_tool") or BOX_HIDE_TOOL_ID)
    return tool_id if tool_id in NATIVE_VISIBILITY_TOOL_IDS else BOX_HIDE_TOOL_ID


def current_family(context=None) -> str:
    tool_id = current_tool(context)
    if tool_id in _HIDE_TOOL_IDS:
        return "HIDE"
    if tool_id in _TRIM_TOOL_IDS:
        return "TRIM"
    return ""


def policy_tool_values(context=None, operator_id: str = "", property_names=()) -> dict:
    workspace = _workspace(context)
    if workspace is None:
        return {}
    return _tool_operator_values(
        workspace,
        str(operator_id or ""),
        tuple(property_names or ()),
    )


def policy_gesture_active(context=None, *, tool_id: str = "") -> bool:
    workspace = _workspace(context)
    if workspace is None:
        return False
    state = _state(workspace)
    if not bool(state.get("gesture_active")):
        return False
    if str(state.get("gesture_owner") or "") != "POLICY":
        return False
    if tool_id and str(state.get("gesture_tool") or "") != str(tool_id):
        return False
    return True


def policy_trace(context, reason: str, **extra) -> None:
    workspace = _workspace(context)
    state = _state(workspace) if workspace is not None else {}
    _trace_state(str(reason or "policy_trace"), context, state, **extra)


def policy_gesture_begin(context=None) -> bool:
    workspace = _workspace(context)
    if workspace is None:
        return False
    state = _state(workspace)
    if not state.get("session_active") or state.get("gesture_active"):
        return False
    tool_id = current_tool(context)
    if tool_id not in _POLICY_TOOL_TO_BL_IDNAME:
        return False

    state["gesture_active"] = True
    state["gesture_owner"] = "POLICY"
    state["gesture_tool"] = tool_id
    state["gesture_bl_idname"] = str(_POLICY_TOOL_TO_BL_IDNAME[tool_id])
    state["gesture_before_ops"] = frozenset()
    state["gesture_deadline"] = time.monotonic() + _GESTURE_TIMEOUT
    state["gesture_cancel_pending"] = False
    state["pointer_down"] = True
    _trace_state("policy_gesture_started", context, state)
    return True


def policy_gesture_end(context=None, *, cancelled: bool = False) -> None:
    workspace = _workspace(context)
    if workspace is None:
        return
    state = _state(workspace)
    if not state.get("gesture_active") or state.get("gesture_owner") != "POLICY":
        return

    _finish_gesture_state(
        state,
        reason="policy_gesture_cancelled" if cancelled else "policy_gesture_finished",
    )

    if (
        state.get("session_active")
        and state.get("restore_pending")
        and not (state.get("ctrl_held") and state.get("shift_held"))
    ):
        session_end(
            context,
            force=True,
            resume_mask=bool(state.get("ctrl_held") and not state.get("shift_held")),
        )


def observe_event(context, event) -> None:
    workspace = _workspace(context)
    state = _state(workspace) if workspace is not None else None
    event_type = str(getattr(event, "type", "") or "").upper()
    event_value = str(getattr(event, "value", "") or "").upper()

    if not _zbrush_product_active() or not _context_is_sculpt(context):
        if state is not None:
            state["ctrl_held"] = False
            state["shift_held"] = False
            state["pointer_down"] = False
        session_end(context, force=True)
        return

    if state is None:
        return

    if event_type == "WINDOW_DEACTIVATE":
        state["ctrl_held"] = False
        state["shift_held"] = False
        state["pointer_down"] = False
        session_end(context, force=True)
        return

    if event_type in {"LEFT_CTRL", "RIGHT_CTRL", "LEFT_SHIFT", "RIGHT_SHIFT"}:
        _trace_state("modifier_event_before", context, state, event=event)

    if event_type in {"LEFT_CTRL", "RIGHT_CTRL"}:
        state["ctrl_held"] = event_value != "RELEASE"
    elif hasattr(event, "ctrl"):
        state["ctrl_held"] = bool(getattr(event, "ctrl", state["ctrl_held"]))

    if event_type in {"LEFT_SHIFT", "RIGHT_SHIFT"}:
        state["shift_held"] = event_value != "RELEASE"
    elif hasattr(event, "shift"):
        state["shift_held"] = bool(getattr(event, "shift", state["shift_held"]))

    if event_type in {"LEFT_CTRL", "RIGHT_CTRL", "LEFT_SHIFT", "RIGHT_SHIFT"}:
        _trace_state("modifier_event_after", context, state, event=event)

    if event_type == "LEFTMOUSE" and event_value == "RELEASE":
        # Generic observation may clean up a release, but pointer-down ownership
        # belongs only to handle_pointer_press() after a native gesture starts.
        state["pointer_down"] = False

    if (
        state.get("gesture_active")
        and event_value == "PRESS"
        and event_type in {"ESC", "RIGHTMOUSE"}
    ):
        # Do not restore in this event. Blender's modal gets to cancel first;
        # the timer releases the temporary tool on the next safe tick.
        state["gesture_cancel_pending"] = True
        _trace("native_gesture_cancel_observed", tool=str(state.get("gesture_tool") or ""))

    chord_active = bool(state.get("ctrl_held") and state.get("shift_held"))
    if chord_active and not state.get("session_active"):
        _trace_state("modifier_chord_begin_request", context, state, event=event)
        session_begin(context)

    if state.get("session_active") and not chord_active:
        if not state.get("restore_pending"):
            state["restore_pending"] = True
            state["restore_blocked_signature"] = ""
            _trace_state("restore_pending_set_from_chord_release", context, state, event=event)
        if not state.get("gesture_active") and not state.get("pointer_down"):
            _trace_state("immediate_restore_request", context, state, event=event)
            session_end(
                context,
                force=True,
                resume_mask=bool(state.get("ctrl_held") and not state.get("shift_held")),
            )
            return

    _observe_native_tool(context)

def _poll_native_tool():
    if not _TIMER_RUNNING:
        return None
    try:
        context = bpy.context
        if _zbrush_product_active() and _context_is_sculpt(context):
            workspace = _workspace(context)
            state = _state(workspace) if workspace is not None else None
            if state is not None and state.get("gesture_active"):
                if state.get("gesture_owner") == "POLICY":
                    if time.monotonic() >= float(state.get("gesture_deadline") or 0.0):
                        _finish_gesture_state(state, reason="policy_gesture_watch_expired")
                elif _gesture_completed(context, state):
                    _finish_gesture_state(state, reason="native_gesture_completed")
                elif (
                    state.get("gesture_cancel_pending")
                    and not state.get("pointer_down")
                ):
                    _finish_gesture_state(state, reason="native_gesture_cancelled")
                elif time.monotonic() >= float(state.get("gesture_deadline") or 0.0):
                    _finish_gesture_state(state, reason="native_gesture_watch_expired")

            restore_waiting = bool(
                state is not None
                and state.get("session_active")
                and state.get("restore_pending")
                and not (state.get("ctrl_held") and state.get("shift_held"))
            )
            if restore_waiting and (state.get("gesture_active") or state.get("pointer_down")):
                signature = "|".join(
                    (
                        "gesture=" + str(bool(state.get("gesture_active"))),
                        "pointer=" + str(bool(state.get("pointer_down"))),
                        "operator=" + str(state.get("gesture_bl_idname") or ""),
                        "tool=" + str(_active_tool_id(workspace) or ""),
                    )
                )
                if str(state.get("restore_blocked_signature") or "") != signature:
                    state["restore_blocked_signature"] = signature
                    _trace_state("restore_blocked", context, state)
                _observe_native_tool(context)
            elif restore_waiting:
                state["restore_blocked_signature"] = ""
                _trace_state("poll_restore_request", context, state)
                session_end(
                    context,
                    force=True,
                    resume_mask=bool(state.get("ctrl_held") and not state.get("shift_held")),
                )
            else:
                if state is not None:
                    state["restore_blocked_signature"] = ""
                _observe_native_tool(context)
        else:
            workspace = _workspace(context)
            if workspace is not None:
                state = _state(workspace)
                state["ctrl_held"] = False
                state["shift_held"] = False
                state["pointer_down"] = False
            session_end(context, force=True)
    except Exception:
        pass
    return _POLL_INTERVAL

def snapshot(context=None) -> dict:
    workspace = _workspace(context)
    if workspace is None:
        return {
            "installed": bool(_INSTALLED),
            "selected_tool": BOX_HIDE_TOOL_ID,
            "session_active": False,
            "ctrl_held": False,
            "shift_held": False,
        }
    state = dict(_state(workspace))
    state["installed"] = bool(_INSTALLED)
    state["active_tool"] = _active_tool_id(workspace)
    state["current_tool"] = current_tool(context)
    state["explicit_native_tool"] = bool(
        state["active_tool"] in NATIVE_VISIBILITY_TOOL_IDS and not state.get("session_active")
    )
    return state


def install(sculpt_input_core, real_machine_trace=None, mask_tool_bridge=None) -> None:
    global _INSTALLED, _INPUT_CORE, _TRACE, _MASK_TOOL_BRIDGE, _TIMER_RUNNING
    if _INSTALLED:
        return
    _INPUT_CORE = sculpt_input_core
    _TRACE = real_machine_trace
    _MASK_TOOL_BRIDGE = mask_tool_bridge
    _INSTALLED = True

    try:
        if _context_is_sculpt(bpy.context):
            _observe_native_tool(bpy.context)
    except Exception:
        pass

    _TIMER_RUNNING = True
    try:
        if not bpy.app.timers.is_registered(_poll_native_tool):
            bpy.app.timers.register(_poll_native_tool, first_interval=_POLL_INTERVAL, persistent=False)
    except Exception:
        pass


def uninstall() -> None:
    global _INSTALLED, _INPUT_CORE, _TRACE, _MASK_TOOL_BRIDGE, _TIMER_RUNNING
    _TIMER_RUNNING = False
    try:
        if bpy.app.timers.is_registered(_poll_native_tool):
            bpy.app.timers.unregister(_poll_native_tool)
    except Exception:
        pass

    try:
        windows = tuple(bpy.context.window_manager.windows)
    except Exception:
        windows = ()

    for window in windows:
        workspace = getattr(window, "workspace", None)
        if workspace is None:
            continue
        state = _state(workspace)
        state["ctrl_held"] = False
        state["shift_held"] = False
        state["pointer_down"] = False
        if not state.get("session_active"):
            continue
        try:
            area = next(
                (
                    item
                    for item in tuple(getattr(window.screen, "areas", ()) or ())
                    if getattr(item, "type", "") == "VIEW_3D"
                ),
                None,
            )
            region = (
                next(
                    (
                        item
                        for item in tuple(getattr(area, "regions", ()) or ())
                        if getattr(item, "type", "") == "WINDOW"
                    ),
                    None,
                )
                if area is not None
                else None
            )
            if area is not None and region is not None:
                with bpy.context.temp_override(window=window, area=area, region=region):
                    session_end(bpy.context, force=True)
        except Exception:
            pass

    _STATES.clear()
    _INPUT_CORE = None
    _TRACE = None
    _MASK_TOOL_BRIDGE = None
    _INSTALLED = False
