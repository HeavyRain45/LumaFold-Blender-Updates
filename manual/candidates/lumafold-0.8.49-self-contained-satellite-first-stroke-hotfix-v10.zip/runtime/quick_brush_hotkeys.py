from __future__ import annotations

import bpy

from ..core.app import APP


_OPERATOR_ID = "lumafold.quick_brush_slot"
_KEYMAP_NAME = "Sculpt"
_SPACE_TYPE = "EMPTY"
_REGION_TYPE = "WINDOW"
_ADDON_KEYMAPS = []

# 16 actual Blender Sculpt bindings. The UI reads these back through
# blender.sculpt_shortcuts instead of hard-coding labels.
_DEFAULT_KEYS = ("ONE", "TWO", "THREE", "FOUR", "FIVE", "SIX", "SEVEN", "EIGHT")
_DEFAULT_BINDINGS = tuple(
    [(name, True, False) for name in _DEFAULT_KEYS]
    + [(name, False, True) for name in _DEFAULT_KEYS]
)


class LUMAFOLD_OT_quick_brush_slot(bpy.types.Operator):
    bl_idname = _OPERATOR_ID
    bl_label = "LumaFold Quick Brush"
    bl_description = "Activate the assigned LumaFold Quick Brush slot in Sculpt Mode"
    bl_options = {"INTERNAL"}

    slot: bpy.props.IntProperty(default=0, min=0, max=15, options={"HIDDEN"})

    @classmethod
    def poll(cls, context):
        objects = getattr(getattr(context, "view_layer", None), "objects", None)
        active = getattr(objects, "active", None) if objects is not None else None
        return bool(
            str(getattr(context, "mode", "")) == "SCULPT"
            and active is not None
            and getattr(active, "type", "") == "MESH"
        )

    def execute(self, context):
        result = APP.execute("sculpt.brush.activate_slot", slot=int(self.slot))
        if not result.ok:
            self.report({"WARNING"}, str(result.message))
            return {"CANCELLED"}
        return {"FINISHED"}


def _addon_keyconfig():
    try:
        return bpy.context.window_manager.keyconfigs.addon
    except Exception:
        return None


def _exact_sculpt_map(kc, *, create=True):
    if kc is None:
        return None
    try:
        km = kc.keymaps.find(
            _KEYMAP_NAME,
            space_type=_SPACE_TYPE,
            region_type=_REGION_TYPE,
        )
    except Exception:
        km = None
    if km is None and create:
        try:
            km = kc.keymaps.new(
                name=_KEYMAP_NAME,
                space_type=_SPACE_TYPE,
                region_type=_REGION_TYPE,
            )
        except Exception:
            km = None
    return km


def _remove_stale_items_everywhere(kc):
    if kc is None:
        return
    try:
        maps = tuple(kc.keymaps)
    except Exception:
        maps = ()
    for km in maps:
        if str(getattr(km, "name", "") or "") != _KEYMAP_NAME:
            continue
        for kmi in tuple(getattr(km, "keymap_items", ()) or ()):
            if str(getattr(kmi, "idname", "") or "") == _OPERATOR_ID:
                try:
                    km.keymap_items.remove(kmi)
                except Exception:
                    pass


def _register_keymaps():
    kc = _addon_keyconfig()
    km = _exact_sculpt_map(kc, create=True)
    if km is None:
        return
    _remove_stale_items_everywhere(kc)
    _ADDON_KEYMAPS.clear()

    for slot, (event_type, use_alt, use_ctrl) in enumerate(_DEFAULT_BINDINGS):
        try:
            kmi = km.keymap_items.new(
                _OPERATOR_ID,
                event_type,
                "PRESS",
                alt=bool(use_alt),
                ctrl=bool(use_ctrl),
                head=True,
            )
            kmi.properties.slot = int(slot)
            kmi.active = True
            _ADDON_KEYMAPS.append((km, kmi))
        except Exception:
            pass


def _unregister_keymaps():
    while _ADDON_KEYMAPS:
        km, kmi = _ADDON_KEYMAPS.pop()
        try:
            km.keymap_items.remove(kmi)
        except Exception:
            pass
    _remove_stale_items_everywhere(_addon_keyconfig())


def register():
    try:
        bpy.utils.register_class(LUMAFOLD_OT_quick_brush_slot)
    except RuntimeError:
        try:
            bpy.utils.unregister_class(LUMAFOLD_OT_quick_brush_slot)
        except Exception:
            pass
        bpy.utils.register_class(LUMAFOLD_OT_quick_brush_slot)
    _register_keymaps()


def unregister():
    _unregister_keymaps()
    try:
        bpy.utils.unregister_class(LUMAFOLD_OT_quick_brush_slot)
    except RuntimeError:
        pass
