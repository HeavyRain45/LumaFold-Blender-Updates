"""Embedded Host close/repaint lifecycle helper.

Blender keeps the pixels produced by a POST_PIXEL draw handler until the owning
area is redrawn.  LumaFold removes that handler when its modal operator finishes;
without an explicit redraw request the last floating-surface frame can therefore
remain visible until the user orbits/pans the View3D.  This hook guarantees a
View3D redraw immediately after Host teardown.
"""
from __future__ import annotations

import bpy


_INSTALLED = False
_ORIGINAL_FINISH = None


def _tag_view3d_redraws():
    """Invalidate visible View3D regions after removing LumaFold's draw handler."""
    try:
        wm = bpy.context.window_manager
        windows = tuple(getattr(wm, "windows", ()) or ())
    except Exception:
        return
    for window in windows:
        screen = getattr(window, "screen", None)
        if screen is None:
            continue
        for area in tuple(getattr(screen, "areas", ()) or ()):
            if getattr(area, "type", "") != 'VIEW_3D':
                continue
            try:
                area.tag_redraw()
            except Exception:
                pass


def install(operators_module):
    """Wrap the Embedded modal teardown once; safe across package hot reloads."""
    global _INSTALLED, _ORIGINAL_FINISH
    if _INSTALLED:
        return
    cls = getattr(operators_module, "LUMAFOLD_OT_toggle_p0", None)
    if cls is None:
        return
    original = getattr(cls, "_finish", None)
    if not callable(original):
        return

    _ORIGINAL_FINISH = original

    def _finish_with_repaint(self, context):
        try:
            return original(self, context)
        finally:
            # The old draw pixels are still in Blender's backbuffer after the
            # handler is removed. Explicitly invalidate the View3D so the close
            # becomes visually immediate instead of waiting for orbit/pan/etc.
            _tag_view3d_redraws()

    cls._finish = _finish_with_repaint
    _INSTALLED = True


def uninstall(operators_module):
    global _INSTALLED, _ORIGINAL_FINISH
    if not _INSTALLED:
        return
    cls = getattr(operators_module, "LUMAFOLD_OT_toggle_p0", None)
    if cls is not None and callable(_ORIGINAL_FINISH):
        try:
            cls._finish = _ORIGINAL_FINISH
        except Exception:
            pass
    _ORIGINAL_FINISH = None
    _INSTALLED = False
