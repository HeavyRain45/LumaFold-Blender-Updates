from __future__ import annotations

"""Stateless Blender-native View3D navigation handoff.

LumaFold may decide *when* a ZBrush-style pointer press should become viewport
navigation, but it never owns navigation state itself.

Hard isolation contract:
- never write RegionView3D.view_rotation;
- never mutate Blender's View3D Rotate Modal keymap;
- never keep rotate/session/timer state;
- never synthesize orbit increments;
- once VIEW3D_OT_rotate is invoked, Blender owns the complete drag lifecycle.

Plain-LMB Sculpt-vs-background ownership is decided by Blender itself through
``sculpt_native_pointer``. This module is retained only for already-authorized
native navigation paths such as plain RMB; it never raycasts or decides whether
a brush stroke exists.
"""

import importlib

import bpy


_base = importlib.import_module(__package__ + ".sculpt_input_core")

_CONFIGURED = False
_REGISTERED = False


def _runtime_state():
    try:
        return _base._APP.store.namespace("sculpt")
    except Exception:
        return None


def _set_status(text: str):
    state = _runtime_state()
    if state is not None:
        state["native_orbit_status"] = str(text or "")
        state["native_shift_snap_bridge"] = "BLENDER_NATIVE"
        state.pop("native_shift_snap_error", None)


def _invoke_blender_rotate(target) -> bool:
    if target is None:
        return False
    window, area, region = target
    try:
        with bpy.context.temp_override(window=window, area=area, region=region):
            result = bpy.ops.view3d.rotate("INVOKE_DEFAULT")
        running = "RUNNING_MODAL" in set(result or ())
    except Exception as exc:
        _set_status(f"Blender Native Rotate ERROR: {type(exc).__name__}: {exc}")
        return False
    if running:
        _set_status("Blender Native Rotate · isolated handoff")
    return bool(running)


def try_native_navigation(context, event, target, *, host=None):
    event_type = str(getattr(event, "type", "") or "")
    event_value = str(getattr(event, "value", "") or "").upper()
    if event_value != "PRESS" or event_type not in {"LEFTMOUSE", "RIGHTMOUSE"}:
        return None
    if bool(getattr(event, "ctrl", False)) or bool(getattr(event, "alt", False)):
        return None
    return _invoke_blender_rotate(target)


def configure(app, sculpt_input_profile, shortcut_product, ui_patch, operators_module):
    global _CONFIGURED
    if _CONFIGURED:
        return
    _base.configure(app, sculpt_input_profile, shortcut_product, ui_patch, operators_module)
    setter = getattr(_base, "set_navigation_handler", None)
    if not callable(setter):
        raise RuntimeError("Sculpt navigation handler slot is unavailable")
    setter(try_native_navigation)
    _CONFIGURED = True


def register():
    global _REGISTERED
    if _REGISTERED:
        return
    _REGISTERED = True
    _base.register()
    _set_status("Blender-native navigation isolation ready")


def unregister():
    global _REGISTERED, _CONFIGURED
    _REGISTERED = False
    try:
        setter = getattr(_base, "set_navigation_handler", None)
        if callable(setter):
            setter(None)
        _base.unregister()
    finally:
        _CONFIGURED = False
