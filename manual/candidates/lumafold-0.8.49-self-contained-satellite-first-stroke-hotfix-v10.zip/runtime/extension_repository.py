from __future__ import annotations

"""Blender-native adapter for LumaFold extension repository operations.

This module may configure and synchronize repositories in the running product
process. It deliberately does not install/replace the LumaFold package there;
package replacement belongs to update_restart_transaction's isolated helper.

Blender extension operators accept either ``repo_index`` or ``repo_directory``.
The index is *not* the raw ``preferences.extensions.repos`` collection index: it
is resolved from Blender's filtered effective repository list. LumaFold therefore
uses the repository directory as the operational identity and never passes a raw
collection index into an extension operator.
"""

from dataclasses import dataclass
import json
from pathlib import Path
from typing import Any

import bpy

from ..services import update_service


@dataclass(frozen=True)
class RepositoryStatus:
    configured: bool
    online_allowed: bool
    index: int
    name: str
    module: str
    remote_url: str
    channel: str
    message: str = ""


def online_allowed() -> bool:
    return bool(getattr(bpy.app, "online_access", False))


def _repos():
    extensions = getattr(getattr(bpy.context, "preferences", None), "extensions", None)
    return getattr(extensions, "repos", None)


def _repo_index(repo) -> int:
    """Raw collection index for diagnostics only; never pass to bpy.ops.extensions."""
    repos = _repos()
    if repos is None:
        return -1
    try:
        for index, item in enumerate(repos):
            if item == repo:
                return index
    except Exception:
        pass
    return -1


def _repo_directory(repo) -> str:
    return str(getattr(repo, "directory", "") or "").strip()


def find_repository(*, remote_url: str = "", name: str = update_service.REPOSITORY_NAME):
    repos = _repos()
    if repos is None:
        return None
    target_url = str(remote_url or "").rstrip("/")
    try:
        for repo in repos:
            repo_url = str(getattr(repo, "remote_url", "") or "").rstrip("/")
            if target_url and repo_url == target_url:
                return repo
            if str(getattr(repo, "name", "") or "") == str(name):
                return repo
    except Exception:
        return None
    return None


def status(channel_id: str, state: dict[str, Any] | None = None) -> RepositoryStatus:
    contract = update_service.repository_contract(channel_id, state)
    if not contract.repository_url:
        return RepositoryStatus(False, online_allowed(), -1, update_service.REPOSITORY_NAME, "", "", contract.id, "在线仓库尚未发布")
    repo = find_repository(remote_url=contract.repository_url)
    if repo is None:
        return RepositoryStatus(False, online_allowed(), -1, update_service.REPOSITORY_NAME, "", contract.repository_url, contract.id, "LumaFold 在线仓库尚未添加到 Blender")
    return RepositoryStatus(
        configured=True,
        online_allowed=online_allowed(),
        index=_repo_index(repo),
        name=str(getattr(repo, "name", "") or update_service.REPOSITORY_NAME),
        module=str(getattr(repo, "module", "") or ""),
        remote_url=str(getattr(repo, "remote_url", "") or ""),
        channel=contract.id,
        message="就绪",
    )


def ensure_repository(channel_id: str, state: dict[str, Any] | None = None):
    contract = update_service.repository_contract(channel_id, state)
    if not contract.repository_url:
        raise RuntimeError("LumaFold 在线仓库尚未发布，当前开发版不会写入临时更新地址")
    repos = _repos()
    if repos is None:
        raise RuntimeError("当前 Blender 没有 Extensions Repository API")

    repo = find_repository(remote_url=contract.repository_url)
    if repo is None:
        repo = repos.new(
            name=update_service.REPOSITORY_NAME,
            module="lumafold_remote",
            remote_url=contract.repository_url,
            source='USER',
        )
    try:
        repo.enabled = True
    except Exception:
        pass
    try:
        repo.use_remote_url = True
    except Exception:
        pass
    try:
        repo.use_sync_on_startup = True
    except Exception:
        pass
    try:
        repo.remote_url = contract.repository_url
    except Exception:
        pass
    try:
        bpy.ops.wm.save_userpref()
    except Exception:
        pass
    return repo


def sync_repository(repo) -> set[str]:
    if not online_allowed():
        raise RuntimeError("Blender 当前禁止联网，请先在系统设置中允许 Online Access")
    directory = _repo_directory(repo)
    if not directory:
        raise RuntimeError("无法定位 LumaFold Extension Repository 目录")
    result = bpy.ops.extensions.repo_sync(repo_directory=directory)
    return set(result or ())


def available_version(repo, extension_id: str = update_service.EXTENSION_ID) -> str:
    """Read the package version from Blender's synced local repository index.

    Network transport remains owned by ``bpy.ops.extensions.repo_sync``. This
    function only reads the cache Blender just wrote under ``.blender_ext`` so
    product UI can show the exact target version without doing its own HTTP.
    """
    directory = _repo_directory(repo)
    if not directory:
        return ""
    index_path = Path(directory) / ".blender_ext" / "index.json"
    try:
        payload = json.loads(index_path.read_text(encoding="utf-8"))
    except Exception:
        return ""
    for item in payload.get("data", ()) if isinstance(payload, dict) else ():
        if not isinstance(item, dict):
            continue
        if str(item.get("id", "") or "") != str(extension_id):
            continue
        return str(item.get("version", "") or "").strip()
    return ""


def open_native_update_ui() -> set[str]:
    try:
        result = bpy.ops.extensions.userpref_show_for_update()
    except Exception:
        result = bpy.ops.screen.userpref_show('INVOKE_DEFAULT')
    return set(result or ())
