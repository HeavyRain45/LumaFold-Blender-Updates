from __future__ import annotations

"""Blender Theme Follow V1 for the Embedded LumaFold host.

Scope is deliberately narrow:
- read Blender's current UI theme colors from bpy.context.preferences.themes;
- map them onto LumaFold semantic color tokens;
- re-apply ImGui colors only when the Blender theme actually changes;
- do not touch layout, typography, scale, roundness, Host geometry, or input.

Satellite/secondary processes consume a serialized snapshot in the next phase.
"""

import time

import bpy
from mathutils import Color

from ..ui import theme as T


_POLL_INTERVAL = 0.50
_INSTALLED = False
_ORIGINAL_APPLY_PENDING_STYLE = None
_UI_HOST_MODULE = None
_CURRENT_SNAPSHOT = None
_CURRENT_SIGNATURE = None

_TOKEN_NAMES = (
    "SURFACE_0",
    "SURFACE_1",
    "SURFACE_2",
    "SURFACE_3",
    "SURFACE_HOVER",
    "SECONDARY_SURFACE_BG",
    "TEXT_PRIMARY",
    "TEXT_SECONDARY",
    "TEXT_MUTED",
    "SELECTED",
    "SELECTED_HOVER",
    "SELECTED_SOFT",
    "BORDER",
    "WINDOW_BORDER",
    "BORDER_SOFT",
    "BUTTON_BG",
    "BUTTON_HOVER",
    "BUTTON_ACTIVE",
    "BUTTON_BORDER",
    "TOOL_BG",
    "TOOL_HOVER",
    "TOOL_ACTIVE",
    "TOOL_BORDER",
    "FRAME_BG",
    "FRAME_HOVER",
    "FRAME_ACTIVE",
    "FRAME_BORDER",
    "TEXT_INPUT_BG",
    "TEXT_INPUT_HOVER",
    "TEXT_INPUT_ACTIVE",
    "TEXT_INPUT_BORDER",
    "PULLDOWN_BG",
    "PULLDOWN_HOVER",
    "PULLDOWN_ACTIVE",
    "PULLDOWN_BORDER",
    "MENU_BG",
    "MENU_BORDER",
    "MENU_TEXT",
    "MENU_ITEM_BG",
    "MENU_ITEM_HOVER",
    "MENU_ITEM_ACTIVE",
    "MENU_ITEM_TEXT",
    "MENU_ITEM_TEXT_SELECTED",
)
_DEFAULT_TOKENS = {name: tuple(getattr(T, name)) for name in _TOKEN_NAMES}


def _tuple4(value, alpha=1.0):
    vals = tuple(float(v) for v in value)
    if len(vals) >= 4:
        return vals[:4]
    if len(vals) >= 3:
        return vals[:3] + (float(alpha),)
    raise ValueError("Theme color requires at least three channels")


def _tuple3(value):
    vals = tuple(float(v) for v in value)
    if len(vals) < 3:
        raise ValueError("Theme color requires at least three channels")
    return vals[:3]


def _clamp01(value: float) -> float:
    return max(0.0, min(1.0, float(value)))


def _mix_srgb(a, b, amount: float):
    a4 = _tuple4(a)
    b4 = _tuple4(b)
    t = _clamp01(amount)
    return tuple(a4[i] * (1.0 - t) + b4[i] * t for i in range(4))


def _composite_srgb(foreground, background):
    """Flatten one Blender-authored RGBA layer over its semantic parent.

    Blender theme colors are not a flat palette. Several widget/panel colors are
    intentionally authored as translucent black/white and only look correct
    after Blender composites them over the parent region. An ImGui floating host
    cannot reuse those raw RGBA values as independent opaque fills: forcing alpha
    to 1 turns transparent-black layers into literal black, while preserving the
    alpha leaks the 3D View through the popup.

    Reconstruct the displayed hierarchy first, then hand ImGui an opaque result.
    The arithmetic stays in the theme's sRGB space because the resulting color is
    converted once through _to_linear_rgba() before it reaches the renderer.
    """
    fg = _tuple4(foreground)
    bg = _tuple4(background)
    af = _clamp01(fg[3])
    ab = _clamp01(bg[3])
    out_a = af + ab * (1.0 - af)
    if out_a <= 1.0e-8:
        return (0.0, 0.0, 0.0, 0.0)
    out_rgb = tuple(
        (fg[i] * af + bg[i] * ab * (1.0 - af)) / out_a
        for i in range(3)
    )
    return out_rgb + (out_a,)


def _opaque(value):
    rgba = _tuple4(value)
    return rgba[:3] + (1.0,)


def _to_linear_rgba(value, alpha=None):
    rgba = _tuple4(value, 1.0 if alpha is None else alpha)
    rgb = Color(rgba[:3]).from_srgb_to_scene_linear()
    out_alpha = rgba[3] if alpha is None else float(alpha)
    return (float(rgb.r), float(rgb.g), float(rgb.b), _clamp01(out_alpha))


def blender_theme_snapshot():
    """Return a JSON-safe snapshot of Blender's active UI theme in sRGB."""
    try:
        themes = bpy.context.preferences.themes
        if not themes:
            return None
        theme = themes[0]
        ui = theme.user_interface
        regular = ui.wcol_regular
        tool = ui.wcol_tool
        numslider = getattr(ui, "wcol_numslider", regular)
        text_widget = getattr(ui, "wcol_text", regular)
        pulldown = getattr(ui, "wcol_pulldown", regular)
        box = ui.wcol_box
        scroll = ui.wcol_scroll
        menu_back = ui.wcol_menu_back
        menu_item = ui.wcol_menu_item
        return {
            "editor_border": _tuple3(ui.editor_border),
            "editor_outline_active": _tuple4(ui.editor_outline_active),
            "panel_back": _tuple4(ui.panel_back),
            "panel_sub_back": _tuple4(ui.panel_sub_back),
            "panel_header": _tuple4(ui.panel_header),
            "panel_outline": _tuple4(ui.panel_outline),
            "panel_text": _tuple3(ui.panel_text),
            "panel_title": _tuple3(ui.panel_title),
            "regular_inner": _tuple4(regular.inner),
            "regular_inner_sel": _tuple4(regular.inner_sel),
            "regular_outline": _tuple4(regular.outline),
            "regular_text": _tuple3(regular.text),
            "regular_text_sel": _tuple3(regular.text_sel),
            "tool_inner": _tuple4(tool.inner),
            "tool_inner_sel": _tuple4(tool.inner_sel),
            "tool_outline": _tuple4(tool.outline),
            "numslider_inner": _tuple4(numslider.inner),
            "numslider_inner_sel": _tuple4(numslider.inner_sel),
            "numslider_outline": _tuple4(numslider.outline),
            "text_inner": _tuple4(text_widget.inner),
            "text_inner_sel": _tuple4(text_widget.inner_sel),
            "text_outline": _tuple4(text_widget.outline),
            "pulldown_inner": _tuple4(pulldown.inner),
            "pulldown_inner_sel": _tuple4(pulldown.inner_sel),
            "pulldown_outline": _tuple4(pulldown.outline),
            "box_inner": _tuple4(box.inner),
            "scroll_inner": _tuple4(scroll.inner),
            "scroll_inner_sel": _tuple4(scroll.inner_sel),
            "menu_back_inner": _tuple4(menu_back.inner),
            "menu_back_outline": _tuple4(menu_back.outline),
            "menu_back_text": _tuple3(menu_back.text),
            "menu_item_inner": _tuple4(menu_item.inner),
            "menu_item_inner_sel": _tuple4(menu_item.inner_sel),
            "menu_item_outline": _tuple4(menu_item.outline),
            "menu_item_text": _tuple3(menu_item.text),
            "menu_item_text_sel": _tuple3(menu_item.text_sel),
        }
    except Exception:
        return None


def _signature(snapshot):
    if not snapshot:
        return None
    return tuple(
        (key, tuple(round(float(v), 6) for v in value))
        for key, value in sorted(snapshot.items())
    )


def _tokens_from_snapshot(snapshot):
    # Blender's theme is hierarchical, not a bag of independent final colors.
    # Keep the root panel as the host's opaque visual base, then rebuild child,
    # widget and box colors exactly as layers over their semantic parent.
    panel = _opaque(snapshot["panel_back"])
    panel_sub = _composite_srgb(snapshot["panel_sub_back"], panel)

    button = _composite_srgb(snapshot["regular_inner"], panel_sub)
    button_selected = _composite_srgb(snapshot["regular_inner_sel"], button)
    tool = _composite_srgb(snapshot["tool_inner"], panel_sub)
    tool_selected = _composite_srgb(snapshot["tool_inner_sel"], tool)
    frame = _composite_srgb(snapshot["numslider_inner"], panel_sub)
    frame_selected = _composite_srgb(snapshot["numslider_inner_sel"], frame)
    text_input = _composite_srgb(snapshot["text_inner"], panel_sub)
    text_input_selected = _composite_srgb(snapshot["text_inner_sel"], text_input)
    pulldown = _composite_srgb(snapshot["pulldown_inner"], panel_sub)
    pulldown_selected = _composite_srgb(snapshot["pulldown_inner_sel"], pulldown)
    box = _composite_srgb(snapshot["box_inner"], panel_sub)

    # A large Brush/Alpha browser is a secondary *panel surface*, not a tiny
    # context-menu background. Blender exposes panel_back / panel_sub_back for
    # this hierarchy, while wcol_menu_back is intentionally much darker in the
    # default dark theme. Using menu_back as the whole browser created the
    # unpleasant near-black slab seen in the real-machine screenshots.
    secondary_surface = _opaque(panel_sub)

    # Compact context menus are the opposite case: Blender deliberately gives
    # them a separate wcol_menu_back shell, then composites wcol_menu_item rows
    # inside that shell. Keeping these two levels distinct prevents menu content
    # from visually dissolving into one flat background.
    menu_back = _composite_srgb(snapshot["menu_back_inner"], panel_sub)
    menu_item = _composite_srgb(snapshot["menu_item_inner"], menu_back)
    menu_item_selected = _composite_srgb(snapshot["menu_item_inner_sel"], menu_back)
    menu_outline = _composite_srgb(snapshot["menu_back_outline"], menu_back)

    # Blender separates floating chrome from widget outlines. Preserve the V1.6
    # host edge with menu/popover semantics, then expose per-widget outlines so
    # buttons, tool buttons, sliders, text fields and pulldowns no longer share
    # one universal Border.
    floating_outline = _composite_srgb(snapshot["menu_back_outline"], secondary_surface)
    button_outline = _composite_srgb(snapshot["regular_outline"], button)
    tool_outline = _composite_srgb(snapshot["tool_outline"], tool)
    frame_outline = _composite_srgb(snapshot["numslider_outline"], frame)
    text_outline = _composite_srgb(snapshot["text_outline"], text_input)
    pulldown_outline = _composite_srgb(snapshot["pulldown_outline"], pulldown)

    text = snapshot["regular_text"] + (1.0,)
    text_sel = snapshot["regular_text_sel"] + (1.0,)
    menu_back_text = snapshot["menu_back_text"] + (1.0,)
    menu_text = snapshot["menu_item_text"] + (1.0,)
    menu_text_sel = snapshot["menu_item_text_sel"] + (1.0,)
    panel_outline = snapshot["panel_outline"]

    # Hover/active states stay within each Blender-owned widget family. This is
    # the important difference from the earlier universal-grey mapping.
    button_hover = _mix_srgb(button, button_selected, 0.24)
    button_active = _mix_srgb(button, button_selected, 0.52)
    tool_hover = _mix_srgb(tool, tool_selected, 0.24)
    tool_active = _mix_srgb(tool, tool_selected, 0.52)
    frame_hover = _mix_srgb(frame, frame_selected, 0.20)
    frame_active = _mix_srgb(frame, frame_selected, 0.36)
    text_input_hover = _mix_srgb(text_input, text_input_selected, 0.18)
    text_input_active = _mix_srgb(text_input, text_input_selected, 0.42)
    pulldown_hover = _mix_srgb(pulldown, pulldown_selected, 0.22)
    pulldown_active = _mix_srgb(pulldown, pulldown_selected, 0.48)
    menu_item_hover = _mix_srgb(menu_item, menu_item_selected, 0.72)
    menu_item_active = menu_item_selected

    selected = tool_selected
    selected_hover = _mix_srgb(selected, text_sel, 0.10)
    selected_soft = _mix_srgb(button, selected, 0.48)
    secondary_text = _mix_srgb(text, panel, 0.30)
    muted_text = _mix_srgb(text, panel, 0.56)

    return {
        "SURFACE_0": _to_linear_rgba(panel, 1.0),
        "SURFACE_1": _to_linear_rgba(panel_sub, 1.0),
        "SURFACE_2": _to_linear_rgba(button, 1.0),
        "SURFACE_3": _to_linear_rgba(box, 1.0),
        "SURFACE_HOVER": _to_linear_rgba(button_hover, 1.0),
        "SECONDARY_SURFACE_BG": _to_linear_rgba(secondary_surface, 1.0),
        "TEXT_PRIMARY": _to_linear_rgba(text, 1.0),
        "TEXT_SECONDARY": _to_linear_rgba(secondary_text, 1.0),
        "TEXT_MUTED": _to_linear_rgba(muted_text, 1.0),
        "SELECTED": _to_linear_rgba(selected, 1.0),
        "SELECTED_HOVER": _to_linear_rgba(selected_hover, 1.0),
        "SELECTED_SOFT": _to_linear_rgba(selected_soft, 1.0),
        "BORDER": _to_linear_rgba(floating_outline, 1.0),
        "WINDOW_BORDER": _to_linear_rgba(floating_outline, 1.0),
        "BORDER_SOFT": _to_linear_rgba(
            panel_outline,
            _clamp01(float(panel_outline[3]) * 0.60),
        ),
        "BUTTON_BG": _to_linear_rgba(button, 1.0),
        "BUTTON_HOVER": _to_linear_rgba(button_hover, 1.0),
        "BUTTON_ACTIVE": _to_linear_rgba(button_active, 1.0),
        "BUTTON_BORDER": _to_linear_rgba(button_outline, 1.0),
        "TOOL_BG": _to_linear_rgba(tool, 1.0),
        "TOOL_HOVER": _to_linear_rgba(tool_hover, 1.0),
        "TOOL_ACTIVE": _to_linear_rgba(tool_active, 1.0),
        "TOOL_BORDER": _to_linear_rgba(tool_outline, 1.0),
        "FRAME_BG": _to_linear_rgba(frame, 1.0),
        "FRAME_HOVER": _to_linear_rgba(frame_hover, 1.0),
        "FRAME_ACTIVE": _to_linear_rgba(frame_active, 1.0),
        "FRAME_BORDER": _to_linear_rgba(frame_outline, 1.0),
        "TEXT_INPUT_BG": _to_linear_rgba(text_input, 1.0),
        "TEXT_INPUT_HOVER": _to_linear_rgba(text_input_hover, 1.0),
        "TEXT_INPUT_ACTIVE": _to_linear_rgba(text_input_active, 1.0),
        "TEXT_INPUT_BORDER": _to_linear_rgba(text_outline, 1.0),
        "PULLDOWN_BG": _to_linear_rgba(pulldown, 1.0),
        "PULLDOWN_HOVER": _to_linear_rgba(pulldown_hover, 1.0),
        "PULLDOWN_ACTIVE": _to_linear_rgba(pulldown_active, 1.0),
        "PULLDOWN_BORDER": _to_linear_rgba(pulldown_outline, 1.0),
        "MENU_BG": _to_linear_rgba(menu_back, 1.0),
        "MENU_BORDER": _to_linear_rgba(menu_outline, 1.0),
        "MENU_TEXT": _to_linear_rgba(menu_back_text, 1.0),
        "MENU_ITEM_BG": _to_linear_rgba(menu_item, 1.0),
        "MENU_ITEM_HOVER": _to_linear_rgba(menu_item_hover, 1.0),
        "MENU_ITEM_ACTIVE": _to_linear_rgba(menu_item_active, 1.0),
        "MENU_ITEM_TEXT": _to_linear_rgba(menu_text, 1.0),
        "MENU_ITEM_TEXT_SELECTED": _to_linear_rgba(menu_text_sel, 1.0),
    }


def apply_snapshot(snapshot) -> bool:
    """Apply one Blender theme snapshot to LumaFold semantic color tokens."""
    global _CURRENT_SNAPSHOT, _CURRENT_SIGNATURE
    sig = _signature(snapshot)
    if sig is None:
        return False
    if sig == _CURRENT_SIGNATURE:
        return False
    tokens = _tokens_from_snapshot(snapshot)
    for name, value in tokens.items():
        setattr(T, name, tuple(value))
    _CURRENT_SNAPSHOT = dict(snapshot)
    _CURRENT_SIGNATURE = sig
    return True


def current_snapshot():
    return dict(_CURRENT_SNAPSHOT or {})


def restore_defaults():
    global _CURRENT_SNAPSHOT, _CURRENT_SIGNATURE
    for name, value in _DEFAULT_TOKENS.items():
        setattr(T, name, tuple(value))
    _CURRENT_SNAPSHOT = None
    _CURRENT_SIGNATURE = None


def install(ui_host_module) -> None:
    global _INSTALLED, _ORIGINAL_APPLY_PENDING_STYLE, _UI_HOST_MODULE
    if _INSTALLED:
        return
    host_cls = getattr(ui_host_module, "UIHost", None)
    original = getattr(host_cls, "_apply_pending_style", None) if host_cls is not None else None
    if not callable(original):
        return

    _UI_HOST_MODULE = ui_host_module
    _ORIGINAL_APPLY_PENDING_STYLE = original

    def apply_pending_style_with_blender_theme(self):
        if str(getattr(self, "host_mode", "embedded")) == "embedded":
            now = time.monotonic()
            last = float(getattr(self, "_lumafold_theme_follow_checked_at", 0.0) or 0.0)
            if now - last >= _POLL_INTERVAL:
                self._lumafold_theme_follow_checked_at = now
                snapshot = blender_theme_snapshot()
                sig = _signature(snapshot)
                previous = getattr(self, "_lumafold_theme_follow_signature", None)
                if sig is not None and sig != previous:
                    changed = apply_snapshot(snapshot)
                    self._lumafold_theme_follow_signature = sig
                    self.state["theme_follow_status"] = "SYNCED"
                    self.state["theme_follow_source"] = "Blender Preferences Theme"
                    if changed:
                        # Force one style re-application at this frame boundary.
                        # Geometry/scale remain untouched.
                        self._applied_scale = None
        return original(self)

    host_cls._apply_pending_style = apply_pending_style_with_blender_theme
    _INSTALLED = True


def uninstall() -> None:
    global _INSTALLED, _ORIGINAL_APPLY_PENDING_STYLE, _UI_HOST_MODULE
    if _INSTALLED and _UI_HOST_MODULE is not None:
        host_cls = getattr(_UI_HOST_MODULE, "UIHost", None)
        if host_cls is not None and callable(_ORIGINAL_APPLY_PENDING_STYLE):
            host_cls._apply_pending_style = _ORIGINAL_APPLY_PENDING_STYLE
    restore_defaults()
    _ORIGINAL_APPLY_PENDING_STYLE = None
    _UI_HOST_MODULE = None
    _INSTALLED = False


def snapshot():
    return {
        "installed": bool(_INSTALLED),
        "poll_interval": float(_POLL_INTERVAL),
        "source": "Blender Preferences Theme",
        "has_snapshot": bool(_CURRENT_SNAPSHOT),
    }
