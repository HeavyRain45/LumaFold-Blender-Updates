from __future__ import annotations

"""Authoritative Brush Library selection policy.

The real Embedded picker is a multi-frame interaction.  The target Quick Brush
slot is latched when the UI publishes ``quick_replace_slot`` and is consumed by
the next Brush selection.  This avoids depending on a transient StateStore value
surviving popup close/dismiss bookkeeping.

Targeted replacement is intentionally split in two safe stages:
1. update the Quick Slot specification immediately (pure LumaFold state only);
2. activate that slot on the next Blender UI tick (native Brush Asset mutation).

Normal Brush Library selection remains deferred to the next Blender UI tick.
"""

import bpy

from ..core.app import APP

_INSTALLED = False
_ORIGINAL_ACTIVATE = None
_ORIGINAL_ASSIGN = None
_ORIGINAL_ACTIVATE_SLOT = None
_UNSUBSCRIBE_STATE = None
_REQUEST_SERIAL = 0
_TARGET_SLOT = -1


def _coerce_slot(value) -> int:
    try:
        return int(value)
    except Exception:
        return -1


def _on_sculpt_state_changed(payload):
    """Latch picker intent independently from popup/state cleanup ordering."""
    global _TARGET_SLOT
    fields = dict((payload or {}).get("fields") or {})
    if "quick_replace_slot" in fields:
        _TARGET_SLOT = _coerce_slot(fields.get("quick_replace_slot"))


def install():
    global _INSTALLED, _ORIGINAL_ACTIVATE, _ORIGINAL_ASSIGN, _ORIGINAL_ACTIVATE_SLOT
    global _UNSUBSCRIBE_STATE, _TARGET_SLOT
    if _INSTALLED:
        return
    commands = getattr(APP.commands, "_commands", {})
    activate = commands.get("sculpt.brush.library_activate")
    assign = commands.get("sculpt.brush.library_assign_slot")
    activate_slot = commands.get("sculpt.brush.activate_slot")
    if not all(callable(fn) for fn in (activate, assign, activate_slot)):
        raise RuntimeError("Sculpt Brush Library commands are unavailable")

    _ORIGINAL_ACTIVATE = activate
    _ORIGINAL_ASSIGN = assign
    _ORIGINAL_ACTIVATE_SLOT = activate_slot
    _TARGET_SLOT = -1
    _UNSUBSCRIBE_STATE = APP.events.subscribe("sculpt.state.changed", _on_sculpt_state_changed)

    def choose_asset(identity: str):
        global _REQUEST_SERIAL, _TARGET_SLOT
        identity = str(identity or "")
        if not identity:
            raise RuntimeError("Brush Asset identity 为空")

        state = APP.store.namespace("sculpt")
        store_target = _coerce_slot(state.get("quick_replace_slot", -1))
        target_slot = int(_TARGET_SLOT if _TARGET_SLOT >= 0 else store_target)

        _REQUEST_SERIAL += 1
        serial = int(_REQUEST_SERIAL)
        state["brush_library_request_serial"] = serial

        # A targeted picker click must update the requested Slot while the exact
        # target is still known.  This operation only updates LumaFold state and
        # persistence; it does not invoke Blender's native Brush operator.
        if target_slot >= 0:
            try:
                message = _ORIGINAL_ASSIGN(identity=identity, slot=target_slot)
            except Exception as exc:
                state["quick_replace_slot"] = -1
                _TARGET_SLOT = -1
                state["brush_action_status"] = f"笔刷库操作失败：{type(exc).__name__}: {exc}"
                raise
            state["quick_replace_slot"] = -1
            _TARGET_SLOT = -1
            state["brush_action_status"] = str(message or f"槽位 {target_slot + 1} 已替换")
        else:
            state["brush_action_status"] = "正在切换笔刷"

        def run():
            # Keep every click deterministic. A later click supersedes an older
            # native activation request that has not run yet.
            if serial != int(_REQUEST_SERIAL):
                return None
            try:
                if target_slot >= 0:
                    message = _ORIGINAL_ACTIVATE_SLOT(slot=target_slot)
                    state["brush_action_status"] = str(message or f"槽位 {target_slot + 1} 已激活")
                else:
                    message = _ORIGINAL_ACTIVATE(identity=identity)
                    state["brush_action_status"] = str(message or "笔刷已切换")
                APP.events.emit(
                    "sculpt.brush_library.selection_completed",
                    {
                        "identity": identity,
                        "target_slot": target_slot,
                        "serial": serial,
                    },
                )
            except Exception as exc:
                state["brush_action_status"] = f"笔刷库操作失败：{type(exc).__name__}: {exc}"
                state["quick_replace_slot"] = -1
            return None

        try:
            bpy.app.timers.register(run, first_interval=0.0)
        except Exception:
            run()
        return state["brush_action_status"]

    APP.commands.register("sculpt.brush.library_activate", choose_asset)
    _INSTALLED = True


def uninstall():
    global _INSTALLED, _ORIGINAL_ACTIVATE, _ORIGINAL_ASSIGN, _ORIGINAL_ACTIVATE_SLOT
    global _UNSUBSCRIBE_STATE, _REQUEST_SERIAL, _TARGET_SLOT
    if not _INSTALLED:
        return
    if callable(_ORIGINAL_ACTIVATE):
        APP.commands.register("sculpt.brush.library_activate", _ORIGINAL_ACTIVATE)
    if callable(_UNSUBSCRIBE_STATE):
        try:
            _UNSUBSCRIBE_STATE()
        except Exception:
            pass
    _UNSUBSCRIBE_STATE = None
    _ORIGINAL_ACTIVATE = None
    _ORIGINAL_ASSIGN = None
    _ORIGINAL_ACTIVATE_SLOT = None
    _REQUEST_SERIAL += 1
    _TARGET_SLOT = -1
    _INSTALLED = False
