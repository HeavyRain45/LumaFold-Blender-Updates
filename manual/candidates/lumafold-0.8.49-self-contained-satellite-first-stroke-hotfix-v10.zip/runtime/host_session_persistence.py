from __future__ import annotations

"""Persist and restore the user-facing LumaFold Host session.

This module owns only stable product session state:
- whether LumaFold was open when Blender closed;
- whether the active Host was Embedded or Satellite;
- the last Embedded local position;
- the last Satellite client-screen position.

It does not own HostControl, rendering, input routing, or migration mechanics.
Those authorities remain unchanged; this module only supplies startup intent and
one-shot placement hints to the existing production launch path.
"""

import ctypes
from ctypes import wintypes
import time

import bpy

from ..core.app import APP
from ..core.host_control import HOST_CONTROL
from ..core.state import STATE


_NAMESPACE = "__host_session__"
_DEFAULT_X_DESIGN = 52.0
_DEFAULT_Y_DESIGN = 68.0
_INSTALLED = False
_OPERATORS = None
_ORIGINAL_LAUNCH = None
_RESTORE_TIMER_ACTIVE = False


def _session():
    APP.register_state_schema(_NAMESPACE, 1)
    return APP.store.namespace(_NAMESPACE, {
        "was_open": False,
        "host_mode": "embedded",
        "satellite_x": 0.0,
        "satellite_y": 0.0,
        "satellite_w": 0.0,
        "satellite_h": 0.0,
        "satellite_restore_once": False,
    })


def _prepare_embedded_restore_hint() -> None:
    """Publish one startup placement hint into the existing UI state contract."""
    ui = APP.store.namespace("__ui__")
    scale = max(0.85, min(2.0, float(ui.get("ui_scale", ui.get("requested_scale", 1.25)) or 1.25)))
    if "embedded_last_valid_pos_x" in ui and "embedded_last_valid_pos_y" in ui:
        x = float(ui.get("embedded_last_valid_pos_x", 0.0) or 0.0)
        y = float(ui.get("embedded_last_valid_pos_y", 0.0) or 0.0)
    else:
        # First-run position: upper-left working area, matching the product
        # onboarding location requested for a new LumaFold user.
        x = _DEFAULT_X_DESIGN * scale
        y = _DEFAULT_Y_DESIGN * scale
    ui["embedded_restore_pos_x"] = max(0.0, x)
    ui["embedded_restore_pos_y"] = max(0.0, y)
    ui["embedded_restore_pending"] = True


def _capture_satellite_client_rect(pid: int):
    if int(pid or 0) <= 0 or not hasattr(ctypes, "WinDLL"):
        return None
    try:
        user32 = ctypes.WinDLL("user32", use_last_error=True)
        WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        found = []

        @WNDENUMPROC
        def enum_proc(hwnd, _lparam):
            process_id = wintypes.DWORD(0)
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(process_id))
            if int(process_id.value) == int(pid) and user32.IsWindowVisible(hwnd):
                found.append(hwnd)
                return False
            return True

        user32.EnumWindows(enum_proc, 0)
        if not found:
            return None
        hwnd = found[0]
        cr = wintypes.RECT()
        pt = wintypes.POINT(0, 0)
        if not user32.GetClientRect(hwnd, ctypes.byref(cr)):
            return None
        if not user32.ClientToScreen(hwnd, ctypes.byref(pt)):
            return None
        return {
            "left": int(pt.x),
            "top": int(pt.y),
            "width": max(1, int(cr.right - cr.left)),
            "height": max(1, int(cr.bottom - cr.top)),
        }
    except Exception:
        return None


def prepare_for_shutdown() -> None:
    """Capture product session truth before normal unregister tears Hosts down."""
    session = _session()
    proc = None
    try:
        from ..desktop.bridge_server import BRIDGE
        proc = getattr(BRIDGE, "satellite_process", None)
    except Exception:
        proc = None
    satellite_alive = bool(proc is not None and proc.poll() is None)
    lease = HOST_CONTROL.snapshot()
    mode = "satellite" if (
        satellite_alive
        or str(getattr(STATE, "host_mode", "embedded") or "embedded").lower() == "satellite"
        or (str(lease.get("state") or "") == "SATELLITE" and str(lease.get("owner") or "") == "satellite")
    ) else "embedded"
    session["was_open"] = bool(getattr(STATE, "running", False) or satellite_alive)
    session["host_mode"] = mode

    host = getattr(STATE, "host", None)
    if host is not None and not getattr(host, "closed", False):
        try:
            APP.store.namespace("__ui__").update(dict(host.export_transfer_state() or {}))
        except Exception:
            pass

    if satellite_alive:
        rect = _capture_satellite_client_rect(int(getattr(proc, "pid", 0) or 0))
        if rect:
            session["satellite_x"] = float(rect["left"])
            session["satellite_y"] = float(rect["top"])
            session["satellite_w"] = float(rect["width"])
            session["satellite_h"] = float(rect["height"])


def mark_mode(mode: str) -> None:
    session = _session()
    session["host_mode"] = "satellite" if str(mode or "").lower() == "satellite" else "embedded"
    session["was_open"] = True


def _find_primary_view3d():
    try:
        wm = bpy.context.window_manager
    except Exception:
        return None, None, None
    candidates = []
    for window in tuple(wm.windows):
        screen = getattr(window, "screen", None)
        if screen is None:
            continue
        for area in tuple(screen.areas):
            if getattr(area, "type", "") != "VIEW_3D":
                continue
            region = next((r for r in area.regions if r.type == "WINDOW"), None)
            if region is None:
                continue
            score = int(getattr(area, "width", 0) or 0) * int(getattr(area, "height", 0) or 0)
            candidates.append((score, window, area, region))
    if not candidates:
        return None, None, None
    candidates.sort(key=lambda item: item[0], reverse=True)
    _score, window, area, region = candidates[0]
    return window, area, region


def _restore_satellite_after_embedded():
    if _OPERATORS is None or not bool(getattr(STATE, "running", False)):
        return 0.05
    if getattr(STATE, "host", None) is None:
        return 0.05
    window, area, region = _find_primary_view3d()
    if window is None:
        return 0.10
    try:
        _session()["satellite_restore_once"] = True
        with bpy.context.temp_override(window=window, area=area, region=region):
            bpy.ops.lumafold.move_to_satellite("EXEC_DEFAULT")
    except Exception:
        return None
    return None


def _restore_startup_tick():
    global _RESTORE_TIMER_ACTIVE
    session = _session()
    if not bool(session.get("was_open", False)):
        _RESTORE_TIMER_ACTIVE = False
        return None
    if bool(getattr(STATE, "running", False)):
        _RESTORE_TIMER_ACTIVE = False
        return None
    window, area, region = _find_primary_view3d()
    if window is None:
        return 0.20
    try:
        _prepare_embedded_restore_hint()
        with bpy.context.temp_override(window=window, area=area, region=region):
            result = bpy.ops.lumafold.toggle_p0("INVOKE_DEFAULT")
        if "RUNNING_MODAL" not in set(result):
            return 0.25
        if str(session.get("host_mode") or "embedded") == "satellite":
            bpy.app.timers.register(_restore_satellite_after_embedded, first_interval=0.03)
    except Exception:
        return 0.25
    _RESTORE_TIMER_ACTIVE = False
    return None


def schedule_startup_restore() -> None:
    global _RESTORE_TIMER_ACTIVE
    _prepare_embedded_restore_hint()
    if _RESTORE_TIMER_ACTIVE or not bool(_session().get("was_open", False)):
        return
    _RESTORE_TIMER_ACTIVE = True
    try:
        bpy.app.timers.register(_restore_startup_tick, first_interval=0.35)
    except Exception:
        _RESTORE_TIMER_ACTIVE = False


def install(operators_module) -> None:
    """Install one-shot Satellite placement injection at the launcher boundary."""
    global _INSTALLED, _OPERATORS, _ORIGINAL_LAUNCH
    if _INSTALLED:
        return
    _OPERATORS = operators_module
    _prepare_embedded_restore_hint()
    original = getattr(operators_module, "launch_satellite_host", None)
    if callable(original):
        _ORIGINAL_LAUNCH = original

        def launch_with_restore(client_width, client_height, *, screen_x, screen_y, generation):
            session = _session()
            if bool(session.get("satellite_restore_once", False)):
                sx = float(session.get("satellite_x", screen_x) or screen_x)
                sy = float(session.get("satellite_y", screen_y) or screen_y)
                if sx or sy:
                    screen_x, screen_y = sx, sy
                session["satellite_restore_once"] = False
            return original(
                client_width, client_height,
                screen_x=screen_x, screen_y=screen_y, generation=generation,
            )

        operators_module.launch_satellite_host = launch_with_restore
    _INSTALLED = True


def uninstall() -> None:
    global _INSTALLED, _OPERATORS, _ORIGINAL_LAUNCH, _RESTORE_TIMER_ACTIVE
    if _OPERATORS is not None and callable(_ORIGINAL_LAUNCH):
        _OPERATORS.launch_satellite_host = _ORIGINAL_LAUNCH
    _INSTALLED = False
    _OPERATORS = None
    _ORIGINAL_LAUNCH = None
    _RESTORE_TIMER_ACTIVE = False


def snapshot():
    session = dict(_session())
    session["installed"] = bool(_INSTALLED)
    return session
