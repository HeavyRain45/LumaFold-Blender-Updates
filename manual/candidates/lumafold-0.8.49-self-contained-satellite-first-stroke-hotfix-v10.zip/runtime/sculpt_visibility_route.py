from __future__ import annotations

"""Narrow route bridge for ZBrush Ctrl+Shift visibility gestures.

This module exists because LumaFold's authoritative Sculpt modal route sees
pointer presses before Blender add-on keymaps. It delegates only Ctrl+Shift
LMB into the isolated visibility operator; all mesh mutation remains in
`sculpt_visibility_faceset` and Blender native operators.
"""

import bpy

_VISIBILITY = None


def install(visibility_module):
    global _VISIBILITY
    _VISIBILITY = visibility_module


def uninstall():
    global _VISIBILITY
    _VISIBILITY = None


def handle_pointer_press(context, event, target, *, tool_id="builtin.box_hide"):
    module = _VISIBILITY
    if module is None:
        return None
    if str(getattr(event, "type", "") or "").upper() != "LEFTMOUSE":
        return None
    if str(getattr(event, "value", "") or "").upper() != "PRESS":
        return None
    if not bool(getattr(event, "ctrl", False)) or not bool(getattr(event, "shift", False)):
        return None
    if target is None:
        return False
    if tool_id not in {"builtin.box_hide", "builtin.lasso_hide", "builtin.line_hide", "builtin.polyline_hide"}:
        return None
    window, area, region = target
    try:
        with bpy.context.temp_override(window=window, area=area, region=region):
            if tool_id == "builtin.lasso_hide":
                result = bpy.ops.lumafold.sculpt_visibility_lasso("INVOKE_DEFAULT")
            elif tool_id == "builtin.line_hide":
                result = bpy.ops.lumafold.sculpt_visibility_line("INVOKE_DEFAULT")
            elif tool_id == "builtin.polyline_hide":
                result = bpy.ops.lumafold.sculpt_visibility_polyline("INVOKE_DEFAULT")
            else:
                result = bpy.ops.lumafold.sculpt_visibility_rect("INVOKE_DEFAULT")
        return "RUNNING_MODAL" in set(result or ())
    except (RuntimeError, TypeError, AttributeError):
        return False
