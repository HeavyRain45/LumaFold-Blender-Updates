"""Satellite handoff safety guard.

Satellite readiness is owned by the child process. As of dev47 the child does
not send ``satellite_ready`` until all of these are true:
- its native WGL/ImGui host completed a real frame;
- its own HWND was moved from the off-screen preflight coordinate;
- the HWND is visible and intersects the Blender owner's monitor work area.

This Blender-side guard deliberately does *not* enumerate, move, or re-validate
the foreign HWND after lease grant. dev46 real-machine telemetry proved that a
second cross-process visibility authority could falsely reject an otherwise
healthy handoff and immediately restore Embedded.

Before detach, the real View3D operator context is also latched into the
Satellite truth cache. The recurring timer remains useful for later updates, but
first-frame correctness never depends on timer/context timing.

Embedded and Satellite positions are intentionally separate geometry truths.
Satellite is launched from the Embedded screen position, but its later HWND
position must never feed back into the saved Embedded region-local position.
That one-way rule prevents cumulative local->screen->local rounding/DPI/clamp
changes from making the floating workbench drift across repeated roundtrips.
"""
from __future__ import annotations

import time

from ..core.host_control import HOST_CONTROL, EMBEDDED, DETACHING, SATELLITE
from ..core.state import STATE
from ..desktop.bridge_server import BRIDGE


_INSTALLED = False
_ORIGINAL_EXECUTE = None
_ORIGINAL_HANDOFF_TICK = None
_ORIGINAL_EXTERNAL_ALIVE = None
_ORIGINAL_RESTORE_EMBEDDED = None
_HANDOFF_STARTED = 0.0
_HANDOFF_TIMEOUT = 6.0


def _process_alive() -> bool:
    proc = getattr(BRIDGE, "satellite_process", None)
    return bool(proc is not None and proc.poll() is None)


def _handoff_running(operators_module) -> bool:
    return bool(
        getattr(operators_module, "_MIGRATION_IN_PROGRESS", False)
        or getattr(operators_module, "_EXTERNAL_SATELLITE_HANDOFF_RUNNING", False)
    )


def _active_owner() -> bool:
    return bool(
        getattr(BRIDGE, "satellite_active", False)
        or str(getattr(STATE, "host_mode", "")) == "satellite"
        or str(getattr(HOST_CONTROL.lease, "state", "")) == SATELLITE
    )


def _publish_handoff_truth(context=None):
    """Late-bind the Blender truth authority only when a migration actually runs."""
    try:
        from . import satellite_bridge_authority
        return satellite_bridge_authority.publish_context_truth(context)
    except Exception:
        return {"mode": "", "workspace": "", "serial": 0}


def _satellite_log_tail(limit: int = 3000) -> str:
    try:
        from ..desktop.launcher import _satellite_log_path, _tail
        return str(_tail(_satellite_log_path(), limit=max(256, int(limit))) or "").strip()
    except Exception:
        return ""


def _record_startup_failure(prefix: str) -> str:
    detail = str(prefix or "Satellite startup failed").strip()
    tail = _satellite_log_tail()
    if tail:
        detail += "\n\nSatellite child log:\n" + tail
    STATE.last_error = detail
    return detail


def _recover_embedded_lease():
    try:
        if HOST_CONTROL.lease.state == DETACHING and HOST_CONTROL.lease.owner == "embedded":
            HOST_CONTROL.cancel_detach()
        elif HOST_CONTROL.lease.state != EMBEDDED or HOST_CONTROL.migration_locked:
            HOST_CONTROL.recover_embedded()
    except Exception:
        try:
            HOST_CONTROL.recover_embedded()
        except Exception:
            pass


def _heal_stale_child(operators_module):
    """Retire an orphan process only when no legitimate migration/owner exists."""
    if _active_owner() or _handoff_running(operators_module):
        return False
    stale = _process_alive() or HOST_CONTROL.lease.state != EMBEDDED or HOST_CONTROL.migration_locked
    if not stale:
        return False
    try:
        BRIDGE.stop_satellite_process()
    except Exception:
        pass
    _recover_embedded_lease()
    try:
        operators_module._EXTERNAL_SATELLITE_HANDOFF_RUNNING = False
        operators_module._MIGRATION_IN_PROGRESS = False
    except Exception:
        pass
    if str(getattr(STATE, "host_mode", "")) != "satellite":
        STATE.host_mode = "embedded"
    STATE.status = "Recovered stale Satellite handoff · Embedded retained"
    return True


def install(operators_module):
    global _INSTALLED, _ORIGINAL_EXECUTE, _ORIGINAL_HANDOFF_TICK, _ORIGINAL_EXTERNAL_ALIVE
    global _ORIGINAL_RESTORE_EMBEDDED
    if _INSTALLED:
        return

    cls = getattr(operators_module, "LUMAFOLD_OT_move_to_satellite", None)
    original_execute = getattr(cls, "execute", None) if cls is not None else None
    original_tick = getattr(operators_module, "_external_satellite_handoff_tick", None)
    original_alive = getattr(operators_module, "_external_satellite_alive", None)
    original_restore = getattr(operators_module, "_restore_embedded_after_satellite", None)
    if not all(callable(item) for item in (original_execute, original_tick, original_alive, original_restore)):
        return

    _ORIGINAL_EXECUTE = original_execute
    _ORIGINAL_HANDOFF_TICK = original_tick
    _ORIGINAL_EXTERNAL_ALIVE = original_alive
    _ORIGINAL_RESTORE_EMBEDDED = original_restore

    def owner_aware_external_alive():
        if not _process_alive():
            return False
        if _active_owner():
            return True
        return bool(
            _handoff_running(operators_module)
            and HOST_CONTROL.lease.state == DETACHING
            and HOST_CONTROL.lease.owner == "embedded"
        )

    def execute_with_stale_recovery(self, context):
        global _HANDOFF_STARTED
        _heal_stale_child(operators_module)
        starting_new = bool(
            not _active_owner()
            and not _handoff_running(operators_module)
            and HOST_CONTROL.lease.state == EMBEDDED
        )
        if starting_new:
            _HANDOFF_STARTED = time.monotonic()
            STATE.last_error = ""
            # Last guaranteed-good View3D context before Embedded can retire.
            _publish_handoff_truth(context)
        result = original_execute(self, context)
        if "FINISHED" not in set(result or ()) or not bool(
            getattr(operators_module, "_EXTERNAL_SATELLITE_HANDOFF_RUNNING", False)
        ):
            if not _handoff_running(operators_module):
                _HANDOFF_STARTED = 0.0
        return result

    def restore_embedded_without_roundtrip_drift(target):
        """Restore the exact Embedded-local position captured before detach.

        The legacy restore helper has an optional spatial-attach branch that maps
        the Satellite child HWND back through the original View3D screen rect.
        That is useful for a deliberate cross-host relocation, but it also makes
        ordinary back-and-forth switching sensitive to OS frame/DPI/clamping
        differences. For the product toggle, Embedded position memory is the
        authority; Satellite movement remains Satellite-only.
        """
        stable_target = dict(target or {})
        stable_target["source_view3d_screen_rect"] = None
        return original_restore(stable_target)

    def handoff_tick_with_timeout():
        global _HANDOFF_STARTED
        running_before = bool(getattr(operators_module, "_EXTERNAL_SATELLITE_HANDOFF_RUNNING", False))
        if running_before:
            # Refresh if Blender can provide a context; empty observations are
            # non-destructive inside the truth authority.
            _publish_handoff_truth(None)
            if _HANDOFF_STARTED <= 0.0:
                _HANDOFF_STARTED = time.monotonic()
            if time.monotonic() - _HANDOFF_STARTED > _HANDOFF_TIMEOUT:
                detail = _record_startup_failure(
                    "Satellite Host did not become child visible-ready within %.1f s" % _HANDOFF_TIMEOUT
                )
                try:
                    BRIDGE.stop_satellite_process()
                except Exception:
                    pass
                _recover_embedded_lease()
                try:
                    operators_module._EXTERNAL_SATELLITE_HANDOFF_RUNNING = False
                    operators_module._MIGRATION_IN_PROGRESS = False
                    operators_module._RETURN_EMBEDDED_TARGET = None
                except Exception:
                    pass
                STATE.host_mode = "embedded"
                last_line = detail.splitlines()[-1].strip() if detail else ""
                STATE.status = "Satellite visible-ready timeout · Embedded retained"
                if last_line:
                    STATE.status += " · " + last_line[:140]
                _HANDOFF_STARTED = 0.0
                return None

        result = original_tick()
        running_after = bool(getattr(operators_module, "_EXTERNAL_SATELLITE_HANDOFF_RUNNING", False))

        if running_before and not running_after and _active_owner() and _process_alive():
            STATE.last_error = ""
            STATE.status = "Satellite running · child visible-ready"

        if running_before and not running_after and not _active_owner() and not _process_alive():
            detail = _record_startup_failure("Satellite Host exited before child visible-ready handoff")
            last_line = detail.splitlines()[-1].strip() if detail else ""
            if last_line:
                STATE.status = "Satellite launch failed · Embedded retained · " + last_line[:140]
        if not running_after:
            _HANDOFF_STARTED = 0.0
        return result

    operators_module._external_satellite_alive = owner_aware_external_alive
    operators_module._external_satellite_handoff_tick = handoff_tick_with_timeout
    operators_module._restore_embedded_after_satellite = restore_embedded_without_roundtrip_drift
    cls.execute = execute_with_stale_recovery
    _INSTALLED = True


def uninstall(operators_module):
    global _INSTALLED, _ORIGINAL_EXECUTE, _ORIGINAL_HANDOFF_TICK, _ORIGINAL_EXTERNAL_ALIVE
    global _ORIGINAL_RESTORE_EMBEDDED, _HANDOFF_STARTED
    if not _INSTALLED:
        return
    cls = getattr(operators_module, "LUMAFOLD_OT_move_to_satellite", None)
    if cls is not None and callable(_ORIGINAL_EXECUTE):
        cls.execute = _ORIGINAL_EXECUTE
    if callable(_ORIGINAL_HANDOFF_TICK):
        operators_module._external_satellite_handoff_tick = _ORIGINAL_HANDOFF_TICK
    if callable(_ORIGINAL_EXTERNAL_ALIVE):
        operators_module._external_satellite_alive = _ORIGINAL_EXTERNAL_ALIVE
    if callable(_ORIGINAL_RESTORE_EMBEDDED):
        operators_module._restore_embedded_after_satellite = _ORIGINAL_RESTORE_EMBEDDED
    _ORIGINAL_EXECUTE = None
    _ORIGINAL_HANDOFF_TICK = None
    _ORIGINAL_EXTERNAL_ALIVE = None
    _ORIGINAL_RESTORE_EMBEDDED = None
    _HANDOFF_STARTED = 0.0
    _INSTALLED = False