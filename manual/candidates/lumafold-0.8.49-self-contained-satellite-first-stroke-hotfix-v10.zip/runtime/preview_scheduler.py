from __future__ import annotations

"""Stable, paced preview residency plus proactive Brush/Alpha prewarm.

The scheduler keeps Blender-owned preview pixels and changes scheduling only:

* while Sculpt mode is active, scan/prewarm the Brush library in the background;
* current/Quick Brush assets are queued before the rest of the Brush library;
* after each Alpha-library refresh, freeze one bounded Alpha working set and
  warm it through short runways until that exact set is actually resident;
* foreground tile requests stay higher priority but synchronously extract only a
  very small batch, so wheel input never pays for a large thumbnail burst;
* Native Secondary snapshots rotate small preview deltas instead of repeating
  the same tail forever, allowing its warm process to accumulate previews before
  the user scrolls.
"""

from collections import deque
import time

import bpy

from ..core.app import APP
from ..desktop.bridge_server import BRIDGE
from . import primary_visual_assets as visual

_BRUSH_CMD = "sculpt.brush.library_preview"
_ALPHA_CMD = "sculpt.alpha.library_preview"
_BRUSH_CACHE_ITEMS = 160
_ALPHA_CACHE_ITEMS = 128
_ALPHA_PREWARM_ITEMS = 64
_ALPHA_PREWARM_RUNWAY = 8
_SEND_BRUSH_ITEMS = 12
_SEND_ALPHA_ITEMS = 8

# Foreground requests come from the currently visible tiles. Keep their
# synchronous portion tiny. Background prewarm is intentionally spread over
# Blender UI ticks so thumbnail extraction never becomes one large hitch.
_FOREGROUND_CHUNK = 2
_BACKGROUND_CHUNK = 2
_PUMP_INTERVAL = 0.030
_PREWARM_FIRST_DELAY = 0.55
_PREWARM_IDLE_POLL = 1.00

_INSTALLED = False
_ORIGINAL_COMMANDS = {}
_ORIGINAL_SNAPSHOT = None
_BRUSH_QUEUE = deque()
_ALPHA_QUEUE = deque()
_BRUSH_PENDING = set()
_ALPHA_PENDING = set()
_BRUSH_TIMER = False
_ALPHA_TIMER = False
_PREWARM_SERIAL = -1
_PREWARM_REFRESH_AT = 0.0
_ALPHA_PREWARM_SERIAL = -1
_ALPHA_PREWARM_TARGETS = []
_SECONDARY_CURSOR = {"brush": 0, "alpha": 0}


def _ids(identities=None, identity=""):
    result = [str(item) for item in list(identities or ()) if str(item or "")]
    if identity:
        result.append(str(identity))
    return list(dict.fromkeys(result))


def _touch(kind: str, identities):
    state = APP.store.namespace("sculpt")
    if kind == "brush":
        keys = ("primary_brush_preview_cache", "brush_library_preview_cache")
        limit = _BRUSH_CACHE_ITEMS
    else:
        keys = ("primary_alpha_preview_cache", "alpha_library_preview_cache")
        limit = _ALPHA_CACHE_ITEMS
    for key in keys:
        cache = state.setdefault(key, {})
        for identity in identities:
            identity = str(identity)
            payload = cache.pop(identity, None)
            if payload:
                cache[identity] = payload
        while len(cache) > limit:
            cache.pop(next(iter(cache)), None)


def _run_delegate(kind: str, delegate, chunk):
    chunk = [str(item) for item in list(chunk or ()) if str(item or "")]
    if not chunk:
        return "NO_PREVIEW_REQUEST"
    try:
        result = delegate(identities=chunk)
    finally:
        _touch(kind, chunk)
    return result


def _queue_more(kind: str, delegate, values):
    global _BRUSH_TIMER, _ALPHA_TIMER
    queue_obj = _BRUSH_QUEUE if kind == "brush" else _ALPHA_QUEUE
    pending = _BRUSH_PENDING if kind == "brush" else _ALPHA_PENDING
    values = [str(item) for item in list(values or ()) if str(item or "")]
    for start in range(0, len(values), _BACKGROUND_CHUNK):
        chunk = tuple(values[start:start + _BACKGROUND_CHUNK])
        fresh = tuple(item for item in chunk if item not in pending)
        if not fresh:
            continue
        pending.update(fresh)
        queue_obj.append((delegate, fresh))

    if kind == "brush":
        if _BRUSH_TIMER or not queue_obj:
            return
        _BRUSH_TIMER = True
    else:
        if _ALPHA_TIMER or not queue_obj:
            return
        _ALPHA_TIMER = True

    def pump():
        global _BRUSH_TIMER, _ALPHA_TIMER
        if not _INSTALLED:
            if kind == "brush":
                _BRUSH_TIMER = False
            else:
                _ALPHA_TIMER = False
            return None
        queue_now = _BRUSH_QUEUE if kind == "brush" else _ALPHA_QUEUE
        pending_now = _BRUSH_PENDING if kind == "brush" else _ALPHA_PENDING
        if not queue_now:
            if kind == "brush":
                _BRUSH_TIMER = False
            else:
                _ALPHA_TIMER = False
            return None
        delegate_now, chunk_now = queue_now.popleft()
        try:
            _run_delegate(kind, delegate_now, chunk_now)
        except Exception:
            pass
        finally:
            for item in chunk_now:
                pending_now.discard(item)
        if not queue_now:
            if kind == "brush":
                _BRUSH_TIMER = False
            else:
                _ALPHA_TIMER = False
            return None
        return _PUMP_INTERVAL

    try:
        bpy.app.timers.register(pump, first_interval=0.020)
    except Exception:
        if kind == "brush":
            _BRUSH_TIMER = False
        else:
            _ALPHA_TIMER = False


def _make_paced(kind: str, delegate):
    def paced(*, identities=None, identity=""):
        requested = _ids(identities, identity)
        if not requested:
            return delegate(identities=identities, identity=identity)
        immediate = requested[:_FOREGROUND_CHUNK]
        later = requested[_FOREGROUND_CHUNK:]
        message = _run_delegate(kind, delegate, immediate)
        if later:
            _queue_more(kind, delegate, later)
        return str(message)
    return paced


def _rotating_delta(cache, count: int, kind: str):
    """Return a small rotating window so a warm Secondary eventually sees all previews."""
    cache = dict(cache or {})
    items = list(cache.items())
    count = max(1, int(count))
    if len(items) <= count:
        return cache
    start = int(_SECONDARY_CURSOR.get(kind, 0)) % len(items)
    selected = []
    for offset in range(count):
        selected.append(items[(start + offset) % len(items)])
    _SECONDARY_CURSOR[kind] = (start + count) % len(items)
    return dict(selected)


def _normalize_rel(value):
    return str(value or "").replace("\\", "/").strip().casefold()


def _ordered_missing_brush_ids(state):
    assets = [dict(item or {}) for item in list(state.get("brush_library_assets") or ())]
    cache = dict(state.get("brush_library_preview_cache") or {})
    current_rel = _normalize_rel((state.get("current_brush_asset") or {}).get("relative_asset_identifier"))
    quick_rels = {
        _normalize_rel((slot or {}).get("relative_asset_identifier"))
        for slot in list(state.get("quick_brush_slots") or ())
        if _normalize_rel((slot or {}).get("relative_asset_identifier"))
    }

    ranked = []
    for index, asset in enumerate(assets):
        identity = str(asset.get("identity") or "")
        if not identity or (cache.get(identity) or {}).get("rgba_b64"):
            continue
        rel = _normalize_rel(asset.get("relative_asset_identifier"))
        priority = 0 if current_rel and rel == current_rel else (1 if rel in quick_rels else 2)
        ranked.append((priority, index, identity))
    ranked.sort(key=lambda item: (item[0], item[1]))
    return [identity for _priority, _index, identity in ranked]


def _ordered_missing_alpha_ids(state):
    """Choose a bounded Alpha working set for a fresh library scan."""
    assets = [dict(item or {}) for item in list(state.get("alpha_library_assets") or ())]
    cache = dict(state.get("alpha_library_preview_cache") or {})
    current_identity = str(state.get("current_alpha_identity") or "none")
    ranked = []
    for index, asset in enumerate(assets):
        identity = str(asset.get("identity") or "")
        if not identity or identity == "none" or (cache.get(identity) or {}).get("rgba_b64"):
            continue
        priority = 0 if identity == current_identity else 1
        ranked.append((priority, index, identity))
    ranked.sort(key=lambda item: (item[0], item[1]))
    return [identity for _priority, _index, identity in ranked[:_ALPHA_PREWARM_ITEMS]]


def _brush_prewarm_tick():
    """Low-priority Brush prewarm while Blender is in Sculpt mode."""
    global _PREWARM_SERIAL, _PREWARM_REFRESH_AT
    if not _INSTALLED:
        return None
    try:
        if str(getattr(bpy.context, "mode", "") or "").upper() != "SCULPT":
            return 0.50

        state = APP.store.namespace("sculpt")
        status = str(state.get("brush_library_status") or "NOT_LOADED")
        now = time.monotonic()
        if status in {"NOT_LOADED", "ERROR"}:
            if now - float(_PREWARM_REFRESH_AT) > 1.5:
                _PREWARM_REFRESH_AT = now
                try:
                    APP.execute("sculpt.brush.library_refresh")
                except Exception:
                    pass
            return 0.20
        if status in {"SCANNING", "PENDING"}:
            return 0.12
        if status != "READY":
            return 0.50

        serial = int(state.get("brush_library_scan_serial", 0) or 0)
        missing = _ordered_missing_brush_ids(state)
        if missing:
            delegate = _ORIGINAL_COMMANDS.get(_BRUSH_CMD)
            if callable(delegate):
                _queue_more("brush", delegate, missing)
            _PREWARM_SERIAL = serial
            return 0.35

        _PREWARM_SERIAL = serial
        return _PREWARM_IDLE_POLL
    except Exception:
        return 0.75


def _alpha_prewarm_tick():
    """Warm one fixed <=64 Alpha target set per successful library refresh.

    A performance guard is allowed to shorten each queue request. Therefore the
    scan is not marked complete merely because work was *queued*. We retain the
    target identities and keep offering a tiny runway until the preview cache
    proves every target is resident. This prevents the old "4 thumbnails only"
    seam while still respecting interaction-time throttling.
    """
    global _ALPHA_PREWARM_SERIAL, _ALPHA_PREWARM_TARGETS
    if not _INSTALLED:
        return None
    try:
        if str(getattr(bpy.context, "mode", "") or "").upper() != "SCULPT":
            return 0.50
        state = APP.store.namespace("sculpt")
        status = str(state.get("alpha_library_status") or "NOT_LOADED")
        if status in {"SCANNING", "PENDING"}:
            return 0.12
        if status != "READY":
            return 0.50

        serial = int(state.get("alpha_library_scan_serial", 0) or 0)
        if serial <= 0:
            return _PREWARM_IDLE_POLL
        if serial != _ALPHA_PREWARM_SERIAL:
            _ALPHA_PREWARM_SERIAL = serial
            _ALPHA_PREWARM_TARGETS = list(_ordered_missing_alpha_ids(state))

        if not _ALPHA_PREWARM_TARGETS:
            return _PREWARM_IDLE_POLL

        cache = dict(state.get("alpha_library_preview_cache") or {})
        remaining = [
            identity for identity in _ALPHA_PREWARM_TARGETS
            if not (cache.get(identity) or {}).get("rgba_b64")
        ]
        if not remaining:
            _ALPHA_PREWARM_TARGETS = []
            return _PREWARM_IDLE_POLL

        delegate = _ORIGINAL_COMMANDS.get(_ALPHA_CMD)
        if callable(delegate):
            _queue_more("alpha", delegate, remaining[:_ALPHA_PREWARM_RUNWAY])
        return 0.35
    except Exception:
        return 0.75


def install():
    global _INSTALLED, _ORIGINAL_SNAPSHOT
    if _INSTALLED:
        return

    visual._BRUSH_CACHE_ITEMS = _BRUSH_CACHE_ITEMS
    visual._ALPHA_CACHE_ITEMS = _ALPHA_CACHE_ITEMS

    commands = getattr(APP.commands, "_commands", {})
    for command_id, kind in ((_BRUSH_CMD, "brush"), (_ALPHA_CMD, "alpha")):
        delegate = commands.get(command_id)
        if callable(delegate):
            _ORIGINAL_COMMANDS[command_id] = delegate
            APP.commands.register(command_id, _make_paced(kind, delegate))

    _ORIGINAL_SNAPSHOT = BRIDGE._snapshot

    def compact_snapshot(client_name: str = ""):
        snapshot = _ORIGINAL_SNAPSHOT(client_name)
        client = str(client_name or "")
        if not client.startswith("LumaFold Secondary"):
            return snapshot
        try:
            module_state = snapshot.get("module_state") or {}
            sculpt = module_state.get("sculpt") or {}
            sculpt["brush_library_preview_cache"] = _rotating_delta(
                sculpt.get("brush_library_preview_cache"), _SEND_BRUSH_ITEMS, "brush"
            )
            sculpt["alpha_library_preview_cache"] = _rotating_delta(
                sculpt.get("alpha_library_preview_cache"), _SEND_ALPHA_ITEMS, "alpha"
            )
            module_state["sculpt"] = sculpt
            snapshot["module_state"] = module_state
        except Exception:
            pass
        return snapshot

    BRIDGE._snapshot = compact_snapshot
    _INSTALLED = True
    try:
        bpy.app.timers.register(_brush_prewarm_tick, first_interval=_PREWARM_FIRST_DELAY)
    except Exception:
        pass
    try:
        bpy.app.timers.register(_alpha_prewarm_tick, first_interval=_PREWARM_FIRST_DELAY + 0.20)
    except Exception:
        pass


def uninstall():
    global _INSTALLED, _ORIGINAL_SNAPSHOT, _BRUSH_TIMER, _ALPHA_TIMER, _PREWARM_SERIAL
    global _ALPHA_PREWARM_SERIAL, _ALPHA_PREWARM_TARGETS
    _INSTALLED = False
    for command_id, delegate in tuple(_ORIGINAL_COMMANDS.items()):
        APP.commands.register(command_id, delegate)
    _ORIGINAL_COMMANDS.clear()
    if _ORIGINAL_SNAPSHOT is not None:
        BRIDGE._snapshot = _ORIGINAL_SNAPSHOT
        _ORIGINAL_SNAPSHOT = None
    _BRUSH_QUEUE.clear(); _ALPHA_QUEUE.clear()
    _BRUSH_PENDING.clear(); _ALPHA_PENDING.clear()
    _BRUSH_TIMER = False; _ALPHA_TIMER = False
    _PREWARM_SERIAL = -1
    _ALPHA_PREWARM_SERIAL = -1
    _ALPHA_PREWARM_TARGETS = []
    _SECONDARY_CURSOR["brush"] = 0
    _SECONDARY_CURSOR["alpha"] = 0
