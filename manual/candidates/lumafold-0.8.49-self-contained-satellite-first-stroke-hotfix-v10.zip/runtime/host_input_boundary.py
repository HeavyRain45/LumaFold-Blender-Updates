from __future__ import annotations

"""Blender UI ownership boundary for the Embedded LumaFold Host modal.

Resolve the concrete Blender region under the pointer. Any non-WINDOW region in
the bound VIEW_3D takes precedence over WINDOW. Only points that are inside the
WINDOW region and not covered by Blender-owned overlay regions may enter
LumaFold's pointer pipeline.

The Blender operator still owns a legacy 60 Hz event timer for lifecycle
compatibility.  Idle TIMER events are coalesced here before they reach the
operator's context/redraw path. Real pointer/key events are never throttled, so
interactive input remains event-driven while an idle LumaFold Host cannot force
an entire View3D redraw sixty times per second.
"""

import time


_POINTER_BUTTONS = {"LEFTMOUSE", "RIGHTMOUSE", "MIDDLEMOUSE"}
_POINTER_MOTION = {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}
_POINTER_WHEEL = {"WHEELUPMOUSE", "WHEELDOWNMOUSE", "WHEELINMOUSE", "WHEELOUTMOUSE"}
_POINTER_EVENTS = _POINTER_BUTTONS | _POINTER_MOTION | _POINTER_WHEEL
_IDLE_TIMER_INTERVAL = 0.10

_INSTALLED = False
_ORIGINAL_MODAL = None
_OPERATORS = None


def configure(operators_module):
    global _OPERATORS
    _OPERATORS = operators_module


def _bound_view3d(operator):
    host = getattr(operator, "_host", None)
    if host is None or _OPERATORS is None:
        return None, None, None
    try:
        window, area, _rebound = _OPERATORS._ensure_host_binding(host)
    except Exception:
        window = None
        area = None
    if area is None:
        return host, window, None
    return host, window, area


def _point_in_region(region, mx, my):
    try:
        return bool(
            float(region.x) <= mx < float(region.x + region.width)
            and float(region.y) <= my < float(region.y + region.height)
        )
    except Exception:
        return False


def _pointer_inside_bound_view3d_window(operator, context, event):
    host, window, area = _bound_view3d(operator)
    if host is None or area is None:
        return False

    try:
        event_window = getattr(context, "window", None)
        if event_window is None:
            return False
        if int(event_window.as_pointer()) != int(getattr(host, "window_pointer", 0) or 0):
            return False
        if window is not None and int(event_window.as_pointer()) != int(window.as_pointer()):
            return False
    except Exception:
        return False

    try:
        mx = float(event.mouse_x)
        my = float(event.mouse_y)
    except Exception:
        return False

    try:
        regions = tuple(getattr(area, "regions", ()) or ())
    except Exception:
        regions = ()

    window_region = next((r for r in regions if getattr(r, "type", "") == "WINDOW"), None)
    if window_region is None or not _point_in_region(window_region, mx, my):
        return False

    for region in regions:
        region_type = str(getattr(region, "type", "") or "")
        if region_type == "WINDOW":
            continue
        try:
            if int(getattr(region, "width", 0) or 0) <= 0 or int(getattr(region, "height", 0) or 0) <= 0:
                continue
        except Exception:
            continue
        if _point_in_region(region, mx, my):
            return False

    return True


def _host_owns_pointer(operator):
    host = getattr(operator, "_host", None)
    if host is None:
        return False
    try:
        owned = getattr(host, "_mouse_owned", None)
        if isinstance(owned, dict):
            return bool(any(bool(value) for value in owned.values()))
    except Exception:
        pass
    return False


def _reset_host_transient_input(operator):
    host = getattr(operator, "_host", None)
    if host is None:
        return
    try:
        host._reset_transient_input()
    except Exception:
        try:
            host._release_owned_input()
        except Exception:
            pass


def _admit_idle_timer(operator) -> bool:
    """Coalesce legacy 60 Hz Blender TIMER traffic to a 10 Hz watchdog.

    The low-frequency pulse is enough for Workspace/Mode roaming, async preview
    visibility and lifecycle health. All real mouse/key events bypass this gate
    and therefore preserve native-feeling interaction latency.
    """
    now = time.perf_counter()
    last = float(getattr(operator, "_lumafold_idle_timer_at", 0.0) or 0.0)
    if last > 0.0 and (now - last) < _IDLE_TIMER_INTERVAL:
        return False
    operator._lumafold_idle_timer_at = now
    return True


def install():
    global _INSTALLED, _ORIGINAL_MODAL
    if _INSTALLED or _OPERATORS is None:
        return

    cls = getattr(_OPERATORS, "LUMAFOLD_OT_toggle_p0", None)
    original = getattr(cls, "modal", None) if cls is not None else None
    if not callable(original):
        return

    _ORIGINAL_MODAL = original

    def modal_with_blender_ui_boundary(self, context, event):
        event_type = str(getattr(event, "type", "") or "")
        event_value = str(getattr(event, "value", "") or "").upper()

        if event_type == "TIMER":
            if not _admit_idle_timer(self):
                return {"RUNNING_MODAL"}
            return original(self, context, event)

        if event_type == "WINDOW_DEACTIVATE":
            return original(self, context, event)

        if event_type in _POINTER_EVENTS:
            inside = _pointer_inside_bound_view3d_window(self, context, event)
            host_owns_pointer = _host_owns_pointer(self)

            if not inside and not host_owns_pointer:
                if event_type in _POINTER_BUTTONS and event_value == "PRESS":
                    _reset_host_transient_input(self)
                return {"PASS_THROUGH"}

            if not inside and host_owns_pointer:
                return original(self, context, event)

        return original(self, context, event)

    cls.modal = modal_with_blender_ui_boundary
    _INSTALLED = True


def uninstall():
    global _INSTALLED, _ORIGINAL_MODAL, _OPERATORS
    if _OPERATORS is not None and callable(_ORIGINAL_MODAL):
        cls = getattr(_OPERATORS, "LUMAFOLD_OT_toggle_p0", None)
        if cls is not None:
            try:
                cls.modal = _ORIGINAL_MODAL
            except Exception:
                pass
    _ORIGINAL_MODAL = None
    _OPERATORS = None
    _INSTALLED = False
