from __future__ import annotations

"""Isolated ZBrush-style Alt gesture semantics.

Ownership contract:
- this module owns only Alt-specific Sculpt interaction;
- ordinary Sculpt/Rotate remain Blender-native elsewhere;
- no Alt grace/timestamp may arm a future gesture;
- inverse sculpt is delegated to Blender Sculpt;
- Alt tap object transfer is delegated to Blender ``object.transfer_mode``;
- continuous ZBrush Scale is delegated to ``sculpt_alt_zoom``;
- custom pan is the only other deliberate view-state exception because ZBrush's
  Alt-release-to-zoom gesture cannot be represented by one native modal handoff.
"""

import bpy
from bpy_extras import view3d_utils


ALT_GESTURE_ID = "lumafold.sculpt_alt_gesture_v1"

_INSTALLED = False
_TRACE = None
_ZOOM = None

_MOVE_EVENTS = {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}
_ALT_KEYS = {"LEFT_ALT", "RIGHT_ALT"}


def _trace(reason: str, context, event, **extra):
    if _TRACE is None:
        return
    try:
        payload = {
            "reason": str(reason),
            "event": str(getattr(event, "type", "") or ""),
            "value": str(getattr(event, "value", "") or ""),
        }
        payload.update(extra)
        _TRACE.trace("ZBRUSH_ALT_GESTURE", **payload)
    except Exception:
        pass


def _region_xy(context, event):
    try:
        return (
            float(getattr(event, "mouse_region_x", 0.0) or 0.0),
            float(getattr(event, "mouse_region_y", 0.0) or 0.0),
        )
    except Exception:
        return 0.0, 0.0


def _drag_threshold(context) -> float:
    try:
        inputs = context.preferences.inputs
        values = []
        for name in ("drag_threshold_tablet", "drag_threshold_mouse", "drag_threshold"):
            value = getattr(inputs, name, None)
            if value is not None and float(value) > 0.0:
                values.append(float(value))
        if values:
            return max(2.0, min(values))
    except Exception:
        pass
    return 4.0


def _tablet_contact_lost(event) -> bool:
    try:
        return bool(event.is_tablet) and float(event.pressure) <= 0.001
    except Exception:
        return False


def _native_inverse_sculpt(target):
    window, area, region = target
    try:
        with bpy.context.temp_override(window=window, area=area, region=region):
            result = bpy.ops.sculpt.brush_stroke(
                "INVOKE_DEFAULT",
                mode="INVERT",
                ignore_background_click=True,
            )
        return set(result or ())
    except (RuntimeError, TypeError, AttributeError):
        return {"CANCELLED"}


def _native_transfer_object(context):
    """Invoke Blender's native under-cursor mode transfer in the live event context."""
    window = getattr(context, "window", None)
    area = getattr(context, "area", None)
    region = getattr(context, "region", None)
    try:
        if window is not None and area is not None and region is not None:
            with bpy.context.temp_override(window=window, area=area, region=region):
                return set(bpy.ops.object.transfer_mode("INVOKE_DEFAULT") or ())
        return set(bpy.ops.object.transfer_mode("INVOKE_DEFAULT") or ())
    except (RuntimeError, TypeError, AttributeError):
        return {"CANCELLED"}


def _pan_step(context, current_x, current_y, previous_x, previous_y):
    """Small isolated ZBrush-specific pan step; never owns ordinary navigation."""
    region = getattr(context, "region", None)
    rv3d = getattr(context, "region_data", None)
    if region is None or rv3d is None:
        return
    try:
        depth = rv3d.view_location.copy()
        prev = view3d_utils.region_2d_to_location_3d(
            region, rv3d, (float(previous_x), float(previous_y)), depth
        )
        curr = view3d_utils.region_2d_to_location_3d(
            region, rv3d, (float(current_x), float(current_y)), depth
        )
        rv3d.view_location += prev - curr
        rv3d.update()
        area = getattr(context, "area", None)
        if area is not None:
            area.tag_redraw()
    except Exception:
        pass


class LUMAFOLD_OT_sculpt_alt_gesture_v1(bpy.types.Operator):
    bl_idname = ALT_GESTURE_ID
    bl_label = "LumaFold ZBrush Alt Gesture"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        return bool(
            str(getattr(context, "mode", "") or "").upper() == "SCULPT"
            and getattr(getattr(context, "area", None), "type", "") == "VIEW_3D"
            and getattr(getattr(context, "region", None), "type", "") == "WINDOW"
        )

    def invoke(self, context, event):
        if not bool(getattr(event, "alt", False)):
            return {"CANCELLED"}
        self._alt_down = True
        self._moved = False
        self._zoom_mode = False
        self._tablet = bool(getattr(event, "is_tablet", False))
        self._start_x, self._start_y = _region_xy(context, event)
        self._last_x, self._last_y = self._start_x, self._start_y
        threshold = _drag_threshold(context)
        self._threshold_sq = threshold * threshold
        context.window_manager.modal_handler_add(self)
        _trace("started", context, event)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        event_type = str(getattr(event, "type", "") or "").upper()
        event_value = str(getattr(event, "value", "") or "").upper()

        if event_type == "WINDOW_DEACTIVATE":
            _trace("window_deactivate", context, event)
            return {"CANCELLED"}
        if event_type == "ESC":
            return {"CANCELLED"}

        # A tablet RELEASE commonly carries pressure=0. Complete the gesture
        # before treating zero-pressure hover/motion as contact loss.
        if event_type == "LEFTMOUSE" and event_value == "RELEASE":
            if not self._moved:
                result = _native_transfer_object(context)
                _trace("alt_tap_transfer", context, event, result=list(result))
            return {"FINISHED"}

        if self._tablet and _tablet_contact_lost(event):
            _trace("tablet_contact_lost", context, event)
            return {"FINISHED"}

        if event_type in _ALT_KEYS:
            if event_value == "PRESS":
                self._alt_down = True
                self._zoom_mode = False
            elif event_value == "RELEASE":
                self._alt_down = False
                if self._moved:
                    self._zoom_mode = True
                    self._last_x, self._last_y = _region_xy(context, event)
                    _trace("zoom_armed_by_real_alt_release", context, event)
            return {"RUNNING_MODAL"}

        if event_type in _MOVE_EVENTS:
            x, y = _region_xy(context, event)
            if not self._moved:
                dx = float(x) - float(self._start_x)
                dy = float(y) - float(self._start_y)
                if dx * dx + dy * dy < self._threshold_sq:
                    self._last_x, self._last_y = float(x), float(y)
                    return {"RUNNING_MODAL"}
                self._moved = True

            alt_now = bool(getattr(event, "alt", False)) or bool(self._alt_down)
            if alt_now and not self._zoom_mode:
                _pan_step(context, x, y, self._last_x, self._last_y)
                _trace("pan_step", context, event)
            else:
                self._zoom_mode = True
                dx = float(x) - float(self._last_x)
                dy = float(y) - float(self._last_y)
                ok = bool(_ZOOM is not None and _ZOOM.apply(context, dx, dy))
                _trace(
                    "continuous_zoom" if ok else "continuous_zoom_failed",
                    context,
                    event,
                    dx=float(dx),
                    dy=float(dy),
                )
            self._last_x, self._last_y = float(x), float(y)
            return {"RUNNING_MODAL"}

        return {"RUNNING_MODAL", "PASS_THROUGH"}


_CLASSES = (LUMAFOLD_OT_sculpt_alt_gesture_v1,)


def handle_pointer_press(context, event, target):
    """Return True/False when owned, or None when this module is not applicable."""
    if str(getattr(event, "type", "") or "").upper() != "LEFTMOUSE":
        return None
    if str(getattr(event, "value", "") or "").upper() != "PRESS":
        return None
    if bool(getattr(event, "ctrl", False)) or bool(getattr(event, "shift", False)):
        return None
    if not bool(getattr(event, "alt", False)):
        return None
    if target is None:
        return False

    inverse = _native_inverse_sculpt(target)
    if "RUNNING_MODAL" in inverse or "FINISHED" in inverse:
        _trace("native_inverse_sculpt", context, event, result=list(inverse))
        return True
    if "PASS_THROUGH" not in inverse:
        _trace("inverse_sculpt_failed_closed", context, event, result=list(inverse))
        return False

    window, area, region = target
    try:
        with bpy.context.temp_override(window=window, area=area, region=region):
            result = bpy.ops.lumafold.sculpt_alt_gesture_v1("INVOKE_DEFAULT")
        ok = bool("RUNNING_MODAL" in set(result or ()))
        _trace("background_alt_started" if ok else "background_alt_failed", context, event)
        return ok
    except (RuntimeError, TypeError, AttributeError):
        return False


def install(real_machine_trace=None, zoom_adapter=None):
    global _INSTALLED, _TRACE, _ZOOM
    if _INSTALLED:
        return
    if zoom_adapter is None or not callable(getattr(zoom_adapter, "apply", None)):
        raise RuntimeError("ZBrush continuous zoom adapter is unavailable")
    _TRACE = real_machine_trace
    _ZOOM = zoom_adapter
    for cls in _CLASSES:
        try:
            bpy.utils.register_class(cls)
        except RuntimeError:
            try:
                bpy.utils.unregister_class(cls)
            except Exception:
                pass
            bpy.utils.register_class(cls)
    _INSTALLED = True


def uninstall():
    global _INSTALLED, _TRACE, _ZOOM
    if not _INSTALLED:
        return
    for cls in reversed(_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    _TRACE = None
    _ZOOM = None
    _INSTALLED = False
