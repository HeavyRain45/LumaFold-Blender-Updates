from __future__ import annotations

from pathlib import Path
import os
import shutil
import subprocess
import sys
import tempfile
import time

import bpy

from .bridge_server import BRIDGE
from ..runtime.bootstrap import vendor_dir
from ..ui.win32_window import find_process_hwnd


def _python_candidates():
    """Yield likely standalone Python executables.

    Prefer python.exe over pythonw.exe for reliability. We suppress the console
    with CREATE_NO_WINDOW instead of relying on pythonw, and always capture a
    launch log so early Desktop Host failures are visible from Blender.
    """
    prefix = Path(sys.prefix)
    roots = [prefix, prefix.parent]
    for root in roots:
        yield root / "bin" / "python.exe"
        yield root / "bin" / "pythonw.exe"
        yield root / "python.exe"
        yield root / "pythonw.exe"

    blender = Path(bpy.app.binary_path).resolve()
    version = f"{bpy.app.version[0]}.{bpy.app.version[1]}"
    base = blender.parent / version / "python"
    yield base / "bin" / "python.exe"
    yield base / "bin" / "pythonw.exe"


def find_python_executable() -> str:
    seen = set()
    for candidate in _python_candidates():
        text = str(candidate)
        if text in seen:
            continue
        seen.add(text)
        if candidate.is_file():
            return text
    for name in ("python.exe", "pythonw.exe", "py.exe"):
        found = shutil.which(name)
        if found:
            return found
    raise RuntimeError(
        "Could not find a standalone Python executable for the Desktop Host. "
        "Expected Blender's bundled python/bin/python.exe."
    )


def _log_path() -> Path:
    root = Path(tempfile.gettempdir()) / "LumaFold"
    root.mkdir(parents=True, exist_ok=True)
    return root / "desktop_host_p011.log"


def _tail(path: Path, limit: int = 4000) -> str:
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return ""
    return text[-limit:].strip()


def launch_desktop_host():
    BRIDGE.start()
    proc = BRIDGE.desktop_process
    if proc is not None and proc.poll() is None:
        return proc

    script = Path(__file__).resolve().parent / "desktop_host.py"
    python_exe = find_python_executable()
    log_path = _log_path()
    try:
        log_path.unlink(missing_ok=True)
    except Exception:
        pass

    args = [
        python_exe,
        "-u",
        str(script),
        "--port", str(BRIDGE.port),
        "--token", BRIDGE.token,
        "--parent-pid", str(os.getpid()),
    ]

    creationflags = 0
    if os.name == "nt":
        creationflags = (
            getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
            | getattr(subprocess, "CREATE_NO_WINDOW", 0)
        )

    log_handle = open(log_path, "ab", buffering=0)
    try:
        proc = subprocess.Popen(
            args,
            cwd=str(script.parent),
            stdin=subprocess.DEVNULL,
            stdout=log_handle,
            stderr=subprocess.STDOUT,
            close_fds=True,
            creationflags=creationflags,
        )
    finally:
        # Child owns its duplicated OS handle; Blender does not need to keep it.
        log_handle.close()

    BRIDGE.desktop_process = proc
    BRIDGE.last_error = ""
    BRIDGE.client_name = f"launching via {Path(python_exe).name}"

    # P0.10 silently discarded early crashes. P0.10.1 explicitly detects them.
    # A Win32 window should be created well within this short gate.
    deadline = time.monotonic() + 0.75
    while time.monotonic() < deadline:
        code = proc.poll()
        if code is not None:
            tail = _tail(log_path)
            BRIDGE.last_error = f"Desktop Host exited during launch (code {code})"
            if tail:
                BRIDGE.last_error += f": {tail.splitlines()[-1]}"
            raise RuntimeError(BRIDGE.last_error + f"\nLog: {log_path}")
        time.sleep(0.05)

    return proc


def _satellite_log_path() -> Path:
    root = Path(tempfile.gettempdir()) / "LumaFold"
    root.mkdir(parents=True, exist_ok=True)
    return root / "satellite_host_s07_2.log"


def _satellite_child_env() -> dict:
    """Build the real child import environment from Blender's runtime truth.

    LumaFold's vendor directory owns slimgui. NumPy is already distributed with
    Blender, but a directly-launched bundled python.exe does not reliably inherit
    the same import search path as the Blender process on every installation.
    slimgui's nanobind ndarray export used by the native font texture requires
    NumPy to be importable in the Satellite child, so carry Blender's exact NumPy
    package parent into PYTHONPATH instead of silently depending on machine layout.
    """
    env = dict(os.environ)
    paths = [str(vendor_dir())]
    try:
        import numpy
        numpy_parent = str(Path(numpy.__file__).resolve().parent.parent)
        if numpy_parent:
            paths.append(numpy_parent)
    except Exception as exc:
        raise RuntimeError(f"Satellite requires Blender NumPy runtime: {type(exc).__name__}: {exc}") from exc
    existing = str(env.get("PYTHONPATH") or "").strip()
    if existing:
        paths.extend(part for part in existing.split(os.pathsep) if part)
    unique = []
    for item in paths:
        if item and item not in unique:
            unique.append(item)
    env["PYTHONPATH"] = os.pathsep.join(unique)
    return env


def launch_satellite_host(client_width: int, client_height: int, *, screen_x: int, screen_y: int, generation: int):
    """Launch the product Satellite as an independent LumaFold-owned window."""
    BRIDGE.start()
    proc = BRIDGE.satellite_process
    if proc is not None and proc.poll() is None:
        return proc
    script = Path(__file__).resolve().parent / "satellite_host.py"
    python_exe = find_python_executable()
    log_path = _satellite_log_path()
    try:
        log_path.unlink(missing_ok=True)
    except Exception:
        pass
    BRIDGE.satellite_ready = False
    BRIDGE.satellite_active = False
    BRIDGE.satellite_closing = False
    BRIDGE.satellite_expected_generation = int(generation)
    BRIDGE.satellite_rect = None
    owner_hwnd = int(find_process_hwnd() or 0)
    args = [
        python_exe, "-u", str(script),
        "--port", str(BRIDGE.port), "--token", BRIDGE.token,
        "--parent-pid", str(os.getpid()),
        "--owner-hwnd", str(owner_hwnd),
        "--width", str(max(240, int(client_width))),
        "--height", str(max(300, int(client_height))),
        "--x", str(int(screen_x)), "--y", str(int(screen_y)),
        "--generation", str(int(generation)),
        "--runtime-path", str(vendor_dir()),
    ]
    creationflags = 0
    if os.name == "nt":
        creationflags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0) | getattr(subprocess, "CREATE_NO_WINDOW", 0)
    log_handle = open(log_path, "ab", buffering=0)
    try:
        proc = subprocess.Popen(
            args, cwd=str(script.parent), stdin=subprocess.DEVNULL,
            stdout=log_handle, stderr=subprocess.STDOUT, close_fds=True,
            creationflags=creationflags, env=_satellite_child_env(),
        )
    finally:
        log_handle.close()
    BRIDGE.satellite_process = proc
    deadline = time.monotonic() + 0.75
    while time.monotonic() < deadline:
        code = proc.poll()
        if code is not None:
            tail = _tail(log_path)
            BRIDGE.last_error = f"Satellite Host exited during launch (code {code})"
            if tail:
                BRIDGE.last_error += f": {tail.splitlines()[-1]}"
            raise RuntimeError(BRIDGE.last_error + f"\nLog: {log_path}")
        time.sleep(0.03)
    return proc
