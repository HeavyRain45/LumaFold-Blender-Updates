from __future__ import annotations

from ..core.platform import ContextSnapshot


class BlenderContextService:
    service_id = "blender.context"

    @staticmethod
    def snapshot(host_id: str = "embedded") -> ContextSnapshot:
        import bpy
        obj = bpy.context.view_layer.objects.active
        return ContextSnapshot(
            mode=str(getattr(bpy.context, "mode", "UNKNOWN")),
            host_id=str(host_id or "embedded"),
            active_object_name=(obj.name if obj is not None else ""),
            active_object_type=(obj.type if obj is not None else ""),
            has_active_object=(obj is not None),
        )


class BlenderObjectService:
    service_id = "blender.object"

    @staticmethod
    def active_object():
        import bpy
        return bpy.context.view_layer.objects.active

    def active_summary(self):
        obj = self.active_object()
        if obj is None:
            return None
        return {
            "name": obj.name,
            "type": obj.type,
            "location": [float(obj.location.x), float(obj.location.y), float(obj.location.z)],
            "mode": getattr(obj, "mode", "OBJECT"),
        }

    def rename_active(self, name: str):
        obj = self.active_object()
        if obj is None:
            raise RuntimeError("No active Blender object")
        obj.name = str(name or "LumaFold_Object")
        return f"renamed active object to {obj.name}"

    def nudge_active_x(self, delta: float = 0.10):
        obj = self.active_object()
        if obj is None:
            raise RuntimeError("No active Blender object")
        obj.location.x += float(delta)
        return f"X = {obj.location.x:.3f}"

    def add_bevel_modifier(self, width: float = 0.02, segments: int = 3):
        obj = self.active_object()
        if obj is None or obj.type != 'MESH':
            raise RuntimeError("Active object must be a mesh")
        mod = obj.modifiers.get("LumaFold Bevel")
        if mod is None:
            mod = obj.modifiers.new(name="LumaFold Bevel", type='BEVEL')
        mod.width = max(0.0, float(width))
        mod.segments = max(1, int(segments))
        return f"Bevel width={mod.width:.3f}, segments={mod.segments}"


class BlenderModeService:
    service_id = "blender.mode"

    @staticmethod
    def current_mode() -> str:
        import bpy
        return str(getattr(bpy.context, "mode", "UNKNOWN"))

    @staticmethod
    def set_mode(mode: str):
        import bpy
        obj = bpy.context.view_layer.objects.active
        if obj is None:
            raise RuntimeError("No active Blender object")
        mode = str(mode).upper()
        if obj.type != 'MESH' and mode == 'SCULPT':
            raise RuntimeError("Sculpt Mode requires an active mesh")
        current = str(getattr(bpy.context, "mode", "OBJECT"))
        if current == mode:
            return f"mode = {current}"
        if current != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        if mode != 'OBJECT':
            bpy.ops.object.mode_set(mode=mode)
        return f"mode = {bpy.context.mode}"


class BlenderBrushService:
    """Blender 5.2 brush-asset bridge.

    Read operations expose the active Sculpt brush and its AssetWeakReference.
    Mutations use bpy.ops.brush.asset_activate, which is the supported asset-
    based brush activation path in Blender 4.3+ / 5.2.
    """
    service_id = "blender.brush"

    @staticmethod
    def _sculpt_paint():
        import bpy
        tool_settings = getattr(bpy.context, "tool_settings", None)
        return getattr(tool_settings, "sculpt", None) if tool_settings is not None else None

    @staticmethod
    def _view3d_override():
        """Return a stable VIEW_3D override for operator calls when possible."""
        import bpy
        wm = getattr(bpy.context, "window_manager", None)
        windows = tuple(getattr(wm, "windows", ()) or ())
        current_window = getattr(bpy.context, "window", None)
        ordered = ([current_window] if current_window is not None else []) + [w for w in windows if w is not current_window]
        for window in ordered:
            screen = getattr(window, "screen", None)
            if screen is None:
                continue
            for area in screen.areas:
                if area.type != 'VIEW_3D':
                    continue
                region = next((r for r in area.regions if r.type == 'WINDOW'), None)
                if region is not None:
                    return {"window": window, "area": area, "region": region}
        return None

    def current_sculpt_brush(self):
        paint = self._sculpt_paint()
        if paint is None:
            return {
                "available": False,
                "name": "",
                "asset_library_type": "",
                "asset_library_identifier": "",
                "relative_asset_identifier": "",
            }
        brush = getattr(paint, "brush", None)
        ref = getattr(paint, "brush_asset_reference", None)
        lib_type = str(getattr(ref, "asset_library_type", "") or "") if ref is not None else ""
        lib_id = str(getattr(ref, "asset_library_identifier", "") or "") if ref is not None else ""
        rel = str(getattr(ref, "relative_asset_identifier", "") or "").replace("\\", "/") if ref is not None else ""
        name = str(getattr(brush, "name", "") or "")
        # LumaFold may create a local editable proxy when an external/Essentials
        # brush cannot accept a local Alpha texture dependency. Keep the original
        # asset identity visible so Quick Slot selection/highlight does not break.
        if brush is not None:
            try:
                if bool(brush.get("_lumafold_alpha_proxy", False)):
                    name = str(brush.get("_lumafold_source_name", name) or name)
                    lib_type = str(brush.get("_lumafold_source_asset_library_type", lib_type) or lib_type)
                    lib_id = str(brush.get("_lumafold_source_asset_library_identifier", lib_id) or lib_id)
                    rel = str(brush.get("_lumafold_source_relative_asset_identifier", rel) or rel).replace("\\", "/")
            except Exception:
                pass
        return {
            "available": brush is not None,
            "name": name,
            "asset_library_type": lib_type,
            "asset_library_identifier": lib_id,
            "relative_asset_identifier": rel,
            "sculpt_brush_type": str(getattr(brush, "sculpt_brush_type", "") or "") if brush is not None else "",
            "lumafold_alpha_proxy": bool(brush.get("_lumafold_alpha_proxy", False)) if brush is not None and hasattr(brush, "get") else False,
        }

    @staticmethod
    def _downsample_rgba(raw: bytes, width: int, height: int, max_edge: int = 64):
        width = int(width); height = int(height); max_edge = max(8, int(max_edge))
        if width <= 0 or height <= 0 or len(raw) != width * height * 4:
            return 0, 0, b""
        if max(width, height) <= max_edge:
            return width, height, raw
        scale = min(max_edge / float(width), max_edge / float(height))
        out_w = max(1, int(round(width * scale)))
        out_h = max(1, int(round(height * scale)))
        out = bytearray(out_w * out_h * 4)
        for oy in range(out_h):
            sy = min(height - 1, int(oy * height / out_h))
            for ox in range(out_w):
                sx = min(width - 1, int(ox * width / out_w))
                src = (sy * width + sx) * 4
                dst = (oy * out_w + ox) * 4
                out[dst:dst+4] = raw[src:src+4]
        return out_w, out_h, bytes(out)

    def _brush_preview_payload(self, brush, max_edge: int = 64):
        """Read Blender-owned ImagePreview pixels from a Brush ID."""
        import base64
        if brush is None:
            return {}
        try:
            preview = brush.preview_ensure()
        except Exception:
            preview = None
        if preview is None:
            return {}

        def _read(size_name, pixels_name):
            try:
                size = tuple(getattr(preview, size_name) or (0, 0))
                width, height = int(size[0]), int(size[1])
                pixels = getattr(preview, pixels_name)
                expected = width * height * 4
                if width <= 0 or height <= 0 or len(pixels) != expected:
                    return 0, 0, b""
                raw = bytes((int(v) & 0xFF) for v in pixels)
                return self._downsample_rgba(raw, width, height, max_edge=max_edge)
            except Exception:
                return 0, 0, b""

        width, height, raw = _read("icon_size", "icon_pixels")
        source = "icon"
        if not raw:
            width, height, raw = _read("image_size", "image_pixels")
            source = "image"
        if not raw:
            return {}
        return {
            "width": width,
            "height": height,
            "rgba_b64": base64.b64encode(raw).decode("ascii"),
            "source": source,
        }

    def current_sculpt_brush_preview(self, max_edge: int = 64):
        """Return a JSON-ready preview for the active Sculpt brush."""
        paint = self._sculpt_paint()
        brush = getattr(paint, "brush", None) if paint is not None else None
        return self._brush_preview_payload(brush, max_edge=max_edge)

    @staticmethod
    def _asset_identity(spec):
        rel = str((spec or {}).get("relative_asset_identifier") or "").replace("\\", "/").strip()
        if not rel:
            return ""
        return "asset|{}|{}|{}".format(
            str((spec or {}).get("asset_library_type") or "").casefold(),
            str((spec or {}).get("asset_library_identifier") or "").casefold(),
            rel.casefold(),
        )

    @staticmethod
    def _essentials_sculpt_blend():
        import bpy
        from pathlib import Path
        candidates = []
        try:
            datafiles = Path(bpy.utils.system_resource('DATAFILES'))
            candidates.append(datafiles / "assets" / "brushes" / "essentials_brushes-mesh_sculpt.blend")
        except Exception:
            pass
        try:
            binary = Path(bpy.app.binary_path).resolve()
            for parent in (binary.parent, binary.parent.parent):
                candidates.append(parent / "5.2" / "datafiles" / "assets" / "brushes" / "essentials_brushes-mesh_sculpt.blend")
                candidates.append(parent / "datafiles" / "assets" / "brushes" / "essentials_brushes-mesh_sculpt.blend")
        except Exception:
            pass
        for candidate in candidates:
            try:
                if candidate.is_file():
                    return candidate
            except Exception:
                pass
        return None

    def list_sculpt_brush_assets(self, max_files: int = 512):
        """Enumerate Brush assets from Blender Essentials + registered local Asset Libraries.

        This deliberately uses Blender's own .blend asset files as the source of
        truth. `assets_only=True` lists only data-blocks marked as assets without
        appending them into the current scene.
        """
        import bpy
        from pathlib import Path

        records = []
        folders = []
        errors = []
        seen_identity = set()
        seen_folder = set()

        def add_folder(folder_id, label, source, path, readonly=False):
            folder_id = str(folder_id or "")
            if not folder_id or folder_id in seen_folder:
                return
            seen_folder.add(folder_id)
            folders.append({
                "id": folder_id, "label": str(label or folder_id),
                "source": str(source or ""), "path": str(path or ""),
                "readonly": bool(readonly),
            })

        def scan_blend(blend_path, *, library_type, library_identifier, root, folder_id, folder_label, source_label, readonly=False):
            try:
                with bpy.data.libraries.load(str(blend_path), assets_only=True) as (data_src, _data_dst):
                    names = list(getattr(data_src, "brushes", ()) or ())
            except Exception as exc:
                errors.append(f"{blend_path.name}: {type(exc).__name__}: {exc}")
                return
            if not names:
                return
            add_folder(folder_id, folder_label, source_label, str(getattr(blend_path, 'parent', '')), readonly=readonly)
            try:
                rel_blend = Path(blend_path).relative_to(root).as_posix()
            except Exception:
                rel_blend = Path(blend_path).name
            for name in names:
                spec = {
                    "name": str(name),
                    "asset_library_type": str(library_type),
                    "asset_library_identifier": str(library_identifier or ""),
                    "relative_asset_identifier": f"{rel_blend}/Brush/{name}",
                    "source_blend": str(blend_path),
                    "source_label": str(source_label),
                    "folder_id": str(folder_id),
                    "folder_label": str(folder_label),
                    "readonly": bool(readonly),
                }
                spec["identity"] = self._asset_identity(spec)
                if spec["identity"] and spec["identity"] not in seen_identity:
                    seen_identity.add(spec["identity"])
                    records.append(spec)

        essentials = self._essentials_sculpt_blend()
        if essentials is not None:
            try:
                assets_root = essentials.parent.parent
                scan_blend(
                    essentials, library_type="ESSENTIALS", library_identifier="",
                    root=assets_root, folder_id="essentials|brushes",
                    folder_label="Blender Essentials", source_label="Essentials", readonly=True,
                )
            except Exception as exc:
                errors.append(f"Essentials: {type(exc).__name__}: {exc}")
        else:
            errors.append("未找到 Blender Essentials Sculpt Brush 资产文件")

        try:
            libraries = list(getattr(bpy.context.preferences.filepaths, "asset_libraries", ()) or ())
        except Exception:
            libraries = []
        files_seen = 0
        file_limit = max(1, int(max_files))
        for lib in libraries:
            if not bool(getattr(lib, "enabled", True)):
                continue
            if files_seen >= file_limit:
                break
            lib_name = str(getattr(lib, "name", "") or "用户资产库")
            raw_path = str(getattr(lib, "path", "") or "")
            try:
                root = Path(bpy.path.abspath(raw_path)).resolve()
            except Exception:
                root = Path(raw_path)
            if not root.is_dir():
                continue
            try:
                blend_files = sorted(root.rglob("*.blend"), key=lambda q: str(q).casefold())
            except Exception as exc:
                errors.append(f"{lib_name}: {type(exc).__name__}: {exc}")
                continue
            blend_files = blend_files[:max(0, file_limit - files_seen)]
            for blend_path in blend_files:
                files_seen += 1
                try:
                    rel_parent = blend_path.parent.relative_to(root)
                    rel_parent_text = rel_parent.as_posix() if str(rel_parent) not in (".", "") else ""
                except Exception:
                    rel_parent_text = ""
                folder_suffix = rel_parent_text or "根目录"
                folder_id = f"custom|{lib_name}|{folder_suffix}"
                folder_label = f"{lib_name}" if not rel_parent_text else f"{lib_name} / {rel_parent_text}"
                scan_blend(
                    blend_path, library_type="CUSTOM", library_identifier=lib_name, root=root,
                    folder_id=folder_id, folder_label=folder_label, source_label=lib_name, readonly=False,
                )

        records.sort(key=lambda item: (str(item.get("folder_label") or "").casefold(), str(item.get("name") or "").casefold()))
        counts = {}
        for item in records:
            counts[item["folder_id"]] = counts.get(item["folder_id"], 0) + 1
        for folder in folders:
            folder["count"] = int(counts.get(folder["id"], 0))
        folders = [folder for folder in folders if folder.get("count", 0) > 0]
        folders.sort(key=lambda item: (0 if item.get("readonly") else 1, str(item.get("label") or "").casefold()))
        return {
            "assets": records, "folders": folders, "errors": errors[-8:],
            "asset_count": len(records), "folder_count": len(folders),
        }

    def brush_asset_preview(self, asset_spec, max_edge: int = 64):
        """Lazily read one asset preview without making it the active brush."""
        import bpy
        from pathlib import Path
        spec = dict(asset_spec or {})
        identity = self._asset_identity(spec)
        if not identity:
            return {}

        current = self.current_sculpt_brush()
        if identity == self._asset_identity(current):
            payload = self.current_sculpt_brush_preview(max_edge=max_edge)
            if payload:
                payload["key"] = identity
            return payload

        blend_path = Path(str(spec.get("source_blend") or ""))
        name = str(spec.get("name") or "")
        if not blend_path.is_file() or not name:
            return {}
        brush = None
        try:
            with bpy.data.libraries.load(str(blend_path), assets_only=True) as (data_src, data_dst):
                available = set(getattr(data_src, "brushes", ()) or ())
                if name not in available:
                    return {}
                data_dst.brushes = [name]
            brush = data_dst.brushes[0] if data_dst.brushes else None
            payload = self._brush_preview_payload(brush, max_edge=max_edge)
            if payload:
                payload["key"] = identity
            return payload
        finally:
            if brush is not None:
                try:
                    bpy.data.brushes.remove(brush)
                except Exception:
                    pass

    def brush_asset_previews(self, asset_specs, max_edge: int = 64):
        """Batch-read previews, loading each source .blend only once per request."""
        import bpy
        from pathlib import Path
        specs = [dict(item or {}) for item in list(asset_specs or ())]
        results = {}
        groups = {}
        current = self.current_sculpt_brush()
        current_identity = self._asset_identity(current)
        for spec in specs:
            identity = self._asset_identity(spec)
            if not identity:
                continue
            if identity == current_identity:
                payload = self.current_sculpt_brush_preview(max_edge=max_edge)
                if payload:
                    payload["key"] = identity
                    results[identity] = payload
                continue
            source = str(spec.get("source_blend") or "")
            if source:
                groups.setdefault(source, []).append(spec)

        for source, group in groups.items():
            blend_path = Path(source)
            if not blend_path.is_file():
                continue
            loaded = []
            try:
                names = [str(spec.get("name") or "") for spec in group]
                with bpy.data.libraries.load(str(blend_path), assets_only=True) as (data_src, data_dst):
                    available = set(getattr(data_src, "brushes", ()) or ())
                    wanted = [name for name in names if name in available]
                    data_dst.brushes = wanted
                loaded = [brush for brush in list(data_dst.brushes or ()) if brush is not None]
                by_name = {}
                for brush in loaded:
                    by_name.setdefault(str(getattr(brush, "name", "") or ""), brush)
                # Appended IDs may gain numeric suffixes on collisions. Fall back to
                # output order when exact names are unavailable.
                for idx, spec in enumerate(group):
                    identity = self._asset_identity(spec)
                    name = str(spec.get("name") or "")
                    brush = by_name.get(name)
                    if brush is None and idx < len(loaded):
                        brush = loaded[idx]
                    payload = self._brush_preview_payload(brush, max_edge=max_edge)
                    if payload:
                        payload["key"] = identity
                        results[identity] = payload
            finally:
                for brush in loaded:
                    try:
                        bpy.data.brushes.remove(brush)
                    except Exception:
                        pass
        return results

    def activate_asset(self, *, asset_library_type: str, asset_library_identifier: str = "", relative_asset_identifier: str):
        import bpy
        obj = getattr(bpy.context.view_layer.objects, "active", None)
        if obj is None or obj.type != 'MESH':
            raise RuntimeError("Sculpt Brush 需要活动 Mesh 对象")

        kwargs = {
            "asset_library_type": str(asset_library_type or "ESSENTIALS"),
            "asset_library_identifier": str(asset_library_identifier or ""),
            "relative_asset_identifier": str(relative_asset_identifier or "").replace("\\", "/"),
            "use_toggle": False,
        }
        if not kwargs["relative_asset_identifier"]:
            raise RuntimeError("Brush Asset 标识为空")

        def _activate():
            current_mode = str(getattr(bpy.context, "mode", "OBJECT"))
            if current_mode != 'SCULPT':
                raise RuntimeError("请先进入 Blender 雕刻模式；LumaFold 不会因点击笔刷自动切换 Mode")
            return bpy.ops.brush.asset_activate(**kwargs)

        override = self._view3d_override()
        if override:
            with bpy.context.temp_override(**override):
                result = _activate()
        else:
            result = _activate()
        if 'FINISHED' not in result:
            raise RuntimeError("Blender Brush Asset 激活失败: " + repr(result))
        return self.current_sculpt_brush()


class BlenderAlphaService:
    """Blender 5.2 Sculpt Alpha bridge.

    Sculpt alpha is represented by the active Brush Texture.  LumaFold keeps
    Blender Images/Textures as the source of truth and only indexes file-backed
    images from registered Asset Library roots plus Images already loaded in the
    current .blend.
    """
    service_id = "blender.alpha"
    IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".tga", ".exr", ".hdr"}

    @staticmethod
    def _sculpt_brush():
        import bpy
        sculpt = getattr(getattr(bpy.context, "tool_settings", None), "sculpt", None)
        return getattr(sculpt, "brush", None) if sculpt is not None else None

    @staticmethod
    def _norm_path(value):
        from pathlib import Path
        raw = str(value or "").strip()
        if not raw:
            return ""
        try:
            return str(Path(raw).resolve()).replace("\\", "/")
        except Exception:
            return raw.replace("\\", "/")

    @classmethod
    def _identity_from_path(cls, path):
        norm = cls._norm_path(path)
        return "file|" + norm.casefold() if norm else ""

    @staticmethod
    def _loaded_identity(name, filepath=""):
        if filepath:
            return BlenderAlphaService._identity_from_path(filepath)
        return "loaded|" + str(name or "").casefold()

    @staticmethod
    def _assigned_texture(brush):
        if brush is None:
            return None
        slot = getattr(brush, "texture_slot", None)
        if slot is not None:
            try:
                tex = getattr(slot, "texture", None)
                if tex is not None:
                    return tex
            except Exception:
                pass
        try:
            return getattr(brush, "texture", None)
        except Exception:
            return None

    @staticmethod
    def _set_texture_on_brush(brush, texture):
        """Assign through Blender's writable TextureSlot first, then Brush.texture.

        Blender 4.3+/5.x asset brushes can reject local ID dependencies on the
        direct Brush.texture path.  TextureSlot.texture is the public writable
        slot property and is therefore the primary path.
        """
        errors = []
        slot = getattr(brush, "texture_slot", None) if brush is not None else None
        if slot is not None:
            try:
                slot.texture = texture
                if getattr(slot, "texture", None) is texture:
                    return True, "texture_slot"
            except Exception as exc:
                errors.append(f"texture_slot: {type(exc).__name__}: {exc}")
        try:
            brush.texture = texture
            if getattr(brush, "texture", None) is texture:
                return True, "brush.texture"
        except Exception as exc:
            errors.append(f"brush.texture: {type(exc).__name__}: {exc}")
        return False, "; ".join(errors)

    @staticmethod
    def _source_asset_snapshot(brush):
        import bpy
        paint = getattr(getattr(bpy.context, "tool_settings", None), "sculpt", None)
        ref = getattr(paint, "brush_asset_reference", None) if paint is not None else None
        return {
            "name": str(getattr(brush, "name", "") or ""),
            "asset_library_type": str(getattr(ref, "asset_library_type", "") or "") if ref is not None else "",
            "asset_library_identifier": str(getattr(ref, "asset_library_identifier", "") or "") if ref is not None else "",
            "relative_asset_identifier": str(getattr(ref, "relative_asset_identifier", "") or "").replace("\\", "/") if ref is not None else "",
        }

    def _editable_alpha_proxy(self, source_brush):
        """Create/reuse a local editable brush asset proxy for external brushes.

        Essentials/external brush assets may not accept a Texture datablock from
        the current file.  A local copy can own that dependency.  The copy keeps
        source-asset metadata so LumaFold still treats it as the original Quick
        Brush identity in the product UI.
        """
        import bpy
        source = self._source_asset_snapshot(source_brush)
        source_key = "|".join((source["asset_library_type"], source["asset_library_identifier"], source["relative_asset_identifier"], source["name"]))
        proxy = None
        for candidate in tuple(getattr(bpy.data, "brushes", ()) or ()):
            try:
                if bool(candidate.get("_lumafold_alpha_proxy", False)) and str(candidate.get("_lumafold_source_key", "")) == source_key:
                    proxy = candidate
                    break
            except Exception:
                continue
        if proxy is None:
            proxy = source_brush.copy()
            proxy.name = f"{source['name']} · LumaFold"
            proxy["_lumafold_alpha_proxy"] = True
            proxy["_lumafold_source_key"] = source_key
            proxy["_lumafold_source_name"] = source["name"]
            proxy["_lumafold_source_asset_library_type"] = source["asset_library_type"]
            proxy["_lumafold_source_asset_library_identifier"] = source["asset_library_identifier"]
            proxy["_lumafold_source_relative_asset_identifier"] = source["relative_asset_identifier"]
            if getattr(proxy, "asset_data", None) is None:
                proxy.asset_mark()
        override = BlenderBrushService._view3d_override()
        def _activate_local():
            return bpy.ops.brush.asset_activate(
                asset_library_type='LOCAL', asset_library_identifier='',
                relative_asset_identifier=f"Brush/{proxy.name}", use_toggle=False,
            )
        if override:
            with bpy.context.temp_override(**override):
                result = _activate_local()
        else:
            result = _activate_local()
        if 'FINISHED' not in result:
            raise RuntimeError("无法激活 LumaFold 本地可编辑笔刷副本: " + repr(result))
        active = self._sculpt_brush()
        if active is None:
            raise RuntimeError("LumaFold 本地笔刷副本激活后未找到活动 Brush")
        return active

    def current_sculpt_alpha(self):
        brush = self._sculpt_brush()
        if brush is None:
            return {"available": False, "name": "默认", "identity": "none", "filepath": "", "map_mode": ""}
        texture = self._assigned_texture(brush)
        image = getattr(texture, "image", None) if texture is not None and str(getattr(texture, "type", "")) == "IMAGE" else None
        if image is None:
            return {"available": False, "name": "默认", "identity": "none", "filepath": "", "map_mode": str(getattr(getattr(brush, "texture_slot", None), "map_mode", "") or "")}
        filepath = ""
        try:
            import bpy
            filepath = self._norm_path(bpy.path.abspath(str(getattr(image, "filepath", "") or "")))
        except Exception:
            filepath = self._norm_path(getattr(image, "filepath", ""))
        return {
            "available": True,
            "name": str(getattr(image, "name", "") or getattr(texture, "name", "Alpha")),
            "identity": self._loaded_identity(getattr(image, "name", ""), filepath),
            "filepath": filepath,
            "image_name": str(getattr(image, "name", "") or ""),
            "texture_name": str(getattr(texture, "name", "") or ""),
            "map_mode": str(getattr(getattr(brush, "texture_slot", None), "map_mode", "") or ""),
        }

    @staticmethod
    def _preview_payload(preview, max_edge=64):
        import base64
        if preview is None:
            return {}
        def read(size_name, pixels_name):
            try:
                size = tuple(getattr(preview, size_name) or (0, 0))
                w, h = int(size[0]), int(size[1])
                pixels = getattr(preview, pixels_name)
                if w <= 0 or h <= 0 or len(pixels) != w*h*4:
                    return 0, 0, b""
                raw = bytes((int(v) & 0xFF) for v in pixels)
                return BlenderBrushService._downsample_rgba(raw, w, h, max_edge=max_edge)
            except Exception:
                return 0, 0, b""
        w, h, raw = read("icon_size", "icon_pixels")
        if not raw:
            w, h, raw = read("image_size", "image_pixels")
        if not raw:
            return {}
        return {"width": w, "height": h, "rgba_b64": base64.b64encode(raw).decode("ascii"), "source": "image"}

    def current_sculpt_alpha_preview(self, max_edge=64):
        brush = self._sculpt_brush()
        texture = self._assigned_texture(brush)
        image = getattr(texture, "image", None) if texture is not None and str(getattr(texture, "type", "")) == "IMAGE" else None
        if image is None:
            return {}
        try:
            preview = image.preview_ensure()
        except Exception:
            preview = None
        return self._preview_payload(preview, max_edge=max_edge)

    def list_sculpt_alphas(self, max_files=512):
        """Index current-file Images plus image files in registered Asset Library roots."""
        import bpy
        from pathlib import Path
        records, folders, errors = [], [], []
        seen, seen_folders = set(), set()

        def add_folder(folder_id, label, source, path, readonly=False):
            if not folder_id or folder_id in seen_folders:
                return
            seen_folders.add(folder_id)
            folders.append({"id": folder_id, "label": str(label), "source": str(source), "path": str(path or ""), "readonly": bool(readonly)})

        def add_record(*, name, identity, filepath="", image_name="", folder_id, folder_label, source_label, readonly=False):
            if not identity or identity in seen:
                return
            seen.add(identity)
            records.append({
                "name": str(name or "Alpha"), "identity": str(identity),
                "filepath": self._norm_path(filepath), "image_name": str(image_name or ""),
                "folder_id": str(folder_id), "folder_label": str(folder_label),
                "source_label": str(source_label), "readonly": bool(readonly),
            })

        # Images already loaded in the current Blender file are real Blender data
        # and remain usable even when packed or generated.
        loaded_folder = "loaded|current_file"
        loaded_count = 0
        for image in list(getattr(bpy.data, "images", ()) or ()):
            try:
                image_name = str(getattr(image, "name", "") or "")
                if str(getattr(image, "source", "")) == "VIEWER" or image_name in {"Render Result", "Viewer Node"}:
                    continue
                raw = str(getattr(image, "filepath", "") or "")
                path = self._norm_path(bpy.path.abspath(raw)) if raw else ""
                identity = self._loaded_identity(getattr(image, "name", ""), path)
                add_record(name=getattr(image, "name", "Alpha"), identity=identity, filepath=path, image_name=getattr(image, "name", ""), folder_id=loaded_folder, folder_label="当前文件", source_label="当前 Blender 文件")
                loaded_count += 1
            except Exception:
                continue
        if loaded_count:
            add_folder(loaded_folder, "当前文件", "Blender", "")

        # S0.7.2 ships a tiny read-only test seed so the real Image -> Texture ->
        # Sculpt Brush chain can be validated immediately on a clean Blender install.
        # These are ordinary PNG files and use the exact same activation/preview
        # path as user Alpha images; they are not a parallel asset database.
        try:
            seed_root = Path(__file__).resolve().parent.parent / "assets" / "test_alphas"
            if seed_root.is_dir():
                seed_folder = "alpha|lumafold|test_seed"
                seed_files = sorted(
                    (q for q in seed_root.iterdir() if q.is_file() and q.suffix.casefold() in self.IMAGE_EXTS),
                    key=lambda q: q.name.casefold(),
                )
                for path in seed_files:
                    add_record(
                        name=path.stem.replace("_", " "),
                        identity=self._identity_from_path(path),
                        filepath=str(path),
                        folder_id=seed_folder,
                        folder_label="LumaFold 测试 Alpha",
                        source_label="LumaFold 测试 Alpha",
                        readonly=True,
                    )
                if seed_files:
                    add_folder(seed_folder, "LumaFold 测试 Alpha", "LumaFold", str(seed_root), readonly=True)
        except Exception as exc:
            errors.append(f"LumaFold Test Alpha: {type(exc).__name__}: {exc}")

        try:
            libraries = list(getattr(bpy.context.preferences.filepaths, "asset_libraries", ()) or ())
        except Exception:
            libraries = []
        file_limit = max(1, int(max_files)); file_count = 0
        for lib in libraries:
            if not bool(getattr(lib, "enabled", True)) or file_count >= file_limit:
                continue
            lib_name = str(getattr(lib, "name", "") or "用户资产库")
            raw_root = str(getattr(lib, "path", "") or "")
            try:
                root = Path(bpy.path.abspath(raw_root)).resolve()
            except Exception:
                root = Path(raw_root)
            if not root.is_dir():
                continue
            try:
                files = sorted((q for q in root.rglob("*") if q.is_file() and q.suffix.casefold() in self.IMAGE_EXTS), key=lambda q: str(q).casefold())
            except Exception as exc:
                errors.append(f"{lib_name}: {type(exc).__name__}: {exc}")
                continue
            for path in files[:max(0, file_limit-file_count)]:
                file_count += 1
                try:
                    rel_parent = path.parent.relative_to(root).as_posix()
                except Exception:
                    rel_parent = ""
                folder_suffix = rel_parent if rel_parent not in ("", ".") else "根目录"
                folder_id = f"alpha|{lib_name}|{folder_suffix}"
                folder_label = lib_name if folder_suffix == "根目录" else f"{lib_name} / {folder_suffix}"
                add_folder(folder_id, folder_label, lib_name, str(path.parent))
                add_record(name=path.stem, identity=self._identity_from_path(path), filepath=str(path), folder_id=folder_id, folder_label=folder_label, source_label=lib_name)

        counts = {}
        for item in records:
            counts[item["folder_id"]] = counts.get(item["folder_id"], 0) + 1
        for folder in folders:
            folder["count"] = int(counts.get(folder["id"], 0))
        folders = [f for f in folders if f.get("count", 0) > 0]
        folders.sort(key=lambda f: (0 if f.get("id") == loaded_folder else 1, str(f.get("label") or "").casefold()))
        records.sort(key=lambda r: (str(r.get("folder_label") or "").casefold(), str(r.get("name") or "").casefold()))
        return {"assets": records, "folders": folders, "errors": errors[-8:], "asset_count": len(records), "folder_count": len(folders)}

    def alpha_previews(self, specs, max_edge=64):
        import bpy
        import bpy.utils.previews
        from pathlib import Path
        results = {}
        pcoll = bpy.utils.previews.new()
        try:
            for idx, raw in enumerate(list(specs or ())):
                spec = dict(raw or {})
                identity = str(spec.get("identity") or "")
                if not identity:
                    continue
                image = None
                image_name = str(spec.get("image_name") or "")
                if image_name:
                    image = bpy.data.images.get(image_name)
                if image is not None:
                    try:
                        payload = self._preview_payload(image.preview_ensure(), max_edge=max_edge)
                    except Exception:
                        payload = {}
                else:
                    path = Path(str(spec.get("filepath") or ""))
                    if not path.is_file():
                        continue
                    key = f"alpha_{idx}_{abs(hash(identity))}"
                    try:
                        preview = pcoll.load(key, str(path), 'IMAGE', force_reload=False)
                        payload = self._preview_payload(preview, max_edge=max_edge)
                    except Exception:
                        payload = {}
                if payload:
                    payload["key"] = identity
                    results[identity] = payload
        finally:
            try:
                bpy.utils.previews.remove(pcoll)
            except Exception:
                pass
        return results

    def activate_alpha(self, spec):
        import bpy
        from pathlib import Path
        brush = self._sculpt_brush()
        if brush is None or str(getattr(bpy.context, "mode", "")) != "SCULPT":
            raise RuntimeError("请先进入 Blender 雕刻模式")
        spec = dict(spec or {})
        identity = str(spec.get("identity") or "")
        if identity == "none":
            # If no texture is currently assigned, read-only Essentials brushes
            # are already at the semantic default and require no proxy.
            if self._assigned_texture(brush) is None:
                return self.current_sculpt_alpha()
            ok, method = self._set_texture_on_brush(brush, None)
            if not ok:
                # A read-only external brush that actually owns a texture needs
                # a local editable proxy before it can be cleared.
                brush = self._editable_alpha_proxy(brush)
                ok, method = self._set_texture_on_brush(brush, None)
            if not ok:
                raise RuntimeError("无法清除当前 Alpha: " + str(method))
            return self.current_sculpt_alpha()
        image = None
        image_name = str(spec.get("image_name") or "")
        if image_name:
            image = bpy.data.images.get(image_name)
        if image is None:
            path = Path(str(spec.get("filepath") or ""))
            if not path.is_file():
                raise RuntimeError("Alpha 图片文件不存在，请刷新 Alpha 库")
            norm = self._norm_path(path)
            for candidate in bpy.data.images:
                try:
                    if self._norm_path(bpy.path.abspath(str(getattr(candidate, "filepath", "") or ""))) == norm:
                        image = candidate; break
                except Exception:
                    pass
            if image is None:
                image = bpy.data.images.load(str(path), check_existing=True)
        tex_name = "LumaFold Alpha · " + str(getattr(image, "name", "Alpha"))
        texture = bpy.data.textures.get(tex_name)
        if texture is None or str(getattr(texture, "type", "")) != "IMAGE":
            if texture is not None:
                tex_name = tex_name + " Image"
            texture = bpy.data.textures.new(name=tex_name, type='IMAGE')
        texture.image = image
        ok, method = self._set_texture_on_brush(brush, texture)
        if not ok:
            # External/Essentials brush assets can reject local texture IDs.
            # Fall back to a local editable asset proxy, then verify assignment.
            brush = self._editable_alpha_proxy(brush)
            ok, method = self._set_texture_on_brush(brush, texture)
        if not ok:
            raise RuntimeError("当前笔刷无法绑定 Alpha Texture: " + str(method))
        result = self.current_sculpt_alpha()
        if str(result.get("identity") or "none") == "none":
            raise RuntimeError("Alpha Texture 写入后 Blender 未返回有效绑定")
        result["assignment_method"] = method
        return result

    def clear_alpha(self):
        import bpy
        brush = self._sculpt_brush()
        if brush is None or str(getattr(bpy.context, "mode", "")) != "SCULPT":
            raise RuntimeError("请先进入 Blender 雕刻模式")
        if self._assigned_texture(brush) is None:
            return self.current_sculpt_alpha()
        ok, method = self._set_texture_on_brush(brush, None)
        if not ok:
            brush = self._editable_alpha_proxy(brush)
            ok, method = self._set_texture_on_brush(brush, None)
        if not ok:
            raise RuntimeError("无法清除当前 Alpha: " + str(method))
        return self.current_sculpt_alpha()


class BlenderLightService:
    service_id = "blender.light"

    @staticmethod
    def active_light():
        import bpy
        obj = bpy.context.view_layer.objects.active
        if obj is None or obj.type != 'LIGHT':
            return None
        return obj

    def active_summary(self):
        obj = self.active_light()
        if obj is None:
            return None
        data = obj.data
        return {
            "name": obj.name,
            "type": str(getattr(data, "type", "LIGHT")),
            "energy": float(getattr(data, "energy", 0.0)),
            "size": float(getattr(data, "size", 0.0)) if hasattr(data, "size") else 0.0,
            "location": [float(obj.location.x), float(obj.location.y), float(obj.location.z)],
        }

    def select_first_scene_light(self):
        import bpy
        obj = next((o for o in bpy.context.scene.objects if o.type == 'LIGHT'), None)
        if obj is None:
            raise RuntimeError("Scene has no light")
        if getattr(bpy.context, "mode", "OBJECT") != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        for selected in tuple(bpy.context.selected_objects):
            try:
                selected.select_set(False)
            except Exception:
                pass
        obj.select_set(True)
        bpy.context.view_layer.objects.active = obj
        return f"selected light {obj.name}"

    def create_area_light(self, energy: float = 1000.0, size: float = 3.0):
        import bpy
        data = bpy.data.lights.new(name="LumaFold Area", type='AREA')
        data.energy = max(0.0, float(energy))
        data.size = max(0.01, float(size))
        obj = bpy.data.objects.new("LumaFold Area", data)
        bpy.context.collection.objects.link(obj)
        obj.location = (4.0, -4.0, 5.0)
        for selected in tuple(bpy.context.selected_objects):
            try:
                selected.select_set(False)
            except Exception:
                pass
        obj.select_set(True)
        bpy.context.view_layer.objects.active = obj
        return f"created area light {obj.name}"

    def set_active_params(self, energy: float, size: float):
        obj = self.active_light()
        if obj is None:
            raise RuntimeError("Select a Light object first")
        data = obj.data
        data.energy = max(0.0, float(energy))
        if hasattr(data, "size"):
            data.size = max(0.01, float(size))
        return f"{obj.name}: energy={data.energy:.1f}, size={getattr(data, 'size', 0.0):.2f}"


class BlenderRenderService:
    service_id = "blender.render"

    @staticmethod
    def summary():
        import bpy
        scene = bpy.context.scene
        render = scene.render
        return {
            "resolution_x": int(render.resolution_x),
            "resolution_y": int(render.resolution_y),
            "percentage": int(render.resolution_percentage),
            "engine": str(scene.render.engine),
            "filepath": str(render.filepath),
        }

    def apply(self, resolution_x: int, resolution_y: int, percentage: int):
        import bpy
        render = bpy.context.scene.render
        render.resolution_x = max(4, int(resolution_x))
        render.resolution_y = max(4, int(resolution_y))
        render.resolution_percentage = max(1, min(100, int(percentage)))
        return f"{render.resolution_x}x{render.resolution_y} @ {render.resolution_percentage}%"
