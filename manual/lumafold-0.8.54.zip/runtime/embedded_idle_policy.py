from __future__ import annotations

"""Version-aware Embedded redraw pulse policy.

Blender 5.0/5.1 benefit from a 60 Hz redraw heartbeat while the user is actually
interacting with LumaFold. Forcing the whole View3D to redraw at 60 Hz while the
pointer is in Blender space competes with orbit/sculpt redraw and makes viewport
navigation feel sticky.

Policy:
- Blender 5.0/5.1: keep the modal timer at 60 Hz, but only execute the expensive
  View3D redraw pulse at 60 Hz while LumaFold owns/requests interactive input.
  Otherwise admit the pulse at 10 Hz for lifecycle/context health.
- Blender 5.2+: keep the accepted 10 Hz idle policy.
- Real pointer/key events remain event-driven and are never throttled here.
"""

import time


_INSTALLED = False
_ORIGINAL = None
_ORIGINAL_INVOKE = None
_OPERATORS = None

_MODERN_IDLE_INTERVAL = 0.10
_LEGACY_TIMER_INTERVAL = 1.0 / 60.0
_LEGACY_IDLE_INTERVAL = 0.10


def _is_legacy_blender() -> bool:
    try:
        import bpy
        version = tuple(int(v) for v in tuple(getattr(bpy.app, "version", (0, 0, 0)))[:3])
        return version < (5, 2, 0)
    except Exception:
        return False


def _lumafold_interactive(host) -> bool:
    if host is None or bool(getattr(host, "closed", False)):
        return False

    try:
        owned = getattr(host, "_mouse_owned", None)
        if isinstance(owned, dict) and any(bool(value) for value in owned.values()):
            return True
    except Exception:
        pass

    try:
        io = getattr(host, "io", None)
        if io is not None:
            if bool(getattr(io, "want_capture_mouse", False)):
                return True
            if bool(getattr(io, "want_capture_keyboard", False)):
                return True
            if bool(getattr(io, "want_text_input", False)):
                return True
    except Exception:
        pass

    return False


def _timer_interval() -> float:
    return _LEGACY_TIMER_INTERVAL if _is_legacy_blender() else _MODERN_IDLE_INTERVAL


def install(operators_module) -> None:
    global _INSTALLED, _ORIGINAL, _ORIGINAL_INVOKE, _OPERATORS
    if _INSTALLED:
        return

    original = getattr(operators_module, "_context_pulse", None)
    toggle_cls = getattr(operators_module, "LUMAFOLD_OT_toggle_p0", None)
    original_invoke = getattr(toggle_cls, "invoke", None) if toggle_cls is not None else None
    if not callable(original) or not callable(original_invoke):
        return

    _OPERATORS = operators_module
    _ORIGINAL = original
    _ORIGINAL_INVOKE = original_invoke

    def adaptive_context_pulse(operator, host, host_id):
        now = time.perf_counter()

        if _is_legacy_blender():
            interval = _LEGACY_TIMER_INTERVAL if _lumafold_interactive(host) else _LEGACY_IDLE_INTERVAL
        else:
            interval = _MODERN_IDLE_INTERVAL

        last = float(getattr(operator, "_lumafold_idle_pulse_at", 0.0) or 0.0)
        if now - last < interval:
            return None

        operator._lumafold_idle_pulse_at = now
        return original(operator, host, host_id)

    def invoke_with_adaptive_timer(self, context, event):
        result = original_invoke(self, context, event)
        if "RUNNING_MODAL" in set(result or ()):
            old_timer = getattr(self, "_timer", None)
            if old_timer is not None:
                try:
                    new_timer = context.window_manager.event_timer_add(
                        _timer_interval(),
                        window=context.window,
                    )
                except Exception:
                    new_timer = None
                if new_timer is not None:
                    try:
                        context.window_manager.event_timer_remove(old_timer)
                    except Exception:
                        pass
                    self._timer = new_timer
                    self._lumafold_idle_pulse_at = 0.0
        return result

    operators_module._context_pulse = adaptive_context_pulse
    toggle_cls.invoke = invoke_with_adaptive_timer
    _INSTALLED = True


def uninstall() -> None:
    global _INSTALLED, _ORIGINAL, _ORIGINAL_INVOKE, _OPERATORS
    if _INSTALLED and _OPERATORS is not None:
        if callable(_ORIGINAL):
            _OPERATORS._context_pulse = _ORIGINAL
        toggle_cls = getattr(_OPERATORS, "LUMAFOLD_OT_toggle_p0", None)
        if toggle_cls is not None and callable(_ORIGINAL_INVOKE):
            toggle_cls.invoke = _ORIGINAL_INVOKE

    _INSTALLED = False
    _ORIGINAL = None
    _ORIGINAL_INVOKE = None
    _OPERATORS = None


def snapshot():
    legacy = _is_legacy_blender()
    return {
        "installed": bool(_INSTALLED),
        "legacy_blender": bool(legacy),
        "modal_timer_hz": 60.0 if legacy else 10.0,
        "interactive_redraw_hz": 60.0 if legacy else 10.0,
        "idle_redraw_hz": 10.0,
        "adaptive_legacy_redraw": bool(legacy),
    }
