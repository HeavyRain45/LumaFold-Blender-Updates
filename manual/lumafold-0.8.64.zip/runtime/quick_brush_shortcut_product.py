from __future__ import annotations

"""Quick Brush interaction product layer.

This module owns two host-independent interactions:

* editing the *real* Blender Sculpt keymap used by ``lumafold.quick_brush_slot``;
* a transient ``quick_replace_slot`` target so a Brush Library selection can
  replace the Quick Brush tile that opened the library, in Embedded or Satellite.

No shortcut label or replacement is UI-only. Blender/Core remains authoritative.
"""

import bpy

from ..core.app import APP

_OPERATOR_ID = "lumafold.quick_brush_slot"
_KEYMAP_NAME = "Sculpt"
_SLOT_COUNT = 16
_WATCH_NS_KEY = "LUMAFOLD_QUICK_SHORTCUT_PRODUCT_V1"
_ORIGINAL_LIBRARY_ACTIVATE = None
_DEFAULT_KEYS = ("ONE", "TWO", "THREE", "FOUR", "FIVE", "SIX", "SEVEN", "EIGHT")
_DEFAULT_BINDINGS = tuple(
    [dict(type=name, alt=True, ctrl=False, shift=False, oskey=False) for name in _DEFAULT_KEYS]
    + [dict(type=name, alt=False, ctrl=True, shift=False, oskey=False) for name in _DEFAULT_KEYS]
)


def _defaults():
    return [dict(item) for item in _DEFAULT_BINDINGS]


def _normalize_binding(raw, fallback=None):
    fallback = dict(fallback or {})
    raw = dict(raw or {})
    return {
        "type": str(raw.get("type") or fallback.get("type") or "ONE").upper(),
        "alt": bool(raw.get("alt", fallback.get("alt", False))),
        "ctrl": bool(raw.get("ctrl", fallback.get("ctrl", False))),
        "shift": bool(raw.get("shift", fallback.get("shift", False))),
        "oskey": bool(raw.get("oskey", fallback.get("oskey", False))),
    }


def _extend_schema_excludes():
    schema = APP.persistence.schemas.get("sculpt")
    if schema is None:
        return
    excluded = list(schema.exclude_keys)
    for key in ("quick_shortcut_request", "quick_replace_slot"):
        if key not in excluded:
            excluded.append(key)
    APP.register_state_schema(
        "sculpt",
        schema.version,
        migrations=dict(schema.migrations),
        exclude_keys=tuple(excluded),
    )


def bindings_from_state():
    state = APP.store.namespace("sculpt")
    source = list(state.get("quick_hotkey_bindings") or ())
    defaults = _defaults()
    bindings = []
    for slot in range(_SLOT_COUNT):
        raw = source[slot] if slot < len(source) else defaults[slot]
        bindings.append(_normalize_binding(raw, defaults[slot]))
    state["quick_hotkey_bindings"] = [dict(item) for item in bindings]
    return bindings


def _addon_keymap():
    wm = getattr(bpy.context, "window_manager", None)
    keyconfigs = getattr(wm, "keyconfigs", None) if wm is not None else None
    kc = getattr(keyconfigs, "addon", None) if keyconfigs is not None else None
    if kc is None:
        return None
    # Blender can contain same-name maps with different space/region tuples.
    # Always target the actual Sculpt add-on map used by event handling.
    try:
        km = kc.keymaps.find(_KEYMAP_NAME, space_type='EMPTY', region_type='WINDOW')
    except Exception:
        km = None
    if km is None:
        km = kc.keymaps.new(name=_KEYMAP_NAME, space_type='EMPTY', region_type='WINDOW')
    return km


def _slot_from_item(kmi):
    try:
        return int(getattr(kmi.properties, "slot", -1))
    except Exception:
        return -1


def _remove_slot_items(km, slot: int):
    if km is None:
        return
    for kmi in tuple(getattr(km, "keymap_items", ()) or ()):
        try:
            if str(getattr(kmi, "idname", "") or "") == _OPERATOR_ID and _slot_from_item(kmi) == int(slot):
                km.keymap_items.remove(kmi)
        except Exception:
            pass


def _create_slot_item(km, slot: int, binding):
    binding = _normalize_binding(binding)
    kmi = km.keymap_items.new(
        _OPERATOR_ID,
        str(binding["type"]),
        'PRESS',
        alt=bool(binding["alt"]),
        ctrl=bool(binding["ctrl"]),
        shift=bool(binding["shift"]),
        oskey=bool(binding["oskey"]),
        # A Quick Brush shortcut is intentionally authoritative in Sculpt.
        # Putting it at the head prevents an older matching Sculpt item from
        # swallowing the key before LumaFold sees it.
        head=True,
    )
    kmi.properties.slot = int(slot)
    kmi.active = True
    return kmi


def apply_all_bindings():
    km = _addon_keymap()
    if km is None:
        return False
    bindings = bindings_from_state()
    for slot in range(_SLOT_COUNT):
        _remove_slot_items(km, slot)
        _create_slot_item(km, slot, bindings[slot])
    # The old 0.5 s shortcut watcher used to populate UI labels after startup.
    # With polling removed, read the real Sculpt keymap once at this explicit
    # mutation boundary so Quick Brush badges still show the actual bindings.
    _refresh_truth_state()
    return True


def _refresh_truth_state():
    state = APP.store.namespace("sculpt")
    service = APP.services.get("blender.sculpt_shortcuts")
    if service is None:
        return
    try:
        snap = service.snapshot()
        labels = list(snap.get("labels") or ())[:_SLOT_COUNT]
        labels += [""] * (_SLOT_COUNT - len(labels))
        previous = list(state.get("quick_shortcuts") or ())[:_SLOT_COUNT]
        previous += [""] * (_SLOT_COUNT - len(previous))
        state["quick_shortcuts"] = labels
        state["quick_shortcuts_status"] = str(snap.get("status") or "READY")
        if labels != previous:
            APP.events.emit(
                "sculpt.state.changed",
                {"fields": {"quick_shortcuts": list(labels)}, "source": "shortcut_truth"},
            )
    except Exception:
        pass


def set_slot_binding(slot: int = 0, key: str = "ONE", modifier: str = "ALT"):
    slot = max(0, min(_SLOT_COUNT - 1, int(slot)))
    modifier = str(modifier or "ALT").upper()
    binding = {
        "type": str(key or "ONE").upper(),
        "alt": modifier == "ALT",
        "ctrl": modifier == "CTRL",
        "shift": modifier == "SHIFT",
        "oskey": modifier in {"OS", "SUPER", "CMD"},
    }
    state = APP.store.namespace("sculpt")
    bindings = bindings_from_state()
    bindings[slot] = _normalize_binding(binding, _DEFAULT_BINDINGS[slot])
    state["quick_hotkey_bindings"] = [dict(item) for item in bindings]

    km = _addon_keymap()
    if km is None:
        raise RuntimeError("Blender Sculpt addon keymap unavailable")
    _remove_slot_items(km, slot)
    _create_slot_item(km, slot, bindings[slot])
    _refresh_truth_state()
    try:
        APP.persistence.save(force=True)
    except Exception:
        pass
    return f"槽位 {slot + 1} 快捷键已更新"


def reset_slot_binding(slot: int = 0):
    slot = max(0, min(_SLOT_COUNT - 1, int(slot)))
    default = dict(_DEFAULT_BINDINGS[slot])
    modifier = "ALT" if default.get("alt") else ("CTRL" if default.get("ctrl") else "SHIFT" if default.get("shift") else "NONE")
    return set_slot_binding(slot=slot, key=str(default.get("type") or "ONE"), modifier=modifier)


def _install_request_watch():
    generation = int(bpy.app.driver_namespace.get(_WATCH_NS_KEY, 0) or 0) + 1
    bpy.app.driver_namespace[_WATCH_NS_KEY] = generation

    def tick():
        if int(bpy.app.driver_namespace.get(_WATCH_NS_KEY, 0) or 0) != generation:
            return None
        state = APP.store.namespace("sculpt")
        request = state.pop("quick_shortcut_request", None)
        if isinstance(request, dict):
            try:
                slot = int(request.get("slot", 0))
                if str(request.get("action") or "").lower() == "reset":
                    message = reset_slot_binding(slot=slot)
                else:
                    message = set_slot_binding(
                        slot=slot,
                        key=str(request.get("key") or "ONE"),
                        modifier=str(request.get("modifier") or "ALT"),
                    )
                state["brush_action_status"] = str(message)
            except Exception as exc:
                state["brush_action_status"] = f"快捷键修改失败：{type(exc).__name__}: {exc}"
        return 0.10

    bpy.app.timers.register(tick, first_interval=0.10, persistent=True)


def _install_targeted_library_activate():
    global _ORIGINAL_LIBRARY_ACTIVATE
    commands = getattr(APP.commands, "_commands", {})
    activate = commands.get("sculpt.brush.library_activate")
    assign = commands.get("sculpt.brush.library_assign_slot")
    if not callable(activate) or not callable(assign) or _ORIGINAL_LIBRARY_ACTIVATE is not None:
        return
    _ORIGINAL_LIBRARY_ACTIVATE = activate

    def activate_or_replace(*, identity: str = ""):
        state = APP.store.namespace("sculpt")
        try:
            target = int(state.get("quick_replace_slot", -1))
        except Exception:
            target = -1
        if target >= 0:
            try:
                return assign(identity=str(identity), slot=target)
            finally:
                state["quick_replace_slot"] = -1
        return activate(identity=str(identity))

    APP.commands.register("sculpt.brush.library_activate", activate_or_replace)


def install():
    _extend_schema_excludes()
    state = APP.store.namespace("sculpt")
    state["quick_replace_slot"] = -1
    state.pop("quick_shortcut_request", None)
    bindings_from_state()
    APP.commands.register("sculpt.brush.set_quick_shortcut", set_slot_binding)
    APP.commands.register("sculpt.brush.reset_quick_shortcut", reset_slot_binding)
    _install_targeted_library_activate()
    # Shortcut edits are dispatched once by the UI action; no persistent
    # 100 ms state-polling timer is needed.


def uninstall():
    global _ORIGINAL_LIBRARY_ACTIVATE
    try:
        bpy.app.driver_namespace[_WATCH_NS_KEY] = int(bpy.app.driver_namespace.get(_WATCH_NS_KEY, 0) or 0) + 1
    except Exception:
        pass
    if callable(_ORIGINAL_LIBRARY_ACTIVATE):
        APP.commands.register("sculpt.brush.library_activate", _ORIGINAL_LIBRARY_ACTIVATE)
    _ORIGINAL_LIBRARY_ACTIVATE = None
