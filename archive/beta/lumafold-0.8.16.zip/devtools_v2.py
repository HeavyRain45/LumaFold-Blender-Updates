import importlib
import sys
import traceback
import types

import bpy

_PACKAGE_PREFIX = __package__
_LUMAFOLD_MODAL_ID = "LUMAFOLD_OT_toggle_p0"
_DEV_NS_KEY = "LUMAFOLD_DEV_RELOAD_V2"

_RELOAD_PENDING = False
_REOPEN_AFTER_RELOAD = False
_RELOAD_PHASE = "idle"
_RELOAD_WAIT_TICKS = 0
_RELOAD_WAIT_LIMIT = 120


def _dev_ns():
    ns = bpy.app.driver_namespace
    data = ns.get(_DEV_NS_KEY)
    if not isinstance(data, dict):
        data = {
            "sequence": 0,
            "phase": "idle",
            "result": "not run",
            "error": "",
        }
        ns[_DEV_NS_KEY] = data
    return data


def hot_reload_status_text():
    data = _dev_ns()
    return f"#{int(data.get('sequence', 0) or 0)} · {str(data.get('result', 'not run') or 'not run')} · {str(data.get('phase', 'idle') or 'idle')}"


def _best_view3d_context():
    try:
        windows = tuple(bpy.context.window_manager.windows)
    except Exception:
        return None, None, None
    for window in windows:
        screen = getattr(window, "screen", None)
        if screen is None:
            continue
        candidates = []
        for area in tuple(screen.areas):
            if getattr(area, "type", "") != 'VIEW_3D':
                continue
            region = next((item for item in area.regions if item.type == 'WINDOW'), None)
            if region is None:
                continue
            score = int(getattr(area, "width", 0) or 0) * int(getattr(area, "height", 0) or 0)
            candidates.append((score, area, region))
        if candidates:
            candidates.sort(key=lambda item: item[0], reverse=True)
            _score, area, region = candidates[0]
            return window, area, region
    return None, None, None


def _fresh_state():
    try:
        return importlib.import_module(f"{_PACKAGE_PREFIX}.core.state").STATE
    except Exception:
        return None


def _reopen_after_reload():
    try:
        window, area, region = _best_view3d_context()
        if window is None or area is None or region is None:
            return None
        with bpy.context.temp_override(window=window, area=area, region=region):
            bpy.ops.lumafold.toggle_p0('INVOKE_DEFAULT')
    except Exception:
        data = _dev_ns()
        data["result"] = "reload ok / reopen failed"
        data["error"] = traceback.format_exc()
        state = _fresh_state()
        if state is not None:
            state.last_error = data["error"]
            state.status = "Development hot reload succeeded · auto reopen failed"
    return None


def _modal_operator_names():
    names = []
    try:
        windows = tuple(bpy.context.window_manager.windows)
    except Exception:
        return names
    for win_index, window in enumerate(windows):
        try:
            modal_ops = tuple(window.modal_operators)
        except Exception:
            continue
        for op in modal_ops:
            try:
                ident = str(getattr(getattr(op, "bl_rna", None), "identifier", "") or "")
                if not ident:
                    ident = str(getattr(op, "bl_idname", "") or type(op).__name__)
            except Exception:
                ident = "<unknown>"
            names.append(f"W{win_index}:{ident}")
    return names


def modal_snapshot_text():
    names = _modal_operator_names()
    return ", ".join(names) if names else "none"


def _lumafold_modal_present():
    try:
        for window in bpy.context.window_manager.windows:
            modal_ops = window.modal_operators
            try:
                if modal_ops.get(_LUMAFOLD_MODAL_ID) is not None:
                    return True
            except Exception:
                for op in modal_ops:
                    ident = str(getattr(getattr(op, "bl_rna", None), "identifier", "") or "")
                    if ident == _LUMAFOLD_MODAL_ID:
                        return True
    except Exception:
        pass
    return False


def _reset_local_reload_state():
    global _RELOAD_PENDING, _REOPEN_AFTER_RELOAD, _RELOAD_PHASE, _RELOAD_WAIT_TICKS
    _RELOAD_PENDING = False
    _REOPEN_AFTER_RELOAD = False
    _RELOAD_PHASE = "idle"
    _RELOAD_WAIT_TICKS = 0


def _record_failure(message, exc_text=""):
    data = _dev_ns()
    data["phase"] = "failed"
    data["result"] = str(message)
    data["error"] = str(exc_text or "")
    state = _fresh_state()
    if state is not None:
        state.status = str(message)
        if exc_text:
            state.last_error = str(exc_text)
    _reset_local_reload_state()
    return None


def _scrub_package_module_attributes(root):
    """Remove stale package attributes that can survive a sys.modules purge.

    `from . import panels` may reuse `root.panels` even after the corresponding
    sys.modules entry was deleted.  That was why S0.7.4 behavior could update
    while the diagnostic panel still showed the old dev5 label.  Scrubbing every
    child-module attribute makes the following root reload import from disk.
    """
    for name, value in tuple(vars(root).items()):
        if not isinstance(value, types.ModuleType):
            continue
        module_name = str(getattr(value, "__name__", "") or "")
        if module_name.startswith(_PACKAGE_PREFIX + "."):
            root.__dict__.pop(name, None)


def _reload_lumafold_package(reopen):
    data = _dev_ns()
    data["phase"] = "unregister"

    root = sys.modules.get(_PACKAGE_PREFIX)
    if root is None:
        root = importlib.import_module(_PACKAGE_PREFIX)

    unregister = getattr(root, "unregister", None)
    if callable(unregister):
        unregister()

    data["phase"] = "purge"
    submodule_names = [name for name in tuple(sys.modules) if name.startswith(_PACKAGE_PREFIX + ".")]
    submodule_names.sort(key=lambda name: (name.count("."), len(name)), reverse=True)
    for name in submodule_names:
        sys.modules.pop(name, None)
    _scrub_package_module_attributes(root)

    importlib.invalidate_caches()
    data["phase"] = "import"
    root = importlib.reload(root)

    register = getattr(root, "register", None)
    if not callable(register):
        raise RuntimeError("Reloaded LumaFold package has no register()")

    data["phase"] = "register"
    register()

    data = bpy.app.driver_namespace.setdefault(_DEV_NS_KEY, data)
    data["phase"] = "complete"
    data["result"] = "success"
    data["error"] = ""

    state = _fresh_state()
    if state is not None:
        state.last_error = ""
        state.status = "Development hot reload complete"

    if reopen:
        bpy.app.timers.register(_reopen_after_reload, first_interval=0.20)


def _reload_tick():
    global _RELOAD_PHASE, _RELOAD_WAIT_TICKS
    try:
        operators = importlib.import_module(f"{_PACKAGE_PREFIX}.operators")

        if _RELOAD_PHASE == "retire":
            data = _dev_ns()
            data["phase"] = "retire"
            active = getattr(operators, "_ACTIVE_OPERATOR", None)
            if active is not None:
                host = getattr(active, "_host", None)
                if host is not None and not bool(getattr(host, "closed", False)):
                    host.shutdown()
            else:
                operators.shutdown_all()
            state = _fresh_state()
            if state is not None:
                state.status = "Development hot reload · retiring LumaFold modal"
            _RELOAD_PHASE = "wait_modal_exit"
            return 0.05

        if _RELOAD_PHASE == "wait_modal_exit":
            _dev_ns()["phase"] = "wait modal"
            if _lumafold_modal_present():
                _RELOAD_WAIT_TICKS += 1
                if _RELOAD_WAIT_TICKS >= _RELOAD_WAIT_LIMIT:
                    return _record_failure(
                        f"Hot reload timed out · LumaFold modal still present: {modal_snapshot_text()}"
                    )
                return 0.05
            operators.shutdown_all()
            _RELOAD_PHASE = "package_reload"
            return 0.05

        if _RELOAD_PHASE == "package_reload":
            reopen = bool(_REOPEN_AFTER_RELOAD)
            _reset_local_reload_state()
            _reload_lumafold_package(reopen)
            return None

        return _record_failure("Hot reload cancelled · invalid phase")
    except Exception:
        return _record_failure("Development hot reload failed", traceback.format_exc())


class LUMAFOLD_OT_dev_reload(bpy.types.Operator):
    bl_idname = "lumafold.dev_reload"
    bl_label = "热重载 LumaFold（开发）"
    bl_description = "完整刷新 LumaFold Python 包；此前已开启则自动恢复浮台"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        global _RELOAD_PENDING, _REOPEN_AFTER_RELOAD, _RELOAD_PHASE, _RELOAD_WAIT_TICKS
        if _RELOAD_PENDING:
            self.report({'INFO'}, "LumaFold 正在等待热重载")
            return {'CANCELLED'}

        data = _dev_ns()
        data["sequence"] = int(data.get("sequence", 0) or 0) + 1
        data["phase"] = "scheduled"
        data["result"] = "running"
        data["error"] = ""

        state = _fresh_state()
        _REOPEN_AFTER_RELOAD = bool(getattr(state, "running", False)) if state is not None else False
        _RELOAD_PENDING = True
        _RELOAD_PHASE = "retire"
        _RELOAD_WAIT_TICKS = 0
        if state is not None:
            state.last_error = ""
            state.status = "Development hot reload scheduled"
        bpy.app.timers.register(_reload_tick, first_interval=0.05)
        self.report({'INFO'}, "LumaFold 热重载已安排")
        return {'FINISHED'}


CLASSES = (LUMAFOLD_OT_dev_reload,)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
