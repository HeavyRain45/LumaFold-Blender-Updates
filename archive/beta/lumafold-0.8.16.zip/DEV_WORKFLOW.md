# LumaFold - Blender Development Workflow

Current development branch: `dev`. Stable milestones are promoted to `main` only after real Blender testing.

## Daily test loop

1. In GitHub Desktop, keep **Current branch = dev**.
2. Click **Fetch origin**. If an update exists, click **Pull origin**.
3. In Blender, open **N Panel > LumaFold > LumaFold · 开发者诊断**.
4. Click **开发：安全重载 LumaFold**.
5. If LumaFold was open before reload, it should return automatically in Embedded/浮台 mode.
6. Test the requested change and report the result/screenshots.

## Why the custom reload button exists

LumaFold owns more runtime state than a typical add-on: an Embedded modal/draw host, Satellite WGL process, Secondary Surface windows, bridge threads, input capture, and texture/runtime state. The development reload path explicitly retires LumaFold runtime state first, then asks Blender to reload scripts. This avoids carrying stale Host state across source-code updates.

## First-time bootstrap

The first time this workflow is installed, use **Blender > System > Reload Scripts** once after pulling the commit that introduces the reload operator. From then on, use the LumaFold development reload button.

## Safety rule

Do not commit directly to `main` during day-to-day iteration. Work on `dev`; promote a tested milestone later.
