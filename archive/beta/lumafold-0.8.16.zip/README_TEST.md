# LumaFold - Blender · S0.8.4-dev43 Real-Machine Path Recovery

当前候选版：**S0.8.4-dev43 · Real-Machine Path Recovery**

Phase C 与 Alpha Preview 继续暂停。dev42 实机仅确认 Embedded Secondary 的空白点击关闭与 ESC 关闭有效；Quick Brush 定向替换仍失败，Satellite 仍未出现，因此 dev42 已拒绝。

## dev43 只处理两个阻断点

### 1. Quick Brush 定向替换

Embedded 不再让 Runtime 根据 `quick_replace_slot` 猜测用户意图。

正式事务固定为：

`Quick Slot 图标 -> 打开 Brush Library -> 点击 Brush -> assign(identity, exact slot) -> clear target -> deferred native activate`

Runtime 仍保留 picker target latch，作为跨帧/其他 Host 的安全兜底，但 Embedded UI 的目标 Slot 由显式 callback 直接传递。

### 2. Satellite 首帧与真实 runtime 路径

旧方案依赖隐藏 HWND (`SW_HIDE`) 完成第一帧 WGL。GitHub Runner 能通过，但这不能证明所有 Windows GPU/驱动都支持同样行为。

dev43 固定为：

`创建 Satellite -> 放到 (-32000,-32000) -> SW_SHOWNOACTIVATE -> 完整 WGL/ImGui 首帧 -> READY -> Blender lease grant -> WM_APP_SHOW -> 移到目标位置`

预飞窗口对用户不可见，但 GPU 得到真实可见 HWND，不再依赖 hidden-window WGL。

Satellite 启动失败时，真实 child log 尾部会进入 `STATE.last_error`，便于下一轮直接定位 import / WGL / runtime / Bridge 错误。

## 自动验收

- Syntax / Static Architecture Contracts
- RuntimeSession / HostController
- Brush Library command policy
- Embedded Secondary input ownership
- Satellite Sculpt Broker lifecycle
- Windows native Satellite WGL process
- 官方 Blender 5.2.1：被产品包装后的 targeted Brush replacement + native Slot activation
- 官方 Blender 5.2.1：真实 LumaFold `runtime.bootstrap.vendor_dir()` + production launcher + off-screen WGL first frame + READY/grant + 最终窗口移动到请求坐标

禁止 QA 再通过 monkey-patch `launcher.vendor_dir()` 绕过生产 runtime 路径。

## 本轮实机 Blocker Gate

必须：**完整退出 Blender -> GitHub Desktop Fetch/Pull -> 重新启动。**

先只测 3 项：

1. 诊断版本显示 `S0.8.4-dev43 · Real-Machine Path Recovery`。
2. Embedded：从一个 Quick Brush Slot 图标打开 Brush Library，选一个明显不同的 Brush，确认该 Slot 立即替换；再换另一个 Slot 重复一次。
3. 点击 Satellite 一次，Satellite 必须直接出现。

只有第 2、3 项都通过，才继续 Satellite ZBrush / N Sidebar / Header / 首一下卡顿等完整 Runtime regression。
