from __future__ import annotations

from dataclasses import dataclass
import json
import os
import tempfile
from pathlib import Path
from typing import Dict, Iterable, Tuple


TRUST_BUILTIN = "builtin"
TRUST_TRUSTED = "trusted"
TRUST_UNKNOWN = "unknown"
TRUST_BLOCKED = "blocked"

# These are policy identifiers, not an OS/Python sandbox.  Unknown external
# modules get only the read-only Blender baseline until the user explicitly
# trusts the module.  Trusted modules may request any *known* permission.
PERMISSION_CATALOG = {
    "blender.read": ("读取 Blender 数据", "low"),
    "blender.write": ("修改 Blender 数据", "medium"),
    "files.read": ("读取本地文件", "medium"),
    "files.write": ("写入本地文件", "high"),
    "network": ("访问网络", "high"),
    "process.launch": ("启动外部进程", "high"),
    "clipboard": ("读写剪贴板", "medium"),
}
UNKNOWN_BASELINE = frozenset({"blender.read"})


@dataclass(frozen=True)
class PermissionDecision:
    module_id: str
    trust: str
    requested: Tuple[str, ...] = ()
    allowed: Tuple[str, ...] = ()
    denied: Tuple[str, ...] = ()
    unknown: Tuple[str, ...] = ()

    @property
    def ok(self) -> bool:
        return not self.denied and not self.unknown


class PermissionManager:
    """Core-owned trust decisions + manifest permission gate.

    This is intentionally a *pre-execution policy gate*.  It prevents an
    untrusted external module with sensitive declared permissions from being
    imported at all.  Once arbitrary Python is trusted and imported in-process,
    Python itself is not sandboxed; later SDK stages can route privileged actions
    through mediated Core services for stronger capability enforcement.
    """

    FORMAT = "lumafold-trust"
    SCHEMA = 1

    def __init__(self):
        self._trust: Dict[str, str] = {}
        self._loaded = False
        self.last_message = ""

    def default_path(self) -> Path:
        import bpy
        root = bpy.utils.user_resource("CONFIG", path="lumafold", create=True)
        return Path(root) / "trust.json"

    def _ensure_loaded(self) -> None:
        if self._loaded:
            return
        self._loaded = True
        path = self.default_path()
        if not path.exists():
            return
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
            if raw.get("format") != self.FORMAT:
                return
            entries = raw.get("modules") or {}
            for module_id, level in entries.items():
                if level in {TRUST_TRUSTED, TRUST_BLOCKED, TRUST_UNKNOWN}:
                    self._trust[str(module_id)] = str(level)
        except Exception as exc:
            # Trust file corruption must never prevent Blender startup.  Fail closed:
            # external modules fall back to UNKNOWN policy.
            self.last_message = f"信任文件读取失败，已按 UNKNOWN 处理: {type(exc).__name__}: {exc}"

    def _save(self) -> None:
        path = self.default_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "format": self.FORMAT,
            "schema": self.SCHEMA,
            "modules": dict(sorted(self._trust.items())),
        }
        text = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True)
        fd, tmp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
                handle.write(text)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(tmp_name, path)
        finally:
            try:
                if os.path.exists(tmp_name):
                    os.unlink(tmp_name)
            except Exception:
                pass

    def trust_level(self, module_id: str, source: str = "external") -> str:
        if source == "builtin":
            return TRUST_BUILTIN
        self._ensure_loaded()
        return self._trust.get(str(module_id), TRUST_UNKNOWN)

    def set_trust(self, module_id: str, level: str) -> str:
        self._ensure_loaded()
        level = str(level or TRUST_UNKNOWN)
        if level not in {TRUST_TRUSTED, TRUST_UNKNOWN, TRUST_BLOCKED}:
            raise ValueError("不支持的信任级别: " + level)
        module_id = str(module_id)
        if level == TRUST_UNKNOWN:
            self._trust.pop(module_id, None)
        else:
            self._trust[module_id] = level
        self._save()
        self.last_message = f"{module_id} → {level}"
        return level

    def forget(self, module_id: str) -> None:
        self._ensure_loaded()
        if str(module_id) in self._trust:
            self._trust.pop(str(module_id), None)
            self._save()

    def evaluate(self, module_id: str, source: str, permissions: Iterable[str]) -> PermissionDecision:
        requested = tuple(dict.fromkeys(str(p).strip() for p in (permissions or ()) if str(p).strip()))
        trust = self.trust_level(module_id, source)
        unknown = tuple(p for p in requested if p not in PERMISSION_CATALOG)
        known = tuple(p for p in requested if p in PERMISSION_CATALOG)

        if trust == TRUST_BUILTIN:
            allowed, denied = known, ()
        elif trust == TRUST_TRUSTED:
            allowed, denied = known, ()
        elif trust == TRUST_BLOCKED:
            allowed, denied = (), known
        else:
            allowed = tuple(p for p in known if p in UNKNOWN_BASELINE)
            denied = tuple(p for p in known if p not in UNKNOWN_BASELINE)

        return PermissionDecision(
            module_id=str(module_id), trust=trust, requested=requested,
            allowed=allowed, denied=denied, unknown=unknown,
        )

    def describe_permission(self, permission_id: str) -> str:
        item = PERMISSION_CATALOG.get(str(permission_id))
        if item is None:
            return str(permission_id) + "（未知权限）"
        label, risk = item
        return f"{permission_id} · {label} · {risk}"

    def trust_file_display(self) -> str:
        try:
            return str(self.default_path())
        except Exception:
            return ""
