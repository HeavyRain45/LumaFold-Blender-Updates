import json
import platform
import sys
import traceback
from pathlib import Path

import bpy

from .state import STATE


def snapshot():
    region = getattr(bpy.context, "region", None)
    area = getattr(bpy.context, "area", None)
    prefs = bpy.context.preferences
    return {
        "product": "LumaFold",
        "core_alpha": "A0.9",
        "blender_version": bpy.app.version_string,
        "python_version": sys.version,
        "platform": platform.platform(),
        "online_access": bool(getattr(bpy.app, "online_access", False)),
        "ui_scale": float(prefs.view.ui_scale),
        "pixel_size": float(getattr(prefs.system, "pixel_size", 1.0)),
        "area_type": getattr(area, "type", None),
        "region_type": getattr(region, "type", None),
        "region_size": [getattr(region, "width", 0), getattr(region, "height", 0)],
        "host_state": ({
            "ime_gate": getattr(STATE.host, "state", {}).get("ime_gate"),
            "ime_info": getattr(STATE.host, "state", {}).get("ime_info", {}),
            "ime_results": getattr(STATE.host, "state", {}).get("ime_results", []),
            "host_mode": getattr(STATE.host, "host_mode", None),
            "window_pointer": getattr(STATE.host, "window_pointer", 0),
        } if STATE.host is not None else {}),
        "runtime": {
            "running": STATE.running,
            "frames": STATE.frames,
            "capture_mouse": STATE.capture_mouse,
            "capture_keyboard": STATE.capture_keyboard,
            "capture_text": STATE.capture_text,
            "runtime_ready": STATE.runtime_ready,
            "runtime_version": STATE.runtime_version,
            "status": STATE.status,
            "host_mode": STATE.host_mode,
            "window_pointer": STATE.window_pointer,
            "last_error": STATE.last_error,
        },
    }


def write_report():
    base_package = __package__.rsplit('.core', 1)[0]
    out_dir = Path(bpy.utils.extension_path_user(base_package, path="diagnostics", create=True))
    path = out_dir / "lumafold_core_a05_diagnostic.json"
    path.write_text(json.dumps(snapshot(), ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def capture_exception(prefix=""):
    STATE.last_error = (prefix + "\n" + traceback.format_exc()).strip()
    STATE.status = "Error"
