from __future__ import annotations

from dataclasses import dataclass, field
from queue import Empty, Queue
import threading
import time
import traceback
import uuid
from typing import Any, Callable, Dict, List, Optional


class TaskCancelled(RuntimeError):
    """Cooperative cancellation signal raised inside a task worker."""


@dataclass
class TaskRecord:
    task_id: str
    label: str
    owner: str = "core"
    status: str = "QUEUED"
    progress: float = 0.0
    message: str = "等待执行"
    result: Any = None
    error: str = ""
    created_at: float = field(default_factory=time.time)
    started_at: float = 0.0
    finished_at: float = 0.0
    cancel_requested: bool = False
    worker_thread: str = ""
    callback_thread: str = ""

    @property
    def done(self) -> bool:
        return self.status in {"COMPLETED", "CANCELLED", "FAILED"}


class TaskContext:
    """Worker-side task API.

    Workers may update progress and poll cancellation, but must not touch Blender
    data. Blender/main-thread work belongs in completion callbacks, which are
    marshalled through TaskManager.pump_main_thread().
    """

    def __init__(self, manager: "TaskManager", task_id: str):
        self._manager = manager
        self.task_id = task_id

    @property
    def cancelled(self) -> bool:
        record = self._manager.get(self.task_id)
        return bool(record and record.cancel_requested)

    def check_cancelled(self) -> None:
        if self.cancelled:
            raise TaskCancelled("任务已取消")

    def update(self, progress: float, message: str = "") -> None:
        self.check_cancelled()
        self._manager._update_progress(self.task_id, progress, message)


class TaskManager:
    """Core-owned cooperative background task system.

    A0.11 deliberately keeps the contract small: daemon worker threads do pure
    Python/background I/O work; progress/cancellation are thread-safe; callbacks
    are queued back to the Blender/UI main thread and executed only when the host
    pumps the queue at a frame boundary.
    """

    def __init__(self):
        self._records: Dict[str, TaskRecord] = {}
        self._lock = threading.RLock()
        self._main_queue: Queue = Queue()
        self._accepting = True
        self._main_thread_ident: Optional[int] = None

    def submit(
        self,
        label: str,
        worker: Callable[[TaskContext], Any],
        *,
        owner: str = "core",
        on_complete: Optional[Callable[[TaskRecord], None]] = None,
        on_error: Optional[Callable[[TaskRecord], None]] = None,
        on_cancel: Optional[Callable[[TaskRecord], None]] = None,
    ) -> str:
        if not callable(worker):
            raise TypeError("worker must be callable")
        with self._lock:
            if not self._accepting:
                raise RuntimeError("TaskManager is shutting down")
            task_id = uuid.uuid4().hex[:12]
            record = TaskRecord(task_id=task_id, label=str(label), owner=str(owner or "core"))
            self._records[task_id] = record

        thread = threading.Thread(
            target=self._run_worker,
            args=(task_id, worker, on_complete, on_error, on_cancel),
            name=f"LumaFoldTask-{task_id[:6]}",
            daemon=True,
        )
        thread.start()
        return task_id

    def _run_worker(self, task_id, worker, on_complete, on_error, on_cancel) -> None:
        with self._lock:
            record = self._records.get(task_id)
            if record is None:
                return
            record.status = "RUNNING"
            record.started_at = time.time()
            record.worker_thread = threading.current_thread().name
            record.message = "后台执行中"

        ctx = TaskContext(self, task_id)
        callback = None
        try:
            ctx.check_cancelled()
            result = worker(ctx)
            ctx.check_cancelled()
            with self._lock:
                record = self._records.get(task_id)
                if record is None:
                    return
                record.result = result
                record.progress = 1.0
                record.status = "COMPLETED"
                record.message = record.message if record.message and record.message != "后台执行中" else "任务完成"
                record.finished_at = time.time()
                callback = on_complete
        except TaskCancelled:
            with self._lock:
                record = self._records.get(task_id)
                if record is None:
                    return
                record.status = "CANCELLED"
                record.message = "已取消"
                record.finished_at = time.time()
                callback = on_cancel
        except Exception as exc:
            with self._lock:
                record = self._records.get(task_id)
                if record is None:
                    return
                record.status = "FAILED"
                record.error = f"{type(exc).__name__}: {exc}"
                record.message = "后台任务失败，已隔离"
                record.finished_at = time.time()
                callback = on_error
            # Keep a detailed traceback only in the queued diagnostic payload;
            # never re-raise into Blender from a worker thread.
            detail = traceback.format_exc()
            self._main_queue.put((task_id, None, detail))

        if callback is not None:
            self._main_queue.put((task_id, callback, ""))

    def _update_progress(self, task_id: str, progress: float, message: str = "") -> None:
        with self._lock:
            record = self._records.get(task_id)
            if record is None:
                return
            record.progress = max(0.0, min(1.0, float(progress)))
            if message:
                record.message = str(message)

    def cancel(self, task_id: str) -> bool:
        with self._lock:
            record = self._records.get(str(task_id))
            if record is None or record.done:
                return False
            record.cancel_requested = True
            if record.status in {"QUEUED", "RUNNING"}:
                record.status = "CANCELLING"
                record.message = "正在取消…"
            return True

    def get(self, task_id: str) -> Optional[TaskRecord]:
        with self._lock:
            return self._records.get(str(task_id))

    def all(self) -> List[TaskRecord]:
        with self._lock:
            return sorted(self._records.values(), key=lambda r: r.created_at, reverse=True)

    def clear_finished(self) -> int:
        with self._lock:
            ids = [task_id for task_id, record in self._records.items() if record.done]
            for task_id in ids:
                self._records.pop(task_id, None)
            return len(ids)

    def pump_main_thread(self, limit: int = 16) -> int:
        """Execute queued completion callbacks on the caller/main UI thread."""
        self._main_thread_ident = threading.get_ident()
        processed = 0
        while processed < max(1, int(limit)):
            try:
                task_id, callback, detail = self._main_queue.get_nowait()
            except Empty:
                break
            record = self.get(task_id)
            if record is not None:
                if detail and not record.error:
                    record.error = detail.splitlines()[-1] if detail.splitlines() else detail
                if callback is not None:
                    try:
                        callback(record)
                    except Exception as exc:
                        record.error = f"Main-thread callback {type(exc).__name__}: {exc}"
                    finally:
                        record.callback_thread = threading.current_thread().name
                elif detail:
                    record.callback_thread = threading.current_thread().name
            processed += 1
        return processed

    def resume(self) -> None:
        with self._lock:
            self._accepting = True

    def shutdown(self) -> None:
        # Workers are daemon threads and cancellation is cooperative.  Blender
        # shutdown must never block waiting for arbitrary third-party task code.
        with self._lock:
            self._accepting = False
            for record in self._records.values():
                if not record.done:
                    record.cancel_requested = True
