from __future__ import annotations

from dataclasses import dataclass, field
from hashlib import sha256
import json
import os
from pathlib import Path
import tempfile
from typing import List, Tuple

from .modulesdk import CORE_API_VERSION, PACKAGE_FORMAT_VERSION
from .platform import (
    CapabilitySnapshot,
    ContextSnapshot,
    EventBus,
    ModuleRegistry,
    ModuleSpec,
    ServiceRegistry,
    StateStore,
)
from .security import PERMISSION_CATALOG, UNKNOWN_BASELINE


SDK_CONTRACT_VERSION = "1.0"
PUBLIC_APP_HOOKS = (
    "register_module",
    "register_state_schema",
    "provide_service",
    "require_service",
    "execute",
    "refresh_context",
)
BUILTIN_MODULES = ("sculpt", "model", "light", "render")
CORE_SERVICES = ("blender.context", "blender.object", "blender.mode")
CORE_CAPABILITIES = (
    "object.active",
    "object.mesh",
    "mode.object",
    "mode.sculpt",
    "mode.edit_mesh",
    "host.embedded",
    "host.satellite",
    "host.desktop",
)
CORE_HOSTS = ("embedded", "satellite", "desktop")


@dataclass(frozen=True)
class ContractCheck:
    check_id: str
    label: str
    passed: bool
    detail: str = ""


@dataclass
class ContractReport:
    status: str = "未运行 NOT RUN"
    checks: List[ContractCheck] = field(default_factory=list)
    fingerprint: str = ""

    @property
    def passed_count(self) -> int:
        return sum(1 for item in self.checks if item.passed)

    @property
    def total_count(self) -> int:
        return len(self.checks)

    @property
    def ok(self) -> bool:
        return bool(self.checks) and self.passed_count == self.total_count


class ContractManager:
    """A1.0 frozen public contract and regression baseline.

    This does not freeze implementation details.  It records the public contract a
    module is allowed to rely on, then exercises the registries in isolation so a
    later Core change can be caught before it silently breaks third-party modules.
    """

    FORMAT = "lumafold-sdk-contract"
    SCHEMA = 1

    def __init__(self, app):
        self.app = app
        self.last_report = ContractReport(fingerprint=self.fingerprint())
        self.last_blender_report = ContractReport(fingerprint=self.fingerprint())
        self.last_message = "尚未运行 A1.0 基线验证"
        self.last_blender_message = "尚未运行真实 Blender 回归"
        self.last_compare_ok = None
        self.sdk_doc_frozen = False
        self.sdk_doc_message = "SDK 文档尚未冻结"

    def snapshot(self) -> dict:
        return {
            "format": self.FORMAT,
            "schema": self.SCHEMA,
            "sdk_contract": SDK_CONTRACT_VERSION,
            "core_api": CORE_API_VERSION,
            "package_format": PACKAGE_FORMAT_VERSION,
            "public_app_hooks": list(PUBLIC_APP_HOOKS),
            "builtin_modules": list(BUILTIN_MODULES),
            "core_services": list(CORE_SERVICES),
            "core_capabilities": list(CORE_CAPABILITIES),
            "hosts": list(CORE_HOSTS),
            "permission_ids": sorted(PERMISSION_CATALOG),
            "unknown_permission_baseline": sorted(UNKNOWN_BASELINE),
            "module_manifest_fields": [
                "id", "name", "version", "category", "entry", "api_version",
                "package_format", "hosts", "description", "self_test",
                "blender_min", "blender_max", "requires_modules",
                "provides_services", "requires_services", "permissions",
            ],
        }

    def fingerprint(self) -> str:
        payload = json.dumps(self.snapshot(), sort_keys=True, ensure_ascii=True, separators=(",", ":"))
        return sha256(payload.encode("utf-8")).hexdigest()[:16]

    def default_path(self) -> Path:
        import bpy
        root = bpy.utils.user_resource("CONFIG", path="lumafold", create=True)
        return Path(root) / "sdk_contract_v1.json"

    def path_display(self) -> str:
        try:
            return str(self.default_path())
        except Exception:
            return ""

    def save_snapshot(self) -> str:
        path = self.default_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        data = dict(self.snapshot())
        data["fingerprint"] = self.fingerprint()
        text = json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True)
        fd, tmp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
                handle.write(text)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(tmp_name, path)
        finally:
            try:
                if os.path.exists(tmp_name):
                    os.unlink(tmp_name)
            except Exception:
                pass
        self.last_message = f"契约快照已保存 SAVED · {self.fingerprint()}"
        return self.last_message

    def compare_saved(self) -> Tuple[bool, str]:
        path = self.default_path()
        if not path.exists():
            self.last_message = "没有已保存契约快照，请先保存"
            return False, self.last_message
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
            old = str(raw.get("fingerprint") or "")
            current = self.fingerprint()
            ok = old == current and bool(old)
            self.last_compare_ok = bool(ok)
            self.last_message = (
                f"契约一致 MATCH · {current}" if ok
                else f"契约发生变化 DRIFT · saved={old or '-'} · current={current}"
            )
            return ok, self.last_message
        except Exception as exc:
            self.last_compare_ok = False
            self.last_message = f"契约对比失败：{type(exc).__name__}: {exc}"
            return False, self.last_message

    def run_regression(self) -> ContractReport:
        checks: List[ContractCheck] = []

        def add(check_id: str, label: str, passed: bool, detail: str = ""):
            checks.append(ContractCheck(check_id, label, bool(passed), str(detail)))

        add("versions", "Core API / Package Format", CORE_API_VERSION == "1" and PACKAGE_FORMAT_VERSION == "1",
            f"Core API={CORE_API_VERSION} · Package={PACKAGE_FORMAT_VERSION}")

        missing_hooks = [name for name in PUBLIC_APP_HOOKS if not callable(getattr(self.app, name, None))]
        add("public_hooks", "公共 SDK 入口", not missing_hooks,
            "完整" if not missing_hooks else "缺少: " + ", ".join(missing_hooks))

        loader = getattr(self.app, "module_loader", None)
        if loader is None:
            add("builtin_modules", "内置模块注册", False, "ModuleLoader 不可用")
        else:
            missing = []
            for module_id in BUILTIN_MODULES:
                record = loader.get(module_id)
                if not record or not record.loaded or self.app.modules.get(module_id) is None:
                    missing.append(module_id)
            add("builtin_modules", "四个内置模块", not missing,
                "sculpt / model / light / render" if not missing else "异常: " + ", ".join(missing))

        service_ids = set(self.app.services.all_ids())
        missing_services = [sid for sid in CORE_SERVICES if sid not in service_ids]
        add("core_services", "Core Blender 服务", not missing_services,
            "完整" if not missing_services else "缺少: " + ", ".join(missing_services))

        cap_ids = set(self.app.capabilities.all_ids())
        missing_caps = [cid for cid in CORE_CAPABILITIES if cid not in cap_ids]
        add("capabilities", "Context / Capability", not missing_caps,
            "8 个基础能力" if not missing_caps else "缺少: " + ", ".join(missing_caps))

        host_ids = {item.host_id for item in self.app.hosts.all()}
        missing_hosts = [hid for hid in CORE_HOSTS if hid not in host_ids]
        add("hosts", "三类 Host 契约", not missing_hosts,
            "embedded / satellite / desktop" if not missing_hosts else "缺少: " + ", ".join(missing_hosts))

        # Isolated ModuleRegistry activation probe: no mutation of live app registries.
        try:
            registry = ModuleRegistry()
            registry.register(ModuleSpec(
                module_id="__contract_probe__", label="probe", category="test", version="1",
                hosts=("embedded",), modes=("OBJECT",), requires=("object.mesh",),
            ))
            ctx = ContextSnapshot(mode="OBJECT", host_id="embedded", active_object_name="Probe",
                                  active_object_type="MESH", has_active_object=True)
            transitions = registry.refresh(ctx, CapabilitySnapshot(("object.mesh",)))
            status = registry.status("__contract_probe__")
            ok = status.active and any(row[1] == "activated" for row in transitions)
            add("module_lifecycle", "模块生命周期解析", ok, status.reason)
        except Exception as exc:
            add("module_lifecycle", "模块生命周期解析", False, f"{type(exc).__name__}: {exc}")

        # Isolated ServiceRegistry protection probe.
        try:
            services = ServiceRegistry()
            services.register("probe.service", object(), owner="provider", version="1")
            services.bind("probe.service", "consumer")
            protected = False
            try:
                services.unregister("probe.service", owner="provider")
            except RuntimeError:
                protected = True
            services.release_consumer("consumer")
            services.unregister("probe.service", owner="provider")
            add("service_contract", "服务绑定 / 卸载保护", protected and services.get("probe.service") is None,
                "consumer 绑定时保护，释放后可卸载")
        except Exception as exc:
            add("service_contract", "服务绑定 / 卸载保护", False, f"{type(exc).__name__}: {exc}")

        # Event listener exceptions must be isolated.
        try:
            bus = EventBus()
            received = []
            bus.subscribe("probe", lambda payload: (_ for _ in ()).throw(RuntimeError("expected")))
            bus.subscribe("probe", lambda payload: received.append(payload))
            bus.emit("probe", 42)
            add("event_bus", "Event Bus 故障隔离", received == [42], "坏监听器不阻断后续监听器")
        except Exception as exc:
            add("event_bus", "Event Bus 故障隔离", False, f"{type(exc).__name__}: {exc}")

        # State snapshot/restore should be deterministic and namespace-safe.
        try:
            store = StateStore()
            store.namespace("probe", {"value": 1})["value"] = 7
            snapshot = store.snapshot()
            store.namespace("probe")["value"] = 99
            store.restore(snapshot, merge=False)
            add("state_store", "State Store 快照恢复", store.namespace("probe").get("value") == 7, "namespace restore")
        except Exception as exc:
            add("state_store", "State Store 快照恢复", False, f"{type(exc).__name__}: {exc}")

        # Unknown modules must keep only read baseline before trust.
        try:
            known_permissions = set(PERMISSION_CATALOG)
            baseline_ok = UNKNOWN_BASELINE == frozenset({"blender.read"})
            catalog_ok = {"blender.read", "blender.write", "files.write", "network"}.issubset(known_permissions)
            add("permission_policy", "权限基线契约", baseline_ok and catalog_ok,
                "UNKNOWN 仅 blender.read")
        except Exception as exc:
            add("permission_policy", "权限基线契约", False, f"{type(exc).__name__}: {exc}")

        task_methods = ("submit", "cancel", "get", "all", "pump_main_thread", "shutdown", "resume")
        missing_task = [name for name in task_methods if not callable(getattr(self.app.tasks, name, None))]
        add("task_api", "Task System 公共能力", not missing_task,
            "后台 / 取消 / 主线程回收" if not missing_task else "缺少: " + ", ".join(missing_task))

        persistence_methods = ("register_namespace", "save", "load", "run_migration_probe")
        missing_persist = [name for name in persistence_methods if not callable(getattr(self.app.persistence, name, None))]
        add("persistence_api", "Persistence / Migration", not missing_persist,
            "保存 / 恢复 / 迁移" if not missing_persist else "缺少: " + ", ".join(missing_persist))

        report = ContractReport(checks=checks, fingerprint=self.fingerprint())
        report.status = (
            f"全部通过 PASS · {report.passed_count}/{report.total_count}"
            if report.ok else f"存在回归 FAIL · {report.passed_count}/{report.total_count}"
        )
        self.last_report = report
        self.last_message = report.status
        return report

    def sdk_reference_path(self) -> Path:
        import bpy
        root = bpy.utils.user_resource("CONFIG", path="lumafold", create=True)
        return Path(root) / "LumaFold_Module_SDK_v1.md"

    def sdk_reference_path_display(self) -> str:
        try:
            return str(self.sdk_reference_path())
        except Exception:
            return ""

    def freeze_sdk_reference(self) -> str:
        """Write the human-readable SDK reference derived from the frozen contract."""
        path = self.sdk_reference_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        snap = self.snapshot()
        lines = [
            "# LumaFold Module SDK v1",
            "",
            "> A1.0 frozen public module contract. Core implementation details may evolve, but breaking public changes require an explicit Core API / SDK version decision.",
            "",
            f"- Contract fingerprint: `{self.fingerprint()}`",
            f"- Core API: `{snap['core_api']}`",
            f"- Package format: `{snap['package_format']}`",
            f"- SDK contract: `{snap['sdk_contract']}`",
            "",
            "## Public App Hooks",
        ]
        lines += [f"- `{name}`" for name in snap["public_app_hooks"]]
        lines += ["", "## Manifest Fields"]
        lines += [f"- `{name}`" for name in snap["module_manifest_fields"]]
        lines += ["", "## Core Services"]
        lines += [f"- `{name}`" for name in snap["core_services"]]
        lines += ["", "## Context / Capability IDs"]
        lines += [f"- `{name}`" for name in snap["core_capabilities"]]
        lines += ["", "## Hosts"]
        lines += [f"- `{name}`" for name in snap["hosts"]]
        lines += ["", "## Permissions"]
        lines += [f"- `{name}`" for name in snap["permission_ids"]]
        lines += [
            "",
            "## Required Module Rules",
            "",
            "1. Business modules register through the public App hooks and do not depend on Core implementation modules.",
            "2. Cross-module features are requested through Service Contract IDs; consumers do not import providers.",
            "3. Blender mutations are routed through Commands/Services. Background workers must not touch Blender data.",
            "4. Durable settings live in module State namespaces and declare a schema version/migrations.",
            "5. External modules declare permissions in the manifest and pass compatibility/trust gates before execution.",
            "6. UI state is host-independent. Embedded, Satellite and Desktop hosts consume the same Core state.",
            "7. A public-contract change requires a Core API / SDK contract version decision; silent breaking changes are forbidden.",
            "",
            "## Package Skeleton",
            "",
            "```text",
            "my_module/",
            "├─ manifest.toml",
            "└─ module.py",
            "```",
            "",
            "The package entry exposes `register(app)`. Use `MODULE_MANIFEST` for built-in modules or `manifest.toml` for external packages.",
            "",
        ]
        text = "\n".join(lines)
        fd, tmp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
                handle.write(text)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(tmp_name, path)
        finally:
            try:
                if os.path.exists(tmp_name):
                    os.unlink(tmp_name)
            except Exception:
                pass
        self.sdk_doc_frozen = True
        self.sdk_doc_message = f"SDK 文档已冻结 FROZEN · {self.fingerprint()}"
        return self.sdk_doc_message

    def run_blender_regression(self) -> ContractReport:
        """A1.0 reversible smoke test against real Blender data and operators.

        The probe creates temporary objects, exercises real Commands/Services, then
        restores selection, mode, render settings and LumaFold module state.
        """
        checks: List[ContractCheck] = []

        def add(check_id: str, label: str, passed: bool, detail: str = ""):
            checks.append(ContractCheck(check_id, label, bool(passed), str(detail)))

        import bpy

        original_active = bpy.context.view_layer.objects.active
        original_selected = list(getattr(bpy.context, "selected_objects", ()))
        original_mode = str(getattr(bpy.context, "mode", "OBJECT"))
        render = bpy.context.scene.render
        original_render = (int(render.resolution_x), int(render.resolution_y), int(render.resolution_percentage))
        state_snapshot = self.app.store.snapshot()
        temp_objects = []
        temp_meshes = []
        temp_lights = []

        def ensure_object_mode():
            current = str(getattr(bpy.context, "mode", "OBJECT"))
            if current != "OBJECT" and bpy.context.view_layer.objects.active is not None:
                bpy.ops.object.mode_set(mode="OBJECT")

        try:
            # 1) Real Context Service.
            ctx = self.app.services.require("blender.context").snapshot("embedded")
            add("real_context", "真实 Context 读取", bool(ctx.mode), f"mode={ctx.mode} · object={ctx.active_object_name or '-'}")

            ensure_object_mode()
            for obj in tuple(getattr(bpy.context, "selected_objects", ())):
                try:
                    obj.select_set(False)
                except Exception:
                    pass

            # Temporary cube-like mesh created without bpy.ops so cleanup is deterministic.
            mesh = bpy.data.meshes.new("__LumaFold_A016_MeshData")
            mesh.from_pydata(
                [(-0.5,-0.5,-0.5),(0.5,-0.5,-0.5),(0.5,0.5,-0.5),(-0.5,0.5,-0.5),
                 (-0.5,-0.5,0.5),(0.5,-0.5,0.5),(0.5,0.5,0.5),(-0.5,0.5,0.5)],
                [],
                [(0,1,2,3),(4,7,6,5),(0,4,5,1),(1,5,6,2),(2,6,7,3),(4,0,3,7)],
            )
            mesh.update()
            obj = bpy.data.objects.new("__LumaFold_A016_Mesh", mesh)
            bpy.context.collection.objects.link(obj)
            temp_objects.append(obj)
            temp_meshes.append(mesh)
            obj.select_set(True)
            bpy.context.view_layer.objects.active = obj
            self.app.refresh_context("embedded")

            # 2) Context capability follows a real temporary Mesh selection.
            cap_ok = "object.mesh" in set(self.app.state.context_capabilities)
            add("real_capability", "真实对象 Capability", cap_ok, "临时 Mesh -> object.mesh")

            # 3) Command -> Service -> Blender object mutation.
            start_x = float(obj.location.x)
            result = self.app.execute("model.nudge_x", delta=0.125)
            nudge_ok = result.ok and abs(float(obj.location.x) - (start_x + 0.125)) < 1e-6
            add("real_command", "Command → Service → Blender", nudge_ok, result.message)

            # 4) Modifier operation through Model module command.
            result = self.app.execute("model.add_bevel", width=0.003, segments=2)
            mod = obj.modifiers.get("LumaFold Bevel")
            bevel_ok = result.ok and mod is not None and abs(float(mod.width) - 0.003) < 1e-6 and int(mod.segments) == 2
            add("real_modifier", "真实 Bevel 修改器", bevel_ok, result.message)

            # 5) Real mode transition and restoration to Object on the temp mesh.
            enter = self.app.execute("sculpt.enter")
            in_sculpt = str(getattr(bpy.context, "mode", "")) == "SCULPT"
            leave = self.app.execute("sculpt.exit_to_object")
            back_object = str(getattr(bpy.context, "mode", "")) == "OBJECT"
            add("real_mode", "真实 Sculpt 模式往返", enter.ok and in_sculpt and leave.ok and back_object,
                f"enter={enter.ok} · return={leave.ok}")

            # 6) Real Light creation through command, followed by deterministic cleanup.
            result = self.app.execute("light.create_area", energy=321.0, size=1.25)
            light_obj = bpy.context.view_layer.objects.active
            light_ok = bool(result.ok and light_obj is not None and light_obj.type == "LIGHT" and
                            abs(float(light_obj.data.energy) - 321.0) < 1e-6)
            if light_obj is not None and light_obj not in temp_objects:
                temp_objects.append(light_obj)
                if getattr(light_obj, "data", None) is not None:
                    temp_lights.append(light_obj.data)
            add("real_light", "真实灯光 Command", light_ok, result.message)

            # 7) Scene-level Render settings through Render module, restored in finally.
            result = self.app.execute("render.apply", resolution_x=640, resolution_y=360, percentage=50)
            render_ok = result.ok and (int(render.resolution_x), int(render.resolution_y), int(render.resolution_percentage)) == (640, 360, 50)
            add("real_render", "真实渲染设置 Command", render_ok, result.message)

        except Exception as exc:
            add("real_exception", "真实 Blender 回归执行", False, f"{type(exc).__name__}: {exc}")
        finally:
            cleanup_ok = True
            cleanup_detail = "选择 / 模式 / 渲染参数 / 临时对象已恢复"
            try:
                ensure_object_mode()
                render.resolution_x, render.resolution_y, render.resolution_percentage = original_render
                for current in tuple(getattr(bpy.context, "selected_objects", ())):
                    try:
                        current.select_set(False)
                    except Exception:
                        pass
                for item in reversed(temp_objects):
                    try:
                        if item and item.name in bpy.data.objects:
                            bpy.data.objects.remove(item, do_unlink=True)
                    except Exception:
                        cleanup_ok = False
                for data in temp_meshes:
                    try:
                        if data and data.name in bpy.data.meshes:
                            bpy.data.meshes.remove(data)
                    except Exception:
                        pass
                for data in temp_lights:
                    try:
                        if data and data.name in bpy.data.lights:
                            bpy.data.lights.remove(data)
                    except Exception:
                        pass
                if original_active is not None and original_active.name in bpy.data.objects:
                    bpy.context.view_layer.objects.active = original_active
                else:
                    bpy.context.view_layer.objects.active = None
                for item in original_selected:
                    try:
                        if item and item.name in bpy.data.objects:
                            item.select_set(True)
                    except Exception:
                        cleanup_ok = False
                # Restore original mode when possible.
                if original_active is not None and original_active.name in bpy.data.objects and original_mode != "OBJECT":
                    mode_map = {
                        "EDIT_MESH": "EDIT", "SCULPT": "SCULPT", "POSE": "POSE",
                        "PAINT_TEXTURE": "TEXTURE_PAINT", "PAINT_VERTEX": "VERTEX_PAINT",
                        "PAINT_WEIGHT": "WEIGHT_PAINT",
                    }
                    target = mode_map.get(original_mode)
                    if target:
                        try:
                            bpy.ops.object.mode_set(mode=target)
                        except Exception:
                            cleanup_ok = False
                self.app.store.restore(state_snapshot, merge=False)
                self.app.refresh_context("embedded")
            except Exception as exc:
                cleanup_ok = False
                cleanup_detail = f"恢复失败: {type(exc).__name__}: {exc}"
            add("real_cleanup", "无痕恢复 / Cleanup", cleanup_ok, cleanup_detail)

        report = ContractReport(checks=checks, fingerprint=self.fingerprint())
        report.status = (
            f"真实回归全部通过 PASS · {report.passed_count}/{report.total_count}"
            if report.ok else f"真实回归存在失败 FAIL · {report.passed_count}/{report.total_count}"
        )
        self.last_blender_report = report
        self.last_blender_message = report.status
        return report

    def a1_readiness(self) -> Tuple[bool, str]:
        platform_ok = self.last_report.ok
        blender_ok = self.last_blender_report.ok
        contract_ok = self.last_compare_ok is True
        docs_ok = bool(self.sdk_doc_frozen)
        count = sum((platform_ok, blender_ok, contract_ok, docs_ok))
        ok = count == 4
        return ok, f"{'A1.0 架构基线 VERIFIED' if ok else 'A1.0 基线待验证 PENDING'} · {count}/4"

