from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional
import time

from .tasks import TaskManager
from .persistence import PersistenceManager
from .security import PermissionManager
from .contract import ContractManager

from .platform import (
    CapabilityRegistry,
    ContextSnapshot,
    EventBus,
    ModuleRegistry,
    ServiceRegistry,
    StateStore,
)


@dataclass
class CommandResult:
    ok: bool
    command_id: str
    message: str = ""
    payload: Any = None
    elapsed_ms: float = 0.0


class CommandRegistry:
    def __init__(self):
        self._commands: Dict[str, Callable[..., Any]] = {}

    def register(self, command_id: str, fn: Callable[..., Any]) -> None:
        if not command_id or not callable(fn):
            raise ValueError("Invalid command registration")
        self._commands[command_id] = fn

    def has(self, command_id: str) -> bool:
        return command_id in self._commands

    def unregister(self, command_id: str) -> None:
        self._commands.pop(command_id, None)

    def all_ids(self) -> List[str]:
        return sorted(self._commands)

    def execute(self, command_id: str, **kwargs) -> CommandResult:
        started = time.perf_counter()
        fn = self._commands.get(command_id)
        if fn is None:
            return CommandResult(False, command_id, f"Unknown command: {command_id}")
        try:
            payload = fn(**kwargs)
            msg = payload if isinstance(payload, str) else "OK"
            return CommandResult(True, command_id, msg, payload, (time.perf_counter() - started) * 1000.0)
        except Exception as exc:
            return CommandResult(False, command_id, f"{type(exc).__name__}: {exc}", None, (time.perf_counter() - started) * 1000.0)


@dataclass(frozen=True)
class HostSpec:
    host_id: str
    label: str
    embedded: bool
    detachable: bool
    desktop_like: bool
    shared_process: bool


class HostRegistry:
    def __init__(self):
        self._hosts: Dict[str, HostSpec] = {}

    def register(self, spec: HostSpec) -> None:
        self._hosts[spec.host_id] = spec

    def get(self, host_id: str) -> Optional[HostSpec]:
        return self._hosts.get(host_id)

    def all(self) -> List[HostSpec]:
        return list(self._hosts.values())


@dataclass
class CoreState:
    shared_counter: int = 0
    shared_enabled: bool = True
    shared_value: float = 0.35
    shared_text: str = "LumaFold Core"
    last_command: str = "none"
    last_command_message: str = ""
    last_command_ok: bool = True
    command_count: int = 0
    event_log: List[str] = field(default_factory=list)
    context: ContextSnapshot = field(default_factory=ContextSnapshot)
    context_capabilities: tuple = ()
    context_refresh_count: int = 0

    def log(self, message: str) -> None:
        self.event_log.append(str(message))
        del self.event_log[:-12]


class LumaFoldApp:
    def __init__(self):
        self.state = CoreState()
        self.commands = CommandRegistry()
        self.hosts = HostRegistry()
        self.modules = ModuleRegistry()
        self.services = ServiceRegistry()
        self.capabilities = CapabilityRegistry()
        self.events = EventBus()
        self.store = StateStore()
        self.tasks = TaskManager()
        self.persistence = PersistenceManager(self)
        self.security = PermissionManager()
        self.contract = ContractManager(self)
        self.module_loader = None
        self._bootstrapped = False
        self._context_fingerprint = None

    def register_state_schema(self, namespace: str, version: int = 1, *, migrations=None, exclude_keys=()):
        """Public SDK hook for durable module state schema + migration ownership."""
        self.persistence.register_namespace(
            namespace, version, migrations=migrations, exclude_keys=exclude_keys
        )

    def provide_service(self, module_id: str, service_id: str, service: Any, *, version: str = "1"):
        """Register a module-owned service contract with Core."""
        self.services.register(service_id, service, owner=str(module_id), version=str(version))
        self.events.emit("service.provided", {"module": str(module_id), "service": str(service_id), "version": str(version)})
        self.state.log(f"service.provided: {service_id} <- {module_id}")
        return service

    def require_service(self, module_id: str, service_id: str):
        """Resolve and bind a service for a consumer module without importing its provider."""
        service = self.services.bind(str(service_id), str(module_id))
        self.events.emit("service.bound", {"module": str(module_id), "service": str(service_id), "provider": self.services.owner_of(str(service_id))})
        self.state.log(f"service.bound: {module_id} -> {service_id}")
        return service

    def register_module(self, *, module_id, label, category="General", version="0.1",
                        description="", hosts=("embedded", "satellite"), modes=(),
                        requires=(), capabilities=(), commands=(),
                        on_activate=None, on_deactivate=None):
        """Public SDK helper used by external modules."""
        from .platform import ModuleSpec
        spec = ModuleSpec(
            module_id=str(module_id), label=str(label), category=str(category),
            version=str(version), description=str(description),
            hosts=tuple(hosts or ()), modes=tuple(modes or ()),
            requires=tuple(requires or ()), capabilities=tuple(capabilities or ()),
            commands=tuple(commands or ()),
        )
        self.modules.register(spec, on_activate=on_activate, on_deactivate=on_deactivate)
        return spec

    def bootstrap(self) -> None:
        if self._bootstrapped:
            return
        self.hosts.register(HostSpec("embedded", "Blender Embedded", True, True, False, True))
        self.hosts.register(HostSpec("satellite", "Adaptive Satellite", False, True, True, True))
        self.hosts.register(HostSpec("desktop", "Desktop Host POC", False, True, True, False))
        self.commands.register("core.counter.increment", self._cmd_counter_increment)
        self.commands.register("core.counter.reset", self._cmd_counter_reset)
        self._bootstrapped = True

    def refresh_context(self, host_id: str = "embedded"):
        self.bootstrap()
        service = self.services.get("blender.context")
        if service is None:
            return self.state.context, None
        context = service.snapshot(host_id=host_id)
        caps = self.capabilities.resolve(context)
        self.state.context = context
        self.state.context_capabilities = caps.available
        self.state.context_refresh_count += 1

        if context.fingerprint != self._context_fingerprint:
            self._context_fingerprint = context.fingerprint
            self.events.emit("context.changed", {
                "mode": context.mode,
                "host": context.host_id,
                "object": context.active_object_name,
                "object_type": context.active_object_type,
            })

        for module_id, event, reason in self.modules.refresh(context, caps):
            self.events.emit(f"module.{event}", {"module": module_id, "reason": reason})
            self.state.log(f"module.{event}: {module_id} · {reason}")
        return context, caps

    def execute(self, command_id: str, **kwargs) -> CommandResult:
        self.bootstrap()
        result = self.commands.execute(command_id, **kwargs)
        s = self.state
        s.command_count += 1
        s.last_command = command_id
        s.last_command_message = result.message
        s.last_command_ok = result.ok
        s.log(f"{command_id}: {result.message}")
        return result

    def _cmd_counter_increment(self, amount: int = 1):
        self.state.shared_counter += int(amount)
        return f"counter = {self.state.shared_counter}"

    def _cmd_counter_reset(self):
        self.state.shared_counter = 0
        return "counter reset"


APP = LumaFoldApp()
APP.bootstrap()
