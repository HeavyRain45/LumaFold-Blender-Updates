from __future__ import annotations

"""Pure-Python runtime session state shared by UI draw and Blender input.

Hard rule: this module must never import or call slimgui, GPU, WGL, bpy UI drawing
APIs, or native window APIs.  It is deliberately boring state so Blender Modal
handlers can safely read it during Mode/Workspace/Region transitions.
"""

from dataclasses import dataclass, field
import threading


@dataclass
class PopupState:
    names: tuple[str, ...] = ()
    serial: int = 0
    close_requested: bool = False
    close_reason: str = ""

    @property
    def open(self) -> bool:
        return bool(self.names)


class RuntimeSession:
    def __init__(self):
        self._lock = threading.RLock()
        self._popups = {
            "embedded": PopupState(),
            "satellite": PopupState(),
        }

    def _bucket(self, host: str) -> PopupState:
        key = str(host or "embedded").strip().casefold()
        if key not in self._popups:
            self._popups[key] = PopupState()
        return self._popups[key]

    def publish_popups(self, host: str, names) -> PopupState:
        clean = tuple(str(name) for name in tuple(names or ()) if str(name or ""))
        with self._lock:
            bucket = self._bucket(host)
            if clean != bucket.names:
                bucket.names = clean
                bucket.serial += 1
            if not clean:
                bucket.close_requested = False
                bucket.close_reason = ""
            return PopupState(
                names=bucket.names,
                serial=bucket.serial,
                close_requested=bucket.close_requested,
                close_reason=bucket.close_reason,
            )

    def popup_snapshot(self, host: str = "embedded") -> PopupState:
        with self._lock:
            bucket = self._bucket(host)
            return PopupState(
                names=bucket.names,
                serial=bucket.serial,
                close_requested=bucket.close_requested,
                close_reason=bucket.close_reason,
            )

    def popup_open(self, host: str = "embedded") -> bool:
        with self._lock:
            return self._bucket(host).open

    def popup_named(self, host: str, name: str) -> bool:
        target = str(name or "")
        with self._lock:
            return target in self._bucket(host).names

    def request_popup_close(self, host: str = "embedded", *, reason: str = "") -> bool:
        with self._lock:
            bucket = self._bucket(host)
            if not bucket.open:
                return False
            bucket.close_requested = True
            bucket.close_reason = str(reason or "")
            return True

    def close_requested(self, host: str = "embedded") -> bool:
        with self._lock:
            return bool(self._bucket(host).close_requested)

    def acknowledge_close_request(self, host: str = "embedded") -> None:
        with self._lock:
            bucket = self._bucket(host)
            bucket.close_requested = False
            bucket.close_reason = ""

    def clear_host(self, host: str) -> None:
        with self._lock:
            self._popups[str(host or "embedded").strip().casefold()] = PopupState()

    def clear_all(self) -> None:
        with self._lock:
            for key in tuple(self._popups):
                self._popups[key] = PopupState()


RUNTIME_SESSION = RuntimeSession()
