from __future__ import annotations

from dataclasses import dataclass
import secrets


EMBEDDED = "EMBEDDED"
DETACHING = "DETACHING"
SATELLITE = "SATELLITE"
ATTACHING = "ATTACHING"
RECOVERING = "RECOVERING"


@dataclass
class HostLease:
    state: str = EMBEDDED
    owner: str = "embedded"
    generation: int = 1
    token: str = ""


class HostController:
    """Single-owner Host state machine.

    The lease is process-authoritative in Blender. Renderers/input paths must
    validate owner + generation before touching the shared Sculpt View.

    Runtime systems may subscribe to lease transitions.  This is the only
    supported way for long-lived input/runtime services to react to
    Embedded <-> Satellite migration; polling is a watchdog, not a source of
    correctness.
    """

    def __init__(self):
        self.lease = HostLease(token=secrets.token_hex(12))
        self.migration_locked = False
        self._subscribers = []

    def subscribe(self, callback):
        if not callable(callback):
            raise ValueError("Host transition subscriber must be callable")
        if callback not in self._subscribers:
            self._subscribers.append(callback)

        def unsubscribe():
            try:
                self._subscribers.remove(callback)
            except ValueError:
                pass

        return unsubscribe

    def _notify(self) -> None:
        snapshot = self.snapshot()
        for callback in tuple(self._subscribers):
            try:
                callback(dict(snapshot))
            except Exception:
                # A runtime observer must never be able to break the lease state
                # machine. Observers are diagnostic/runtime conveniences only.
                pass

    def _rotate(self, *, state: str, owner: str) -> HostLease:
        self.lease = HostLease(
            state=state,
            owner=owner,
            generation=int(self.lease.generation) + 1,
            token=secrets.token_hex(12),
        )
        return self.lease

    def begin_detach(self) -> HostLease:
        if self.migration_locked or self.lease.state != EMBEDDED or self.lease.owner != "embedded":
            raise RuntimeError(f"Host cannot detach from {self.lease.state}/{self.lease.owner}")
        self.migration_locked = True
        self.lease.state = DETACHING
        self.lease.owner = "embedded"
        self._notify()
        return self.lease

    def cancel_detach(self) -> HostLease:
        if self.lease.state != DETACHING or self.lease.owner != "embedded":
            raise RuntimeError(f"Host cannot cancel detach from {self.lease.state}/{self.lease.owner}")
        self.lease.state = EMBEDDED
        self.lease.owner = "embedded"
        self.migration_locked = False
        self._notify()
        return self.lease

    def grant_satellite(self, expected_generation: int) -> HostLease:
        if self.lease.state != DETACHING or self.lease.owner != "embedded":
            raise RuntimeError("Satellite lease grant requested outside DETACHING")
        if int(expected_generation) != int(self.lease.generation):
            raise RuntimeError("Stale Satellite generation")
        lease = self._rotate(state=SATELLITE, owner="satellite")
        self.migration_locked = False
        self._notify()
        return lease

    def begin_attach(self) -> HostLease:
        if self.lease.state not in {SATELLITE, DETACHING, RECOVERING}:
            raise RuntimeError(f"Host cannot attach from {self.lease.state}")
        self.migration_locked = True
        lease = self._rotate(state=ATTACHING, owner="none")
        self._notify()
        return lease

    def grant_embedded(self) -> HostLease:
        if self.lease.state not in {ATTACHING, RECOVERING}:
            raise RuntimeError(f"Embedded lease grant requested from {self.lease.state}")
        lease = self._rotate(state=EMBEDDED, owner="embedded")
        self.migration_locked = False
        self._notify()
        return lease

    def recover_embedded(self) -> HostLease:
        self.migration_locked = True
        self._rotate(state=RECOVERING, owner="none")
        self._notify()
        return self.grant_embedded()

    def owns(self, owner: str, generation: int | None = None) -> bool:
        if self.lease.owner != str(owner):
            return False
        if generation is not None and int(generation) != int(self.lease.generation):
            return False
        if owner == "embedded":
            return self.lease.state in {EMBEDDED, DETACHING}
        if owner == "satellite":
            return self.lease.state == SATELLITE
        return False

    def snapshot(self) -> dict:
        return {
            "state": self.lease.state,
            "owner": self.lease.owner,
            "generation": int(self.lease.generation),
            "token": self.lease.token,
            "migration_locked": bool(self.migration_locked),
        }


HOST_CONTROL = HostController()
