from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Iterable, List, Optional, Tuple
import time


@dataclass(frozen=True)
class ContextSnapshot:
    mode: str = "UNKNOWN"
    host_id: str = "embedded"
    active_object_name: str = ""
    active_object_type: str = ""
    has_active_object: bool = False

    @property
    def fingerprint(self) -> tuple:
        return (
            self.mode,
            self.host_id,
            self.active_object_name,
            self.active_object_type,
            self.has_active_object,
        )


@dataclass(frozen=True)
class CapabilitySnapshot:
    available: Tuple[str, ...] = ()

    def has(self, capability_id: str) -> bool:
        return capability_id in self.available


class CapabilityRegistry:
    """Context capability resolver shared by every module.

    Concrete Blender checks are registered outside Core. Modules only declare
    capability IDs such as object.mesh or mode.sculpt.
    """

    def __init__(self):
        self._checks: Dict[str, Callable[[ContextSnapshot], bool]] = {}

    def register(self, capability_id: str, predicate: Callable[[ContextSnapshot], bool]) -> None:
        if not capability_id or not callable(predicate):
            raise ValueError("Invalid capability registration")
        self._checks[capability_id] = predicate

    def resolve(self, context: ContextSnapshot) -> CapabilitySnapshot:
        available = []
        for capability_id, predicate in self._checks.items():
            try:
                if predicate(context):
                    available.append(capability_id)
            except Exception:
                # Capability checks are isolated just like event listeners.
                pass
        return CapabilitySnapshot(tuple(sorted(available)))

    def all_ids(self) -> List[str]:
        return sorted(self._checks)


@dataclass(frozen=True)
class ModuleSpec:
    module_id: str
    label: str
    category: str
    version: str
    description: str = ""
    hosts: Tuple[str, ...] = ("embedded",)
    modes: Tuple[str, ...] = ()
    requires: Tuple[str, ...] = ()
    capabilities: Tuple[str, ...] = ()
    commands: Tuple[str, ...] = ()


@dataclass(frozen=True)
class ModuleStatus:
    module_id: str
    enabled: bool
    active: bool
    reason: str = ""
    missing_capabilities: Tuple[str, ...] = ()


class ModuleRegistry:
    def __init__(self):
        self._modules: Dict[str, ModuleSpec] = {}
        self._callbacks: Dict[str, Tuple[Optional[Callable], Optional[Callable]]] = {}
        self._enabled: Dict[str, bool] = {}
        self._status: Dict[str, ModuleStatus] = {}

    def register(self, spec: ModuleSpec, *, on_activate=None, on_deactivate=None) -> None:
        if not spec.module_id:
            raise ValueError("module_id is required")
        self._modules[spec.module_id] = spec
        self._callbacks[spec.module_id] = (on_activate, on_deactivate)
        self._enabled.setdefault(spec.module_id, True)
        self._status.setdefault(spec.module_id, ModuleStatus(spec.module_id, True, False, "Not evaluated"))

    def get(self, module_id: str) -> Optional[ModuleSpec]:
        return self._modules.get(module_id)

    def unregister(self, module_id: str) -> None:
        self._modules.pop(module_id, None)
        self._callbacks.pop(module_id, None)
        self._enabled.pop(module_id, None)
        self._status.pop(module_id, None)


    def all(self) -> List[ModuleSpec]:
        return sorted(self._modules.values(), key=lambda s: (s.category, s.label))

    def status(self, module_id: str) -> ModuleStatus:
        return self._status.get(module_id, ModuleStatus(module_id, False, False, "Unknown module"))

    def statuses(self) -> List[ModuleStatus]:
        return [self.status(spec.module_id) for spec in self.all()]

    def set_enabled(self, module_id: str, enabled: bool) -> None:
        if module_id not in self._modules:
            raise KeyError(module_id)
        self._enabled[module_id] = bool(enabled)

    def refresh(self, context: ContextSnapshot, capabilities: CapabilitySnapshot):
        transitions = []
        cap_set = set(capabilities.available)
        for spec in self.all():
            enabled = self._enabled.get(spec.module_id, True)
            missing = tuple(sorted(c for c in spec.requires if c not in cap_set))
            host_ok = (not spec.hosts) or (context.host_id in spec.hosts)
            mode_ok = (not spec.modes) or (context.mode in spec.modes)
            if not enabled:
                active, reason = False, "Disabled"
            elif not host_ok:
                active, reason = False, f"Host {context.host_id} is not supported"
            elif missing:
                active, reason = False, "Missing: " + ", ".join(missing)
            elif not mode_ok:
                active, reason = False, f"Mode {context.mode} is not supported"
            else:
                active, reason = True, "Ready"

            previous = self._status.get(spec.module_id)
            current = ModuleStatus(spec.module_id, enabled, active, reason, missing)
            self._status[spec.module_id] = current
            was_active = bool(previous.active) if previous else False
            if was_active != active:
                event = "activated" if active else "deactivated"
                transitions.append((spec.module_id, event, reason))
                on_activate, on_deactivate = self._callbacks.get(spec.module_id, (None, None))
                callback = on_activate if active else on_deactivate
                if callback is not None:
                    try:
                        callback(context, current)
                    except Exception:
                        pass
        return transitions

    def clear(self) -> None:
        self._modules.clear()
        self._callbacks.clear()
        self._enabled.clear()
        self._status.clear()


class ServiceRegistry:
    """Core-owned service contracts shared across modules.

    A0.10 adds explicit provider ownership and consumer bindings.  Modules exchange
    behavior through stable service IDs instead of importing one another.  The
    registry can therefore protect a provider from unload while live consumers are
    still bound to one of its services.
    """

    def __init__(self):
        self._services: Dict[str, Any] = {}
        self._owners: Dict[str, str] = {}
        self._versions: Dict[str, str] = {}
        self._consumers: Dict[str, set] = {}

    def register(self, service_id: str, service: Any, *, owner: str = "", version: str = "1") -> None:
        if not service_id:
            raise ValueError("service_id is required")
        existing_owner = self._owners.get(service_id, "")
        if service_id in self._services and existing_owner and owner and existing_owner != owner:
            raise RuntimeError(f"Service already provided by {existing_owner}: {service_id}")
        self._services[service_id] = service
        self._owners[service_id] = str(owner or existing_owner or "core")
        self._versions[service_id] = str(version or "1")
        self._consumers.setdefault(service_id, set())

    def unregister(self, service_id: str, *, owner: Optional[str] = None) -> None:
        if service_id not in self._services:
            return
        current_owner = self._owners.get(service_id, "")
        if owner is not None and current_owner != owner:
            raise RuntimeError(f"Service {service_id} is owned by {current_owner}, not {owner}")
        consumers = sorted(self._consumers.get(service_id, set()))
        if consumers:
            raise RuntimeError(f"Service still has consumers: {service_id} <- {', '.join(consumers)}")
        self._services.pop(service_id, None)
        self._owners.pop(service_id, None)
        self._versions.pop(service_id, None)
        self._consumers.pop(service_id, None)

    def get(self, service_id: str, default=None):
        return self._services.get(service_id, default)

    def require(self, service_id: str):
        if service_id not in self._services:
            raise RuntimeError(f"Required service is unavailable: {service_id}")
        return self._services[service_id]

    def bind(self, service_id: str, consumer_id: str):
        service = self.require(service_id)
        consumer_id = str(consumer_id or "").strip()
        if consumer_id:
            self._consumers.setdefault(service_id, set()).add(consumer_id)
        return service

    def release_consumer(self, consumer_id: str) -> None:
        consumer_id = str(consumer_id or "")
        for consumers in self._consumers.values():
            consumers.discard(consumer_id)

    def owner_of(self, service_id: str) -> str:
        return self._owners.get(service_id, "")

    def version_of(self, service_id: str) -> str:
        return self._versions.get(service_id, "")

    def consumers_of(self, service_id: str) -> List[str]:
        return sorted(self._consumers.get(service_id, set()))

    def services_of_owner(self, owner: str) -> List[str]:
        return sorted(service_id for service_id, service_owner in self._owners.items() if service_owner == owner)

    def unregister_owner(self, owner: str) -> None:
        service_ids = self.services_of_owner(owner)
        blockers = {sid: self.consumers_of(sid) for sid in service_ids if self.consumers_of(sid)}
        if blockers:
            details = "; ".join(f"{sid} <- {', '.join(consumers)}" for sid, consumers in blockers.items())
            raise RuntimeError("Owned services still have consumers: " + details)
        for service_id in service_ids:
            self.unregister(service_id, owner=owner)

    def all_ids(self) -> List[str]:
        return sorted(self._services)


@dataclass
class EventRecord:
    topic: str
    payload: Any
    timestamp: float = field(default_factory=time.time)


class EventBus:
    def __init__(self):
        self._subscribers: Dict[str, List[Callable[[Any], None]]] = {}
        self._history: List[EventRecord] = []

    def subscribe(self, topic: str, fn: Callable[[Any], None]) -> Callable[[], None]:
        self._subscribers.setdefault(topic, []).append(fn)
        def unsubscribe():
            items = self._subscribers.get(topic, [])
            if fn in items:
                items.remove(fn)
        return unsubscribe

    def emit(self, topic: str, payload: Any = None) -> None:
        self._history.append(EventRecord(topic, payload))
        del self._history[:-40]
        for fn in tuple(self._subscribers.get(topic, ())):
            try:
                fn(payload)
            except Exception:
                pass

    def tail(self, count: int = 8) -> List[EventRecord]:
        return self._history[-max(0, int(count)):]


class StateStore:
    """Small namespaced state store used by modules, independent of UI hosts."""

    def __init__(self):
        self._data: Dict[str, Dict[str, Any]] = {}

    def namespace(self, module_id: str, defaults: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        bucket = self._data.setdefault(module_id, {})
        if defaults:
            for key, value in defaults.items():
                bucket.setdefault(key, value)
        return bucket

    def snapshot(self) -> Dict[str, Dict[str, Any]]:
        return {k: dict(v) for k, v in self._data.items()}

    def restore(self, snapshot: Dict[str, Dict[str, Any]], *, merge: bool = True) -> None:
        """Restore state in-place so module closures keep valid bucket references."""
        if not merge:
            for namespace in tuple(self._data):
                if namespace not in snapshot:
                    self._data.pop(namespace, None)
        for namespace, values in (snapshot or {}).items():
            if not isinstance(values, dict):
                continue
            bucket = self._data.setdefault(str(namespace), {})
            if not merge:
                bucket.clear()
            bucket.update(values)

    def clear_namespace(self, module_id: str) -> None:
        self._data.pop(str(module_id), None)
