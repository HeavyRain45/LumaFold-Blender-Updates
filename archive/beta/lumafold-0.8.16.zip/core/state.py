from dataclasses import dataclass, field
from typing import Optional


@dataclass
class RuntimeState:
    running: bool = False
    area_pointer: int = 0
    frames: int = 0
    last_error: str = ""
    capture_mouse: bool = False
    capture_keyboard: bool = False
    capture_text: bool = False
    runtime_ready: bool = False
    runtime_version: str = ""
    status: str = "Idle"
    host: Optional[object] = field(default=None, repr=False)
    host_mode: str = "embedded"
    window_pointer: int = 0


STATE = RuntimeState()
