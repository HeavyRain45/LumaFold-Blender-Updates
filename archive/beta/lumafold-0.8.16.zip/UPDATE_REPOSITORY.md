# LumaFold Online Update Contract

## Product promise

The first colleague-facing install should be the last manual install in normal use.
After the permanent LumaFold repository is configured once, later releases must
upgrade through Blender's native Extensions system without replacing the product
ID, losing user data, or requiring colleagues to repeat repository setup.

## Frozen identity

- Extension ID: `lumafold`
- Blender extension display name: `LumaFold Blender`
- Repository display name: `LumaFold`
- Primary platform today: `windows-x64`
- Current validated Blender baseline: `5.2.1 LTS`

The extension ID must never be changed for an ordinary product release. The
Blender-facing display name may change without creating a new extension identity.

## Ownership

- `services/update_service.py`
  - stable product ID
  - Stable/Beta channel policy
  - manifest version/capability metadata
  - persisted update-state schema
- `runtime/extension_repository.py`
  - the only owner of Blender Extension repository mutation
  - the only owner of `bpy.ops.extensions.*` sync/install calls
- `runtime/update_product.py`
  - user-facing update intents and product status
  - update metadata stored under Blender user CONFIG, never inside the installed extension
- Blender Extensions
  - network synchronization
  - package validation/download/install
  - extension enable/reload/update semantics

Host, Sculpt input, Satellite and asset modules must not download or replace
LumaFold code.

## Stable and Beta

Both channels use the same package ID `lumafold`.

- Stable: default for colleagues and production use
- Beta: internal validation channel

A channel is a repository policy, not a separate add-on installation.

## Distribution boundary

Private development repository:

- `HeavyRain45/LumaFold-Blender`

Planned public update-artifact repository:

- `HeavyRain45/LumaFold-Blender-Updates`

The public repository contains validated distributable extension packages and
Blender-generated repository indexes. It does not expose the private repository's
branches, issues, CI history or development credentials. Because LumaFold is a
Python add-on, the distributable package itself still contains executable Python
code and should not be treated as a source-code secrecy boundary.

Target GitHub Pages endpoints after the public repository exists and Pages has
been verified:

- Stable: `https://heavyrain45.github.io/LumaFold-Blender-Updates/stable/`
- Beta: `https://heavyrain45.github.io/LumaFold-Blender-Updates/beta/`

These target URLs are recorded in `services/update_service.py`, but production
client endpoints remain disabled until an end-to-end upgrade rehearsal succeeds.
No colleague build may be pointed at a repository that does not yet exist.

## Permanent endpoint rule

Once the Stable endpoint is activated, treat it like a public API. If hosting must
move later, keep the old endpoint alive long enough to serve a LumaFold release
that migrates the stored repository URL to the new endpoint.

Do not onboard colleagues against temporary raw GitHub URLs, private-repository
URLs, CI artifact URLs or expiring download links.

## User data rule

Extension code is disposable and may be replaced during an update. Durable user
state must live under Blender's user profile / LumaFold data locations. The update
state is stored at `CONFIG/lumafold/update_state.json` with an explicit schema
version so future migrations can be introduced without reinstalling the add-on.

## Release pipeline

`.github/workflows/release-extension.yml` uses Blender itself to:

1. resolve Stable or Beta channel
2. validate the extension manifest
3. build the extension ZIP
4. validate the built ZIP
5. generate a Blender-native repository index for the selected channel
6. upload a verified CI artifact
7. when `LUMAFOLD_UPDATES_TOKEN` is configured, clone the independent public
   update repository, add the new package without deleting older packages,
   regenerate that channel's full index, then publish to `main`

Tag-triggered `v*` releases resolve to Stable. Manual workflow runs may target
Beta or Stable explicitly.

Historical packages are retained in each channel. This matters once multiple
Blender versions are supported: publishing a package for a newer Blender release
must not erase the last package that is compatible with an older supported
Blender version.

## Compatibility policy

Repository packages carry Blender/platform compatibility from
`blender_manifest.toml`. New Blender versions are only advertised after real CI
coverage is added and all LumaFold gates pass on that version.

If Blender versions eventually require different package builds, the repository
may retain multiple version/platform-specific packages while users keep the same
repository and `lumafold` identity.

## One-time infrastructure activation

Before colleague rollout, the maintainer must perform these one-time actions:

1. create public repository `HeavyRain45/LumaFold-Blender-Updates`
2. enable GitHub Pages for its `main` branch
3. create a narrowly scoped token able to write only that update repository
4. store it in the private source repository as `LUMAFOLD_UPDATES_TOKEN`
5. publish a Beta package and verify `/beta/index.json`
6. rehearse a real Blender upgrade from one LumaFold version to the next
7. only then activate Stable/Beta URLs in `services/update_service.py`

After activation, ordinary colleagues should never need GitHub access or repeat
repository configuration for routine updates.
