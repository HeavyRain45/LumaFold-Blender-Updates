# Primary Surface Geometry Contract

Build baseline: `S0.8.4-dev79h · Primary Surface Geometry Authority`

## Purpose

`浮台 Embedded` and `卫星 Satellite` are two Hosts for the same Sculpt Primary View. They are not two layout implementations.

The UI rule is therefore:

> Product View owns geometry. Host only carries, positions and translates that geometry into its native coordinate space.

## Single owner

`ui/primary_surface_geometry.py` is the only authority for Quick Brush row-dependent Primary geometry.

It derives geometry only from shared UI tokens in `ui/layout_system.py`:

- `PRIMARY.outer_padding`
- `SCULPT_PRIMARY.min_content_w`
- `SCULPT_PRIMARY.quick_tile_min`
- `SCULPT_PRIMARY.grid_gap`
- 4 fixed Quick Brush columns

No Host may maintain its own row-height formula.

## Embedded calibration

Embedded renders the canonical shared View with Dear ImGui auto-size. The exact Embedded footprint at detach is passed to Satellite by `operators.py -> launch_satellite_host(...)`.

Satellite uses that already-valid footprint once, while hidden, to normalize a canonical two-row base height. This is calibration, not a second layout implementation.

After calibration, 2/3/4 rows are deterministic variants of one shared geometry contract.

## Satellite frame rule

A row change is committed at the start of the next native frame:

1. resolve the target row count;
2. resolve the target client size from the shared Primary geometry contract;
3. resize the native client area if necessary;
4. update the local row state;
5. begin the ImGui frame and render the new row count.

The visible Satellite must never render a new row count into an old client size and then compensate afterwards.

## Forbidden patterns

The Primary Satellite path must not contain:

- post-draw `get_content_region_avail()` height measurement for Host resizing;
- `row_delta` accumulated from current native height;
- Host-local Quick tile/row geometry formulas;
- Wrapper monkey-patching of `_queue_quick_rows` for sizing;
- repeated visible-frame autofit loops;
- independent Embedded/Satellite padding, row gap or Quick tile constants.

## Secondary Surfaces

This contract applies to the Primary Sculpt surface only. Brush Library, Alpha Library and More remain Secondary Surfaces and continue to use `secondary_surface_design_size(...)` / their existing shared Secondary contract.

## Regression rule

For the same width, UI scale and calibrated base:

- `2 -> 4 -> 2` must return to the exact same client size;
- `2 -> 3 -> 4` must be monotonic by exactly one shared row pitch;
- no size drift may accumulate from repeated switching;
- changing Quick rows must not trigger a post-render correction frame.
