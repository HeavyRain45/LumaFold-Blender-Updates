# S0.8.4-dev43 · Real-Machine Path Recovery — 验收记录

状态：**AUTO-PASS / REAL-MACHINE BLOCKER GATE REQUIRED**

## dev42 实机结论

用户实机确认：

- Embedded Secondary 点 Blender 空白关闭：通过；
- Embedded Secondary ESC 关闭：通过；
- Quick Brush 定向替换：失败；
- Satellite：未出现。

因此 dev42 被拒绝，不作为 Accepted Baseline。

## 本轮修正

### Quick Brush

不再依赖 `quick_replace_slot` 让后续 Runtime 猜测“这次 Brush 选择是不是替换”。

Embedded 现在执行显式产品事务：

`目标 Slot -> Brush Library -> 选择 Brush -> assign(identity, slot) -> clear target -> deferred native activate`

Runtime 同时保留 picker target latch，避免跨帧/Popup 清理造成目标丢失。

### Satellite

旧启动协议要求隐藏 HWND (`SW_HIDE`) 完成第一帧 WGL 后才发 READY。GitHub Runner 可以通过，但不同 Windows GPU/驱动不保证隐藏窗口首帧 WGL 行为一致。

dev43 改为：

`创建窗口 -> 移到 (-32000,-32000) -> SW_SHOWNOACTIVATE -> 完整 WGL/ImGui 首帧 -> READY -> Blender grant -> WM_APP_SHOW -> 移到真实目标位置`

用户屏幕不会看到预飞窗口，但 GPU 获得一个真实可见 HWND 完成首帧。

### Satellite 失败诊断

启动超时或 child 提前退出时，`runtime/satellite_handoff_stability.py` 会把 `%TEMP%/LumaFold/satellite_host_s07_2.log` 尾部写入 `STATE.last_error`，不再只返回“Satellite 没出现”。

## 自动 Gate

本轮自动验收已升级：

- Brush Gate 使用官方 Blender 5.2.1，执行被产品包装后的 `sculpt.brush.library_activate` 定向替换路径；
- Satellite Gate 不再 monkey-patch `launcher.vendor_dir()`；CI 依赖复制到 LumaFold 真正 `runtime.bootstrap.vendor_dir()` 后，再走 production launcher；
- Satellite Gate 验证预飞坐标为 off-screen，并在 lease grant 后移动到请求的屏幕坐标；
- 原 Architecture / Runtime / Secondary ownership / Satellite Broker 生命周期 Gate 保留。

## 实机 Blocker Gate

必须完整退出 Blender -> Pull -> 重启。

只先验证两个阻断点：

1. 确认版本 `S0.8.4-dev43 · Real-Machine Path Recovery`。
2. Embedded：从任意 Quick Brush Slot 图标打开 Brush Library，选一个明显不同的笔刷；该 Slot 必须立即替换。再换另一个 Slot 重复一次。
3. 点击 Satellite 一次；Satellite 必须直接出现，不允许靠重复切换恢复。

只有 2、3 都通过，才继续测试 Satellite ZBrush、N Sidebar/Header、Satellite -> Blender 第一下卡顿等后续 Runtime regression。

Phase C 与 Alpha Preview 继续暂停。
