# LumaFold 研发治理 / Development Governance

LumaFold 从本文件生效起采用“用户定义目标、项目团队负责正确实现”的开发模式。
用户只需要说明“想要什么效果”，不需要承担架构、程序或测试设计责任。

## 角色与最终责任

### 产品负责人 / Product Owner（用户）
- 定义目标、使用感受、优先级和不可接受的体验。
- 不要求提供技术方案。
- 对最终实机体验拥有最终决定权。

### 项目总监 / Project Director
- 把用户需求拆成可交付范围，控制 WIP，避免连续堆叠互相干扰的改动。
- 决定一个版本是否允许进入用户实机 Gate。
- 如果任一专业总监拒绝签字，版本不得交付。

### 架构总监 / Architecture Director
每个跨模块功能开发前必须回答：
1. 真正的 Source of Truth 是什么？
2. 谁拥有输入 / Popup / Host / Blender 状态？
3. UI draw、Blender Modal、Blender main-thread command、Satellite process 各自允许做什么？
4. 是否新增第二个权威来源、轮询正确性或 monkey patch 链？
5. Embedded / Satellite 是否共享同一业务语义？
6. register / unregister / Host migration 生命周期如何闭环？

硬规则：
- 一个领域只能有一个权威 owner。
- Blender Modal 可以通过已经建立的 Input Bridge 向现有 ImGui IO 投递键鼠输入，但不得在 Modal 中查询/遍历 ImGui Window 或 Popup 树，不得 begin/end/draw/render，不得创建/销毁 ImGui context，也不得执行 GPU/WGL 绘制或资源操作。
- Popup / Window truth 只能在有效 ImGui draw frame 内采样，再发布为纯 Python snapshot 给 Modal 读取。
- ImGui draw 只表达 UI 与提交 intent；改变 Blender 数据的操作必须进入安全 command/main-thread 边界。
- Host 正确性由 HostController transition 驱动；timer 只能做 watchdog，不能做 correctness source。
- 不允许为了修一个 bug 再增加一层同职责 wrapper，除非架构总监记录临时性、退出条件和删除版本。

### 程序总监 / Engineering Director
负责实现质量：
- 模块依赖方向清楚，不出现循环 ownership。
- 生命周期 register/unregister 对称。
- Blender API 只在允许线程和 context 中执行。
- defer/timer 有取消、generation 或 stale-request 保护。
- 不让异常观察者破坏核心状态机。
- 对性能敏感路径避免全量 snapshot、重复 preview decode、无意义高频 sync。
- 新代码必须通过 syntax + static contract + pure-Python state/behavior tests。

### UI 总监 / UI Director
负责 Native-first 与交互一致性：
- Blender 原生能力优先，LumaFold 做布局、组合与业务桥接。
- UI draw 不承担 Blender 业务状态变更。
- 一级/二级 Surface 的开关、ESC、outside click、焦点和 Selected/Hover 规则必须一致。
- Embedded / Satellite 的相同功能必须具有相同语义。
- UI 新功能不得破坏已有紧凑度、遮挡预算和中文/中英双语规则。

### 功能总监 / Functional Director
负责“用户说的效果是否真的实现”：
- 为每个需求写 Behavior Contract（前置条件 → 操作 → 唯一预期结果）。
- Quick Brush、Brush Library、Alpha、ZBrush Profile、Host migration 等高频链必须有固定回归合同。
- 功能不能只验证“按钮有反应”，必须验证最终 Blender truth。

### QA / 发布总监 / QA & Release Director
负责最终准入：
- 自动 Gate 全绿。
- 代码审查无 Blocker / Critical。
- 需要真实 Blender 图形/输入环境的场景进入 Real-machine Gate。
- Real-machine Gate 未通过时版本状态只能是 `REJECTED` 或 `HOLD`，不能声称“验收通过”。
- 通过后记录 Baseline，后续版本必须持续回归。

## 每个新需求的固定流程

1. **需求 Intake**：把用户自然语言转换成 Behavior Contract。
2. **Architecture Plan**：先画清数据流、状态 owner、host parity、线程/context、影响文件，不写功能代码。
3. **Director Review**：架构 / 程序 / UI / 功能四个视角先审设计；存在冲突先改设计。
4. **Implementation**：只实现批准范围。跨 Runtime 与 UI 的改动必须显式分层。
5. **Automated Gate**：compileall + static contracts + pure state/behavior tests。
6. **Code Acceptance**：各总监按职责审 diff，不通过就精准回到责任层修改，不跨层补丁。
7. **Real-machine Gate**：只测试自动化无法覆盖的 Blender 输入、GPU、Window、Tablet、Host migration。
8. **Release Baseline**：通过后冻结关键行为，更新回归矩阵，再进入下一功能。

## WIP 限制

- Runtime / Host / Input 稳定性未通过时，不同时推进 Alpha、Phase C、Pie Menu 等新功能。
- 同一版本最多一个“跨层架构变更主题”。
- 新功能可以批量开发，但前提是共享同一已批准架构且不会修改 Runtime ownership。
- 一旦出现进程崩溃、输入 ownership 回归或 Host lifecycle 回归，立即停止功能开发，回到架构 Gate。

## 长期不可破坏合同

### Runtime Safety
- Modal 仅允许通过稳定 Input Bridge 投递输入；禁止 Modal 查询 ImGui Popup/Window 状态、draw/render、context 生命周期和 GPU/WGL 资源操作。
- Popup truth 只在有效 draw frame 采样，Modal 只读纯 Python snapshot。
- Concrete Blender Region（N Sidebar/Header/Tool Header/HUD）永远优先于 Sculpt View 路由。

### Quick Brush
- 名称 LMB = 激活 Slot。
- Preview LMB = 打开 Brush Library 并锁定替换目标。
- Library 选择 = 写入目标 Slot + 激活目标 Slot + 清除目标。
- RMB = Slot menu。
- Popup ESC / outside click 只关闭当前 Secondary，不误触 Blender 后方内容。

### Host / Satellite
- Blender Mode/Workspace 是唯一 truth。
- HostController 是 Embedded/Satellite lease 唯一 truth。
- 进入 Satellite 后 ZBrush broker 第一时间可用，不依赖来回切换自愈。
- Satellite 轮询不得让 Blender 主线程反复复制完整资源库或 decode preview。
- Satellite 开启期间 Blender N Sidebar/Header 保持原生可操作。

## 验收状态定义

- `DESIGN`: 仅方案阶段。
- `IMPLEMENTED`: 已编码但未完成 Gate。
- `AUTO-PASS`: 自动 Gate 全绿，尚未通过 Blender 实机。
- `RC`: 自动 Gate + 总监代码审查通过，可交用户实机。
- `ACCEPTED`: 用户真实 Blender Gate 通过，成为新 Baseline。
- `HOLD`: 发现风险，停止继续堆功能。
- `REJECTED`: 验收失败，必须修复后重新进入完整 Gate。
