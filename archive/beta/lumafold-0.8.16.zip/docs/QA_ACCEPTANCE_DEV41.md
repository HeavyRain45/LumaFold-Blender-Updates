# S0.8.4-dev41 · Satellite Preflight Handoff — 验收记录

状态：**REJECTED / HOLD**

## 实机结论

dev41 未通过真实 Blender 5.2.1 Windows Gate，禁止作为稳定基线，也禁止在此基础上继续 Phase C / Alpha Preview。

用户实机确认三个发布阻断问题：

1. Embedded / 浮台：Quick Brush 打开 Brush Library 后仍不能通过真实鼠标点击完成笔刷选择/定向替换。
2. Embedded / 浮台：Secondary 点击 Blender 视图空白不能可靠自动关闭。
3. Satellite：点击 Host 切换后 Satellite 没有形成可见窗口。

此外，前序版本还出现过 Satellite 首次 ZBrush broker 失效、来回切 Host 后才自愈的问题，因此 Broker 生命周期也列入恢复版发布 Gate。

## 为什么旧 AUTO-PASS 无效

旧 dev41 自动验收覆盖不足：

- Brush 测试直接调用命令层，没有经过 `Blender Modal -> UIHost input -> ImGui Popup -> Brush tile` 真实输入链；
- Popup outside-click 只验证状态变量/静态规则，没有验证“事件先送达 ImGui、Blender 再决定 ownership”；
- Satellite Gate 只证明进程/READY，没有验证真实 WGL 首帧、生产 Launcher、Host generation、lease grant 后 Win32 可见窗口完整事务；
- Satellite ZBrush broker 没有独立 lifecycle Gate。

因此旧的“Architecture PASS / QA PASS”不能作为发布证据。

## dev41 后续处置

恢复线必须先建立并通过以下 Gate，才能生成下一 RC：

- Static Architecture Gate
- RuntimeSession / HostController Gate
- Embedded Secondary input ownership Gate
- Quick Brush command policy Gate
- Satellite Sculpt broker lifecycle Gate
- Windows native Satellite WGL first-render Gate
- 官方 Blender 5.2.1 Brush Asset / Quick Slot truth Gate
- 官方 Blender 5.2.1 -> production Launcher -> Bridge -> READY -> Lease Grant -> visible Satellite Gate

## 发布决定

**dev41 = REJECTED。**

后续恢复版必须使用新版本号，不能把 dev41 重新标记为通过。
