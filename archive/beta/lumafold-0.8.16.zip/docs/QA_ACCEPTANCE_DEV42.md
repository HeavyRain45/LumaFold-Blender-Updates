# S0.8.4-dev42 · Runtime Recovery RC — 验收记录

状态：**RC / INTERNAL MULTI-LAYER GATES REQUIRED / FINAL REAL-MACHINE COMPATIBILITY GATE**

## 恢复目标

dev42 不是功能开发版。Phase C 与 Alpha Preview 继续冻结。本版只恢复并锁定 dev41 实机失败的基础合同：

1. Embedded Quick Brush -> Brush Library 的真实点击必须到达 ImGui，并能完成目标 Slot 替换。
2. Embedded Secondary 的 outside-click / ESC 必须可靠关闭，且关闭点击不能穿透操作 Blender。
3. Satellite 必须走完整生产链真正显示，而不是只存在 PID / socket / READY。
4. Satellite 获得 Host 后必须立即建立当前 generation 的 Sculpt/ZBrush broker，不允许靠多次 Host 切换自愈。

## 架构总监 / Architecture Director

结论：**PASS，等待本 RC SHA 的最终 CI**

### Secondary 单一权威

- Blender Modal 不查询 ImGui popup/window tree；
- popup truth 只在 draw frame 内采样到 `RuntimeSession`；
- Popup 打开期间所有真实鼠标 PRESS/RELEASE 先进入既有 ImGui input bridge；
- Dear ImGui popup stack 是 inside/outside-click 的唯一判定者；
- Python 不再用估算 popup rect 生成第二套 outside-close；
- Blender 对 popup 鼠标事件统一 capture，避免“关菜单的一下同时转动/雕刻视图”；
- ESC 保留显式产品关闭请求，但执行仍回到 draw frame。

### Satellite 单一权威

正式协议固定为：

`launch hidden -> complete native WGL/ImGui frame -> READY -> Blender grants Host lease -> child observes satellite_active/owner -> WM_APP_SHOW`

READY 只证明隐藏 child 已成功完成真实首帧；只有 Lease Grant 后才允许显示。

`ui/sculpt_popup_state.py` 已退出 Satellite 正式入口；Satellite popup-open 状态只由共享 `sculpt_view` 发布。

## 程序总监 / Engineering Director

结论：**PASS，等待本 RC SHA 的最终 CI**

本恢复线没有修改冻结的 Sculpt gesture 核心、Preview 算法或 Asset Service。

产品侧主要变更集中在：

- `runtime/runtime_core.py`
- `desktop/satellite_host.py`
- `runtime/satellite_handoff_stability.py`

其余新增/修改主要为 QA Harness 与验收记录。

Quick Brush 业务层保持：

`target Slot -> Library click -> deferred command -> assign exact Slot -> activate exact Slot -> clear target`

真实 Blender 5.2.1 background integration Gate 已验证 64 个真实 Sculpt Brush Assets 可读取，并验证真实 asset activation + Quick Slot assignment/activation truth。

## Runtime & Integration Lead

结论：**PASS，等待本 RC SHA 的最终 CI**

新增 Satellite Sculpt broker lifecycle contract：

- Host transition 必须清 gesture registry；
- reset transient input；
- bump runtime generation；
- 清旧 `_RUNNING_SAT_WINDOWS`；
- 只有 `SATELLITE / owner=satellite` 才调度 fresh broker；
- `STATE.host_mode` 反映 Satellite 后，必须执行 `_ensure_satellite_brokers()`。

这专门防止“Satellite 第一次 ZBrush 失灵，切几次 Host 后才恢复”的历史回归。

## QA / 发布总监

本版必须同时通过以下自动 Gate，任何一项 FAIL 均不得交给用户：

### Architecture Gate
- Syntax compile
- Static architecture contracts
- RuntimeSession / HostController state tests
- Brush Library deferred command policy
- Embedded Secondary input ownership
- Satellite Sculpt broker lifecycle

### Windows / Blender Integration Gate
- Real Windows Satellite WGL process gate
- 官方 Blender 5.2.1 Brush + Quick Slot background integration gate
- 官方 Blender 5.2.1 -> production `desktop.launcher` -> bundled Python -> real Bridge -> hidden first-render READY -> lease grant -> visible Win32 Satellite gate

## 最终用户 Gate

只有本 RC SHA 的内部 Gate 全部 PASS 后才允许执行。

用户不再负责广泛找 bug，只做以下兼容/体验确认：

1. 完整退出 Blender -> Pull -> 启动，确认 `S0.8.4-dev42 · Runtime Recovery RC`。
2. Embedded：点击一个 Quick Brush 图标打开 Brush Library，选一个新 Brush，确认准确替换原 Slot；换 3 个 Slot 重复。
3. Embedded Secondary：点 3D View 空白关闭；ESC 关闭；菜单内部点击正常，不被 dismissal 吃掉。
4. Satellite：点击一次必须出现；无需来回切换 Host。
5. Satellite：第一次 ZBrush 视图/雕刻输入立即可用。
6. Satellite 开启时 Blender N Sidebar / Header 仍可操作。
7. Satellite 操作后立即回 Blender 旋转/缩放/雕刻，确认首一下无异常卡顿。

只有这 7 项通过，dev42 才能标记 **ACCEPTED BASELINE**。之后才允许恢复 Alpha Preview，再讨论 Phase C。
