# dev75 · Sculpt Pointer Ownership Boundary

Plain LMB ownership is now explicit and host-independent:

- Active Sculpt surface: Blender native Sculpt owns the original pointer press.
- Confirmed empty View3D: Blender native Rotate owns the full navigation lifecycle.
- Unknown hit classification: Blender Sculpt wins; LumaFold never converts uncertainty into Rotate.
- Ctrl/Alt and other LumaFold-specific modifier gestures remain in the transient gesture layer.

The pointer classifier is read-only. It does not execute strokes, rotate the view, mutate Host state, or keep gesture/session state.

This boundary is intentionally shared by Embedded and Satellite. Host switching cannot change plain-LMB ownership policy.
