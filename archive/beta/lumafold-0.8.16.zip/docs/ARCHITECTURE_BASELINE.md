# LumaFold Architecture Baseline

Status: S0.8.4-dev79 baseline for Blender 5.2.1 LTS / Windows.

This document is the default architectural rule for new LumaFold work. The goal is not to maximize the number of modules; it is to keep one authoritative owner per concern and delegate to Blender whenever Blender already owns the behavior reliably.

## 1. Native-first rule

LumaFold must not duplicate Blender behavior merely to make it look internally consistent.

- Blender owns Workspace, Mode, active object and live event context truth.
- Blender owns ordinary Sculpt stroke lifecycle.
- Blender owns ordinary View3D Rotate lifecycle.
- Plain LMB Sculpt-vs-background arbitration uses Blender `SCULPT_OT_brush_stroke(ignore_background_click=True)`. Only Blender's explicit `PASS_THROUGH` may promote that same press to native Rotate.
- ZBrush-style extensions must delegate mutation back to Blender operators whenever Blender exposes the required operation.
- LumaFold may implement custom behavior only when it represents a deliberate product feature Blender does not directly provide with the required interaction semantics.

## 2. Single-owner matrix

| Concern | Authoritative owner | Rule |
| --- | --- | --- |
| Host Embedded/Satellite lease | `core.host_control.HOST_CONTROL` | No other module owns Host migration state. |
| Embedded popup/modal bridge | `runtime.runtime_core` | Modal reads pure Python popup snapshots; ImGui popup truth is sampled only in draw frames. |
| Blender-window Sculpt input session | `runtime.sculpt_input_core` | One long-lived broker per Blender Window. Embedded/Satellite never switch modal owners. |
| Input activity admission | `runtime.sculpt_input_core` + `HOST_CONTROL` lease | Satellite activity never depends on `STATE.running`; Host lease is authoritative. |
| Event route truth | `runtime.sculpt_route_truth` injected through `set_route_handler` | Uses the current modal event context, not global `bpy.context`, for Sculpt admission. |
| View3D region resolution | `runtime.runtime_core` policy injected through `set_view3d_region_resolver` | Concrete Blender UI regions win over Sculpt viewport routing. |
| Plain LMB Sculpt vs Rotate | `runtime.sculpt_native_pointer` + Blender operators | No LumaFold surface raycast classifier. |
| Ordinary View3D rotation | Blender `VIEW3D_OT_rotate` | LumaFold owns no rotation quaternion, axis-snap state, Rotate keymap mutation, or rotate timer/session. |
| Native navigation adapter | `runtime.sculpt_navigation` injected through `set_navigation_handler` | Stateless handoff only; no camera/session ownership. |
| Alt reverse sculpt / pan-to-zoom / object transfer | `runtime.sculpt_alt_gesture` | Strict current-event Alt truth. No grace timer may arm a later gesture. Inverse Sculpt, object transfer and zoom mutation use Blender operators. |
| Surface Ctrl tap/drag mask semantics | `runtime.sculpt_mask_surface_gesture` | Ctrl tap = native Smooth Mask, Ctrl+Alt tap = native Sharpen Mask; surface drag hands off to native Mask stroke. |
| Background Ctrl box-mask compatibility | legacy transient in `runtime.sculpt_input_core` | Frozen compatibility seam only. It must be migrated or deleted before it is extended with new behavior. |
| Tablet multi-monitor diagnostics | `runtime.tablet_pointer_locality` via `runtime.satellite_input_probe` | Read-only Windows cursor/window/monitor observation. Never warp, clip, capture, or remap the OS pointer. |
| Input telemetry | `runtime.satellite_input_probe` injected through `set_input_observer` | Observe only; never wrap broker modal or alter results. |
| Quick Brush command/state | Quick Brush product + public command layer | UI emits commands and reads state; it does not own brush lifecycle. |
| Blender -> Store brush/alpha sync | `SculptResourceSyncService` and resource services | Bridge snapshots must not synchronize Blender resources. |
| Satellite transport snapshot | `runtime.satellite_bridge_authority` / desktop transport | Store transport only; bounded preview payload. |
| Alpha external linked sources | `AlphaSourceStore` | Never destructive to external files. |
| LumaFold-managed Alpha filesystem | `AlphaManagedStore` | The only owner allowed to mutate managed Alpha files/folders. |
| Canonical Alpha library composition | `BlenderAlphaLinkedProduct` | Merges managed and linked sources into the product library. |
| Alpha mutation revision publication | `runtime.alpha_library_revision` | Publish a complete library revision after actual mutation completion. |
| UI composition | `ui/*` product/foundation modules | UI renders state and emits commands; no hidden filesystem/Host/input ownership. |

## 3. Forbidden architecture patterns

New work must not introduce:

1. A second Host state machine beside `HOST_CONTROL`.
2. A second long-lived Sculpt input broker for Embedded vs Satellite.
3. Runtime mutation of Blender `View3D Rotate Modal` keymaps.
4. Direct writes to `RegionView3D.view_rotation` for ordinary navigation.
5. A custom plain-LMB mesh hit-test used to choose Sculpt vs Rotate.
6. Blender resource synchronization inside Satellite `get_state` snapshot handling.
7. ImGui popup/window queries from Blender modal/input code.
8. Command ACKs that replace a complete Secondary state snapshot.
9. External Alpha deletion through the LumaFold-managed filesystem service.
10. A new wrapper/monkey patch around the universal input broker, route handler, navigation handler, input observer, or View3D region resolver when an explicit dependency slot exists.
11. Alt grace/timestamp state that can arm a new pen gesture after Alt is physically released.
12. Windows pointer mutation (`SetCursorPos`, `ClipCursor`, capture hacks) for tablet multi-monitor behavior without a proven OS-level requirement.
13. Reusing mask-only raycasts to arbitrate ordinary Sculpt versus Rotate.

## 4. Dependency direction

Preferred direction:

`UI -> public command / Store snapshot -> product/service -> Blender`

`Blender event -> sculpt_input_core broker -> route authority -> native Blender operator OR isolated LumaFold gesture`

`modifier gesture -> one gesture module -> Blender operator/native data mutation`

`Blender resource truth -> sync service -> Store -> Embedded/Satellite presentation`

Host/UI/transport layers must not reach backward to become resource owners.

## 5. Remaining compatibility seams

The input stack no longer depends on the historical activity/session/route/probe patch chain. Its runtime dependencies are explicit callback slots on `sculpt_input_core`.

The dev79 gesture foundation deliberately leaves one older seam frozen: background Ctrl box-mask behavior still lives in the legacy transient operator. New Alt and surface-mask behavior must not be added there. That seam should be extracted when the visibility/mask gesture phase is implemented, then the dead legacy Alt branch can be physically removed.

A few older integration seams also remain intentionally frozen because they are stable and outside the current risk area, notably Runtime Core's UIHost popup bridge and some compatibility command aliases. When these seams are touched by future feature work, migrate toward explicit callbacks/public commands instead of layering another wrapper on top.

Rules for remaining seams:

- one production owner per concern;
- install/uninstall symmetry covered by CI;
- no new wrapper around an already wrapped method;
- prefer public command or explicit dependency injection;
- cleanup must be behavior-preserving unless the feature explicitly changes product semantics.

## 6. Intentional custom exceptions

Native-first does not mean "never custom". Current justified exceptions include the ZBrush Alt pan-to-zoom gesture transition, background mask rectangle preview, popup transport between Blender and the native Satellite window, and the compact floating presentation itself.

A custom exception must be:

- isolated behind one module boundary;
- unable to mutate unrelated Blender global state;
- covered by a regression contract;
- removable without changing neighboring ownership domains.

Custom mask hit-testing is allowed only for mask semantics. It must never be reused to arbitrate ordinary Sculpt versus Rotate.

## 7. Definition of ready for new features

Before adding a new feature, identify:

1. What is the source of truth?
2. Which one module/service owns mutation?
3. Can Blender provide the behavior natively?
4. What public command/state contract does UI use?
5. Does the feature add a new long-lived modal/timer/watchdog? If yes, why is an existing owner insufficient?
6. What CI contract prevents a second owner from appearing later?
7. Does it require wrapping an existing runtime method? If yes, redesign the dependency first.
8. Is the feature observational only? If yes, prove it cannot mutate Host/input/OS pointer state.

If these questions do not have clear answers, architecture work comes before product code.
