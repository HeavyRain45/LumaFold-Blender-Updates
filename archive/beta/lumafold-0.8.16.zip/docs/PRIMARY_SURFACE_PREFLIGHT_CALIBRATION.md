# Primary Surface Preflight Calibration

Satellite Primary geometry has two distinct phases:

1. **Preflight calibration** — before the Satellite becomes user-visible, render the shared Primary View once and measure the View's actual content extent. This establishes the canonical two-row base height in design units.
2. **Steady-state geometry** — once calibrated, all 2/3/4-row variants are produced only by `ui.primary_surface_geometry`; no visible-frame measurement or incremental native resize heuristics are allowed.

The launch window size is transport/spawn geometry only. It is not a geometry truth source.

This prevents stale or oversized Embedded transfer measurements from becoming the permanent Satellite base height while preserving deterministic, non-flashing row changes after the Satellite is visible.
