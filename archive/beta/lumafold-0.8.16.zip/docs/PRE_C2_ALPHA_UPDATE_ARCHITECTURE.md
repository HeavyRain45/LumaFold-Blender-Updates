# Pre-C2 · Alpha Library 2.0 + Online Update Architecture

状态：**DESIGN / APPROVED FOR IMPLEMENTATION**

基线：`S0.8.4-dev54` / `1ad07974a458432fe6452c4da5e6441f7c663932`

Phase C 状态：**HOLD**。C2 实验已封存到 `phase-c-hold-c2-20260913`，本阶段不得修改 Host / Satellite / Input ownership。

## 目标

在进入 Phase C 之前先补齐两项产品基础设施：

1. Alpha Library 2.0：可靠缩略图、本地文件夹链接、文件夹移除、Alpha 右键移除；
2. LumaFold Online Update：为后续同事使用建立可维护、可回滚的 Blender Native 更新通道。

两项必须独立开发、独立 Gate、独立 RC，不允许同一版本同时改 Alpha 资产模型与更新安装机制。

---

# P1 · Alpha Library 2.0

## Source of Truth

Alpha 真值仍由实际图片文件 + Blender Image/Texture/Brush 状态持有。

LumaFold 只维护“来源注册信息”和“显示偏好”，不复制一份 Alpha 图像数据库。

来源分三类：

- `managed`：LumaFold 用户 Alpha 目录，现有“导入文件并复制”能力继续保留；
- `linked`：用户新增的任意本地文件夹，只登记路径，不复制文件；
- `runtime/read-only`：当前 .blend 已加载图片、测试种子等现有来源。

## 本地文件夹 Registry

新增唯一 owner：`alpha.source_registry`。

持久化字段只允许保存：

- stable source id；
- 规范化绝对路径；
- 显示名（默认取实际文件夹 basename）；
- source type；
- enabled / missing 状态；
- per-source hidden Alpha identities。

不得把目录扫描结果整包写入持久化状态。

### 添加文件夹

左侧文件夹区 `+`：打开 Blender 原生目录选择器。

选择后：

1. 记录真实目录路径；
2. 左侧显示真实文件夹名；
3. 扫描该目录中的支持图片；
4. 右侧只显示该来源的 Alpha；
5. 不复制、不移动、不修改源文件。

目录可以包含子目录；扫描允许递归，但 UI 第一版把“用户添加的根目录”作为一个来源，不自动生成无限层级树。

### 移除文件夹

左侧 `-` 只对 `linked` 来源启用。

行为：

- 从 LumaFold Registry 删除该来源；
- 清理该来源的运行时缓存；
- **绝不删除、移动或改名本地目录和其中任何文件**；
- 当前激活 Alpha 若来自该目录，不强行清除 Blender 当前 Texture，只是后续库中不再列出。

`managed` / Blender runtime / readonly 来源不能被 `-` 当成本地目录删除。

## Alpha 右键移除

安全优先，第一版不提供“直接永久删除外部素材文件”。

右键菜单：

- 收藏 / 取消收藏；
- `从 LumaFold 中移除`：对 linked Alpha 写入 source-local hidden identity，文件仍留在磁盘；
- `恢复已隐藏 Alpha`：通过文件夹级菜单或管理入口恢复；
- managed Alpha 后续可增加 `删除 LumaFold 副本…`，必须二次确认，而且只能删除 LumaFold-owned copy，不能追溯删除原始导入源。

## 缩略图

现有 UI 已具备 preview tile 与 `alpha_library_preview_cache`，现有 Blender service 也已具备 `alpha_previews(...)` 路径；本阶段不重写 Secondary Surface。

改造重点：

1. `AlphaPreviewOwner` 只负责 `identity -> preview payload`；
2. UI draw 只请求可见 tile，不直接读磁盘、不调用 `bpy.data.images.load`；
3. 使用现有 preview scheduler + disk cache；
4. 文件缩略图 cache key 必须至少包含：规范化路径 + size + mtime_ns + preview format revision；
5. 文件变化后只使对应缩略图失效，不清空整个库；
6. linked folder 首次打开允许逐批出现缩略图，不能阻塞 Host/Input；
7. Embedded / Satellite 使用相同 preview payload，Satellite 不重复扫描本地文件系统。

当前库 UI 的 8 列 tile 几何、Secondary 生命周期、ESC/outside click 合同全部冻结。

## UI Contract

左侧：

- 全部
- 收藏
- 文件夹列表（真实 basename）
- 底部来源工具栏

底部工具栏最终至少保留：

- 添加本地文件夹；
- 移除当前 linked 文件夹；
- 现有“导入 Alpha 文件到 LumaFold 用户库”能力必须保留，但 UI Director 可调整其入口，不能因为新增 linked folder 而删除旧能力。

右侧：

- 搜索；
- 当前范围计数；
- 8 列真实缩略图；
- 左键激活；
- 右键资产菜单。

## P1 QA Gate

自动合同至少覆盖：

- 添加 linked folder 后显示真实 basename；
- 同一路径重复添加幂等；
- 不存在目录显示 missing，不自动删除 Registry；
- 移除 linked folder 后目录和全部文件 byte-for-byte 保留；
- 右键移除 linked Alpha 后源文件保留且刷新后不重新出现；
- 恢复隐藏后重新出现；
- supported image extensions 延续 BlenderAlphaService.IMAGE_EXTS；
- preview key 随文件 size/mtime 变化而失效；
- 预览生成不发生在 UI draw；
- dev54 Quick Brush / Embedded Secondary / Satellite / ESC / first-action regression gates 全部继续执行。

Real Blender Gate 使用临时目录创建真实 PNG fixture：注册 -> 扫描 -> 生成 preview -> 激活 -> 移除来源，并最终断言源目录与文件仍存在。

---

# P2 · LumaFold Online Update

## 决策

**不做“插件自己下载 ZIP 后覆盖自己的 Python 文件”的自更新器。**

正式方案使用 Blender 5.2 Extensions 原生 Remote Repository / Update 机制。LumaFold 可以提供自己的更新入口和状态显示，但安装、版本替换与仓库管理交给 Blender Extension System。

原因：

- 避免运行中的插件覆盖自身文件；
- 避免 Host/Modal 尚未 unregister 时替换代码；
- 使用 Blender 自带版本/平台/manifest 校验；
- 同事端可以直接使用 Blender 的检查更新与 Update All；
- 更容易回滚到上一发布包。

## Release Pipeline

发布源与开发源分离：

- `dev`：开发；
- Stable Release：只有 QA + 实机 ACCEPTED 后才能发布；
- 可选 Beta Channel：仅用户本人/测试者使用。

GitHub Actions 发布阶段：

1. 校验 `blender_manifest.toml`；
2. `blender --command extension validate`；
3. `blender --command extension build` 生成 zip；
4. 运行完整 LumaFold Quality Gate；
5. 生成/更新 Blender static extension repository `index.json`；
6. 发布 zip + index；
7. Stable 指针只指向 ACCEPTED build。

## Version Authority

在线更新接入前必须解决当前版本号分裂问题。

唯一 Release Version 由 manifest 持有，例如 `0.8.4`；`core/build_info.py` 保留 `dev54 / RC / build label` 作为工程构建标识。

CI 必须检查：

- Manifest Release Version；
- build_info release version；
- package filename；
- repository index version；

四者不允许发布时不一致。

## User Data Safety

更新包只替换扩展安装目录。

以下数据必须继续位于 Blender user profile / cache，不放在扩展包目录：

- Alpha linked-folder Registry；
- Favorites；
- Quick Brush 用户状态；
- 用户 Alpha managed library；
- preview cache；
- LumaFold durable state。

因此插件更新不得导致同事的 Alpha 文件夹、收藏、快捷笔刷等被重置。

## Network Contract

- 遵守 `bpy.app.online_access`；
- 不在后台偷偷上传用户信息；
- 更新检查只访问配置的 extension repository；
- private/internal repository 所需 token 由 Blender Repository 设置保存，LumaFold 代码中不得硬编码 PAT/token。

## 推荐部署

优先使用 Blender Static Extensions Repository。

团队在同一网络/VPN：可直接把 repository 放公司共享目录或内部 HTTP/NAS 服务。

跨网络：使用 HTTPS static repository；认证交给服务器/Blender repository token，不把 GitHub 私有 token 打进插件。

---

# WIP / 防回归规则

顺序固定：

1. A0 Alpha Source Registry + persistence contract；
2. A1 linked folder service + no-delete Gate；
3. A2 thumbnail owner/cache invalidation；
4. A3 Alpha UI folder add/remove + right-click remove；
5. A4 Embedded + Satellite + Real Blender RC Gate；
6. U0 version authority；
7. U1 extension build/repository pipeline；
8. U2 clean-install/update/rollback Gate；
9. 用户集中实机验收；
10. Alpha/Updater 成为新 ACCEPTED BASELINE；
11. 恢复 Phase C。

本阶段禁止主动修改：

- HostController ownership；
- Satellite input / activation policy；
- Secondary close/ESC/outside-click lifecycle；
- Quick Brush target-slot transaction；
- ZBrush navigation/input profile。

任何一条 dev54 frozen regression 失败，版本立即 HOLD，不能通过“顺手修 Host”继续向前堆功能。
