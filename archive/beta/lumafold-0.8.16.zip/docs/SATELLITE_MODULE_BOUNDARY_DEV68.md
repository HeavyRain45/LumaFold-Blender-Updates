# S0.8.4-dev68 Satellite Module Boundary

## Goal

Remove duplicate ownership from Satellite input lifecycle and Blender-native UI requests.

## Ownership rules

### 1. Satellite input broker

- One persistent broker instance per Blender Window.
- Broker lifetime follows Blender Window / addon registration, **not** Embedded/Satellite toggles.
- Host transitions only reset transient gesture/input state.
- The broker returns `PASS_THROUGH` while Host is not Satellite.
- No Host transition is allowed to clear the broker registry, bump a broker generation, or launch a second broker.

### 2. Blender native UI requests

- `blender.ui_requests` is the sole owner of deferred native Blender operator invocation.
- Callers provide only an operator id and optional status target; they do not resolve Window/Area/Region themselves.
- Alpha `source_add_dialog` and legacy/product alias `library_import_dialog` both route to the same native `lumafold.add_alpha_folder` operator.
- Satellite/Secondary never invokes Blender operators directly.

## Frozen contracts

This change does not redesign Host lease, child visible-ready, Secondary ESC, Quick Brush, Alpha library data ownership, or UI presentation.
