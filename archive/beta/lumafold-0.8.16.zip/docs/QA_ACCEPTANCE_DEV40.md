# S0.8.4-dev40 · Runtime Core Rebuild — 验收记录

状态：**REJECTED / Real-machine Gate Failed**

## 实机结论

dev40 自动 Gate 与代码审查通过，但真实 Blender 5.2.1 Windows 测试失败：

- 点击浮台上的 Satellite 按钮后，Embedded 浮窗直接消失；
- Satellite Host 未形成用户可见、可确认的接管结果。

因此 dev40 **不得成为 Runtime Baseline**，也不得继续叠加 Alpha Preview / Phase C / Pie Menu 等新功能。

## 根因归属

这是 Host migration 协议问题，不是普通按钮问题。

原协议把 `satellite_ready` 当成“可以立即关闭 Embedded”的最终条件。但 `satellite_ready` 实际只证明：

- Satellite 子进程已启动；
- Bridge/网络线程已连通；
- WGL/ImGui 初始化流程已经走到可发送 ready 的位置。

它**不能证明 Satellite 已经成功运行首批 draw frame 并具备稳定展示能力**。

所以存在错误顺序：

`Satellite READY -> 立即关闭 Embedded -> grant Satellite -> Satellite 再尝试真实展示`

如果 Satellite 在 ready 之后的首帧/显示阶段失败，用户就会看到“浮窗直接消失”。

## 总监结论

- 项目总监：**REJECTED** — 停止新功能开发。
- 架构总监：**REJECTED** — Host handoff 缺少可展示前的 preflight gate。
- 程序总监：自动测试通过，但覆盖范围不足以证明 native Satellite presentation。
- UI 总监：Embedded -> Satellite 交接体验不满足“不可出现空窗期/失去 Host”。
- 功能总监：Satellite 功能最终效果未实现。
- QA / 发布总监：**Real-machine Gate FAIL**。

## 后续修复方向

进入 `S0.8.4-dev41 · Satellite Preflight Handoff`：

`启动 Satellite -> READY -> Embedded 保持 -> 隐藏 Host 预飞并持续存活 -> 才允许真正 Lease handoff`

如果 Satellite 在 READY 后预飞阶段死亡，原 Embedded 必须保留，不得先关闭。

只有 dev41 通过新的自动 Gate + Blender 实机 Satellite Gate，才允许重新进入 RC / ACCEPTED 流程。
