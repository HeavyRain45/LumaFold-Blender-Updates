# Current build: S0.7.3 — Window-Level Input Router

# LumaFold Module SDK v1

> A1.0 frozen public module contract. Core implementation details may evolve, but breaking public changes require an explicit Core API / SDK version decision.

- Contract fingerprint: `41387f8b9c0c6715`
- Core API: `1`
- Package format: `1`
- SDK contract: `1.0`

## Public App Hooks
- `register_module`
- `register_state_schema`
- `provide_service`
- `require_service`
- `execute`
- `refresh_context`

## Manifest Fields
- `id`
- `name`
- `version`
- `category`
- `entry`
- `api_version`
- `package_format`
- `hosts`
- `description`
- `self_test`
- `blender_min`
- `blender_max`
- `requires_modules`
- `provides_services`
- `requires_services`
- `permissions`

## Core Services
- `blender.context`
- `blender.object`
- `blender.mode`

## Context / Capability IDs
- `object.active`
- `object.mesh`
- `mode.object`
- `mode.sculpt`
- `mode.edit_mesh`
- `host.embedded`
- `host.satellite`
- `host.desktop`

## Hosts
- `embedded`
- `satellite`
- `desktop`

## Permissions
- `blender.read`
- `blender.write`
- `clipboard`
- `files.read`
- `files.write`
- `network`
- `process.launch`

## Required Module Rules

1. Business modules register through the public App hooks and do not depend on Core implementation modules.
2. Cross-module features are requested through Service Contract IDs; consumers do not import providers.
3. Blender mutations are routed through Commands/Services. Background workers must not touch Blender data.
4. Durable settings live in module State namespaces and declare a schema version/migrations.
5. External modules declare permissions in the manifest and pass compatibility/trust gates before execution.
6. UI state is host-independent. Embedded, Satellite and Desktop hosts consume the same Core state.
7. A public-contract change requires a Core API / SDK contract version decision; silent breaking changes are forbidden.

## Package Skeleton

```text
my_module/
├─ manifest.toml
└─ module.py
```

The package entry exposes `register(app)`. Use `MODULE_MANIFEST` for built-in modules or `manifest.toml` for external packages.
