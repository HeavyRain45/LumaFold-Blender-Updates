from __future__ import annotations

"""Product Brush preview bridge for Blender 5.2/5.3.

Blender ``ImagePreview.image_pixels`` / ``icon_pixels`` are arrays of packed
32-bit pixels (one integer per pixel), while ``*_pixels_float`` exposes the same
memory as explicit RGBA components.  Real-machine probing on Blender 5.2.1
confirmed 32x32 previews contain 1024 packed values.

For product fidelity we prefer Blender's explicit ``*_pixels_float`` view and
only retain packed/native-endian decoding as a compatibility fallback.  Blender's
own icon renderer also documents PreviewImage data as premultiplied-alpha and
uses premultiplied blending. LumaFold's shared ImGui renderers use straight-alpha
blending, so Brush previews are un-premultiplied once before transport. Preview
rows are vertically flipped once as well because Blender's PreviewImage bitmap
row origin is opposite the ImGui texture convention used by LumaFold.

The resulting artwork still comes exclusively from Blender's Brush Asset
preview. No LumaFold-authored replacement artwork is generated.
"""

import base64
import sys
from pathlib import Path

from .blender_compat53 import BlenderBrushServiceCompat


class BlenderBrushServiceProduct(BlenderBrushServiceCompat):
    """Brush service with Blender-faithful PreviewImage decode + fallbacks."""

    def __init__(self):
        super().__init__()
        self._preview_spec_cache = {}
        self._last_preview_path = ""
        self._thumbnail_hits = 0
        self._thumbnail_misses = 0
        self._packed_decode_hits = 0
        self._float_decode_hits = 0
        self._premul_normalize_hits = 0

    @staticmethod
    def _flip_rgba_rows(raw: bytes, width: int, height: int) -> bytes:
        stride = int(width) * 4
        if stride <= 0 or int(height) <= 1 or len(raw) != stride * int(height):
            return bytes(raw)
        return b"".join(
            raw[row * stride:(row + 1) * stride]
            for row in range(int(height) - 1, -1, -1)
        )

    def _straight_alpha_rgba(self, raw: bytes) -> bytes:
        """Convert Blender PreviewImage premultiplied RGBA to straight RGBA8.

        Blender draws PreviewImage with premultiplied-alpha blending. Our shared
        ImGui renderers intentionally use ordinary straight-alpha blending for
        every UI texture, so normalize only these Brush preview pixels at the
        service boundary instead of changing global renderer blend state.
        """
        if not raw:
            return b""
        out = bytearray(raw)
        changed = False
        for start in range(0, len(out), 4):
            alpha = int(out[start + 3])
            if alpha <= 0:
                if out[start] or out[start + 1] or out[start + 2]:
                    changed = True
                out[start] = out[start + 1] = out[start + 2] = 0
                continue
            if alpha >= 255:
                continue
            changed = True
            half = alpha // 2
            out[start] = min(255, (int(out[start]) * 255 + half) // alpha)
            out[start + 1] = min(255, (int(out[start + 1]) * 255 + half) // alpha)
            out[start + 2] = min(255, (int(out[start + 2]) * 255 + half) // alpha)
        if changed:
            self._premul_normalize_hits += 1
        return bytes(out)

    def _read_preview_plane(self, preview, size_name: str, pixels_name: str, max_edge: int = 64):
        """Return (width, height, straight top-down RGBA8, storage_kind)."""
        if preview is None:
            return 0, 0, b"", ""
        try:
            size = tuple(getattr(preview, size_name) or (0, 0))
            width, height = int(size[0]), int(size[1])
            if width <= 0 or height <= 0:
                return 0, 0, b"", ""
            pixel_count = width * height
            raw = b""
            storage = ""

            # Blender RNA exposes an explicit float component view whose source
            # implementation reads the PreviewImage byte buffer as uchar RGBA.
            # Prefer this over host-endian integer unpacking whenever available.
            float_name = f"{pixels_name}_float"
            try:
                float_pixels = getattr(preview, float_name)
            except Exception:
                float_pixels = None
            if float_pixels is not None:
                try:
                    if len(float_pixels) == pixel_count * 4:
                        raw = bytes(
                            max(0, min(255, int(round(float(value) * 255.0))))
                            for value in float_pixels
                        )
                        storage = "rgba_float"
                        self._float_decode_hits += 1
                except Exception:
                    raw = b""
                    storage = ""

            if not raw:
                pixels = getattr(preview, pixels_name)
                item_count = len(pixels)

                # Blender 5.2 observed behavior: one uint32 per pixel. memcpy in
                # Blender RNA preserves the native byte layout of PreviewImage.
                if item_count == pixel_count:
                    packed_raw = bytearray(pixel_count * 4)
                    for index, packed in enumerate(pixels):
                        start = index * 4
                        packed_raw[start:start + 4] = (int(packed) & 0xFFFFFFFF).to_bytes(
                            4, byteorder=sys.byteorder, signed=False
                        )
                    raw = bytes(packed_raw)
                    storage = "packed32"
                    self._packed_decode_hits += 1

                # Compatibility guard for builds that expose flattened channels.
                elif item_count == pixel_count * 4:
                    raw = bytes((int(value) & 0xFF) for value in pixels)
                    storage = "rgba8"

            if not raw:
                return 0, 0, b"", ""

            raw = self._straight_alpha_rgba(raw)
            raw = self._flip_rgba_rows(raw, width, height)
            out_w, out_h, out = self._downsample_rgba(
                raw, width, height, max_edge=max_edge
            )
            return out_w, out_h, out, storage + "+straight+flip_y"
        except Exception:
            return 0, 0, b"", ""

    def _image_preview_payload(self, preview, max_edge: int = 64):
        """Convert a Blender ImagePreview into LumaFold's JSON-ready RGBA payload."""
        if preview is None:
            return {}

        width, height, raw, storage = self._read_preview_plane(
            preview, "image_size", "image_pixels", max_edge=max_edge
        )
        source = "thumbnail_image"
        if not raw:
            width, height, raw, storage = self._read_preview_plane(
                preview, "icon_size", "icon_pixels", max_edge=max_edge
            )
            source = "thumbnail_icon"
        if not raw:
            return {}
        return {
            "width": int(width),
            "height": int(height),
            "rgba_b64": base64.b64encode(raw).decode("ascii"),
            "source": f"{source}+{storage}",
        }

    def _brush_preview_payload(self, brush, max_edge: int = 64):
        """Override the legacy byte-count assumption for Brush ID previews."""
        if brush is None:
            return {}
        try:
            preview = brush.preview_ensure()
        except Exception:
            preview = None
        payload = self._image_preview_payload(preview, max_edge=max_edge)
        if payload:
            payload["source"] = str(payload.get("source") or "").replace(
                "thumbnail_", "brush_", 1
            )
        return payload

    @staticmethod
    def _blend_id_preview_path(spec):
        """Return Blender's library-ID thumbnail path for one Brush Asset."""
        spec = dict(spec or {})
        source = str(spec.get("source_blend") or "").strip()
        name = str(spec.get("name") or "").strip()
        if not source or not name:
            return ""
        try:
            blend_path = Path(source)
            if not blend_path.is_file():
                return ""
            source = blend_path.resolve().as_posix()
        except Exception:
            return ""
        return f"{source}/Brush/{name}"

    def _thumbnail_preview_batch(self, specs, max_edge: int = 64):
        """Read Asset Browser thumbnails through Blender's thumbnail manager."""
        import bpy.utils.previews

        specs = [dict(item or {}) for item in list(specs or ())]
        if not specs:
            return {}
        pcoll = bpy.utils.previews.new()
        results = {}
        try:
            for index, spec in enumerate(specs):
                identity = self._asset_identity(spec)
                filepath = self._blend_id_preview_path(spec)
                if not identity or not filepath:
                    continue
                preview = None
                try:
                    preview = pcoll.load(f"asset_{index}", filepath, 'BLEND')
                except Exception:
                    preview = None
                payload = self._image_preview_payload(preview, max_edge=max_edge)

                if not payload and preview is not None:
                    try:
                        preview.reload()
                    except Exception:
                        pass
                    payload = self._image_preview_payload(preview, max_edge=max_edge)

                if not payload:
                    try:
                        forced = pcoll.load(
                            f"asset_force_{index}", filepath, 'BLEND', force_reload=True
                        )
                    except Exception:
                        forced = None
                    payload = self._image_preview_payload(forced, max_edge=max_edge)

                if payload.get("rgba_b64"):
                    payload["key"] = identity
                    payload["source"] = str(payload.get("source") or "") + "+blend_thumb_manager"
                    results[identity] = payload
                    self._thumbnail_hits += 1
                    self._last_preview_path = "blend_thumb_manager"
                else:
                    self._thumbnail_misses += 1
        finally:
            try:
                bpy.utils.previews.remove(pcoll)
            except Exception:
                try:
                    pcoll.close()
                except Exception:
                    pass
        return results

    def _payload_with_reload(self, brush, max_edge: int = 64):
        payload = dict(self._brush_preview_payload(brush, max_edge=max_edge) or {})
        if payload.get("rgba_b64"):
            return payload

        preview = None
        try:
            preview = getattr(brush, "preview", None)
        except Exception:
            preview = None
        if preview is None:
            try:
                preview = brush.preview_ensure()
            except Exception:
                preview = None
        if preview is not None:
            try:
                preview.reload()
            except Exception:
                pass
            payload = dict(self._image_preview_payload(preview, max_edge=max_edge) or {})
            if payload.get("rgba_b64"):
                return payload
        return {}

    def _linked_preview_batch(self, specs, max_edge: int = 64):
        """Serialized Brush-ID preview fallback retained for compatibility."""
        import bpy

        specs = [dict(item or {}) for item in list(specs or ())]
        groups = {}
        for spec in specs:
            identity = self._asset_identity(spec)
            source = str(spec.get("source_blend") or "")
            name = str(spec.get("name") or "")
            if identity and source and name:
                groups.setdefault(source, []).append(spec)

        results = {}
        for source, group in groups.items():
            blend_path = Path(source)
            if not blend_path.is_file():
                continue
            loaded = []
            wanted_specs = []
            try:
                with bpy.data.libraries.load(str(blend_path), link=True, assets_only=False) as (data_src, data_dst):
                    available = set(getattr(data_src, "brushes", ()) or ())
                    for spec in group:
                        name = str(spec.get("name") or "")
                        if name in available:
                            wanted_specs.append(spec)
                    data_dst.brushes = [str(spec.get("name") or "") for spec in wanted_specs]
                loaded = [brush for brush in list(data_dst.brushes or ()) if brush is not None]

                for index, spec in enumerate(wanted_specs):
                    if index >= len(loaded):
                        break
                    brush = loaded[index]
                    identity = self._asset_identity(spec)
                    payload = self._payload_with_reload(brush, max_edge=max_edge)
                    if payload.get("rgba_b64"):
                        payload["key"] = identity
                        payload["source"] = str(payload.get("source") or "") + "+linked_asset"
                        results[identity] = payload
                        self._last_preview_path = "linked_asset"
            except Exception:
                pass
            finally:
                for brush in loaded:
                    try:
                        bpy.data.brushes.remove(brush)
                    except Exception:
                        pass
        return results

    def _spec_for_current(self):
        current = dict(self.current_sculpt_brush() or {})
        identity = self._asset_identity(current)
        if not identity:
            return None
        cached = self._preview_spec_cache.get(identity)
        if cached:
            return dict(cached)

        rel = str(current.get("relative_asset_identifier") or "").replace("\\", "/")
        lib_type = str(current.get("asset_library_type") or "")
        name = rel.rsplit("/Brush/", 1)[-1] if "/Brush/" in rel else str(current.get("name") or "")

        if lib_type == "ESSENTIALS" and rel:
            source = self._essentials_sculpt_blend()
            if source is not None:
                spec = dict(current)
                spec.update({"name": name, "source_blend": str(source)})
                self._preview_spec_cache[identity] = dict(spec)
                return spec

        try:
            assets = list((self.list_sculpt_brush_assets(max_files=256) or {}).get("assets") or ())
        except Exception:
            assets = []
        for raw in assets:
            spec = dict(raw or {})
            spec_identity = self._asset_identity(spec)
            if spec_identity:
                self._preview_spec_cache[spec_identity] = dict(spec)
            if spec_identity == identity:
                return spec
        return None

    def _fallback_for_specs(self, specs, max_edge: int = 64):
        specs = [dict(item or {}) for item in list(specs or ())]
        results = self._thumbnail_preview_batch(specs, max_edge=max_edge)
        missing = []
        for spec in specs:
            identity = self._asset_identity(spec)
            if identity and not dict(results.get(identity) or {}).get("rgba_b64"):
                missing.append(spec)
        if missing:
            results.update(self._linked_preview_batch(missing, max_edge=max_edge))
        return results

    def current_sculpt_brush_preview(self, max_edge: int = 64):
        payload = dict(super().current_sculpt_brush_preview(max_edge=max_edge) or {})
        if payload.get("rgba_b64"):
            self._last_preview_path = "runtime_id"
            return payload

        spec = self._spec_for_current()
        if spec is None:
            return {}
        identity = self._asset_identity(spec)
        return dict(self._fallback_for_specs([spec], max_edge=max_edge).get(identity) or {})

    def brush_asset_preview(self, asset_spec, max_edge: int = 64):
        spec = dict(asset_spec or {})
        identity = self._asset_identity(spec)
        payload = dict(super().brush_asset_preview(spec, max_edge=max_edge) or {})
        if payload.get("rgba_b64"):
            self._last_preview_path = "asset_only"
            return payload
        return dict(self._fallback_for_specs([spec], max_edge=max_edge).get(identity) or {})

    def brush_asset_previews(self, asset_specs, max_edge: int = 64):
        specs = [dict(item or {}) for item in list(asset_specs or ())]
        results = dict(super().brush_asset_previews(specs, max_edge=max_edge) or {})
        missing = []
        for spec in specs:
            identity = self._asset_identity(spec)
            if identity and not dict(results.get(identity) or {}).get("rgba_b64"):
                missing.append(spec)
        if missing:
            results.update(self._fallback_for_specs(missing, max_edge=max_edge))
        return results

    def preview_debug_snapshot(self):
        return {
            "last_preview_path": str(self._last_preview_path),
            "spec_cache": int(len(self._preview_spec_cache)),
            "thumbnail_hits": int(self._thumbnail_hits),
            "thumbnail_misses": int(self._thumbnail_misses),
            "packed_decode_hits": int(self._packed_decode_hits),
            "float_decode_hits": int(self._float_decode_hits),
            "premul_normalize_hits": int(self._premul_normalize_hits),
        }
