from __future__ import annotations

"""Lifecycle manager for LumaFold-generated editable Sculpt Brush proxies.

Blender Essentials/external Brush assets can reject local Texture datablocks.
LumaFold therefore creates a local editable proxy only while a real Alpha is
attached. This service makes that implementation detail temporary: clearing the
Alpha restores the original source asset, and inactive generated proxies are
cleaned so they do not accumulate in the current .blend.
"""

import time


_WATCH_NS_KEY = "LUMAFOLD_ALPHA_PROXY_WATCH_V1"


class BlenderBrushProxyLifecycleService:
    service_id = "blender.brush_proxy"

    def __init__(self):
        self._generation = 0
        self._last_cleanup = 0.0
        self._status = "IDLE"
        self._active_proxy = ""
        self._source_name = ""
        self._proxy_count = 0

    @staticmethod
    def _active_brush():
        import bpy
        sculpt = getattr(getattr(bpy.context, "tool_settings", None), "sculpt", None)
        return getattr(sculpt, "brush", None) if sculpt is not None else None

    @staticmethod
    def _is_proxy(brush) -> bool:
        if brush is None or not hasattr(brush, "get"):
            return False
        try:
            return bool(brush.get("_lumafold_alpha_proxy", False))
        except Exception:
            return False

    @staticmethod
    def _assigned_texture(brush):
        if brush is None:
            return None
        slot = getattr(brush, "texture_slot", None)
        if slot is not None:
            try:
                tex = getattr(slot, "texture", None)
                if tex is not None:
                    return tex
            except Exception:
                pass
        try:
            return getattr(brush, "texture", None)
        except Exception:
            return None

    @staticmethod
    def _source_spec(brush):
        if brush is None or not hasattr(brush, "get"):
            return None
        try:
            rel = str(brush.get("_lumafold_source_relative_asset_identifier", "") or "").replace("\\", "/")
            if not rel:
                return None
            return {
                "asset_library_type": str(brush.get("_lumafold_source_asset_library_type", "") or "ESSENTIALS"),
                "asset_library_identifier": str(brush.get("_lumafold_source_asset_library_identifier", "") or ""),
                "relative_asset_identifier": rel,
                "name": str(brush.get("_lumafold_source_name", "") or ""),
            }
        except Exception:
            return None

    @staticmethod
    def _all_proxies():
        import bpy
        result = []
        for brush in tuple(getattr(bpy.data, "brushes", ()) or ()):
            if BlenderBrushProxyLifecycleService._is_proxy(brush):
                result.append(brush)
        return result

    @staticmethod
    def _remove_proxy(brush):
        import bpy
        try:
            bpy.data.brushes.remove(brush, do_unlink=True)
            return True
        except TypeError:
            try:
                bpy.data.brushes.remove(brush)
                return True
            except Exception:
                return False
        except Exception:
            return False

    def _cleanup_inactive(self, active):
        removed = 0
        for brush in self._all_proxies():
            if brush is active:
                continue
            if self._remove_proxy(brush):
                removed += 1
        return removed

    def _restore_source_if_default(self, app, active):
        if not self._is_proxy(active):
            return False
        if self._assigned_texture(active) is not None:
            return False
        spec = self._source_spec(active)
        if not spec:
            self._status = "PROXY_DEFAULT_NO_SOURCE"
            return False
        brush_service = app.services.require("blender.brush")
        brush_service.activate_asset(
            asset_library_type=spec["asset_library_type"],
            asset_library_identifier=spec["asset_library_identifier"],
            relative_asset_identifier=spec["relative_asset_identifier"],
        )
        restored = self._active_brush()
        if restored is active:
            self._status = "RESTORE_SOURCE_FAILED"
            return False
        self._remove_proxy(active)
        self._status = "RESTORED_SOURCE"
        self._active_proxy = ""
        self._source_name = str(spec.get("name") or "")
        return True

    def snapshot(self):
        return {
            "status": str(self._status),
            "active_proxy": str(self._active_proxy),
            "source_name": str(self._source_name),
            "proxy_count": int(self._proxy_count),
        }

    def start_watch(self, app, interval: float = 0.15):
        import bpy

        ns = bpy.app.driver_namespace
        generation = int(ns.get(_WATCH_NS_KEY, 0) or 0) + 1
        ns[_WATCH_NS_KEY] = generation
        self._generation = generation
        interval = max(0.08, min(0.50, float(interval)))

        def tick():
            if int(bpy.app.driver_namespace.get(_WATCH_NS_KEY, 0) or 0) != generation:
                return None
            try:
                active = self._active_brush()
                now = time.monotonic()
                if str(getattr(bpy.context, "mode", "")) == "SCULPT" and active is not None:
                    if self._is_proxy(active):
                        source = self._source_spec(active) or {}
                        self._active_proxy = str(getattr(active, "name", "") or "")
                        self._source_name = str(source.get("name") or "")
                        if self._assigned_texture(active) is None:
                            self._restore_source_if_default(app, active)
                            active = self._active_brush()
                        else:
                            self._status = "ACTIVE_ALPHA_PROXY"
                    else:
                        self._active_proxy = ""
                        self._source_name = ""
                        self._status = "NATIVE_BRUSH"

                if now - self._last_cleanup >= 1.0:
                    self._cleanup_inactive(active)
                    self._last_cleanup = now

                self._proxy_count = len(self._all_proxies())
                try:
                    state = app.store.namespace("sculpt")
                    state["alpha_proxy_status"] = self._status
                    state["alpha_proxy_count"] = self._proxy_count
                    state["alpha_proxy_active"] = self._active_proxy
                    state["alpha_proxy_source"] = self._source_name
                except Exception:
                    pass
            except Exception as exc:
                self._status = f"ERROR: {type(exc).__name__}: {exc}"
                try:
                    state = app.store.namespace("sculpt")
                    state["alpha_proxy_status"] = self._status
                except Exception:
                    pass
            return interval

        bpy.app.timers.register(tick, first_interval=0.20, persistent=True)
        return generation
