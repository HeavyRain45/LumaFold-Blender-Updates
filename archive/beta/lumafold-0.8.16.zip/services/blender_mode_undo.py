from __future__ import annotations

"""Undo-safe Blender Mode bridge for LumaFold.

LumaFold's floating UI follows Blender's real mode.  A scripted mode switch that
is not followed by an undo boundary can be folded into the next user edit by
Blender's global undo system.  The visible symptom is especially confusing in
Sculpt Mode: enter Sculpt through LumaFold, make the first stroke, press Ctrl+Z,
and Blender may restore the pre-mode-switch Object state together with the
stroke.

This service keeps mode changes native (bpy.ops.object.mode_set) but pushes one
explicit Blender undo boundary *after* the final mode is active.  Geometry undo
therefore lands on a Sculpt-state snapshot instead of crossing the product-mode
transition.  LumaFold itself is still not an undoable UI state; it simply keeps
following Blender's authoritative mode.
"""


class BlenderModeUndoSafeService:
    service_id = "blender.mode"

    def __init__(self):
        self._transition_count = 0
        self._last_transition = "idle"
        self._last_boundary = "not-run"

    @staticmethod
    def current_mode() -> str:
        import bpy
        return str(getattr(bpy.context, "mode", "UNKNOWN"))

    @staticmethod
    def _set_native_mode(mode: str):
        import bpy

        # Scripted operator calls should not independently add an undo step.
        # LumaFold owns exactly one explicit boundary after the whole transition,
        # including the temporary OBJECT hop required by some mode changes.
        result = bpy.ops.object.mode_set('EXEC_DEFAULT', False, mode=str(mode))
        if 'FINISHED' not in set(result):
            raise RuntimeError(f"Blender Mode 切换失败: {mode} · {result!r}")
        return result

    @staticmethod
    def _push_mode_boundary(mode: str):
        import bpy

        label = {
            "SCULPT": "雕刻模式",
            "OBJECT": "物体模式",
            "EDIT_MESH": "编辑模式",
            "EDIT": "编辑模式",
        }.get(str(mode).upper(), str(mode))
        try:
            result = bpy.ops.ed.undo_push(message=f"LumaFold · {label}")
            if 'FINISHED' in set(result):
                return True, "pushed"
            return False, repr(result)
        except Exception as exc:
            return False, f"{type(exc).__name__}: {exc}"

    def set_mode(self, mode: str):
        import bpy

        obj = getattr(bpy.context.view_layer.objects, "active", None)
        if obj is None:
            raise RuntimeError("No active Blender object")

        requested = str(mode or "OBJECT").upper()
        if obj.type != 'MESH' and requested == 'SCULPT':
            raise RuntimeError("Sculpt Mode requires an active mesh")

        current = str(getattr(bpy.context, "mode", "OBJECT"))
        if current == requested:
            self._last_transition = f"{current} -> {requested} · unchanged"
            return f"mode = {current}"

        # Blender expects most cross-mode transitions to pass through Object.
        if current != 'OBJECT':
            self._set_native_mode('OBJECT')
        if requested != 'OBJECT':
            self._set_native_mode(requested)

        actual = str(getattr(bpy.context, "mode", "UNKNOWN"))
        if actual != requested:
            raise RuntimeError(f"Blender Mode 真值不一致: requested={requested}, actual={actual}")

        boundary_ok, boundary_detail = self._push_mode_boundary(actual)
        self._transition_count += 1
        self._last_boundary = boundary_detail
        self._last_transition = f"{current} -> {actual}"

        # Failing to create the boundary should not silently pretend the mode
        # switch failed: Blender is already in the requested mode.  Surface the
        # diagnostic so smoke/diagnostics can catch it while normal work remains
        # usable.
        suffix = "undo-boundary" if boundary_ok else f"undo-boundary-warning={boundary_detail}"
        return f"mode = {actual} · {suffix}"

    def snapshot(self):
        return {
            "mode": self.current_mode(),
            "transition_count": int(self._transition_count),
            "last_transition": str(self._last_transition),
            "last_boundary": str(self._last_boundary),
            "profile": "native-mode + explicit undo boundary",
        }
