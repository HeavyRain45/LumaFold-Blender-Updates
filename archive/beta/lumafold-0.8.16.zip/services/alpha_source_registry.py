from __future__ import annotations

"""Persistent, non-destructive registry for user-linked Alpha folders.

This service owns only source registration metadata and per-source hidden items.
It never copies, moves, renames or deletes user files. Runtime scan results are
returned to the caller and are intentionally not persisted.
"""

from hashlib import sha1
from pathlib import Path


class AlphaSourceRegistryService:
    service_id = "alpha.source_registry"
    SOURCES_KEY = "alpha_linked_sources"
    HIDDEN_KEY = "alpha_hidden_by_source"

    @staticmethod
    def normalize_path(value) -> str:
        raw = str(value or "").strip()
        if not raw:
            return ""
        try:
            return str(Path(raw).expanduser().resolve()).replace("\\", "/")
        except Exception:
            return str(Path(raw).expanduser()).replace("\\", "/")

    @classmethod
    def source_id_for_path(cls, value) -> str:
        path = cls.normalize_path(value)
        if not path:
            return ""
        digest = sha1(path.casefold().encode("utf-8", "surrogatepass")).hexdigest()[:16]
        return "alpha|linked|" + digest

    @staticmethod
    def _display_name(path: str) -> str:
        try:
            name = Path(path).name
        except Exception:
            name = ""
        return str(name or path or "Alpha 文件夹")

    @classmethod
    def _sources(cls, state):
        rows = []
        seen = set()
        for raw in list((state or {}).get(cls.SOURCES_KEY) or ()):
            item = dict(raw or {})
            path = cls.normalize_path(item.get("path"))
            if not path:
                continue
            source_id = str(item.get("id") or cls.source_id_for_path(path))
            key = path.casefold()
            if not source_id or key in seen:
                continue
            seen.add(key)
            rows.append({
                "id": source_id,
                "path": path,
                "label": str(item.get("label") or cls._display_name(path)),
                "type": "linked",
                "enabled": bool(item.get("enabled", True)),
            })
        return rows

    @classmethod
    def list_sources(cls, state):
        return [dict(item) for item in cls._sources(state)]

    @classmethod
    def add_folder(cls, state, path):
        if state is None:
            raise RuntimeError("Alpha source registry state is unavailable")
        norm = cls.normalize_path(path)
        if not norm:
            raise RuntimeError("Alpha 文件夹路径为空")
        folder = Path(norm)
        if not folder.is_dir():
            raise RuntimeError(f"Alpha 文件夹不存在: {norm}")
        rows = cls._sources(state)
        for row in rows:
            if str(row.get("path") or "").casefold() == norm.casefold():
                state[cls.SOURCES_KEY] = rows
                return dict(row), False
        record = {
            "id": cls.source_id_for_path(norm),
            "path": norm,
            "label": cls._display_name(norm),
            "type": "linked",
            "enabled": True,
        }
        rows.append(record)
        state[cls.SOURCES_KEY] = rows
        return dict(record), True

    @classmethod
    def remove_folder(cls, state, source_id: str):
        """Unregister one linked source without touching the filesystem."""
        if state is None:
            raise RuntimeError("Alpha source registry state is unavailable")
        source_id = str(source_id or "")
        rows = cls._sources(state)
        match = next((dict(row) for row in rows if str(row.get("id") or "") == source_id), None)
        if match is None:
            raise RuntimeError("Alpha 文件夹来源不存在或已移除")
        state[cls.SOURCES_KEY] = [row for row in rows if str(row.get("id") or "") != source_id]
        hidden = dict(state.get(cls.HIDDEN_KEY) or {})
        hidden.pop(source_id, None)
        state[cls.HIDDEN_KEY] = hidden
        return match

    @classmethod
    def hidden_identities(cls, state, source_id: str):
        hidden = dict((state or {}).get(cls.HIDDEN_KEY) or {})
        return tuple(str(item) for item in list(hidden.get(str(source_id or "")) or ()) if str(item or ""))

    @classmethod
    def hide_identity(cls, state, source_id: str, identity: str):
        source_id = str(source_id or "")
        identity = str(identity or "")
        if not source_id or not identity:
            raise RuntimeError("Alpha 来源或资源标识为空")
        if not any(str(row.get("id") or "") == source_id for row in cls._sources(state)):
            raise RuntimeError("只能从已链接的 Alpha 文件夹中移除资源")
        hidden = dict(state.get(cls.HIDDEN_KEY) or {})
        values = [str(item) for item in list(hidden.get(source_id) or ()) if str(item or "")]
        if identity not in values:
            values.append(identity)
        hidden[source_id] = values
        state[cls.HIDDEN_KEY] = hidden
        return True

    @classmethod
    def unhide_identity(cls, state, source_id: str, identity: str):
        source_id = str(source_id or "")
        identity = str(identity or "")
        hidden = dict(state.get(cls.HIDDEN_KEY) or {})
        values = [str(item) for item in list(hidden.get(source_id) or ()) if str(item or "") and str(item) != identity]
        if values:
            hidden[source_id] = values
        else:
            hidden.pop(source_id, None)
        state[cls.HIDDEN_KEY] = hidden
        return True

    @classmethod
    def clear_hidden(cls, state, source_id: str):
        source_id = str(source_id or "")
        hidden = dict(state.get(cls.HIDDEN_KEY) or {})
        hidden.pop(source_id, None)
        state[cls.HIDDEN_KEY] = hidden
        return True

    @classmethod
    def scan(cls, state, image_exts, max_files: int = 512):
        """Return linked-folder records without mutating disk or persistence."""
        exts = {str(ext).casefold() for ext in set(image_exts or ())}
        limit = max(1, int(max_files))
        folders, assets, errors = [], [], []
        seen_identity = set()

        for source in cls._sources(state):
            if not bool(source.get("enabled", True)):
                continue
            source_id = str(source.get("id") or "")
            root = Path(str(source.get("path") or ""))
            label = str(source.get("label") or cls._display_name(str(root)))
            missing = not root.is_dir()
            hidden = set(cls.hidden_identities(state, source_id))
            folder = {
                "id": source_id,
                "label": label,
                "source": label,
                "path": cls.normalize_path(root),
                "readonly": False,
                "linked": True,
                "removable": True,
                "missing": bool(missing),
                "count": 0,
                "hidden_count": 0,
                "total_count": 0,
            }
            folders.append(folder)
            if missing:
                errors.append(f"{label}: 文件夹不存在: {folder['path']}")
                continue
            try:
                paths = sorted(
                    (p for p in root.rglob("*") if p.is_file() and p.suffix.casefold() in exts),
                    key=lambda p: str(p).casefold(),
                )
            except Exception as exc:
                errors.append(f"{label}: {type(exc).__name__}: {exc}")
                continue
            for path in paths:
                norm = cls.normalize_path(path)
                identity = "file|" + norm.casefold()
                if not norm or identity in seen_identity:
                    continue
                folder["total_count"] += 1
                if identity in hidden:
                    folder["hidden_count"] += 1
                    continue
                if len(assets) >= limit:
                    continue
                seen_identity.add(identity)
                assets.append({
                    "name": path.stem,
                    "identity": identity,
                    "filepath": norm,
                    "image_name": "",
                    "folder_id": source_id,
                    "folder_label": label,
                    "source_label": label,
                    "source_type": "linked",
                    "linked_source_id": source_id,
                    "readonly": False,
                    "loaded": False,
                })
                folder["count"] += 1

        return {"folders": folders, "assets": assets, "errors": errors[-8:]}
