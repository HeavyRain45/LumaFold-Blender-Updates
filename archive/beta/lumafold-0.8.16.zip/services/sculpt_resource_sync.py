from __future__ import annotations

"""Native Blender Brush/Alpha -> LumaFold truth watcher.

Size/Strength already have their own high-frequency bridge. This watcher handles
resource identity changes made through Blender itself (Asset Shelf, native brush
selector, texture panels) so LumaFold stays coherent even when none of its own
buttons were used.

Performance invariant:
The 10 Hz idle watcher may inspect Blender ID pointers and small strings only.
It must not resolve file-system paths, load images, read image pixels, generate
previews, or Base64-encode thumbnails unless the native Brush/Texture/Image token
has actually changed. This keeps an active file-backed Alpha from becoming a
permanent Blender main-thread tax.
"""

import time


_WATCH_NS_KEY = "LUMAFOLD_SCULPT_RESOURCE_SYNC_V1"


class SculptResourceSyncService:
    service_id = "blender.sculpt_resource_sync"

    def __init__(self):
        self._generation = 0
        self._status = "IDLE"
        self._serial = 0
        self._brush_identity = ""
        self._alpha_identity = ""
        self._alpha_token = None
        self._brush_name = ""
        self._alpha_name = "默认"
        self._last_change = 0.0
        self._alpha_light_polls = 0
        self._alpha_full_syncs = 0
        self._alpha_preview_reuses = 0
        self._alpha_preview_builds = 0

    @staticmethod
    def _normalize_asset(value):
        return str(value or "").replace("\\", "/").strip()

    @classmethod
    def _brush_identity_from_snapshot(cls, snap):
        snap = dict(snap or {})
        rel = cls._normalize_asset(snap.get("relative_asset_identifier"))
        if rel:
            return "asset|{}|{}|{}".format(
                str(snap.get("asset_library_type") or "").casefold(),
                str(snap.get("asset_library_identifier") or "").casefold(),
                rel.casefold(),
            )
        name = str(snap.get("name") or "")
        return "local|" + name.casefold() if name else ""

    @classmethod
    def _brush_identity_from_slot(cls, slot):
        slot = dict(slot or {})
        rel = cls._normalize_asset(slot.get("relative_asset_identifier"))
        if not rel:
            return ""
        return "asset|{}|{}|{}".format(
            str(slot.get("asset_library_type") or "").casefold(),
            str(slot.get("asset_library_identifier") or "").casefold(),
            rel.casefold(),
        )

    @staticmethod
    def _alpha_identity_from_snapshot(snap):
        return str((snap or {}).get("identity") or "none")

    @staticmethod
    def _pointer(value):
        if value is None:
            return 0
        try:
            return int(value.as_pointer())
        except Exception:
            return id(value)

    @classmethod
    def _alpha_native_token(cls):
        """Return one memory-only Alpha change token from Blender native IDs.

        This intentionally does *not* call BlenderAlphaService.current_sculpt_alpha:
        that full snapshot canonicalizes a file path and is therefore unsuitable
        for a 10 Hz idle poll. The token only observes already-resident Blender
        datablocks and strings; a token change authorizes one full Alpha sync.
        """
        import bpy

        sculpt = getattr(getattr(bpy.context, "tool_settings", None), "sculpt", None)
        brush = getattr(sculpt, "brush", None) if sculpt is not None else None
        slot = getattr(brush, "texture_slot", None) if brush is not None else None
        texture = None
        if slot is not None:
            try:
                texture = getattr(slot, "texture", None)
            except Exception:
                texture = None
        if texture is None and brush is not None:
            try:
                texture = getattr(brush, "texture", None)
            except Exception:
                texture = None
        image = None
        if texture is not None and str(getattr(texture, "type", "")) == "IMAGE":
            image = getattr(texture, "image", None)
        return (
            cls._pointer(brush),
            cls._pointer(texture),
            cls._pointer(image),
            str(getattr(image, "name", "") or "") if image is not None else "",
            str(getattr(image, "filepath", "") or "") if image is not None else "",
            str(getattr(slot, "map_mode", "") or "") if slot is not None else "",
        )

    def _sync_brush(self, app, state, brush_service, snap, identity):
        snap = dict(snap or {})
        name = str(snap.get("name") or "")
        state["current_brush_name"] = name
        state["current_brush_asset"] = {
            "asset_library_type": str(snap.get("asset_library_type") or ""),
            "asset_library_identifier": str(snap.get("asset_library_identifier") or ""),
            "relative_asset_identifier": self._normalize_asset(snap.get("relative_asset_identifier")),
        }
        state["current_brush_type"] = str(snap.get("sculpt_brush_type") or "")
        state["brush_sync_status"] = "SYNCED" if snap.get("available") else "NO_ACTIVE_BRUSH"

        # Quick Brush selection is identity based. Alpha proxies intentionally
        # report their source asset identity through BlenderBrushService.
        matched = -1
        for index, slot in enumerate(list(state.get("quick_brush_slots") or ())):
            if identity and identity == self._brush_identity_from_slot(slot):
                matched = index
                break
        state["active_quick_slot"] = matched
        if matched >= 0:
            state["quick_slot"] = matched

        preview = {}
        if snap.get("available"):
            try:
                preview = dict(brush_service.current_sculpt_brush_preview(max_edge=72) or {})
            except Exception:
                preview = {}
        if preview:
            preview["key"] = identity
            cache = state.setdefault("brush_preview_cache", {})
            cache[identity] = preview
            if len(cache) > 12:
                for key in tuple(cache.keys())[:-12]:
                    cache.pop(key, None)
        state["current_brush_preview"] = preview

        self._brush_identity = identity
        self._brush_name = name
        self._serial += 1
        self._last_change = time.monotonic()
        app.events.emit("sculpt.native_brush.changed", {"identity": identity, "name": name})

    def _cached_alpha_preview(self, state, identity):
        identity = str(identity or "")
        if not identity or identity == "none":
            return {}
        for key in (
            "alpha_library_preview_cache",
            "primary_alpha_preview_cache",
        ):
            payload = dict((state.get(key) or {}).get(identity) or {})
            if payload.get("rgba_b64"):
                payload["key"] = identity
                return payload
        return {}

    def _sync_alpha(self, app, state, alpha_service, snap, identity):
        snap = dict(snap or {})
        name = str(snap.get("name") or "默认")
        state["current_alpha_name"] = name
        state["current_alpha_identity"] = identity
        state["current_alpha_filepath"] = str(snap.get("filepath") or "")
        state["current_alpha_map_mode"] = str(snap.get("map_mode") or "")
        state["alpha_sync_status"] = "SYNCED"

        # Library tiles already own a 64px product thumbnail. Reuse that payload
        # for the active Alpha instead of loading the same source file a second
        # time. Only native/external Alpha changes without a cached tile are
        # allowed to build a one-off current preview.
        preview = self._cached_alpha_preview(state, identity)
        if preview:
            self._alpha_preview_reuses += 1
        elif bool(snap.get("available")):
            try:
                preview = dict(alpha_service.current_sculpt_alpha_preview(max_edge=72) or {})
            except Exception:
                preview = {}
            if preview:
                self._alpha_preview_builds += 1
        if preview:
            preview["key"] = identity
        state["current_alpha_preview"] = preview

        self._alpha_identity = identity
        self._alpha_name = name
        self._alpha_full_syncs += 1
        self._serial += 1
        self._last_change = time.monotonic()
        app.events.emit("sculpt.native_alpha.changed", {"identity": identity, "name": name})

    def snapshot(self):
        return {
            "status": str(self._status),
            "serial": int(self._serial),
            "brush_identity": str(self._brush_identity),
            "brush_name": str(self._brush_name),
            "alpha_identity": str(self._alpha_identity),
            "alpha_name": str(self._alpha_name),
            "last_change": float(self._last_change),
            "alpha_light_polls": int(self._alpha_light_polls),
            "alpha_full_syncs": int(self._alpha_full_syncs),
            "alpha_preview_reuses": int(self._alpha_preview_reuses),
            "alpha_preview_builds": int(self._alpha_preview_builds),
        }

    def start_watch(self, app, interval: float = 0.10):
        import bpy

        generation = int(bpy.app.driver_namespace.get(_WATCH_NS_KEY, 0) or 0) + 1
        bpy.app.driver_namespace[_WATCH_NS_KEY] = generation
        self._generation = generation
        interval = max(0.05, min(0.30, float(interval)))

        def tick():
            if int(bpy.app.driver_namespace.get(_WATCH_NS_KEY, 0) or 0) != generation:
                return None
            try:
                if str(getattr(bpy.context, "mode", "")) != "SCULPT":
                    self._status = "STANDBY"
                    self._brush_identity = ""
                    self._alpha_identity = ""
                    self._alpha_token = None
                    return interval

                brush_service = app.services.require("blender.brush")
                alpha_service = app.services.require("blender.alpha")
                state = app.store.namespace("sculpt")

                brush_snap = dict(brush_service.current_sculpt_brush() or {})
                brush_identity = self._brush_identity_from_snapshot(brush_snap)
                if brush_identity != self._brush_identity:
                    self._sync_brush(app, state, brush_service, brush_snap, brush_identity)

                # Idle Alpha polling is memory-only. The full Alpha snapshot may
                # resolve a real file path, so call it only after Blender's native
                # Brush/Texture/Image token proves something actually changed.
                alpha_token = self._alpha_native_token()
                self._alpha_light_polls += 1
                if alpha_token != self._alpha_token:
                    alpha_snap = dict(alpha_service.current_sculpt_alpha() or {})
                    alpha_identity = self._alpha_identity_from_snapshot(alpha_snap)
                    self._sync_alpha(app, state, alpha_service, alpha_snap, alpha_identity)
                    self._alpha_token = alpha_token

                self._status = "SYNCED"
            except Exception as exc:
                self._status = f"ERROR: {type(exc).__name__}: {exc}"
            return interval

        bpy.app.timers.register(tick, first_interval=0.12, persistent=True)
        return generation
