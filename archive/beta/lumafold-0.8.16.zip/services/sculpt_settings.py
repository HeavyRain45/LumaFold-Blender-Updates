from __future__ import annotations

"""Blender Sculpt settings truth bridge + version compatibility foundation.

S0.7.4 keeps product UI independent from Blender-version-specific RNA paths.
The service resolves the authoritative Size/Strength owner at runtime and a
small watcher performs two-way synchronization between Blender and LumaFold.

Blender 5.2:
    UnifiedPaintSettings.use_unified_size / use_unified_strength choose whether
    the shared per-mode value or the active Brush value is authoritative.

Blender 5.3+:
    the same choice moves to per-Brush use_unified_* flags.  Detection is by RNA
    capability rather than a hard-coded version branch so development builds are
    supported naturally.
"""

import math
import time


_WATCH_NS_KEY = "LUMAFOLD_SCULPT_SETTINGS_WATCH_V1"


class BlenderCapabilitiesService:
    service_id = "blender.capabilities"

    @staticmethod
    def snapshot():
        import bpy

        brush_type = getattr(bpy.types, "Brush", None)
        ups_type = getattr(bpy.types, "UnifiedPaintSettings", None)
        wm_type = getattr(bpy.types, "WindowManager", None)
        window_type = getattr(bpy.types, "Window", None)
        node_tree_type = getattr(bpy.types, "NodeTreeInterface", None)

        return {
            "version": str(getattr(bpy.app, "version_string", "")),
            "version_tuple": tuple(int(v) for v in tuple(getattr(bpy.app, "version", (0, 0, 0)))[:3]),
            "per_brush_unified_settings": bool(
                brush_type is not None
                and hasattr(brush_type, "use_unified_size")
                and hasattr(brush_type, "use_unified_strength")
            ),
            "legacy_unified_paint_flags": bool(
                ups_type is not None
                and hasattr(ups_type, "use_unified_size")
                and hasattr(ups_type, "use_unified_strength")
            ),
            "window_modal_operators": bool(window_type is not None and hasattr(window_type, "modal_operators")),
            "window_manager_undo_stack": bool(wm_type is not None and hasattr(wm_type, "undo_stack")),
            "try_activate_rna_button": bool(wm_type is not None and hasattr(wm_type, "try_activate_rna_button")),
            "node_tree_root_panel": bool(node_tree_type is not None and hasattr(node_tree_type, "root_panel")),
        }


class BlenderSculptSettingsService:
    """Authoritative Blender Size/Strength adapter used by LumaFold Sculpt."""

    service_id = "blender.sculpt_settings"

    def __init__(self):
        self._generation = 0
        self._initialized = False
        self._last_state = None
        self._last_blender = None
        self._last_brush_key = None

    @staticmethod
    def _paint_and_brush():
        import bpy

        tool_settings = getattr(bpy.context, "tool_settings", None)
        paint = getattr(tool_settings, "sculpt", None) if tool_settings is not None else None
        brush = getattr(paint, "brush", None) if paint is not None else None
        ups = getattr(paint, "unified_paint_settings", None) if paint is not None else None
        if ups is None and tool_settings is not None:
            # Compatibility fallback for older/newer RNA placements.
            ups = getattr(tool_settings, "unified_paint_settings", None)
        return paint, brush, ups

    @staticmethod
    def _bool_attr(obj, name, default=False):
        if obj is None or not hasattr(obj, name):
            return bool(default)
        try:
            return bool(getattr(obj, name))
        except Exception:
            return bool(default)

    def _use_unified(self, brush, ups, field: str) -> bool:
        flag = "use_unified_" + str(field)
        # 5.3+: unified choice is per brush.
        if brush is not None and hasattr(brush, flag):
            return self._bool_attr(brush, flag, False)
        # 5.2 LTS: choice lives on UnifiedPaintSettings.
        return self._bool_attr(ups, flag, False)

    @staticmethod
    def _read_number(obj, name, default):
        if obj is None or not hasattr(obj, name):
            return float(default)
        try:
            value = float(getattr(obj, name))
            return value if math.isfinite(value) else float(default)
        except Exception:
            return float(default)

    @staticmethod
    def _write_number(obj, name, value):
        if obj is None or not hasattr(obj, name):
            return False
        try:
            setattr(obj, name, value)
            return True
        except Exception:
            return False

    def snapshot(self):
        import bpy

        paint, brush, ups = self._paint_and_brush()
        if paint is None or brush is None:
            return {
                "available": False,
                "size": 0.0,
                "strength": 0.0,
                "size_source": "none",
                "strength_source": "none",
                "use_unified_size": False,
                "use_unified_strength": False,
                "brush_key": "",
            }

        use_size = self._use_unified(brush, ups, "size")
        use_strength = self._use_unified(brush, ups, "strength")
        size_owner = ups if use_size and ups is not None else brush
        strength_owner = ups if use_strength and ups is not None else brush

        size = self._read_number(size_owner, "size", 100.0)
        strength = self._read_number(strength_owner, "strength", 0.5)
        try:
            brush_key = f"{brush.name_full}|{brush.as_pointer()}"
        except Exception:
            brush_key = str(getattr(brush, "name", ""))

        return {
            "available": True,
            "size": size,
            "strength": strength,
            "size_source": "unified" if use_size else "brush",
            "strength_source": "unified" if use_strength else "brush",
            "use_unified_size": use_size,
            "use_unified_strength": use_strength,
            "brush_key": brush_key,
            "blender_version": str(getattr(bpy.app, "version_string", "")),
        }

    def set_size(self, value: float):
        paint, brush, ups = self._paint_and_brush()
        if paint is None or brush is None:
            raise RuntimeError("当前没有可编辑的 Sculpt Brush")
        value = max(1, min(10000, int(round(float(value)))))
        use_unified = self._use_unified(brush, ups, "size")
        owner = ups if use_unified and ups is not None else brush
        if not self._write_number(owner, "size", value):
            # Defensive RNA fallback: prefer shared settings if a development
            # build moved the property but kept UnifiedPaintSettings.size.
            if owner is not ups and self._write_number(ups, "size", value):
                owner = ups
            else:
                raise RuntimeError("Blender 当前 API 无法写入 Sculpt Size")
        return self.snapshot()

    def set_strength(self, value: float):
        paint, brush, ups = self._paint_and_brush()
        if paint is None or brush is None:
            raise RuntimeError("当前没有可编辑的 Sculpt Brush")
        value = max(0.0, min(1.0, float(value)))
        use_unified = self._use_unified(brush, ups, "strength")
        owner = ups if use_unified and ups is not None else brush
        if not self._write_number(owner, "strength", value):
            if owner is not ups and self._write_number(ups, "strength", value):
                owner = ups
            else:
                raise RuntimeError("Blender 当前 API 无法写入 Sculpt Strength")
        return self.snapshot()

    def apply(self, *, size=None, strength=None):
        if size is not None:
            self.set_size(size)
        if strength is not None:
            self.set_strength(strength)
        return self.snapshot()

    @staticmethod
    def _pair_from_state(state):
        try:
            return (float(state.get("brush_size", 72.0)), float(state.get("brush_strength", 0.5)))
        except Exception:
            return (72.0, 0.5)

    @staticmethod
    def _pair_from_snapshot(snap):
        return (float(snap.get("size", 0.0)), float(snap.get("strength", 0.0)))

    @staticmethod
    def _pair_changed(a, b, eps_size=0.49, eps_strength=0.0005):
        if a is None or b is None:
            return True
        return abs(float(a[0]) - float(b[0])) > eps_size or abs(float(a[1]) - float(b[1])) > eps_strength

    @staticmethod
    def _write_state_from_snapshot(state, snap):
        state["brush_size"] = float(snap.get("size", state.get("brush_size", 72.0)))
        state["brush_strength"] = float(snap.get("strength", state.get("brush_strength", 0.5)))
        state["brush_size_source"] = str(snap.get("size_source", ""))
        state["brush_strength_source"] = str(snap.get("strength_source", ""))
        state["brush_use_unified_size"] = bool(snap.get("use_unified_size", False))
        state["brush_use_unified_strength"] = bool(snap.get("use_unified_strength", False))
        state["brush_settings_sync_status"] = "SYNCED"

    def start_watch(self, app, interval: float = 0.033):
        """Start a superseding app-timer watcher; safe across package hot reload."""
        import bpy

        ns = bpy.app.driver_namespace
        generation = int(ns.get(_WATCH_NS_KEY, 0) or 0) + 1
        ns[_WATCH_NS_KEY] = generation
        self._generation = generation
        self._initialized = False
        self._last_state = None
        self._last_blender = None
        self._last_brush_key = None
        interval = max(0.02, min(0.20, float(interval)))

        def tick():
            # New package hot reloads increment the generation; stale timers end.
            if int(bpy.app.driver_namespace.get(_WATCH_NS_KEY, 0) or 0) != generation:
                return None
            try:
                state = app.store.namespace("sculpt")
                snap = self.snapshot()
                if not bool(snap.get("available")):
                    state["brush_settings_sync_status"] = "NO_ACTIVE_SCULPT_BRUSH"
                    self._initialized = False
                    self._last_state = self._pair_from_state(state)
                    self._last_blender = None
                    self._last_brush_key = None
                    return interval

                state_pair = self._pair_from_state(state)
                blender_pair = self._pair_from_snapshot(snap)
                brush_key = str(snap.get("brush_key", ""))

                # First valid sample or brush switch: Blender is authoritative.
                if (not self._initialized) or brush_key != self._last_brush_key:
                    self._write_state_from_snapshot(state, snap)
                    self._last_state = self._pair_from_snapshot(snap)
                    self._last_blender = self._pair_from_snapshot(snap)
                    self._last_brush_key = brush_key
                    self._initialized = True
                    return interval

                state_changed = self._pair_changed(state_pair, self._last_state)
                blender_changed = self._pair_changed(blender_pair, self._last_blender)

                if state_changed and not blender_changed:
                    # LumaFold UI/Satellite changed state since the previous tick.
                    snap = self.apply(size=state_pair[0], strength=state_pair[1])
                    self._write_state_from_snapshot(state, snap)
                    blender_pair = self._pair_from_snapshot(snap)
                elif blender_changed:
                    # F / Shift-F / Blender native UI / brush settings changed.
                    # Blender wins on simultaneous changes to avoid fighting the
                    # application that owns the actual Sculpt setting.
                    self._write_state_from_snapshot(state, snap)
                    state_pair = self._pair_from_snapshot(snap)

                self._last_state = self._pair_from_state(state)
                self._last_blender = blender_pair
                self._last_brush_key = brush_key
            except Exception as exc:
                try:
                    state = app.store.namespace("sculpt")
                    state["brush_settings_sync_status"] = f"ERROR: {type(exc).__name__}: {exc}"
                except Exception:
                    pass
            return interval

        bpy.app.timers.register(tick, first_interval=0.05, persistent=True)
        return generation
