from __future__ import annotations

"""Operational compatibility gate layered over the 5.2/5.3 metadata gate.

Blender 5.2 can hide some RNA members from bpy.types while exposing them on
live objects. A compatibility failure must mean LumaFold cannot actually use a
required capability, not merely that class-level introspection is incomplete.
"""

from .blender_compat53 import BlenderCompatibilityGateService


class BlenderCompatibilityRuntimeGateService(BlenderCompatibilityGateService):
    service_id = "blender.compat_gate"

    def snapshot(self):
        result = dict(super().snapshot() or {})
        caps = dict(self.capabilities.snapshot() or {})
        missing = [str(item) for item in list(result.get("missing") or ())]

        if bool(caps.get("sculpt_size_strength_owner")):
            missing = [item for item in missing if item != "Sculpt unified Size/Strength owner"]

        if bool(caps.get("window_modal_operators")):
            missing = [item for item in missing if item != "Window.modal_operators"]

        result["missing"] = missing
        result["status"] = "READY" if not missing else "DEGRADED"
        result["sculpt_unified_probe"] = str(caps.get("sculpt_unified_probe") or "unknown")
        result["sculpt_value_owner_probe"] = str(caps.get("sculpt_value_owner_probe") or "unknown")
        result["modal_probe"] = str(caps.get("window_modal_operators_probe") or "unknown")
        return result
