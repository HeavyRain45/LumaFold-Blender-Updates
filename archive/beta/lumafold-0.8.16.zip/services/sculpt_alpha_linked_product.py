from __future__ import annotations

"""Linked-folder extension of the accepted Alpha product service.

This layer owns final Alpha browser composition and thumbnail fidelity, but it
never mutates source files. Filesystem mutation for LumaFold-owned copies lives
in ``alpha_managed_store`` so linked-source safety remains structurally obvious.

* linked folders take precedence for identical file-path identities;
* Alpha artwork is treated as data, not display color;
* thumbnails are top-down, aspect-preserving and centered in a square canvas;
* individually imported files remain in ``全部`` without a managed-root nav row;
* user-created managed subfolders are surfaced through managed-store snapshots;
* Blender's generic ``当前文件`` bucket is content-only and never a nav folder;
* externally linked folders remain strictly non-destructive.
"""

from pathlib import Path

from .sculpt_alpha_product import BlenderAlphaServiceProduct


class BlenderAlphaLinkedProduct(BlenderAlphaServiceProduct):
    service_id = "blender.alpha"
    LINKED_PREFIX = "alpha|linked|"
    TEST_SEED_FOLDER_ID = "alpha|lumafold|test_seed"
    CURRENT_FILE_FOLDER_ID = "loaded|current_file"

    def __init__(self, source_store, managed_store):
        super().__init__()
        self.source_store = source_store
        self.managed_store = managed_store

    @staticmethod
    def _preview_byte(value):
        try:
            value = float(value)
        except Exception:
            value = 0.0
        value = max(0.0, min(1.0, value))
        return max(0, min(255, int(round(value * 255.0))))

    @classmethod
    def _image_pixels_payload(cls, image, max_edge=64, *, scaled=False):
        """Return a square, non-stretched, top-down Alpha preview payload."""
        import base64

        if image is None:
            return {}
        try:
            width, height = (int(v) for v in tuple(image.size)[:2])
        except Exception:
            return {}
        if width <= 0 or height <= 0:
            return {}

        target_w, target_h = cls._target_size(width, height, max_edge)
        if scaled and (width, height) != (target_w, target_h):
            try:
                image.scale(target_w, target_h)
                width, height = target_w, target_h
            except Exception:
                scaled = False

        try:
            pixels = image.pixels
        except Exception:
            return {}

        content_w, content_h = cls._target_size(width, height, max_edge)
        side = max(1, max(content_w, content_h))
        offset_x = max(0, (side - content_w) // 2)
        offset_y = max(0, (side - content_h) // 2)
        raw = bytearray(side * side * 4)

        try:
            for y in range(content_h):
                sampled_y = min(height - 1, int((y + 0.5) * height / content_h))
                src_y = (height - 1) - sampled_y
                dst_y = offset_y + y
                for x in range(content_w):
                    src_x = min(width - 1, int((x + 0.5) * width / content_w))
                    source = (src_y * width + src_x) * 4
                    target = (dst_y * side + offset_x + x) * 4
                    raw[target] = cls._preview_byte(pixels[source])
                    raw[target + 1] = cls._preview_byte(pixels[source + 1])
                    raw[target + 2] = cls._preview_byte(pixels[source + 2])
                    raw[target + 3] = cls._preview_byte(pixels[source + 3])
        except Exception:
            return {}

        return {
            "width": side,
            "height": side,
            "content_width": content_w,
            "content_height": content_h,
            "content_x": offset_x,
            "content_y": offset_y,
            "rgba_b64": base64.b64encode(bytes(raw)).decode("ascii"),
            "source": "alpha_data_pixels",
        }

    @classmethod
    def _file_pixels_payload(cls, path, max_edge=64):
        """Load a disposable Blender Image as Non-Color Alpha data."""
        import bpy

        path = Path(str(path or ""))
        if not path.is_file():
            return {}
        temp = None
        try:
            temp = bpy.data.images.load(str(path), check_existing=False)
            settings = getattr(temp, "colorspace_settings", None)
            if settings is not None:
                for name in ("Non-Color", "Raw"):
                    try:
                        settings.name = name
                        break
                    except Exception:
                        continue
            return cls._image_pixels_payload(temp, max_edge=max_edge, scaled=True)
        except Exception:
            return {}
        finally:
            if temp is not None:
                try:
                    bpy.data.images.remove(temp)
                except Exception:
                    pass

    def list_sculpt_alphas(self, max_files=512):
        result = dict(super().list_sculpt_alphas(max_files=max_files) or {})
        assets = [dict(item or {}) for item in list(result.get("assets") or ())]
        folders = [dict(item or {}) for item in list(result.get("folders") or ())]
        errors = list(result.get("errors") or ())

        linked = dict(self.source_store.scan(self.IMAGE_EXTS, max_files=max_files) or {})
        linked_folders = [dict(item or {}) for item in list(linked.get("folders") or ())]
        linked_assets = [dict(item or {}) for item in list(linked.get("assets") or ())]
        errors.extend(str(item) for item in list(linked.get("errors") or ()) if str(item or ""))

        hidden = set(str(item) for item in self.source_store.all_hidden_identities() if str(item or ""))
        if hidden:
            assets = [item for item in assets if str(item.get("identity") or "") not in hidden]

        by_identity = {
            str(item.get("identity") or ""): item
            for item in assets
            if str(item.get("identity") or "")
        }
        folder_map = {
            str(item.get("id") or ""): item
            for item in folders
            if str(item.get("id") or "")
        }

        # Keep linked roots visible even when empty or temporarily missing so the
        # user can still select/remove/fix that source from the left navigation.
        for folder in linked_folders:
            folder_id = str(folder.get("id") or "")
            if not folder_id:
                continue
            current = folder_map.get(folder_id)
            if current is None:
                folders.append(folder)
                folder_map[folder_id] = folder
            else:
                current.update(folder)

        for linked_item in linked_assets:
            identity = str(linked_item.get("identity") or "")
            if not identity:
                continue
            existing = by_identity.get(identity)
            if existing is None:
                assets.append(linked_item)
                by_identity[identity] = linked_item
                continue
            loaded_name = str(existing.get("image_name") or "")
            loaded = bool(existing.get("loaded", False))
            existing.update(linked_item)
            if loaded_name:
                existing["image_name"] = loaded_name
            existing["loaded"] = bool(existing.get("loaded", False)) or loaded

        # Individually imported images live in the managed root. They belong in
        # 全部, but the root itself is not a useful folder in the left sidebar.
        managed_root_id = self.USER_FOLDER_PREFIX + "根目录"
        for item in assets:
            folder_id = str(item.get("folder_id") or "")
            if folder_id.startswith(self.USER_FOLDER_PREFIX):
                item["source_type"] = "managed"
                item["managed"] = True
            elif folder_id.startswith(self.LINKED_PREFIX):
                item["source_type"] = "linked"

        # User-created LumaFold subfolders remain visible even while empty. The
        # linked product consumes a snapshot; filesystem ownership stays in the
        # separate managed store.
        try:
            for record in list(self.managed_store.list_folders() or ()):
                record = dict(record or {})
                folder_id = str(record.get("id") or "")
                rel = str(record.get("relative") or "")
                if not folder_id or not rel:
                    continue
                folder = folder_map.get(folder_id)
                if folder is None:
                    folder = {
                        "id": folder_id,
                        "label": f"{self.USER_SOURCE_LABEL} / {rel}",
                        "source": self.USER_SOURCE_LABEL,
                        "path": str(record.get("path") or ""),
                        "readonly": False,
                        "count": 0,
                    }
                    folders.append(folder)
                    folder_map[folder_id] = folder
                folder.update({
                    "managed": True,
                    "source_type": "managed",
                    "removable": True,
                    "missing": False,
                    "hidden_count": 0,
                    "total_count": int(folder.get("count", 0) or 0),
                })
        except Exception as exc:
            errors.append(f"{self.USER_SOURCE_LABEL}: {type(exc).__name__}: {exc}")

        for folder in folders:
            folder_id = str(folder.get("id") or "")
            if folder_id.startswith(self.USER_FOLDER_PREFIX) and folder_id != managed_root_id:
                folder["managed"] = True
                folder["source_type"] = "managed"
                folder["removable"] = True
                folder.setdefault("hidden_count", 0)
                folder.setdefault("total_count", int(folder.get("count", 0) or 0))

        def source_rank(item):
            folder_id = str(item.get("folder_id") or "")
            if folder_id.startswith(self.LINKED_PREFIX):
                return 0
            if folder_id.startswith(self.USER_FOLDER_PREFIX):
                return 1
            return 2

        assets.sort(key=lambda item: (
            source_rank(item),
            str(item.get("folder_label") or "").casefold(),
            str(item.get("name") or "").casefold(),
        ))
        assets = assets[:max(1, int(max_files))]

        counts = {}
        for item in assets:
            folder_id = str(item.get("folder_id") or "")
            if folder_id:
                counts[folder_id] = counts.get(folder_id, 0) + 1
        for folder in folders:
            folder["count"] = int(counts.get(str(folder.get("id") or ""), 0))
            if bool(folder.get("managed", False)):
                folder["total_count"] = int(folder.get("count", 0) or 0)

        # System buckets are content sources, not user navigation. Their assets
        # remain available through 全部, but they never appear as left-side rows.
        hidden_nav_ids = {
            managed_root_id,
            self.TEST_SEED_FOLDER_ID,
            self.CURRENT_FILE_FOLDER_ID,
        }
        folders = [
            folder for folder in folders
            if str(folder.get("id") or "") not in hidden_nav_ids
            and (
                str(folder.get("id") or "").startswith(self.LINKED_PREFIX)
                or str(folder.get("id") or "").startswith(self.USER_FOLDER_PREFIX)
                or int(folder.get("count", 0) or 0) > 0
            )
        ]
        folders.sort(key=lambda folder: (
            0 if str(folder.get("id") or "").startswith(self.LINKED_PREFIX) else 1,
            0 if str(folder.get("id") or "").startswith(self.USER_FOLDER_PREFIX) else 1,
            str(folder.get("label") or "").casefold(),
        ))

        result.update({
            "assets": assets,
            "folders": folders,
            "errors": errors[-8:],
            "asset_count": len(assets),
            "folder_count": len(folders),
            "linked_source_count": len(linked_folders),
        })
        return result
