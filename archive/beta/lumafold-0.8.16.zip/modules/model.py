from __future__ import annotations

MODULE_MANIFEST = {
    "id": "model", "name": "Model", "version": "0.6", "category": "Create",
    "api_version": "1", "entry": "register", "hosts": ("embedded", "satellite", "desktop"),
    "description": "Modeling workspace module."
}

from ..core.platform import ModuleSpec


def register(app):
    module_id = "model"
    app.register_state_schema(module_id, 1, exclude_keys=("lifecycle", "activation_count"))
    state = app.store.namespace(module_id, {
        "bevel_width": 0.02,
        "bevel_segments": 3,
        "lifecycle": "REGISTERED",
        "activation_count": 0,
    })

    def on_activate(context, status):
        state["lifecycle"] = "ACTIVE"
        state["activation_count"] = int(state.get("activation_count", 0)) + 1

    def on_deactivate(context, status):
        state["lifecycle"] = "INACTIVE"

    def nudge(delta=0.10):
        result = app.services.require("blender.object").nudge_active_x(delta)
        app.events.emit("model.object.changed", {"action": "nudge_x", "delta": float(delta)})
        return result

    def add_bevel(width=None, segments=None):
        if width is not None:
            state["bevel_width"] = max(0.0, float(width))
        if segments is not None:
            state["bevel_segments"] = max(1, int(segments))
        result = app.services.require("blender.object").add_bevel_modifier(
            state["bevel_width"], state["bevel_segments"]
        )
        app.events.emit("model.modifier.changed", {
            "modifier": "BEVEL",
            "width": state["bevel_width"],
            "segments": state["bevel_segments"],
        })
        return result

    app.commands.register("model.nudge_x", nudge)
    app.commands.register("model.add_bevel", add_bevel)
    app.modules.register(ModuleSpec(
        module_id=module_id,
        label="Model",
        category="Create",
        version="0.6",
        description="Model shell automatically activates only in supported mesh contexts.",
        hosts=("embedded", "satellite", "desktop"),
        modes=("OBJECT", "EDIT_MESH"),
        requires=("object.active", "object.mesh"),
        capabilities=("mesh.modify", "modifier.bevel", "object.transform"),
        commands=("model.nudge_x", "model.add_bevel"),
    ), on_activate=on_activate, on_deactivate=on_deactivate)
