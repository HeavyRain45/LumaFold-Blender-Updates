from __future__ import annotations

MODULE_MANIFEST = {
    "id": "sculpt", "name": "Sculpt", "version": "1.7.1", "category": "Create",
    "api_version": "1", "entry": "register", "hosts": ("embedded", "satellite", "desktop"),
    "description": "Compact multi-host Sculpt workspace with real Blender Brush + Alpha libraries."
}

from ..core.platform import ModuleSpec


_ESSENTIALS_PREFIX = "brushes/essentials_brushes-mesh_sculpt.blend/Brush/"
_DEFAULT_BRUSHES = (
    ("Draw", "Draw"),
    ("Clay", "Clay"),
    ("Crease", "Crease Polish"),
    ("Smooth", "Smooth"),
    ("Inflate", "Inflate/Deflate"),
    ("Grab", "Grab"),
    ("Scrape", "Scrape/Fill"),
    ("Mask", "Mask"),
)
_QUICK_COLUMNS = 4
_MIN_QUICK_ROWS = 2
_MAX_QUICK_ROWS = 4
_MAX_QUICK_SLOTS = _QUICK_COLUMNS * _MAX_QUICK_ROWS


def _empty_slot(index: int):
    return {
        "slot_id": f"quick_{index+1:02d}",
        "label": "",
        "asset_library_type": "",
        "asset_library_identifier": "",
        "relative_asset_identifier": "",
        "empty": True,
    }


def default_quick_brush_slots():
    slots = []
    for index in range(_MAX_QUICK_SLOTS):
        if index < len(_DEFAULT_BRUSHES):
            label, asset_name = _DEFAULT_BRUSHES[index]
            slots.append({
                "slot_id": f"quick_{index+1:02d}",
                "label": label,
                "asset_library_type": "ESSENTIALS",
                "asset_library_identifier": "",
                "relative_asset_identifier": _ESSENTIALS_PREFIX + asset_name,
                "empty": False,
            })
        else:
            slots.append(_empty_slot(index))
    return slots


def _normalize_asset(value):
    return str(value or "").replace("\\", "/").strip()


def _normalize_slots(slots):
    defaults = default_quick_brush_slots()
    source = list(slots or ())
    normalized = []
    for index in range(_MAX_QUICK_SLOTS):
        fallback = defaults[index]
        src = dict(source[index] if index < len(source) else fallback)
        rel = _normalize_asset(src.get("relative_asset_identifier"))
        normalized.append({
            "slot_id": str(src.get("slot_id") or f"quick_{index+1:02d}"),
            "label": str(src.get("label") or "") if rel else "",
            "asset_library_type": str(src.get("asset_library_type") or "") if rel else "",
            "asset_library_identifier": str(src.get("asset_library_identifier") or "") if rel else "",
            "relative_asset_identifier": rel,
            "empty": not bool(rel),
        })
    return normalized


def _migrate_v1_to_v2(data):
    data = dict(data or {})
    data.setdefault("quick_brush_slots", default_quick_brush_slots()[:8])
    return data


def _migrate_v2_to_v3(data):
    data = dict(data or {})
    slots = list(data.get("quick_brush_slots") or default_quick_brush_slots()[:8])
    normalized = []
    defaults = default_quick_brush_slots()
    for index in range(8):
        slot = dict(slots[index] if index < len(slots) else defaults[index])
        slot.setdefault("slot_id", f"quick_{index+1:02d}")
        normalized.append(slot)
    data["quick_brush_slots"] = normalized
    return data


def _migrate_v3_to_v4(data):
    data = dict(data or {})
    data["quick_brush_slots"] = _normalize_slots(list(data.get("quick_brush_slots") or ())[:8])[:8]
    return data


def _migrate_v4_to_v5(data):
    data = dict(data or {})
    old_slots = list(data.get("quick_brush_slots") or ())
    data["quick_brush_slots"] = _normalize_slots(old_slots)
    rows = int(data.get("quick_rows", 2) or 2)
    rows = max(_MIN_QUICK_ROWS, min(_MAX_QUICK_ROWS, rows))
    data["quick_rows"] = rows
    data["slot_count"] = rows * _QUICK_COLUMNS
    return data


def _migrate_v5_to_v6(data):
    data = dict(data or {})
    favorites = list(data.get("brush_library_favorites") or ())
    data["brush_library_favorites"] = [str(item) for item in favorites if str(item or "").strip()]
    return data


def _migrate_v6_to_v7(data):
    data = dict(data or {})
    favorites = list(data.get("alpha_library_favorites") or ())
    data["alpha_library_favorites"] = [str(item) for item in favorites if str(item or "").strip()]
    return data


def _save_user_state(app):
    try:
        app.persistence.save(force=True)
    except Exception:
        pass


def _asset_identity(name, asset):
    rel = _normalize_asset((asset or {}).get("relative_asset_identifier"))
    if rel:
        return "asset|{}|{}|{}".format(
            str((asset or {}).get("asset_library_type") or "").casefold(),
            str((asset or {}).get("asset_library_identifier") or "").casefold(),
            rel.casefold(),
        )
    return "local|" + str(name or "").casefold()


def sync_brush_state(app):
    """Read Blender's current Sculpt brush into host-independent Sculpt state."""
    state = app.store.namespace("sculpt")
    service = app.services.get("blender.brush")
    if service is None:
        return None
    try:
        snap = dict(service.current_sculpt_brush() or {})
    except Exception as exc:
        state["brush_sync_status"] = f"读取失败: {type(exc).__name__}: {exc}"
        return None

    name = str(snap.get("name") or "")
    asset = {
        "asset_library_type": str(snap.get("asset_library_type") or ""),
        "asset_library_identifier": str(snap.get("asset_library_identifier") or ""),
        "relative_asset_identifier": _normalize_asset(snap.get("relative_asset_identifier")),
    }
    state["current_brush_name"] = name
    state["current_brush_asset"] = asset
    state["current_brush_type"] = str(snap.get("sculpt_brush_type") or "")

    identity = _asset_identity(name, asset)
    preview_cache = state.setdefault("brush_preview_cache", {})
    preview = dict(preview_cache.get(identity) or {}) if identity else {}
    if identity and not preview and snap.get("available"):
        try:
            payload = dict(service.current_sculpt_brush_preview(max_edge=72) or {})
        except Exception:
            payload = {}
        if payload.get("rgba_b64"):
            payload["key"] = identity
            preview_cache[identity] = payload
            if len(preview_cache) > 12:
                for old_key in tuple(preview_cache.keys())[:-12]:
                    preview_cache.pop(old_key, None)
            preview = payload
    state["current_brush_preview"] = preview

    matched = -1
    slots = _normalize_slots(state.get("quick_brush_slots") or ())
    state["quick_brush_slots"] = slots
    current_rel = asset["relative_asset_identifier"].casefold()
    current_lib = asset["asset_library_type"].casefold()
    current_ident = asset["asset_library_identifier"].casefold()
    for index, slot in enumerate(slots):
        slot_rel = _normalize_asset(slot.get("relative_asset_identifier")).casefold()
        slot_lib = str(slot.get("asset_library_type") or "").casefold()
        slot_ident = str(slot.get("asset_library_identifier") or "").casefold()
        if current_rel and current_rel == slot_rel and current_lib == slot_lib and current_ident == slot_ident:
            matched = index
            break
        if not current_rel and name and name.casefold() == str(slot.get("label") or "").casefold():
            matched = index
            break
    state["active_quick_slot"] = int(matched)
    if matched >= 0:
        state["quick_slot"] = int(matched)
    state["brush_sync_status"] = "SYNCED" if snap.get("available") else "NO_ACTIVE_BRUSH"
    return snap



def sync_alpha_state(app):
    """Read the active Sculpt Brush texture into host-independent Alpha state."""
    state = app.store.namespace("sculpt")
    service = app.services.get("blender.alpha")
    if service is None:
        return None
    try:
        snap = dict(service.current_sculpt_alpha() or {})
    except Exception as exc:
        state["alpha_sync_status"] = f"读取失败: {type(exc).__name__}: {exc}"
        return None
    state["current_alpha_name"] = str(snap.get("name") or "默认")
    state["current_alpha_identity"] = str(snap.get("identity") or "none")
    state["current_alpha_filepath"] = str(snap.get("filepath") or "")
    state["current_alpha_map_mode"] = str(snap.get("map_mode") or "")
    preview = {}
    if snap.get("available"):
        try:
            preview = dict(service.current_sculpt_alpha_preview(max_edge=72) or {})
        except Exception:
            preview = {}
    if preview:
        preview["key"] = state["current_alpha_identity"]
    state["current_alpha_preview"] = preview
    state["alpha_sync_status"] = "SYNCED"
    return snap

def register(app):
    module_id = "sculpt"
    app.register_state_schema(
        module_id,
        7,
        migrations={1: _migrate_v1_to_v2, 2: _migrate_v2_to_v3, 3: _migrate_v3_to_v4, 4: _migrate_v4_to_v5, 5: _migrate_v5_to_v6, 6: _migrate_v6_to_v7},
        exclude_keys=(
            "lifecycle", "activation_count", "active_quick_slot",
            "current_brush_name", "current_brush_asset", "current_brush_type",
            "current_brush_preview", "brush_preview_cache",
            "brush_sync_status", "brush_action_status",
            "brush_library_assets", "brush_library_folders", "brush_library_status",
            "brush_library_errors", "brush_library_preview_cache", "brush_library_scan_serial",
            "current_alpha_name", "current_alpha_identity", "current_alpha_filepath", "current_alpha_map_mode",
            "current_alpha_preview", "alpha_sync_status", "alpha_action_status",
            "alpha_library_assets", "alpha_library_folders", "alpha_library_status",
            "alpha_library_errors", "alpha_library_preview_cache", "alpha_library_scan_serial",
        ),
    )
    state = app.store.namespace(module_id, {
        "slot_count": 8,
        "quick_rows": 2,
        "quick_slot": 0,
        "quick_brush_slots": default_quick_brush_slots(),
        "active_quick_slot": -1,
        "current_brush_name": "",
        "current_brush_asset": {},
        "current_brush_type": "",
        "current_brush_preview": {},
        "brush_preview_cache": {},
        "brush_sync_status": "PENDING",
        "brush_action_status": "",
        "brush_library_assets": [],
        "brush_library_folders": [],
        "brush_library_favorites": [],
        "brush_library_status": "NOT_LOADED",
        "brush_library_errors": [],
        "brush_library_preview_cache": {},
        "brush_library_scan_serial": 0,
        "current_alpha_name": "默认",
        "current_alpha_identity": "none",
        "current_alpha_filepath": "",
        "current_alpha_map_mode": "",
        "current_alpha_preview": {},
        "alpha_sync_status": "PENDING",
        "alpha_action_status": "",
        "alpha_library_assets": [],
        "alpha_library_folders": [],
        "alpha_library_favorites": [],
        "alpha_library_status": "NOT_LOADED",
        "alpha_library_errors": [],
        "alpha_library_preview_cache": {},
        "alpha_library_scan_serial": 0,
        "brush_size": 72.0,
        "brush_strength": 0.50,
        "alpha_slot": 0,
        "embedded_preset": "compact",
        "satellite_preset": "compact",
        "last_mode": "OBJECT",
        "lifecycle": "REGISTERED",
        "activation_count": 0,
    })
    state["quick_brush_slots"] = _normalize_slots(state.get("quick_brush_slots"))
    state["quick_rows"] = max(_MIN_QUICK_ROWS, min(_MAX_QUICK_ROWS, int(state.get("quick_rows", 2) or 2)))
    state["slot_count"] = state["quick_rows"] * _QUICK_COLUMNS

    def on_activate(context, status):
        state["lifecycle"] = "ACTIVE"
        state["activation_count"] = int(state.get("activation_count", 0)) + 1
        sync_brush_state(app)
        sync_alpha_state(app)

    def on_deactivate(context, status):
        state["lifecycle"] = "INACTIVE"

    def enter():
        result = app.services.require("blender.mode").set_mode("SCULPT")
        state["last_mode"] = "SCULPT"
        app.events.emit("sculpt.mode.changed", {"mode": "SCULPT"})
        sync_brush_state(app)
        sync_alpha_state(app)
        return result

    def exit_to_object():
        result = app.services.require("blender.mode").set_mode("OBJECT")
        state["last_mode"] = "OBJECT"
        app.events.emit("sculpt.mode.changed", {"mode": "OBJECT"})
        return result

    def activate_slot(slot: int = 0):
        slot = int(slot)
        slots = _normalize_slots(state.get("quick_brush_slots") or ())
        if slot < 0 or slot >= len(slots):
            raise RuntimeError(f"Quick Brush Slot 越界: {slot}")
        spec = dict(slots[slot] or {})
        relative_asset_identifier = _normalize_asset(spec.get("relative_asset_identifier"))
        if bool(spec.get("empty")) or not relative_asset_identifier:
            raise RuntimeError(f"Quick Brush Slot {slot + 1} 为空")
        service = app.services.require("blender.brush")
        snapshot = service.activate_asset(
            asset_library_type=str(spec.get("asset_library_type") or "ESSENTIALS"),
            asset_library_identifier=str(spec.get("asset_library_identifier") or ""),
            relative_asset_identifier=relative_asset_identifier,
        )
        state["quick_slot"] = slot
        state["active_quick_slot"] = slot
        state["current_brush_name"] = str(snapshot.get("name") or spec.get("label") or "")
        state["current_brush_asset"] = {
            "asset_library_type": str(snapshot.get("asset_library_type") or spec.get("asset_library_type") or ""),
            "asset_library_identifier": str(snapshot.get("asset_library_identifier") or spec.get("asset_library_identifier") or ""),
            "relative_asset_identifier": _normalize_asset(snapshot.get("relative_asset_identifier") or spec.get("relative_asset_identifier")),
        }
        state["current_brush_type"] = str(snapshot.get("sculpt_brush_type") or "")
        state["brush_action_status"] = f"已切换: {state['current_brush_name']}"
        sync_brush_state(app)
        sync_alpha_state(app)
        app.events.emit("sculpt.brush.changed", {"slot": slot, "name": state["current_brush_name"]})
        return state["brush_action_status"]

    def assign_current_to_slot(slot: int = 0):
        slot = int(slot)
        slots = _normalize_slots(state.get("quick_brush_slots") or ())
        if slot < 0 or slot >= len(slots):
            raise RuntimeError(f"Quick Brush Slot 越界: {slot}")
        snap = sync_brush_state(app) or {}
        name = str(snap.get("name") or state.get("current_brush_name") or "").strip()
        rel = _normalize_asset(snap.get("relative_asset_identifier") or (state.get("current_brush_asset") or {}).get("relative_asset_identifier"))
        if not name or not rel:
            raise RuntimeError("当前笔刷没有可持久化的 Brush Asset 标识")
        asset = dict(state.get("current_brush_asset") or {})
        old = dict(slots[slot] or {})
        slots[slot] = {
            "slot_id": str(old.get("slot_id") or f"quick_{slot+1:02d}"),
            "label": name,
            "asset_library_type": str(asset.get("asset_library_type") or snap.get("asset_library_type") or "ESSENTIALS"),
            "asset_library_identifier": str(asset.get("asset_library_identifier") or snap.get("asset_library_identifier") or ""),
            "relative_asset_identifier": rel,
            "empty": False,
        }
        state["quick_brush_slots"] = slots
        state["quick_slot"] = slot
        state["active_quick_slot"] = slot
        state["brush_action_status"] = f"槽位 {slot + 1} 已替换为: {name}"
        _save_user_state(app)
        app.events.emit("sculpt.quick_slot.assigned", {"slot": slot, "name": name})
        return state["brush_action_status"]

    def clear_slot(slot: int = 0):
        slot = int(slot)
        slots = _normalize_slots(state.get("quick_brush_slots") or ())
        if slot < 0 or slot >= len(slots):
            raise RuntimeError(f"Quick Brush Slot 越界: {slot}")
        slots[slot] = _empty_slot(slot)
        state["quick_brush_slots"] = slots
        if int(state.get("active_quick_slot", -1)) == slot:
            state["active_quick_slot"] = -1
        state["brush_action_status"] = f"槽位 {slot + 1} 已清空"
        _save_user_state(app)
        app.events.emit("sculpt.quick_slot.cleared", {"slot": slot})
        return state["brush_action_status"]

    def reset_quick_slots():
        state["quick_brush_slots"] = default_quick_brush_slots()
        state["active_quick_slot"] = -1
        state["brush_action_status"] = "快捷笔刷已恢复默认"
        sync_brush_state(app)
        _save_user_state(app)
        app.events.emit("sculpt.quick_slots.reset", {})
        return state["brush_action_status"]

    def set_quick_rows(rows: int = 2):
        rows = max(_MIN_QUICK_ROWS, min(_MAX_QUICK_ROWS, int(rows)))
        state["quick_rows"] = rows
        state["slot_count"] = rows * _QUICK_COLUMNS
        state["quick_brush_slots"] = _normalize_slots(state.get("quick_brush_slots") or ())
        state["brush_action_status"] = f"快捷笔刷布局：{rows} 行 × {_QUICK_COLUMNS} 列"
        _save_user_state(app)
        app.events.emit("sculpt.quick_rows.changed", {"rows": rows})
        return state["brush_action_status"]

    def _library_asset(identity: str):
        identity = str(identity or "")
        for item in list(state.get("brush_library_assets") or ()):
            if str((item or {}).get("identity") or "") == identity:
                return dict(item or {})
        return None

    def refresh_brush_library():
        service = app.services.require("blender.brush")
        state["brush_library_status"] = "SCANNING"
        try:
            result = dict(service.list_sculpt_brush_assets() or {})
            state["brush_library_assets"] = list(result.get("assets") or ())
            state["brush_library_folders"] = list(result.get("folders") or ())
            state["brush_library_errors"] = list(result.get("errors") or ())
            state["brush_library_scan_serial"] = int(state.get("brush_library_scan_serial", 0)) + 1
            count = len(state["brush_library_assets"])
            state["brush_library_status"] = "READY" if count else "EMPTY"
            app.events.emit("sculpt.brush_library.refreshed", {"assets": count, "folders": len(state["brush_library_folders"])})
            return f"笔刷库已读取：{count} 个 Brush Asset"
        except Exception as exc:
            state["brush_library_status"] = "ERROR"
            state["brush_library_errors"] = [f"{type(exc).__name__}: {exc}"]
            raise

    def request_library_preview(identities=None, identity: str = ""):
        requested_ids = [str(item) for item in list(identities or ()) if str(item or "")]
        if identity:
            requested_ids.append(str(identity))
        # Preserve order while de-duplicating and cap one UI batch.
        requested_ids = list(dict.fromkeys(requested_ids))[:12]
        if not requested_ids:
            return "NO_PREVIEW_REQUEST"
        cache = state.setdefault("brush_library_preview_cache", {})
        service = app.services.require("blender.brush")
        pending_specs = []
        for asset_identity in requested_ids:
            if asset_identity in cache and (cache.get(asset_identity) or {}).get("rgba_b64"):
                continue
            spec = _library_asset(asset_identity)
            if spec is not None:
                pending_specs.append(spec)
        loaded_map = dict(service.brush_asset_previews(pending_specs, max_edge=64) or {}) if pending_specs else {}
        loaded = 0
        for asset_identity, payload_raw in loaded_map.items():
            payload = dict(payload_raw or {})
            if payload.get("rgba_b64"):
                payload["key"] = str(asset_identity)
                cache[str(asset_identity)] = payload
                loaded += 1
        # Keep bridge snapshots compact. Visible tiles can repopulate evicted entries.
        if len(cache) > 10:
            for old_key in tuple(cache.keys())[:-10]:
                cache.pop(old_key, None)
        return f"PREVIEW_READY:{loaded}"

    def activate_library_asset(identity: str):
        spec = _library_asset(identity)
        if spec is None:
            raise RuntimeError("笔刷资产已变化，请刷新笔刷库")
        service = app.services.require("blender.brush")
        snap = service.activate_asset(
            asset_library_type=str(spec.get("asset_library_type") or "ESSENTIALS"),
            asset_library_identifier=str(spec.get("asset_library_identifier") or ""),
            relative_asset_identifier=_normalize_asset(spec.get("relative_asset_identifier")),
        )
        sync_brush_state(app)
        sync_alpha_state(app)
        state["brush_action_status"] = f"已切换: {str(snap.get('name') or spec.get('name') or '')}"
        app.events.emit("sculpt.brush_library.activated", {"identity": str(identity), "name": str(spec.get("name") or "")})
        return state["brush_action_status"]

    def assign_asset_to_slot(identity: str, slot: int = 0):
        spec = _library_asset(identity)
        if spec is None:
            raise RuntimeError("笔刷资产已变化，请刷新笔刷库")
        slot = int(slot)
        slots = _normalize_slots(state.get("quick_brush_slots") or ())
        if slot < 0 or slot >= len(slots):
            raise RuntimeError(f"Quick Brush Slot 越界: {slot}")
        old = dict(slots[slot] or {})
        slots[slot] = {
            "slot_id": str(old.get("slot_id") or f"quick_{slot+1:02d}"),
            "label": str(spec.get("name") or "Brush"),
            "asset_library_type": str(spec.get("asset_library_type") or "ESSENTIALS"),
            "asset_library_identifier": str(spec.get("asset_library_identifier") or ""),
            "relative_asset_identifier": _normalize_asset(spec.get("relative_asset_identifier")),
            "empty": False,
        }
        state["quick_brush_slots"] = slots
        state["brush_action_status"] = f"槽位 {slot + 1} 已设为: {slots[slot]['label']}"
        _save_user_state(app)
        app.events.emit("sculpt.quick_slot.assigned_asset", {"slot": slot, "identity": str(identity)})
        return state["brush_action_status"]

    def toggle_library_favorite(identity: str):
        identity = str(identity or "")
        if not identity:
            raise RuntimeError("Brush Asset identity 为空")
        favorites = [str(item) for item in list(state.get("brush_library_favorites") or ()) if str(item or "")]
        if identity in favorites:
            favorites = [item for item in favorites if item != identity]
            result = "已取消收藏"
        else:
            favorites.append(identity)
            result = "已收藏"
        state["brush_library_favorites"] = favorites
        _save_user_state(app)
        app.events.emit("sculpt.brush_library.favorite_changed", {"identity": identity, "favorite": identity in favorites})
        return result

    def _alpha_asset(identity: str):
        identity = str(identity or "")
        for item in list(state.get("alpha_library_assets") or ()):
            if str((item or {}).get("identity") or "") == identity:
                return dict(item or {})
        return None

    def refresh_alpha_library():
        service = app.services.require("blender.alpha")
        state["alpha_library_status"] = "SCANNING"
        try:
            result = dict(service.list_sculpt_alphas() or {})
            state["alpha_library_assets"] = list(result.get("assets") or ())
            state["alpha_library_folders"] = list(result.get("folders") or ())
            state["alpha_library_errors"] = list(result.get("errors") or ())
            state["alpha_library_scan_serial"] = int(state.get("alpha_library_scan_serial", 0)) + 1
            count = len(state["alpha_library_assets"])
            state["alpha_library_status"] = "READY" if count else "EMPTY"
            sync_alpha_state(app)
            app.events.emit("sculpt.alpha_library.refreshed", {"assets": count, "folders": len(state["alpha_library_folders"])})
            return f"Alpha 库已读取：{count} 个图片资源"
        except Exception as exc:
            state["alpha_library_status"] = "ERROR"
            state["alpha_library_errors"] = [f"{type(exc).__name__}: {exc}"]
            raise

    def request_alpha_preview(identities=None, identity: str = ""):
        ids = [str(item) for item in list(identities or ()) if str(item or "")]
        if identity:
            ids.append(str(identity))
        ids = list(dict.fromkeys(ids))[:16]
        if not ids:
            return "NO_PREVIEW_REQUEST"
        cache = state.setdefault("alpha_library_preview_cache", {})
        service = app.services.require("blender.alpha")
        specs = []
        for ident in ids:
            if ident == "none" or (cache.get(ident) or {}).get("rgba_b64"):
                continue
            spec = _alpha_asset(ident)
            if spec is not None:
                specs.append(spec)
        loaded_map = dict(service.alpha_previews(specs, max_edge=64) or {}) if specs else {}
        loaded = 0
        for ident, raw in loaded_map.items():
            payload = dict(raw or {})
            if payload.get("rgba_b64"):
                payload["key"] = str(ident)
                cache[str(ident)] = payload
                loaded += 1
        if len(cache) > 8:
            for old_key in tuple(cache.keys())[:-8]:
                cache.pop(old_key, None)
        return f"ALPHA_PREVIEW_READY:{loaded}"

    def activate_alpha_library_asset(identity: str):
        identity = str(identity or "")
        service = app.services.require("blender.alpha")
        if identity == "none":
            snap = service.clear_alpha()
        else:
            spec = _alpha_asset(identity)
            if spec is None:
                raise RuntimeError("Alpha 资源已变化，请刷新 Alpha 库")
            snap = service.activate_alpha(spec)
        # Alpha activation may transparently switch an external/Essentials brush
        # to a local editable proxy; resync both Brush identity and Alpha state.
        sync_brush_state(app)
        sync_alpha_state(app)
        state["alpha_action_status"] = f"当前 Alpha：{str((snap or {}).get('name') or '默认')}"
        app.events.emit("sculpt.alpha_library.activated", {"identity": identity})
        return state["alpha_action_status"]

    def toggle_alpha_favorite(identity: str):
        identity = str(identity or "")
        if not identity or identity == "none":
            raise RuntimeError("默认 Alpha 不需要收藏")
        favorites = [str(item) for item in list(state.get("alpha_library_favorites") or ()) if str(item or "")]
        if identity in favorites:
            favorites = [item for item in favorites if item != identity]
            result = "已取消收藏"
        else:
            favorites.append(identity)
            result = "已收藏"
        state["alpha_library_favorites"] = favorites
        _save_user_state(app)
        app.events.emit("sculpt.alpha_library.favorite_changed", {"identity": identity, "favorite": identity in favorites})
        return result

    def open_alpha_import_dialog():
        import bpy
        # Always defer the file-selector invoke out of the current Core/ImGui
        # command frame.  DesktopBridge already dispatches commands on Blender's
        # main thread; this extra timer keeps the operator lifecycle independent.
        def _invoke():
            try:
                bpy.ops.lumafold.import_alpha_images('INVOKE_DEFAULT')
            except Exception as exc:
                state["alpha_action_status"] = "Alpha 导入窗口打开失败：" + str(exc)
            return None
        bpy.app.timers.register(_invoke, first_interval=0.0)
        return "打开 Alpha 图片导入窗口"

    app.commands.register("sculpt.enter", enter)
    app.commands.register("sculpt.exit_to_object", exit_to_object)
    app.commands.register("sculpt.brush.activate_slot", activate_slot)
    app.commands.register("sculpt.brush.assign_current_to_slot", assign_current_to_slot)
    app.commands.register("sculpt.brush.clear_slot", clear_slot)
    app.commands.register("sculpt.brush.reset_quick_slots", reset_quick_slots)
    app.commands.register("sculpt.brush.set_quick_rows", set_quick_rows)
    app.commands.register("sculpt.brush.library_refresh", refresh_brush_library)
    app.commands.register("sculpt.brush.library_preview", request_library_preview)
    app.commands.register("sculpt.brush.library_activate", activate_library_asset)
    app.commands.register("sculpt.brush.library_assign_slot", assign_asset_to_slot)
    app.commands.register("sculpt.brush.library_toggle_favorite", toggle_library_favorite)
    app.commands.register("sculpt.alpha.library_refresh", refresh_alpha_library)
    app.commands.register("sculpt.alpha.library_preview", request_alpha_preview)
    app.commands.register("sculpt.alpha.library_activate", activate_alpha_library_asset)
    app.commands.register("sculpt.alpha.library_toggle_favorite", toggle_alpha_favorite)
    app.commands.register("sculpt.alpha.library_import_dialog", open_alpha_import_dialog)
    app.modules.register(ModuleSpec(
        module_id=module_id,
        label="Sculpt",
        category="Create",
        version="1.7.2",
        description="S0.7.3 window-level Embedded input routing, workspace-roaming Host, and Essentials-compatible real Alpha workflow.",
        hosts=("embedded", "satellite", "desktop"),
        modes=("OBJECT", "SCULPT"),
        requires=("object.active", "object.mesh"),
        capabilities=("mode.sculpt", "brush.quick", "brush.asset", "brush.library", "alpha.browser", "alpha.real"),
        commands=(
            "sculpt.enter", "sculpt.exit_to_object", "sculpt.brush.activate_slot",
            "sculpt.brush.assign_current_to_slot", "sculpt.brush.clear_slot", "sculpt.brush.reset_quick_slots",
            "sculpt.brush.set_quick_rows",
            "sculpt.brush.library_refresh", "sculpt.brush.library_preview",
            "sculpt.brush.library_activate", "sculpt.brush.library_assign_slot",
            "sculpt.brush.library_toggle_favorite",
            "sculpt.alpha.library_refresh", "sculpt.alpha.library_preview",
            "sculpt.alpha.library_activate", "sculpt.alpha.library_toggle_favorite",
            "sculpt.alpha.library_import_dialog",
        ),
    ), on_activate=on_activate, on_deactivate=on_deactivate)
