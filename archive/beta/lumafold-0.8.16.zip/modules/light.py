from __future__ import annotations

MODULE_MANIFEST = {
    "id": "light", "name": "Light", "version": "0.6", "category": "Scene",
    "api_version": "1", "entry": "register", "hosts": ("embedded", "satellite", "desktop"),
    "description": "Lighting workspace module."
}

from ..core.platform import ModuleSpec


def register(app):
    module_id = "light"
    app.register_state_schema(module_id, 1, exclude_keys=("lifecycle", "activation_count"))
    state = app.store.namespace(module_id, {
        "energy": 1000.0,
        "size": 3.0,
        "bound_light": "",
        "lifecycle": "REGISTERED",
        "activation_count": 0,
    })

    def on_activate(context, status):
        state["lifecycle"] = "ACTIVE"
        state["activation_count"] = int(state.get("activation_count", 0)) + 1

    def on_deactivate(context, status):
        state["lifecycle"] = "INACTIVE"

    def select_first():
        result = app.services.require("blender.light").select_first_scene_light()
        app.events.emit("light.selection.changed", {"source": "scene"})
        return result

    def create_area(energy=None, size=None):
        if energy is not None:
            state["energy"] = max(0.0, float(energy))
        if size is not None:
            state["size"] = max(0.01, float(size))
        result = app.services.require("blender.light").create_area_light(state["energy"], state["size"])
        app.events.emit("light.created", {"type": "AREA"})
        return result

    def apply(energy=None, size=None):
        if energy is not None:
            state["energy"] = max(0.0, float(energy))
        if size is not None:
            state["size"] = max(0.01, float(size))
        result = app.services.require("blender.light").set_active_params(state["energy"], state["size"])
        app.events.emit("light.params.changed", {"energy": state["energy"], "size": state["size"]})
        return result

    app.commands.register("light.select_first", select_first)
    app.commands.register("light.create_area", create_area)
    app.commands.register("light.apply", apply)
    app.modules.register(ModuleSpec(
        module_id=module_id,
        label="Light",
        category="Scene",
        version="0.6",
        description="Lighting workspace available in Object Mode; selected-light controls activate contextually.",
        hosts=("embedded", "satellite", "desktop"),
        modes=("OBJECT",),
        requires=(),
        capabilities=("light.create", "light.energy", "light.size"),
        commands=("light.select_first", "light.create_area", "light.apply"),
    ), on_activate=on_activate, on_deactivate=on_deactivate)
