from __future__ import annotations

MODULE_MANIFEST = {
    "id": "render", "name": "Render", "version": "0.6", "category": "Output",
    "api_version": "1", "entry": "register", "hosts": ("embedded", "satellite", "desktop"),
    "description": "Render workspace module."
}

from ..core.platform import ModuleSpec


def register(app):
    module_id = "render"
    app.register_state_schema(module_id, 1, exclude_keys=("lifecycle", "activation_count"))
    state = app.store.namespace(module_id, {
        "resolution_x": 1920,
        "resolution_y": 1080,
        "percentage": 100,
        "lifecycle": "REGISTERED",
        "activation_count": 0,
    })

    def on_activate(context, status):
        state["lifecycle"] = "ACTIVE"
        state["activation_count"] = int(state.get("activation_count", 0)) + 1

    def on_deactivate(context, status):
        state["lifecycle"] = "INACTIVE"

    def sync_from_scene():
        summary = app.services.require("blender.render").summary()
        state["resolution_x"] = int(summary["resolution_x"])
        state["resolution_y"] = int(summary["resolution_y"])
        state["percentage"] = int(summary["percentage"])
        app.events.emit("render.settings.synced", dict(summary))
        return f"synced {summary['resolution_x']}x{summary['resolution_y']} @ {summary['percentage']}%"

    def apply(resolution_x=None, resolution_y=None, percentage=None):
        if resolution_x is not None:
            state["resolution_x"] = max(4, int(resolution_x))
        if resolution_y is not None:
            state["resolution_y"] = max(4, int(resolution_y))
        if percentage is not None:
            state["percentage"] = max(1, min(100, int(percentage)))
        result = app.services.require("blender.render").apply(
            state["resolution_x"], state["resolution_y"], state["percentage"]
        )
        app.events.emit("render.settings.changed", {
            "resolution_x": state["resolution_x"],
            "resolution_y": state["resolution_y"],
            "percentage": state["percentage"],
        })
        return result

    def preset_hd():
        return apply(1920, 1080, state.get("percentage", 100))

    def preset_4k():
        return apply(3840, 2160, state.get("percentage", 100))

    app.commands.register("render.sync_from_scene", sync_from_scene)
    app.commands.register("render.apply", apply)
    app.commands.register("render.preset_hd", preset_hd)
    app.commands.register("render.preset_4k", preset_4k)
    app.modules.register(ModuleSpec(
        module_id=module_id,
        label="Render",
        category="Output",
        version="0.6",
        description="Scene-level render workspace; intentionally independent of active object and Blender mode.",
        hosts=("embedded", "satellite", "desktop"),
        modes=(),
        requires=(),
        capabilities=("render.settings", "render.resolution", "render.output"),
        commands=("render.sync_from_scene", "render.apply", "render.preset_hd", "render.preset_4k"),
    ), on_activate=on_activate, on_deactivate=on_deactivate)
