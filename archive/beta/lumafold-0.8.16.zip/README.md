# LumaFold - Blender

Private development repository for LumaFold - Blender.

Current development baseline: **S0.7.3 / Blender 5.2.1 LTS / Windows x64**.

## Branches

- `main` — stable milestones only.
- `dev` — active development and tester builds.

## Development workflow

Daily iteration happens on `dev`. Pull the latest `dev` changes locally, then reload/restart LumaFold in Blender for testing. ZIP packages are reserved for stable milestones and recovery builds.

See `README_TEST.md`, `UI_DESIGN_SYSTEM.md`, and `SDK_V1.md` for current test scope and architecture contracts.
