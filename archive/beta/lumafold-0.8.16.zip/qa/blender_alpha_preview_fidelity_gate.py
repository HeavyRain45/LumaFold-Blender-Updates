from __future__ import annotations

"""Real Blender 5.2.1 gate for Alpha selector + thumbnail fidelity."""

import base64
import bpy
import importlib
import importlib.util
import json
from pathlib import Path
import struct
import sys
import tempfile
import traceback
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
RESULT_PATH = ROOT / "blender_alpha_preview_fidelity_result.json"
if "--" in sys.argv:
    rest = sys.argv[sys.argv.index("--") + 1:]
    for idx, value in enumerate(rest):
        if value == "--result-path" and idx + 1 < len(rest):
            RESULT_PATH = Path(rest[idx + 1]).resolve()


def write_result(ok: bool, stage: str, detail: str = "", extra=None):
    payload = {
        "ok": bool(ok),
        "stage": str(stage),
        "detail": str(detail),
        "blender_version": bpy.app.version_string,
        "background": bool(bpy.app.background),
        "extra": dict(extra or {}),
    }
    RESULT_PATH.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print("LUMAFOLD_ALPHA_FIDELITY_GATE", json.dumps(payload, ensure_ascii=False), flush=True)


def load_addon():
    name = "lumafold_alpha_fidelity_ci"
    for key in tuple(sys.modules):
        if key == name or key.startswith(name + "."):
            sys.modules.pop(key, None)
    spec = importlib.util.spec_from_file_location(
        name,
        ROOT / "__init__.py",
        submodule_search_locations=[str(ROOT)],
    )
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    sys.modules[name] = module
    spec.loader.exec_module(module)
    module.register()
    return module


def write_bmp(path: Path):
    """Write a 4x2 opaque grayscale BMP with known visual top/bottom rows."""
    width, height = 4, 2
    top = [200, 180, 160, 140]
    bottom = [50, 60, 70, 80]
    rows = []
    # Positive-height BMP stores rows bottom-up.
    for values in (bottom, top):
        row = bytearray()
        for value in values:
            row.extend((value, value, value))  # B, G, R are equal for grayscale.
        rows.append(bytes(row))
    pixel_data = b"".join(rows)
    offset = 14 + 40
    file_size = offset + len(pixel_data)
    file_header = b"BM" + struct.pack("<IHHI", file_size, 0, 0, offset)
    info_header = struct.pack(
        "<IIIHHIIIIII",
        40, width, height, 1, 24, 0, len(pixel_data), 2835, 2835, 0, 0,
    )
    path.write_bytes(file_header + info_header + pixel_data)
    return {"top": top, "bottom": bottom, "width": width, "height": height}


def pixel(raw: bytes, side: int, x: int, y: int):
    base = (y * side + x) * 4
    return tuple(raw[base:base + 4])


def main():
    addon = None
    temp = None
    try:
        if tuple(bpy.app.version[:3]) != (5, 2, 1):
            raise RuntimeError(f"expected Blender 5.2.1, got {bpy.app.version_string}")
        addon = load_addon()
        app = addon.APP
        alpha = app.services.require("blender.alpha")

        temp = tempfile.TemporaryDirectory(prefix="lumafold_alpha_fidelity_")
        root = Path(temp.name)
        folder = root / "My Alpha Folder"
        folder.mkdir(parents=True)
        image_path = folder / "orientation_aspect_value.bmp"
        truth = write_bmp(image_path)

        payload = dict(alpha._file_pixels_payload(image_path, max_edge=8) or {})
        side_w = int(payload.get("width", 0) or 0)
        side_h = int(payload.get("height", 0) or 0)
        content_w = int(payload.get("content_width", 0) or 0)
        content_h = int(payload.get("content_height", 0) or 0)
        content_x = int(payload.get("content_x", -1))
        content_y = int(payload.get("content_y", -1))
        if (side_w, side_h) != (4, 4):
            raise RuntimeError(f"preview must be square 4x4, got {(side_w, side_h)}")
        if (content_w, content_h, content_x, content_y) != (4, 2, 0, 1):
            raise RuntimeError(
                "aspect contain contract failed: "
                f"content={(content_w, content_h)} offset={(content_x, content_y)}"
            )
        if str(payload.get("source") or "") != "alpha_data_pixels":
            raise RuntimeError("Alpha preview did not use the data-fidelity path")

        raw = base64.b64decode(str(payload.get("rgba_b64") or ""))
        if len(raw) != side_w * side_h * 4:
            raise RuntimeError("preview byte count does not match square canvas")

        # Padding proves the 4x2 source was contained, not stretched to 4x4.
        if any(pixel(raw, side_w, x, 0)[3] != 0 for x in range(side_w)):
            raise RuntimeError("top letterbox padding is not transparent")
        if any(pixel(raw, side_w, x, 3)[3] != 0 for x in range(side_w)):
            raise RuntimeError("bottom letterbox padding is not transparent")

        preview_top = [pixel(raw, side_w, x, 1)[0] for x in range(4)]
        preview_bottom = [pixel(raw, side_w, x, 2)[0] for x in range(4)]
        for got, expected in zip(preview_top, truth["top"]):
            if abs(int(got) - int(expected)) > 2:
                raise RuntimeError(f"top row value drift/gamma detected: got={preview_top} expected={truth['top']}")
        for got, expected in zip(preview_bottom, truth["bottom"]):
            if abs(int(got) - int(expected)) > 2:
                raise RuntimeError(f"bottom row value drift/gamma detected: got={preview_bottom} expected={truth['bottom']}")
        if sum(preview_top) <= sum(preview_bottom):
            raise RuntimeError("preview orientation is vertically inverted")

        selector = importlib.import_module(addon.__name__ + ".runtime.alpha_import_product")
        folder_fake = SimpleNamespace(directory="", filepath=str(folder), files=[])
        folder_paths = selector._selection_paths(folder_fake)
        if folder_paths != [folder.resolve()]:
            raise RuntimeError("direct folder selection did not resolve to the selected folder: " + repr(folder_paths))

        file_fake = SimpleNamespace(
            directory=str(folder),
            filepath=str(image_path),
            files=[SimpleNamespace(name=image_path.name)],
        )
        file_paths = selector._selection_paths(file_fake)
        if file_paths != [image_path.resolve()]:
            raise RuntimeError("single-file selection did not resolve only the selected file: " + repr(file_paths))

        write_result(
            True,
            "complete",
            "folder/file selector + orientation + aspect contain + raw Alpha values passed",
            extra={
                "canvas": [side_w, side_h],
                "content": [content_w, content_h],
                "offset": [content_x, content_y],
                "top": preview_top,
                "bottom": preview_bottom,
            },
        )
        return 0
    except Exception:
        write_result(False, "fidelity_failure", traceback.format_exc())
        return 2
    finally:
        if addon is not None:
            try:
                addon.unregister()
            except Exception:
                pass
        if temp is not None:
            try:
                temp.cleanup()
            except Exception:
                pass


raise SystemExit(main())
