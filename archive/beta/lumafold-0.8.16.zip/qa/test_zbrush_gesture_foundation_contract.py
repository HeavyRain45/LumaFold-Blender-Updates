from __future__ import annotations

"""Static contract for modular ZBrush gesture foundation."""

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ADDON = (ROOT / "__init__.py").read_text(encoding="utf-8")
ROUTE = (ROOT / "runtime" / "sculpt_route_truth.py").read_text(encoding="utf-8")
ALT = (ROOT / "runtime" / "sculpt_alt_gesture.py").read_text(encoding="utf-8")
ZOOM = (ROOT / "runtime" / "sculpt_alt_zoom.py").read_text(encoding="utf-8")
MASK = (ROOT / "runtime" / "sculpt_mask_gesture.py").read_text(encoding="utf-8")
LOCALITY = (ROOT / "runtime" / "tablet_pointer_locality.py").read_text(encoding="utf-8")
PROBE = (ROOT / "runtime" / "satellite_input_probe.py").read_text(encoding="utf-8")


def require(text: str, token: str, label: str):
    if token not in text:
        raise AssertionError(f"{label} missing: {token}")


def main():
    require(ADDON, 'runtime.sculpt_alt_zoom', "continuous zoom module wiring")
    require(ADDON, 'runtime.sculpt_alt_gesture', "Alt gesture module wiring")
    require(ADDON, 'runtime.sculpt_mask_gesture', "Mask gesture module wiring")
    require(ADDON, 'runtime.tablet_pointer_locality', "tablet locality module wiring")
    require(ADDON, 'sculpt_alt_gesture.install(real_machine_trace, sculpt_alt_zoom)', "Alt zoom dependency injection")
    require(ADDON, 'sculpt_mask_gesture.install(real_machine_trace)', "Mask gesture registration")
    require(ADDON, 'satellite_input_probe.install(sculpt_input_core, tablet_pointer_locality)', "locality observer wiring")

    require(ROUTE, '_ALT_GESTURE.handle_pointer_press(context, event, target)', "isolated Alt route")
    require(ROUTE, '_MASK_GESTURE.handle_pointer_press(context, event, target)', "single-owner mask route")
    require(ROUTE, '"zbrush_mask_gesture"', "mask owner route evidence")
    if "_recent_alt()" in ROUTE:
        raise AssertionError("route authority still arms new gestures from Alt grace")

    require(ALT, 'if not bool(getattr(event, "alt", False)):', "strict Alt start truth")
    require(ALT, 'bpy.ops.sculpt.brush_stroke(', "native inverse Sculpt")
    require(ALT, 'mode="INVERT"', "native inverse mode")
    require(ALT, 'bpy.ops.object.transfer_mode("INVOKE_DEFAULT")', "native object transfer")
    require(ALT, '_ZOOM.apply(context, dx, dy)', "continuous zoom delegation")
    for forbidden in ("_ALT_GRACE_SECONDS", "_recent_alt", "_ZOOM_PIXELS_PER_STEP", "bpy.ops.view3d.zoom(", "SetCursorPos", "ClipCursor"):
        if forbidden in ALT:
            raise AssertionError("Alt gesture isolation violated by: " + forbidden)

    require(ZOOM, 'ZOOM_LOG_GAIN = 0.0028325', "validated continuous zoom speed")
    require(ZOOM, 'return (float(dx) - float(dy)) / math.sqrt(2.0)', "normalized 2D zoom direction")
    require(ZOOM, 'rv3d.view_distance =', "isolated continuous distance mutation")
    if "bpy.ops.view3d.zoom(" in ZOOM:
        raise AssertionError("continuous tablet zoom regressed to integer EXEC stepping")

    require(MASK, 'filter_type": "SHARPEN" if sharpen else "SMOOTH"', "native mask filters")
    require(MASK, '"auto_iteration_count": True', "adaptive visible mask filter pass")
    require(MASK, 'self._start_on_surface = bool(_drag_hits_active_surface(context, event))', "mask-local start intent")
    require(MASK, 'if self._start_on_surface:', "surface/background split")
    require(MASK, '_run_mask_flood(context, "INVERT")', "background tap invert")
    require(MASK, '_run_mask_flood(context, "VALUE", value=0.0)', "background drag clear")
    require(MASK, 'bpy.ops.paint.mask_flood_fill', "Blender-native clear/invert")
    require(MASK, 'bpy.ops.paint.mask_box_gesture', "Blender-native box mask")
    require(MASK, 'brush_toggle="MASK"', "native mask drag handoff")
    require(MASK, '"ZBRUSH_MASK_GESTURE"', "mask gesture trace")

    # Mask hit testing is allowed only inside the isolated mask owner. Route-level
    # ordinary Sculpt/Rotate arbitration must never depend on this classifier.
    press_gate = MASK.find('def handle_pointer_press')
    hit_gate = MASK.find('_drag_hits_active_surface(context, event)', press_gate)
    if hit_gate >= 0:
        raise AssertionError("route entry itself is gated by mask surface ray cast")

    require(LOCALITY, "GetCursorPos", "Windows cursor truth")
    require(LOCALITY, "WindowFromPoint", "Windows window-under-cursor truth")
    require(LOCALITY, "MonitorFromPoint", "Windows cursor monitor truth")
    require(LOCALITY, "MonitorFromWindow", "Windows foreground monitor truth")
    require(LOCALITY, '"cursor_foreground_monitor_mismatch"', "cross-monitor mismatch evidence")
    require(LOCALITY, '"tablet_api"', "Blender tablet API evidence")
    require(LOCALITY, 'real_machine_trace.trace("TABLET_POINTER_LOCALITY"', "tablet locality trace")
    for forbidden in ("SetCursorPos", "ClipCursor", "SetCapture", "ReleaseCapture"):
        if forbidden in LOCALITY:
            raise AssertionError("tablet locality diagnostics mutate pointer state: " + forbidden)

    require(PROBE, '_TABLET_LOCALITY.observe(context, event, real_machine_trace)', "observer fan-out")

    print("ZBrush gesture foundation contract: PASS")


if __name__ == "__main__":
    main()
