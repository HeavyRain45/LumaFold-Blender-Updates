from __future__ import annotations

"""Behavior tests for the real Brush Library selection contract.

Runs without Blender by providing a tiny fake bpy timer and fake Core APP.
Targeted replacement is a two-stage transaction:
- the selected asset is written to the exact Quick Slot immediately;
- native Blender Brush activation is deferred to the next UI tick.

The target is latched from the real ``sculpt.state.changed`` UI event so popup
cleanup cannot erase the destination before the Brush tile is clicked.
"""

from pathlib import Path
import importlib.util
import sys
import types

ROOT = Path(__file__).resolve().parents[1]


class FakeCommands:
    def __init__(self):
        self._commands = {}

    def register(self, command_id, fn):
        self._commands[command_id] = fn


class FakeStore:
    def __init__(self):
        self.data = {"sculpt": {"quick_replace_slot": -1}}

    def namespace(self, name, defaults=None):
        bucket = self.data.setdefault(name, {})
        if defaults:
            for key, value in defaults.items():
                bucket.setdefault(key, value)
        return bucket


class FakeEvents:
    def __init__(self):
        self.items = []
        self.subscribers = {}

    def subscribe(self, topic, fn):
        self.subscribers.setdefault(str(topic), []).append(fn)
        def unsubscribe():
            items = self.subscribers.get(str(topic), [])
            if fn in items:
                items.remove(fn)
        return unsubscribe

    def emit(self, topic, payload):
        topic = str(topic)
        payload = dict(payload or {})
        self.items.append((topic, payload))
        for fn in tuple(self.subscribers.get(topic, ())):
            fn(payload)


class FakeApp:
    def __init__(self):
        self.commands = FakeCommands()
        self.store = FakeStore()
        self.events = FakeEvents()


class TimerQueue:
    def __init__(self):
        self.callbacks = []

    def register(self, callback, first_interval=0.0, **_kwargs):
        self.callbacks.append(callback)
        return callback

    def run_all(self):
        callbacks = list(self.callbacks)
        self.callbacks.clear()
        for callback in callbacks:
            callback()


def load_action_module(app, timers):
    for name in (
        "lumafold_test",
        "lumafold_test.runtime",
        "lumafold_test.core",
        "lumafold_test.core.app",
    ):
        sys.modules.pop(name, None)

    pkg = types.ModuleType("lumafold_test")
    pkg.__path__ = [str(ROOT)]
    runtime_pkg = types.ModuleType("lumafold_test.runtime")
    runtime_pkg.__path__ = [str(ROOT / "runtime")]
    core_pkg = types.ModuleType("lumafold_test.core")
    core_pkg.__path__ = [str(ROOT / "core")]
    app_mod = types.ModuleType("lumafold_test.core.app")
    app_mod.APP = app

    sys.modules[pkg.__name__] = pkg
    sys.modules[runtime_pkg.__name__] = runtime_pkg
    sys.modules[core_pkg.__name__] = core_pkg
    sys.modules[app_mod.__name__] = app_mod

    bpy = types.ModuleType("bpy")
    bpy.app = types.SimpleNamespace(timers=timers)
    sys.modules["bpy"] = bpy

    name = "lumafold_test.runtime.sculpt_library_actions"
    path = ROOT / "runtime" / "sculpt_library_actions.py"
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def fixture():
    app = FakeApp()
    timers = TimerQueue()
    calls = []

    def activate(identity):
        calls.append(("activate", identity))
        return f"activated:{identity}"

    def assign(identity, slot):
        calls.append(("assign", identity, slot))
        return f"assigned:{identity}:{slot}"

    def activate_slot(slot):
        calls.append(("activate_slot", slot))
        return f"slot:{slot}"

    app.commands.register("sculpt.brush.library_activate", activate)
    app.commands.register("sculpt.brush.library_assign_slot", assign)
    app.commands.register("sculpt.brush.activate_slot", activate_slot)
    module = load_action_module(app, timers)
    module.install()
    return app, timers, calls, module


def test_normal_selection_is_deferred():
    app, timers, calls, _module = fixture()
    result = app.commands._commands["sculpt.brush.library_activate"]("asset-A")
    assert calls == []
    assert "正在切换笔刷" in result
    timers.run_all()
    assert calls == [("activate", "asset-A")]


def test_targeted_replace_assigns_immediately_then_activates():
    app, timers, calls, _module = fixture()
    state = app.store.namespace("sculpt")
    state["quick_replace_slot"] = 3
    result = app.commands._commands["sculpt.brush.library_activate"]("asset-B")
    assert calls == [("assign", "asset-B", 3)], calls
    assert state["quick_replace_slot"] == -1
    assert "assigned:asset-B:3" in result
    timers.run_all()
    assert calls == [
        ("assign", "asset-B", 3),
        ("activate_slot", 3),
    ]
    assert app.events.items[-1][0] == "sculpt.brush_library.selection_completed"
    assert app.events.items[-1][1]["target_slot"] == 3


def test_ui_event_latches_target_across_popup_cleanup():
    app, timers, calls, _module = fixture()
    state = app.store.namespace("sculpt")
    state["quick_replace_slot"] = 5
    app.events.emit(
        "sculpt.state.changed",
        {"fields": {"quick_replace_slot": 5}, "source": "embedded"},
    )
    # Simulate UI/popup cleanup clearing the transient mirror before the Brush
    # selection command arrives. The latched picker session must still own Slot 6.
    state["quick_replace_slot"] = -1
    app.commands._commands["sculpt.brush.library_activate"]("asset-latched")
    assert calls == [("assign", "asset-latched", 5)], calls
    timers.run_all()
    assert calls[-1] == ("activate_slot", 5)


def test_later_normal_click_supersedes_pending_native_activation():
    app, timers, calls, _module = fixture()
    choose = app.commands._commands["sculpt.brush.library_activate"]
    choose("asset-old")
    choose("asset-new")
    timers.run_all()
    assert calls == [("activate", "asset-new")]


def test_assignment_failure_clears_target_and_does_not_queue_activation():
    app, timers, calls, module = fixture()
    state = app.store.namespace("sculpt")
    state["quick_replace_slot"] = 1

    def broken_assign(identity, slot):
        calls.append(("broken_assign", identity, slot))
        raise RuntimeError("boom")

    module._ORIGINAL_ASSIGN = broken_assign
    try:
        app.commands._commands["sculpt.brush.library_activate"]("asset-X")
    except RuntimeError:
        pass
    else:
        raise AssertionError("targeted assignment failure must propagate to CommandRegistry")
    assert state["quick_replace_slot"] == -1
    assert "笔刷库操作失败" in state["brush_action_status"]
    assert timers.callbacks == []


def main():
    test_normal_selection_is_deferred()
    test_targeted_replace_assigns_immediately_then_activates()
    test_ui_event_latches_target_across_popup_cleanup()
    test_later_normal_click_supersedes_pending_native_activation()
    test_assignment_failure_clears_target_and_does_not_queue_activation()
    print("LumaFold Brush Library action contract tests: PASS")


if __name__ == "__main__":
    main()
