from __future__ import annotations

"""Windows native Satellite integration gate.

This test launches the real desktop/satellite_host.py in a separate CPython
process with the pinned slimgui runtime and a tiny fake Blender bridge.  It
verifies the native WGL/ImGui host can:
- fetch one real Blender state before becoming visible;
- create and render a full state-backed frame before it sends satellite_ready;
- complete the lease-style state exchange;
- make its real Win32 top-level window visible;
- keep ordinary primary mouse interaction non-activating;
- remain alive after visibility;
- close cleanly through WM_CLOSE.

It is intentionally Windows-only and is run by GitHub Actions on windows-latest.
"""

import argparse
import ctypes
from ctypes import wintypes
import json
from pathlib import Path
import secrets
import socketserver
import subprocess
import sys
import threading
import time


ROOT = Path(__file__).resolve().parents[1]
WM_CLOSE = 0x0010
WM_MOUSEACTIVATE = 0x0021
MA_NOACTIVATE = 3


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--runtime-path", required=True)
    return p.parse_args()


class BridgeState:
    def __init__(self, token: str, generation: int):
        self.token = token
        self.generation = int(generation)
        self.first_action = ""
        self.actions = []
        self.ready_seen = False
        self.lock = threading.Lock()

    def snapshot(self):
        # Once ready is received, emulate Blender granting the Satellite lease.
        owner = "satellite" if self.ready_seen else "embedded"
        state = "SATELLITE" if self.ready_seen else "DETACHING"
        return {
            "shared_counter": 0,
            "shared_value": 0.0,
            "shared_enabled": True,
            "shared_text": "",
            "last_command": "",
            "last_command_message": "",
            "last_command_ok": True,
            "command_count": 0,
            "event_log": [],
            "active_object": {"name": "Cube", "location": [0.0, 0.0, 0.0]},
            "blender_version": "5.2.1",
            "sculpt_status": {
                "active": True,
                "enabled": True,
                "reason": "",
                "mode": "SCULPT",
                "workspace": "Sculpting",
            },
            "modules": [],
            "services": [],
            "module_state": {
                "sculpt": {
                    "quick_slot": 0,
                    "quick_rows": 2,
                    "slot_count": 8,
                    "quick_brush_slots": [],
                    "active_quick_slot": -1,
                    "brush_size": 72.0,
                    "brush_strength": 0.5,
                    "input_profile": "zbrush",
                    "quick_shortcuts": [],
                    "quick_hotkey_bindings": [],
                    "quick_replace_slot": -1,
                },
                "__ui__": {"ui_scale": 1.25, "requested_scale": 1.25, "style_scale": 1.25},
            },
            "event_bus": [],
            "host_control": {
                "state": state,
                "owner": owner,
                "generation": self.generation,
                "token": "fake-lease",
                "migration_locked": not self.ready_seen,
                "satellite_ready": self.ready_seen,
                "satellite_active": self.ready_seen,
                "satellite_closing": False,
                "satellite_rect": None,
            },
        }


class LocalServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


def make_server(state: BridgeState):
    class Handler(socketserver.StreamRequestHandler):
        def handle(self):
            raw = self.rfile.readline(512 * 1024)
            if not raw:
                return
            payload = json.loads(raw.decode("utf-8"))
            if payload.get("token") != state.token:
                response = {"ok": False, "error": "unauthorized"}
            else:
                action = str(payload.get("action") or "")
                with state.lock:
                    if not state.first_action:
                        state.first_action = action
                    state.actions.append(action)
                    if action == "satellite_ready":
                        state.ready_seen = True
                    if action == "satellite_closing":
                        response = {"ok": True, "state": state.snapshot()}
                    elif action in {"satellite_ready", "get_state", "ping", "set_module_state", "command"}:
                        response = {"ok": True, "state": state.snapshot()}
                    else:
                        response = {"ok": False, "error": "unknown action: " + action}
            self.wfile.write((json.dumps(response) + "\n").encode("utf-8"))

    server = LocalServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server


def find_top_window(pid: int):
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    found = []

    @WNDENUMPROC
    def callback(hwnd, _lparam):
        owner_pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(owner_pid))
        if int(owner_pid.value) == int(pid):
            found.append(hwnd)
        return True

    user32.EnumWindows(callback, 0)
    visible = [hwnd for hwnd in found if user32.IsWindowVisible(hwnd)]
    return (visible[0] if visible else None), found


def main():
    if sys.platform != "win32":
        print("Satellite process gate: SKIP (Windows only)")
        return 0

    args = parse_args()
    runtime_path = Path(args.runtime_path).resolve()
    if not runtime_path.is_dir():
        raise RuntimeError(f"runtime path missing: {runtime_path}")

    token = secrets.token_hex(16)
    generation = 17
    bridge = BridgeState(token, generation)
    server = make_server(bridge)
    port = int(server.server_address[1])

    script = ROOT / "desktop" / "satellite_host.py"
    cmd = [
        sys.executable, "-u", str(script),
        "--port", str(port),
        "--token", token,
        "--parent-pid", str(__import__("os").getpid()),
        "--owner-hwnd", "0",
        "--width", "420",
        "--height", "500",
        "--x", "120",
        "--y", "120",
        "--generation", str(generation),
        "--runtime-path", str(runtime_path),
    ]

    proc = subprocess.Popen(
        cmd,
        cwd=str(ROOT),
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )

    output = ""
    try:
        deadline = time.monotonic() + 12.0
        visible_hwnd = None
        while time.monotonic() < deadline:
            code = proc.poll()
            if code is not None:
                output = proc.stdout.read() if proc.stdout else ""
                raise RuntimeError(f"Satellite exited before visibility (code {code})\n{output}")
            hwnd, _all = find_top_window(proc.pid)
            if hwnd is not None and bridge.ready_seen:
                visible_hwnd = hwnd
                break
            time.sleep(0.05)

        if visible_hwnd is None:
            raise RuntimeError(
                "Satellite did not become a visible native window within timeout; "
                f"first_action={bridge.first_action!r} actions={bridge.actions[-8:]}"
            )

        # dev53 contract: the very first bridge request must prime a full Blender
        # state while the HWND is still off-screen. Only after a frame has drawn
        # from that snapshot may the child send satellite_ready.
        if bridge.first_action != "get_state":
            raise RuntimeError(f"unexpected first bridge action: {bridge.first_action!r}")
        try:
            ready_index = bridge.actions.index("satellite_ready")
        except ValueError as exc:
            raise RuntimeError(f"satellite_ready was never sent: {bridge.actions[:12]}") from exc
        if ready_index <= 0 or "get_state" not in bridge.actions[:ready_index]:
            raise RuntimeError(f"Satellite became ready before state preflight: {bridge.actions[:12]}")

        # Primary Satellite is a non-activating tool palette for ordinary mouse
        # interaction. This is the focus contract that prevents the first Blender
        # viewport action from paying a foreground-app reacquire cost.
        user32 = ctypes.WinDLL("user32", use_last_error=True)
        user32.SendMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
        user32.SendMessageW.restype = ctypes.c_ssize_t
        mouse_activate = int(user32.SendMessageW(visible_hwnd, WM_MOUSEACTIVATE, 0, 0))
        if mouse_activate != MA_NOACTIVATE:
            raise RuntimeError(
                f"Satellite primary mouse activation policy regressed: {mouse_activate} != {MA_NOACTIVATE}"
            )

        # The child must survive after becoming visible; this catches a common
        # first-frame/first-state race where the HWND flashes and immediately dies.
        time.sleep(0.60)
        if proc.poll() is not None:
            output = proc.stdout.read() if proc.stdout else ""
            raise RuntimeError(f"Satellite died after visibility\n{output}")

        user32.PostMessageW(visible_hwnd, WM_CLOSE, 0, 0)
        proc.wait(timeout=4.0)
        if proc.returncode not in (0, None):
            output = proc.stdout.read() if proc.stdout else ""
            raise RuntimeError(f"Satellite close returned {proc.returncode}\n{output}")

        print("LumaFold Windows Satellite native process gate: PASS")
        print("actions:", bridge.actions[:8])
        return 0
    finally:
        try:
            server.shutdown()
            server.server_close()
        except Exception:
            pass
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=2.0)
            except Exception:
                proc.kill()


if __name__ == "__main__":
    raise SystemExit(main())
