from __future__ import annotations

from pathlib import Path
import tomllib

ROOT = Path(__file__).resolve().parents[1]
manifest = tomllib.loads((ROOT / "blender_manifest.toml").read_text(encoding="utf-8"))
version = str(manifest.get("version", ""))
parts = version.split(".")
assert len(parts) == 3 and all(p.isdigit() for p in parts), f"invalid release version: {version!r}"
print(f"release version contract: PASS ({version})")
