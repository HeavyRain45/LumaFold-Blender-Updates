from __future__ import annotations

"""Real Blender 5.2.1 Alpha Library 2.0 integration gate.

This gate executes the product contract against actual Blender data, not mocks:

* link an ordinary local folder through the public Alpha Source command;
* refresh the canonical Alpha Library and verify the real folder basename;
* extract a real thumbnail through Blender's preview system;
* bind that Alpha to the active Sculpt brush and verify Blender truth;
* hide/restore the linked Alpha through public commands and verify visible/hidden counts;
* verify hidden/removed browser items leave no stale library preview payload;
* remove the linked folder from LumaFold;
* verify source files are byte-for-byte unchanged after hide and folder removal.

Preview extraction is deliberately deferred by the interactive product scheduler.
A blocking background Blender script has no normal UI-tick loop, so this gate
first exercises the public command and then invokes the scheduler's preserved
synchronous delegate, exactly like the existing Brush integration gate validates
a deferred UI transaction through its underlying native primitive.
"""

import bpy
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import tempfile
import traceback

ROOT = Path(__file__).resolve().parents[1]
RESULT_PATH = ROOT / "blender_alpha_library_result.json"
if "--" in sys.argv:
    rest = sys.argv[sys.argv.index("--") + 1:]
    for idx, value in enumerate(rest):
        if value == "--result-path" and idx + 1 < len(rest):
            RESULT_PATH = Path(rest[idx + 1]).resolve()


def write_result(ok: bool, *, stage: str, detail: str = "", extra=None):
    payload = {
        "ok": bool(ok),
        "stage": str(stage),
        "detail": str(detail),
        "blender_version": bpy.app.version_string,
        "background": bool(bpy.app.background),
        "extra": dict(extra or {}),
    }
    RESULT_PATH.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print("LUMAFOLD_ALPHA_GATE", json.dumps(payload, ensure_ascii=False), flush=True)
    return payload


def load_addon():
    name = "lumafold_alpha_ci"
    for key in tuple(sys.modules):
        if key == name or key.startswith(name + "."):
            sys.modules.pop(key, None)
    spec = importlib.util.spec_from_file_location(
        name,
        ROOT / "__init__.py",
        submodule_search_locations=[str(ROOT)],
    )
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    sys.modules[name] = module
    spec.loader.exec_module(module)
    module.register()
    return module


def ensure_mesh():
    if str(getattr(bpy.context, "mode", "OBJECT")) != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")
    bpy.ops.object.select_all(action="DESELECT")
    bpy.ops.mesh.primitive_cube_add(size=2.0, location=(0.0, 0.0, 0.0))
    obj = bpy.context.view_layer.objects.active
    if obj is None or obj.type != "MESH":
        raise RuntimeError("failed to create active Mesh")
    return obj


def public(app, command_id: str, **kwargs):
    result = app.execute(command_id, **kwargs)
    if not result.ok:
        raise RuntimeError(f"{command_id} failed: {result.message}")
    return result


def linked_asset(sculpt, source_id: str, name: str = ""):
    for raw in list(sculpt.get("alpha_library_assets") or ()):
        item = dict(raw or {})
        if str(item.get("linked_source_id") or "") != str(source_id):
            continue
        if name and str(item.get("name") or "") != name:
            continue
        return item
    return None


def linked_folder(sculpt, source_id: str):
    return next(
        (
            dict(item or {})
            for item in list(sculpt.get("alpha_library_folders") or ())
            if str((item or {}).get("id") or "") == str(source_id)
        ),
        None,
    )


def ensure_preview(addon, app, sculpt, identity: str):
    request = public(app, "sculpt.alpha.library_preview", identities=[identity])
    cache = dict(sculpt.get("alpha_library_preview_cache") or {})
    payload = dict(cache.get(identity) or {})
    if not payload.get("rgba_b64"):
        # Interactive LumaFold intentionally sets foreground preview work to
        # zero synchronous items. Background Blender has no frame/timer pump
        # while this script blocks, so invoke the preserved synchronous
        # command delegate to validate the real extraction primitive.
        delegate = getattr(addon.preview_scheduler, "_ORIGINAL_COMMANDS", {}).get("sculpt.alpha.library_preview")
        if not callable(delegate):
            raise RuntimeError("Alpha preview scheduler lost its preserved delegate")
        delegate(identities=[identity])
        cache = dict(sculpt.get("alpha_library_preview_cache") or {})
        payload = dict(cache.get(identity) or {})
    if not payload.get("rgba_b64") or int(payload.get("width", 0) or 0) <= 0 or int(payload.get("height", 0) or 0) <= 0:
        raise RuntimeError("real Blender Alpha thumbnail extraction failed: " + str(request.message))
    return request, payload


def assert_preview_pruned(sculpt, identity: str, reason: str):
    for key in ("alpha_library_preview_cache", "primary_alpha_preview_cache"):
        cache = dict(sculpt.get(key) or {})
        if identity in cache:
            raise RuntimeError(f"{reason}: stale preview remained in {key}")


def main():
    addon = None
    temp_ctx = None
    try:
        if tuple(bpy.app.version[:3]) != (5, 2, 1):
            raise RuntimeError(f"expected Blender 5.2.1, got {bpy.app.version_string}")
        if not bpy.app.background:
            raise RuntimeError("this CI gate must run in Blender background mode")

        addon = load_addon()
        app = addon.APP
        ensure_mesh()
        app.refresh_context(host_id="embedded")
        mode_message = app.services.require("blender.mode").set_mode("SCULPT")
        if str(bpy.context.mode).upper() != "SCULPT":
            raise RuntimeError("failed to establish Sculpt truth: " + str(mode_message))
        app.refresh_context(host_id="embedded")

        temp_ctx = tempfile.TemporaryDirectory(prefix="lumafold_alpha_product_")
        root = Path(temp_ctx.name) / "Studio Skin Alphas"
        nested = root / "Details"
        nested.mkdir(parents=True)

        source_a = ROOT / "assets" / "test_alphas" / "01_Soft_Round.png"
        source_b = ROOT / "assets" / "test_alphas" / "07_Scratches.png"
        if not source_a.is_file() or not source_b.is_file():
            raise RuntimeError("repository Alpha test seed is missing")
        alpha_a = root / "Soft Round.png"
        alpha_b = nested / "Scratches.png"
        shutil.copy2(source_a, alpha_a)
        shutil.copy2(source_b, alpha_b)
        before_a = alpha_a.read_bytes()
        before_b = alpha_b.read_bytes()

        add = public(app, "sculpt.alpha.source_add", path=str(root))
        store = app.services.require("alpha.source_registry")
        sources = [dict(item or {}) for item in list(store.list_sources() or ())]
        source = next((item for item in sources if str(item.get("path") or "").casefold() == str(root.resolve()).replace("\\", "/").casefold()), None)
        if source is None:
            raise RuntimeError("public source_add did not persist the linked folder")
        source_id = str(source.get("id") or "")
        if not source_id.startswith("alpha|linked|"):
            raise RuntimeError("linked source did not receive canonical identity: " + repr(source))
        if str(source.get("label") or "") != root.name:
            raise RuntimeError("linked folder did not preserve real basename: " + repr(source))

        public(app, "sculpt.alpha.library_refresh")
        sculpt = app.store.namespace("sculpt")
        folder = linked_folder(sculpt, source_id)
        if folder is None or int(folder.get("count", 0) or 0) != 2:
            raise RuntimeError("linked folder did not merge into canonical Alpha library: " + repr(folder))
        if int(folder.get("hidden_count", -1) or 0) != 0 or int(folder.get("total_count", 0) or 0) != 2:
            raise RuntimeError("linked folder initial management counts are wrong: " + repr(folder))
        if str(folder.get("label") or "") != root.name:
            raise RuntimeError("Alpha Library folder label is not the real folder name: " + repr(folder))

        item = linked_asset(sculpt, source_id, "Soft Round")
        if item is None:
            raise RuntimeError("linked Alpha was not discoverable in selected source")
        identity = str(item.get("identity") or "")
        if not identity.startswith("file|"):
            raise RuntimeError("linked Alpha lost filepath identity: " + repr(item))

        preview_request, payload = ensure_preview(addon, app, sculpt, identity)

        activate = public(app, "sculpt.alpha.library_activate", identity=identity)
        current = dict(app.services.require("blender.alpha").current_sculpt_alpha() or {})
        if str(current.get("identity") or "") != identity:
            raise RuntimeError(
                "Alpha activation did not reach Blender truth; "
                f"expected={identity} current={current} message={activate.message}"
            )

        public(app, "sculpt.alpha.asset_hide", source_id=source_id, identity=identity)
        if linked_asset(sculpt, source_id, "Soft Round") is not None:
            raise RuntimeError("hidden linked Alpha remained visible after refresh")
        folder_hidden = linked_folder(sculpt, source_id)
        if folder_hidden is None:
            raise RuntimeError("linked source disappeared after hiding one Alpha")
        if int(folder_hidden.get("count", 0) or 0) != 1:
            raise RuntimeError("visible Alpha count did not decrease after hide: " + repr(folder_hidden))
        if int(folder_hidden.get("hidden_count", 0) or 0) != 1:
            raise RuntimeError("hidden Alpha count did not increase after hide: " + repr(folder_hidden))
        if int(folder_hidden.get("total_count", 0) or 0) != 2:
            raise RuntimeError("total Alpha count changed after hide: " + repr(folder_hidden))
        assert_preview_pruned(sculpt, identity, "hide")
        if alpha_a.read_bytes() != before_a or alpha_b.read_bytes() != before_b:
            raise RuntimeError("hiding linked Alpha mutated source files")

        public(app, "sculpt.alpha.source_restore_hidden", source_id=source_id)
        if linked_asset(sculpt, source_id, "Soft Round") is None:
            raise RuntimeError("restored linked Alpha did not return to library")
        folder_restored = linked_folder(sculpt, source_id)
        if folder_restored is None:
            raise RuntimeError("linked source disappeared after restore")
        if int(folder_restored.get("count", 0) or 0) != 2 or int(folder_restored.get("hidden_count", 0) or 0) != 0:
            raise RuntimeError("restore did not return folder counts to normal: " + repr(folder_restored))

        # Rebuild the tile after restore so source removal must clean a genuinely
        # resident payload, not merely pass because hide already evicted it.
        _restore_request, _restore_payload = ensure_preview(addon, app, sculpt, identity)

        public(app, "sculpt.alpha.library_activate", identity="none")
        remove = public(app, "sculpt.alpha.source_remove", source_id=source_id)
        if any(str(item.get("id") or "") == source_id for item in list(store.list_sources() or ())):
            raise RuntimeError("linked folder remained in source registry after remove")
        if any(str((item or {}).get("id") or "") == source_id for item in list(sculpt.get("alpha_library_folders") or ())):
            raise RuntimeError("removed linked folder remained in Alpha Library")
        assert_preview_pruned(sculpt, identity, "source remove")
        if not alpha_a.is_file() or alpha_a.read_bytes() != before_a:
            raise RuntimeError("folder removal modified/deleted first source Alpha")
        if not alpha_b.is_file() or alpha_b.read_bytes() != before_b:
            raise RuntimeError("folder removal modified/deleted nested source Alpha")

        write_result(
            True,
            stage="complete",
            detail="real Blender linked folder + thumbnail + counts + cache pruning + safe hide/remove passed",
            extra={
                "source_id": source_id,
                "folder_label": str(folder.get("label") or ""),
                "asset_count": int(folder.get("count", 0) or 0),
                "hidden_count_after_hide": int(folder_hidden.get("hidden_count", 0) or 0),
                "preview_size": [int(payload.get("width", 0)), int(payload.get("height", 0))],
                "preview_request": str(preview_request.message),
                "add_message": str(add.message),
                "activate_message": str(activate.message),
                "remove_message": str(remove.message),
            },
        )
        return 0
    except Exception:
        write_result(False, stage="alpha_integration_failure", detail=traceback.format_exc())
        return 2
    finally:
        if addon is not None:
            try:
                addon.unregister()
            except Exception:
                pass
        if temp_ctx is not None:
            try:
                temp_ctx.cleanup()
            except Exception:
                pass


raise SystemExit(main())
