from __future__ import annotations

"""Behavior gate for the Embedded Brush Library pointer-commit fallback.

Real-machine dev45 telemetry proved this failure shape:
- targeted Quick Slot state published;
- Brush popup open;
- LEFTMOUSE PRESS/RELEASE reached the popup input bridge;
- no Brush command was emitted.

The dev46 fallback fixed that final hop, but real-machine testing then showed an
outside-click dismissal regression. dev47 therefore adds one more invariant:
only releases inside the *actual ImGui popup window rect* may become synthetic
Brush commits. Releases outside the popup remain pure Dear ImGui dismissal.
"""

from pathlib import Path
import importlib.util
import sys
import types

ROOT = Path(__file__).resolve().parents[1]
POPUP = "LumaFold Brush Library##foundation"


class FakeRuntimeSession:
    def __init__(self):
        self.names = (POPUP,)

    def popup_named(self, host, name):
        return host == "embedded" and name in self.names


class FakeRegion:
    x = 100
    y = 50
    width = 800
    height = 600


class FakeEvent:
    type = "LEFTMOUSE"
    value = "RELEASE"

    def __init__(self, local_x, local_y_top):
        self.mouse_x = FakeRegion.x + int(local_x)
        self.mouse_y = FakeRegion.y + int(FakeRegion.height - 1 - local_y_top)


class FakeHost:
    def __init__(self):
        self.state = {}

    def _window_region(self):
        return FakeRegion()

    def feed_event(self, event, *, region=None):
        return "base"


class FakeImgui:
    def __init__(self, item_rect=((20.0, 30.0), (80.0, 90.0)), popup_pos=(10.0, 20.0), popup_size=(200.0, 180.0)):
        self.rect = item_rect
        self.popup_pos = popup_pos
        self.popup_size = popup_size

    def get_item_rect_min(self):
        return self.rect[0]

    def get_item_rect_max(self):
        return self.rect[1]

    def get_window_pos(self):
        return self.popup_pos

    def get_window_size(self):
        return self.popup_size


class FakeFoundation:
    def __init__(self):
        self.square_button = self._square_button
        self.image_square_button = self._image_square_button
        self.draw_brush_library_foundation = self._draw
        self.mode = "square"

    @staticmethod
    def _square_button(imgui, label, *args, **kwargs):
        return False

    @staticmethod
    def _image_square_button(imgui, ident, *args, **kwargs):
        return False

    def _draw(
        self,
        imgui,
        sculpt,
        scale,
        *,
        library_ui_state=None,
        on_refresh_library=None,
        on_activate_asset=None,
        on_toggle_favorite=None,
        on_assign_asset_to_slot=None,
        on_request_preview=None,
        resolve_preview_texture=None,
    ):
        if self.mode == "image":
            clicked = self.image_square_button(imgui, "library_asset_0", 1, scale, 48.0)
        else:
            clicked = self.square_button(imgui, "Brush##library_asset_0", scale, 48.0)
        if clicked and on_activate_asset is not None:
            on_activate_asset("asset|essentials|brush")
        return clicked


def load_module():
    prefix = "lumafold_pointer_commit_test"
    for key in tuple(sys.modules):
        if key == prefix or key.startswith(prefix + "."):
            sys.modules.pop(key, None)

    root_pkg = types.ModuleType(prefix)
    root_pkg.__path__ = [str(ROOT)]
    runtime_pkg = types.ModuleType(prefix + ".runtime")
    runtime_pkg.__path__ = [str(ROOT / "runtime")]
    core_pkg = types.ModuleType(prefix + ".core")
    core_pkg.__path__ = [str(ROOT / "core")]
    session_mod = types.ModuleType(prefix + ".core.runtime_session")
    session_mod.RUNTIME_SESSION = FakeRuntimeSession()
    for mod in (root_pkg, runtime_pkg, core_pkg, session_mod):
        sys.modules[mod.__name__] = mod

    name = prefix + ".runtime.embedded_library_pointer_commit"
    spec = importlib.util.spec_from_file_location(name, ROOT / "runtime" / "embedded_library_pointer_commit.py")
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def _prime_popup_rect(foundation, host, imgui, activations):
    foundation.draw_brush_library_foundation(
        imgui,
        {},
        1.0,
        library_ui_state=host.state,
        on_activate_asset=activations.append,
    )
    assert host.state.get("_embedded_brush_popup_actual_rect") == {
        "left": 10.0, "top": 20.0, "right": 210.0, "bottom": 200.0,
    }, host.state


def run_inside_case(mode, x, y, expected_count):
    module = load_module()
    foundation = FakeFoundation()
    foundation.mode = mode
    module.install(FakeHost, foundation)
    host = FakeHost()
    activations = []
    imgui = FakeImgui()

    # The actual popup window rect is sampled on a prior draw frame.
    _prime_popup_rect(foundation, host, imgui, activations)
    host.feed_event(FakeEvent(x, y), region=FakeRegion())
    foundation.draw_brush_library_foundation(
        imgui,
        {},
        1.0,
        library_ui_state=host.state,
        on_activate_asset=activations.append,
    )
    assert len(activations) == expected_count, (mode, x, y, activations, host.state)

    # The same commit is one-shot; a later frame cannot activate it again.
    foundation.draw_brush_library_foundation(
        imgui,
        {},
        1.0,
        library_ui_state=host.state,
        on_activate_asset=activations.append,
    )
    assert len(activations) == expected_count, ("replay", mode, activations, host.state)
    module.uninstall()


def test_outside_release_never_becomes_commit():
    module = load_module()
    foundation = FakeFoundation()
    module.install(FakeHost, foundation)
    host = FakeHost()
    activations = []
    imgui = FakeImgui()
    _prime_popup_rect(foundation, host, imgui, activations)

    # Outside the real popup rect. Runtime Core/Dear ImGui own dismissal; the
    # Brush fallback must not create a candidate commit at all.
    host.feed_event(FakeEvent(350, 250), region=FakeRegion())
    assert "_embedded_brush_pointer_commit" not in host.state, host.state
    foundation.draw_brush_library_foundation(
        imgui,
        {},
        1.0,
        library_ui_state=host.state,
        on_activate_asset=activations.append,
    )
    assert activations == [], activations
    module.uninstall()


def main():
    run_inside_case("square", 40, 50, 1)
    run_inside_case("image", 40, 50, 1)
    run_inside_case("square", 140, 150, 0)
    test_outside_release_never_becomes_commit()
    print("LumaFold Embedded Brush pointer commit tests: PASS")


if __name__ == "__main__":
    main()
