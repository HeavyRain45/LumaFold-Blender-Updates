from __future__ import annotations

"""Behavior contract for Satellite Secondary ESC dismissal.

Regression covered by dev54:
- dev53 intentionally made the Satellite primary palette non-activating so
  returning to Blender no longer pays a foreground-focus hitch;
- a freshly opened Brush/Alpha/More Secondary therefore may not own keyboard
  focus, so its native WM_KEYDOWN ESC handler is not sufficient;
- while the Secondary is visible, one global ESC rising edge must hide it
  without taking focus or installing a keyboard hook;
- an ESC key already held before the menu appears must not immediately dismiss
  the newly opened menu.

The production entry module cannot be imported in a headless gate because it
boots the native child runtime and parses process arguments at import time.  We
therefore execute the exact production helper AST with a fake Win32 runtime.
"""

import ast
from pathlib import Path
import types

ROOT = Path(__file__).resolve().parents[1]
SOURCE_PATH = ROOT / "desktop" / "secondary_surface_host.py"


def _load_escape_helper():
    source = SOURCE_PATH.read_text(encoding="utf-8")
    tree = ast.parse(source, filename=str(SOURCE_PATH))
    helper = next(
        (node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "_escape_dismiss_tick"),
        None,
    )
    assert helper is not None, "production _escape_dismiss_tick helper is missing"

    draw = next(
        (node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "_draw_frame"),
        None,
    )
    assert draw is not None, "production _draw_frame is missing"
    calls = {
        node.func.id
        for node in ast.walk(draw)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
    }
    assert "_escape_dismiss_tick" in calls, "Satellite Secondary ESC helper is not wired into every draw tick"

    module = ast.Module(body=[helper], type_ignores=[])
    ast.fix_missing_locations(module)

    class FakeUser32:
        def __init__(self):
            self.visible = False
            self.hide_calls = 0

        def IsWindowVisible(self, _hwnd):
            return bool(self.visible)

        def ShowWindow(self, _hwnd, command):
            assert command == 0, command
            self.visible = False
            self.hide_calls += 1
            return True

    user32 = FakeUser32()
    runtime = types.SimpleNamespace(hwnd_main=101, user32=user32, SW_HIDE=0)
    key_state = {"down": False, "pressed_since": False}

    def button_state(_vk):
        return bool(key_state["down"]), bool(key_state["pressed_since"])

    env = {
        "_runtime": runtime,
        "_button_state": button_state,
        "_VK_ESCAPE": 0x1B,
        "_escape_down_last": False,
        "_outside_visible_last": True,
        "_outside_armed": True,
    }
    exec(compile(module, str(SOURCE_PATH), "exec"), env)
    return env, user32, key_state


def test_hidden_window_primes_held_escape_without_future_false_close():
    env, user32, key = _load_escape_helper()
    fn = env["_escape_dismiss_tick"]

    # ESC is already held while Secondary is hidden. The latch must observe the
    # held state without treating the next menu appearance as a new key press.
    user32.visible = False
    key.update(down=True, pressed_since=False)
    assert fn() is False
    assert env["_escape_down_last"] is True

    user32.visible = True
    assert fn() is False
    assert user32.hide_calls == 0


def test_new_escape_press_hides_visible_secondary_without_focus_contract():
    env, user32, key = _load_escape_helper()
    fn = env["_escape_dismiss_tick"]

    user32.visible = True
    key.update(down=False, pressed_since=False)
    assert fn() is False

    key.update(down=True, pressed_since=True)
    assert fn() is True
    assert user32.hide_calls == 1
    assert user32.visible is False
    assert env["_outside_visible_last"] is False
    assert env["_outside_armed"] is False


def test_release_then_next_press_is_a_new_dismiss_edge():
    env, user32, key = _load_escape_helper()
    fn = env["_escape_dismiss_tick"]

    user32.visible = True
    key.update(down=True, pressed_since=False)
    assert fn() is True
    assert user32.hide_calls == 1

    # Hidden frames keep the key latch synchronized.
    key.update(down=False, pressed_since=False)
    assert fn() is False
    user32.visible = True

    key.update(down=True, pressed_since=False)
    assert fn() is True
    assert user32.hide_calls == 2


def main():
    test_hidden_window_primes_held_escape_without_future_false_close()
    test_new_escape_press_hides_visible_secondary_without_focus_contract()
    test_release_then_next_press_is_a_new_dismiss_edge()
    print("LumaFold Satellite Secondary ESC contract: PASS")


if __name__ == "__main__":
    main()
