# LumaFold clean first-install acceptance contract

A release is not considered ready for first-time users unless a clean Blender 5.2.1 environment can:

1. Add the LumaFold remote repository using an `index.json` URL.
2. Synchronize that repository and install `lumafold` into a clean custom extension directory.
3. Install exactly the version published by the release manifest without resolving an older package.

The release workflow must exercise this contract with an isolated Blender user configuration and repository directory before publishing the channel artifact.

This gate intentionally does not test the already-frozen self-update helper. It protects only fresh-install behavior and repository/package identity.
