from __future__ import annotations

"""Static product contract for the lightweight Alpha Library composition."""

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PRODUCT = ROOT / "ui" / "alpha_library_product.py"
UI_INIT = ROOT / "ui" / "__init__.py"
IMPORT_PRODUCT = ROOT / "runtime" / "alpha_import_product.py"
ALPHA_SERVICE = ROOT / "services" / "sculpt_alpha_product.py"
LINKED_ALPHA_SERVICE = ROOT / "services" / "sculpt_alpha_linked_product.py"
MANAGED_STORE = ROOT / "services" / "alpha_managed_store.py"
REGISTRY = ROOT / "services" / "alpha_source_registry.py"
SERVICES = ROOT / "services" / "__init__.py"
SCHEDULER = ROOT / "runtime" / "preview_scheduler.py"
PERFORMANCE = ROOT / "runtime" / "preview_performance.py"


def fail(message):
    raise AssertionError(message)


def require(text, token, label):
    if token not in text:
        fail(f"{label} missing contract token: {token}")


def main():
    product = PRODUCT.read_text(encoding="utf-8")
    ui_init = UI_INIT.read_text(encoding="utf-8")
    import_product = IMPORT_PRODUCT.read_text(encoding="utf-8")
    alpha_service = ALPHA_SERVICE.read_text(encoding="utf-8")
    linked_alpha_service = LINKED_ALPHA_SERVICE.read_text(encoding="utf-8")
    managed_store = MANAGED_STORE.read_text(encoding="utf-8")
    registry = REGISTRY.read_text(encoding="utf-8")
    services = SERVICES.read_text(encoding="utf-8")
    scheduler = SCHEDULER.read_text(encoding="utf-8")
    performance = PERFORMANCE.read_text(encoding="utf-8")

    for token in (
        "runtime_core", "host_input_boundary", "satellite_input_boundary",
        "UIHost.feed_event", "UIHost.should_capture", "WndProc",
    ):
        if token in product:
            fail("Alpha Library product crossed Host/Input boundary: " + token)

    # External-source layers remain permanently non-destructive. Only the
    # dedicated managed store may mutate files, and only beneath its guarded root.
    for text, label in (
        (product, "Alpha UI"),
        (import_product, "Alpha selector"),
        (registry, "Alpha registry"),
        (linked_alpha_service, "linked Alpha product"),
    ):
        for token in (".unlink(", ".rmdir(", "os.remove(", "os.unlink(", "shutil.rmtree(", "shutil.move("):
            if token in text:
                fail(f"{label} contains forbidden source-file mutation: {token}")

    require(ui_init, "alpha_library_product", "UI package")
    require(ui_init, "_alpha_library_product.install()", "UI package")

    for command in (
        "sculpt.alpha.source_add_dialog",
        "sculpt.alpha.user_folder_create_dialog",
        "sculpt.alpha.folder_remove",
        "sculpt.alpha.asset_delete",
        "sculpt.alpha.source_restore_hidden",
    ):
        require(product, command, "Alpha UI command boundary")

    require(product, '"删除 Alpha"', "Alpha asset delete wording")
    require(product, "本地原文件不会删除", "linked Alpha safe-delete wording")
    require(product, 'marker = "##alpha_folder_"', "Alpha folder right-click")
    require(product, '"删除文件夹" if managed', "managed folder delete action")
    require(product, '"从 LumaFold 移除文件夹"', "linked folder remove action")
    require(product, '"新建 LumaFold 文件夹"', "managed folder create action")
    require(product, 'folder.get("hidden_count"', "Alpha hidden-count UI")
    require(product, 'disabled=(hidden_count <= 0)', "Alpha restore disabled state")
    require(product, "文件夹路径当前不可用", "missing linked-folder status")
    require(product, 'label_text == "+##alpha_folder_add"', "Alpha plus interception")
    require(product, "MouseButton.RIGHT", "Alpha plus/folder context gesture")

    require(registry, '"hidden_count": 0', "linked source hidden count")
    require(registry, '"total_count": 0', "linked source total count")
    require(registry, 'folder["hidden_count"] += 1', "linked source hidden counting")
    require(registry, 'folder["total_count"] += 1', "linked source total counting")

    require(import_product, "class LUMAFOLD_OT_add_alpha_folder", "Alpha mixed selector operator")
    require(import_product, "subtype='FILE_PATH'", "Alpha mixed FILE_PATH selector")
    require(import_product, "def _selection_paths", "Alpha exact selection resolver")
    require(import_product, "path.is_dir()", "Alpha direct folder classification")
    require(import_product, "path.is_file()", "Alpha direct file classification")
    require(import_product, "到“全部”", "single/multi file all-scope wording")
    require(import_product, "class LUMAFOLD_OT_create_alpha_folder", "managed folder operator")
    require(import_product, "invoke_props_dialog", "managed folder native dialog")

    require(services, 'AlphaManagedStore()', "managed store construction")
    require(services, 'app.services.register("alpha.managed_store"', "managed store registration")
    require(services, 'app.commands.register("sculpt.alpha.source_add_dialog"', "source dialog command")
    require(services, 'app.commands.register("sculpt.alpha.user_folder_create_dialog"', "managed folder dialog command")
    require(services, 'app.commands.register("sculpt.alpha.folder_remove"', "unified folder remove command")
    require(services, 'app.commands.register("sculpt.alpha.asset_delete"', "unified asset delete command")
    require(services, "def _prune_alpha_preview_identities", "Alpha preview cache pruning")
    require(services, '"alpha_library_preview_cache", "primary_alpha_preview_cache"', "Alpha preview cache ownership")
    require(services, "identities = _alpha_identities_for_source(source_id)", "linked folder cache pruning")
    require(services, "identities = _alpha_identities_for_folder(folder_id)", "managed folder cache pruning")
    require(services, "alpha_managed_store.remove_folder(folder_id)", "managed folder owner routing")
    require(services, "alpha_managed_store.delete_asset(filepath)", "managed asset owner routing")

    # Managed filesystem ownership is explicit and path-contained.
    require(managed_store, "class AlphaManagedStore", "managed filesystem owner")
    require(managed_store, 'path="lumafold/alphas"', "managed root")
    require(managed_store, "def _contained_path", "managed path guard")
    require(managed_store, "path.relative_to(root)", "managed path containment")
    require(managed_store, "def create_folder", "managed folder creation")
    require(managed_store, "def list_folders", "managed folder snapshot")
    require(managed_store, "def remove_folder", "managed folder deletion")
    require(managed_store, "def delete_asset", "managed Alpha deletion")
    require(managed_store, "if not folder_id.startswith(self.USER_FOLDER_PREFIX)", "managed folder ownership gate")
    require(managed_store, "child.unlink()", "managed child deletion")
    require(managed_store, "path.unlink()", "managed asset deletion")
    if "shutil.rmtree(" in managed_store or "shutil.move(" in managed_store:
        fail("managed store must keep mutations explicit and root-contained")

    require(linked_alpha_service, 'managed_root_id = self.USER_FOLDER_PREFIX + "根目录"', "managed root classification")
    require(linked_alpha_service, "self.TEST_SEED_FOLDER_ID", "system seed nav suppression")
    require(linked_alpha_service, "self.managed_store.list_folders()", "managed folder snapshot composition")
    require(linked_alpha_service, "User-created LumaFold subfolders remain visible even while empty", "empty managed folder visibility")

    require(alpha_service, "def _file_pixels_payload", "base Alpha pixel thumbnail owner")
    require(alpha_service, "check_existing=False", "base disposable Alpha Image load")
    require(alpha_service, "image.scale(target_w, target_h)", "base temporary thumbnail downscale")
    require(alpha_service, "bpy.data.images.remove(temp)", "base temporary Image cleanup")
    for token in ("temp.save(", "image.save(", "shutil.move(", "shutil.rmtree("):
        if token in alpha_service or token in linked_alpha_service:
            fail("Alpha thumbnail path contains forbidden source mutation: " + token)

    require(linked_alpha_service, "def _preview_byte", "Alpha data-value preview conversion")
    require(linked_alpha_service, "src_y = (height - 1) - sampled_y", "Alpha top-down orientation")
    require(linked_alpha_service, "side = max(1, max(content_w, content_h))", "Alpha square contain canvas")
    require(linked_alpha_service, '"content_width": content_w', "Alpha aspect metadata")
    require(linked_alpha_service, '"source": "alpha_data_pixels"', "Alpha data-fidelity payload")
    require(linked_alpha_service, 'settings.name = name', "Alpha disposable Non-Color interpretation")
    if "gamma_encode" in linked_alpha_service:
        fail("final Alpha thumbnail path must not gamma-encode sculpt data")

    require(scheduler, "_ALPHA_PREWARM_ITEMS = 64", "Alpha preview budget")
    require(scheduler, "_ALPHA_PREWARM_RUNWAY = 8", "Alpha preview runway")
    require(scheduler, "_ALPHA_PREWARM_TARGETS", "Alpha preview target ownership")
    require(scheduler, "def _ordered_missing_alpha_ids", "Alpha preview ordering")
    require(scheduler, "def _alpha_prewarm_tick", "Alpha preview prewarm")
    require(scheduler, "remaining[:_ALPHA_PREWARM_RUNWAY]", "Alpha incremental prewarm")
    require(scheduler, "if not remaining:", "Alpha residency completion")
    require(scheduler, "bpy.app.timers.register(_alpha_prewarm_tick", "Alpha prewarm timer")

    require(performance, "_ORIGINAL_ALPHA_TICK", "Alpha performance delegate")
    require(performance, "def idle_alpha_tick", "Alpha user-busy guard")
    require(performance, "preview_module._alpha_prewarm_tick = idle_alpha_tick", "Alpha guard installation")
    require(performance, "module._alpha_prewarm_tick = _ORIGINAL_ALPHA_TICK", "Alpha guard cleanup")

    print("Alpha Library lightweight asset-management contract: PASS")


if __name__ == "__main__":
    main()
