from __future__ import annotations

"""Real Blender 5.2.1 gate for lightweight Alpha asset management.

This gate covers the real UI semantics introduced after dev62:

* individually imported images are loaded into Blender and remain available in
  ``全部`` without producing a managed-root folder in the left navigation;
* the packaged LumaFold test seed and Blender's generic ``当前文件`` bucket never
  appear as left-navigation folders;
* deleting a loaded LumaFold-managed Alpha removes its disk copy and matching
  Blender Image datablock so it cannot resurrect through ``当前文件``;
* an empty LumaFold-owned subfolder is visible and removable;
* deleting a LumaFold-managed folder removes that managed folder and its files;
* externally linked source files remain outside every destructive code path.
"""

import bpy
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import tempfile
import traceback
import uuid

ROOT = Path(__file__).resolve().parents[1]
RESULT_PATH = ROOT / "blender_alpha_asset_management_result.json"
if "--" in sys.argv:
    rest = sys.argv[sys.argv.index("--") + 1:]
    for idx, value in enumerate(rest):
        if value == "--result-path" and idx + 1 < len(rest):
            RESULT_PATH = Path(rest[idx + 1]).resolve()


def write_result(ok: bool, *, stage: str, detail: str = "", extra=None):
    payload = {
        "ok": bool(ok),
        "stage": str(stage),
        "detail": str(detail),
        "blender_version": bpy.app.version_string,
        "background": bool(bpy.app.background),
        "extra": dict(extra or {}),
    }
    RESULT_PATH.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print("LUMAFOLD_ALPHA_ASSET_GATE", json.dumps(payload, ensure_ascii=False), flush=True)
    return payload


def load_addon():
    name = "lumafold_alpha_asset_ci"
    for key in tuple(sys.modules):
        if key == name or key.startswith(name + "."):
            sys.modules.pop(key, None)
    spec = importlib.util.spec_from_file_location(
        name,
        ROOT / "__init__.py",
        submodule_search_locations=[str(ROOT)],
    )
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    sys.modules[name] = module
    spec.loader.exec_module(module)
    module.register()
    return module


def public(app, command_id: str, **kwargs):
    result = app.execute(command_id, **kwargs)
    if not result.ok:
        raise RuntimeError(f"{command_id} failed: {result.message}")
    return result


def norm_path(value):
    raw = str(value or "")
    if not raw:
        return ""
    try:
        raw = bpy.path.abspath(raw)
    except Exception:
        pass
    try:
        return str(Path(raw).resolve()).replace("\\", "/").casefold()
    except Exception:
        return raw.replace("\\", "/").casefold()


def image_by_path(filepath: Path):
    wanted = norm_path(filepath)
    for image in list(getattr(bpy.data, "images", ()) or ()):
        if norm_path(getattr(image, "filepath", "")) == wanted:
            return image
    return None


def asset_by_path(sculpt, filepath: Path):
    wanted = norm_path(filepath)
    for raw in list(sculpt.get("alpha_library_assets") or ()):
        item = dict(raw or {})
        actual = norm_path(item.get("filepath") or "")
        if actual == wanted:
            return item
    return None


def folder_by_id(sculpt, folder_id: str):
    return next(
        (
            dict(raw or {})
            for raw in list(sculpt.get("alpha_library_folders") or ())
            if str((raw or {}).get("id") or "") == str(folder_id)
        ),
        None,
    )


def folder_by_label(sculpt, label: str):
    return next(
        (
            dict(raw or {})
            for raw in list(sculpt.get("alpha_library_folders") or ())
            if str((raw or {}).get("label") or "") == str(label)
        ),
        None,
    )


def main():
    addon = None
    temp_ctx = None
    imported_path = None
    managed_folder_id = ""
    try:
        if tuple(bpy.app.version[:3]) != (5, 2, 1):
            raise RuntimeError(f"expected Blender 5.2.1, got {bpy.app.version_string}")
        if not bpy.app.background:
            raise RuntimeError("this CI gate must run in Blender background mode")

        addon = load_addon()
        app = addon.APP
        service = app.services.require("blender.alpha")
        sculpt = app.store.namespace("sculpt")

        temp_ctx = tempfile.TemporaryDirectory(prefix="lumafold_alpha_asset_")
        temp_root = Path(temp_ctx.name)
        seed = ROOT / "assets" / "test_alphas" / "01_Soft_Round.png"
        if not seed.is_file():
            raise RuntimeError("repository Alpha test seed is missing")

        # 1) Reproduce the real UI path: import one image AND load the managed
        # copy into bpy.data.images. It must be visible in 全部 but no system/root
        # source may become a left-navigation folder.
        unique = uuid.uuid4().hex[:10]
        source = temp_root / f"Managed_Single_{unique}.png"
        shutil.copy2(seed, source)
        source_before = source.read_bytes()
        imported = dict(service.import_alpha_files([source], load_current=True) or {})
        files = [Path(value) for value in list(imported.get("files") or ())]
        if len(files) != 1:
            raise RuntimeError("managed single-file import did not return exactly one file: " + repr(imported))
        imported_path = files[0].resolve()
        if not imported_path.is_file():
            raise RuntimeError("managed Alpha copy was not created")
        if image_by_path(imported_path) is None:
            raise RuntimeError("real UI import path did not load managed copy into bpy.data.images")
        public(app, "sculpt.alpha.library_refresh")

        root_folder_id = service.USER_FOLDER_PREFIX + "根目录"
        if folder_by_id(sculpt, root_folder_id) is not None:
            raise RuntimeError("single-file import leaked managed root into left folder navigation")
        if folder_by_id(sculpt, service.TEST_SEED_FOLDER_ID) is not None:
            raise RuntimeError("packaged LumaFold test seed leaked into left folder navigation")
        if folder_by_id(sculpt, service.CURRENT_FILE_FOLDER_ID) is not None or folder_by_label(sculpt, "当前文件") is not None:
            raise RuntimeError("Blender 当前文件 system bucket leaked into left folder navigation")
        item = asset_by_path(sculpt, imported_path)
        if item is None:
            raise RuntimeError("managed single-file import is missing from 全部 asset list")
        if str(item.get("folder_id") or "") != root_folder_id:
            raise RuntimeError("single-file import lost managed-root ownership: " + repr(item))

        # 2) This is the exact reported bug. Deleting a loaded managed Alpha must
        # remove both the managed disk copy and its matching Blender Image. After
        # refresh there must be no second/resurrected record under 当前文件.
        identity = str(item.get("identity") or "")
        public(
            app,
            "sculpt.alpha.asset_delete",
            identity=identity,
            filepath=str(imported_path),
            folder_id=root_folder_id,
            source_id="",
        )
        if imported_path.exists():
            raise RuntimeError("managed Alpha delete left the LumaFold copy on disk")
        if image_by_path(imported_path) is not None:
            raise RuntimeError("deleted managed Alpha remained loaded in bpy.data.images and can resurrect")
        if not source.is_file() or source.read_bytes() != source_before:
            raise RuntimeError("managed Alpha delete mutated the user's original import source")
        if asset_by_path(sculpt, imported_path) is not None:
            raise RuntimeError("deleted managed Alpha resurrected in library state")
        if folder_by_id(sculpt, service.CURRENT_FILE_FOLDER_ID) is not None or folder_by_label(sculpt, "当前文件") is not None:
            raise RuntimeError("当前文件 appeared in left navigation after managed Alpha deletion")

        # 3) A real LumaFold-owned empty subfolder must appear in the existing left
        # folder list, without creating a new navigation system.
        folder_name = f"Gate_{unique}"
        created = dict(service.create_user_folder(folder_name) or {})
        managed_folder_id = str(created.get("folder_id") or "")
        managed_folder_path = Path(str(created.get("path") or "")).resolve()
        public(app, "sculpt.alpha.library_refresh")
        folder = folder_by_id(sculpt, managed_folder_id)
        if folder is None:
            raise RuntimeError("empty LumaFold user folder is not visible in left navigation")
        if not bool(folder.get("managed", False)) or not bool(folder.get("removable", False)):
            raise RuntimeError("managed folder did not expose removable ownership truth: " + repr(folder))
        if int(folder.get("count", -1) or 0) != 0:
            raise RuntimeError("new empty managed folder reported a non-zero Alpha count: " + repr(folder))

        # Put one managed file inside that folder and load it, so folder deletion
        # proves runtime Images are retired together with the managed disk files.
        nested_alpha = managed_folder_path / f"Nested_{unique}.png"
        shutil.copy2(seed, nested_alpha)
        bpy.data.images.load(str(nested_alpha), check_existing=True)
        public(app, "sculpt.alpha.library_refresh")
        nested_item = asset_by_path(sculpt, nested_alpha)
        if nested_item is None or str(nested_item.get("folder_id") or "") != managed_folder_id:
            raise RuntimeError("managed subfolder Alpha did not receive its folder classification")
        if image_by_path(nested_alpha) is None:
            raise RuntimeError("managed subfolder test Alpha failed to load into Blender")

        public(app, "sculpt.alpha.folder_remove", folder_id=managed_folder_id)
        if managed_folder_path.exists():
            raise RuntimeError("managed folder delete left its LumaFold folder on disk")
        if image_by_path(nested_alpha) is not None:
            raise RuntimeError("managed folder delete left nested Alpha loaded in Blender")
        if folder_by_id(sculpt, managed_folder_id) is not None:
            raise RuntimeError("deleted managed folder remained in left navigation")
        if asset_by_path(sculpt, nested_alpha) is not None:
            raise RuntimeError("Alpha inside deleted managed folder remained in library state")

        # The original selected source remains the safety sentinel throughout.
        if not source.is_file() or source.read_bytes() != source_before:
            raise RuntimeError("managed folder lifecycle mutated an external source file")

        write_result(
            True,
            stage="complete",
            detail="loaded-image delete + hidden current-file bucket + managed lifecycle safety passed",
            extra={
                "root_folder_hidden": True,
                "test_seed_folder_hidden": True,
                "current_file_folder_hidden": True,
                "deleted_loaded_image_unloaded": True,
                "managed_folder_id": managed_folder_id,
                "source_preserved": True,
            },
        )
        return 0
    except Exception:
        write_result(False, stage="alpha_asset_management_failure", detail=traceback.format_exc())
        return 2
    finally:
        if addon is not None:
            try:
                addon.unregister()
            except Exception:
                pass
        if temp_ctx is not None:
            try:
                temp_ctx.cleanup()
            except Exception:
                pass


raise SystemExit(main())
