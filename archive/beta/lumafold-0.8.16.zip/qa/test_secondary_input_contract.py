from __future__ import annotations

"""Behavior gate for Embedded Secondary input ownership.

Real-machine regression contract:
- popup PRESS/RELEASE refreshes the exact pointer position even without a prior
  MOUSEMOVE;
- button lifecycle still runs through the established UIHost.feed_event bridge,
  preserving Dear ImGui outside-click dismissal;
- Runtime Core does not own a second direct button implementation;
- ESC reaches the normal input bridge and requests explicit close;
- View3D region policy is injected through the Sculpt Core resolver slot rather
  than replacing a private function.
"""

from pathlib import Path
import importlib.util
import sys
import types

ROOT = Path(__file__).resolve().parents[1]


class PopupState:
    def __init__(self, names=(), serial=0, close_requested=False, close_reason=""):
        self.names = tuple(names)
        self.serial = int(serial)
        self.close_requested = bool(close_requested)
        self.close_reason = str(close_reason)


class FakeRuntimeSession:
    def __init__(self):
        self.names = ()
        self.requested = False
        self.reason = ""

    def popup_open(self, host="embedded"):
        return bool(self.names)

    def popup_named(self, host, name):
        return str(name) in self.names

    def popup_snapshot(self, host="embedded"):
        return PopupState(self.names, 1, self.requested, self.reason)

    def publish_popups(self, host, names):
        self.names = tuple(names or ())
        return self.popup_snapshot(host)

    def request_popup_close(self, host="embedded", *, reason=""):
        self.requested = True
        self.reason = str(reason)
        return True

    def close_requested(self, host="embedded"):
        return self.requested

    def acknowledge_close_request(self, host="embedded"):
        self.requested = False
        self.reason = ""

    def clear_all(self):
        self.names = ()
        self.requested = False
        self.reason = ""


class FakeHostControl:
    def subscribe(self, callback): return lambda: None


class FakeState:
    capture_mouse = False
    capture_keyboard = False
    capture_text = False
    host = None
    host_mode = "embedded"


class FakeRegion:
    x = 100
    y = 50
    width = 800
    height = 600


class FakeEvent:
    def __init__(self, event_type, value="PRESS", *, local_x=0, local_y_top=0):
        self.type = event_type
        self.value = value
        self.mouse_x = FakeRegion.x + int(local_x)
        self.mouse_y = FakeRegion.y + int(FakeRegion.height - 1 - local_y_top)
        self.ctrl = self.shift = self.alt = self.oskey = False
        self.unicode = ""


class FakeRenderer:
    def __init__(self): self.ensure_calls = 0
    def ensure_context(self): self.ensure_calls += 1


class FakeIO:
    def __init__(self): self.events = []
    def add_mouse_pos_event(self, x, y): self.events.append(("pos", float(x), float(y)))
    def add_mouse_button_event(self, button, down): self.events.append(("button", int(button), bool(down)))


class FakeHost:
    def __init__(self):
        self.state = {}
        self.feed_calls = []
        self.renderer = FakeRenderer()
        self.io = FakeIO()
        self.closed = False
        self._mouse_owned = {0: False, 1: False, 2: False}

    def _window_region(self): return FakeRegion()

    def feed_event(self, event, *, region=None):
        self.feed_calls.append((event.type, event.value, bool(FakeState.capture_mouse), bool(FakeState.capture_keyboard)))
        button = {"LEFTMOUSE": 0, "RIGHTMOUSE": 1, "MIDDLEMOUSE": 2}.get(event.type)
        if button is not None and event.value in {"PRESS", "RELEASE"}:
            if event.value == "PRESS" and FakeState.capture_mouse:
                self.io.add_mouse_button_event(button, True)
                self._mouse_owned[button] = True
            elif event.value == "RELEASE" and self._mouse_owned.get(button, False):
                self.io.add_mouse_button_event(button, False)
                self._mouse_owned[button] = False
        return "base"

    def should_capture(self, event): return False


class FakeSculptCore:
    _RUNNING_SAT_WINDOWS = set()
    region_resolver = None

    @classmethod
    def set_view3d_region_resolver(cls, resolver):
        cls.region_resolver = resolver

    @staticmethod
    def _clear_gesture_registry(): pass
    @staticmethod
    def _reset_transient_input(host=None): pass
    @staticmethod
    def _bump_generation(): return 1
    @staticmethod
    def _ensure_satellite_brokers(): pass


class FakeInteractions:
    _SHORTCUT_CAPTURE_ACTIVE = False


class FakeGallery:
    @staticmethod
    def draw_shared_sculpt_compact(*args, **kwargs): return None


def load_runtime_core():
    prefix = "lumafold_secondary_test"
    for key in tuple(sys.modules):
        if key == prefix or key.startswith(prefix + "."):
            sys.modules.pop(key, None)
    root_pkg = types.ModuleType(prefix); root_pkg.__path__ = [str(ROOT)]
    runtime_pkg = types.ModuleType(prefix + ".runtime"); runtime_pkg.__path__ = [str(ROOT / "runtime")]
    core_pkg = types.ModuleType(prefix + ".core"); core_pkg.__path__ = [str(ROOT / "core")]
    host_mod = types.ModuleType(prefix + ".core.host_control"); host_mod.HOST_CONTROL = FakeHostControl()
    session_mod = types.ModuleType(prefix + ".core.runtime_session"); session_mod.RUNTIME_SESSION = FakeRuntimeSession()
    state_mod = types.ModuleType(prefix + ".core.state"); state_mod.STATE = FakeState
    for mod in (root_pkg, runtime_pkg, core_pkg, host_mod, session_mod, state_mod): sys.modules[mod.__name__] = mod
    name = prefix + ".runtime.runtime_core"
    spec = importlib.util.spec_from_file_location(name, ROOT / "runtime" / "runtime_core.py")
    module = importlib.util.module_from_spec(spec); assert spec.loader is not None
    sys.modules[name] = module; spec.loader.exec_module(module)
    return module, session_mod.RUNTIME_SESSION


def fixture():
    FakeSculptCore.region_resolver = None
    module, session = load_runtime_core()
    module.install(FakeHost, FakeSculptCore, FakeInteractions, FakeGallery)
    assert callable(FakeSculptCore.region_resolver)
    host = FakeHost()
    session.publish_popups("embedded", ("LumaFold Brush Library##foundation",))
    return module, session, host


def uninstall_and_assert_resolver_cleared(module):
    module.uninstall()
    assert FakeSculptCore.region_resolver is None


def test_popup_button_uses_exact_pointer_then_normal_bridge():
    module, session, host = fixture()
    press = FakeEvent("LEFTMOUSE", "PRESS", local_x=350, local_y_top=220)
    host.feed_event(press, region=FakeRegion())
    assert host.io.events == [("pos", 350.0, 220.0), ("button", 0, True)], host.io.events
    assert host.feed_calls[-1] == ("LEFTMOUSE", "PRESS", True, False)
    assert host.should_capture(press) is True
    assert not session.close_requested("embedded")

    release = FakeEvent("LEFTMOUSE", "RELEASE", local_x=366, local_y_top=234)
    host.feed_event(release, region=FakeRegion())
    assert host.io.events[-2:] == [("pos", 366.0, 234.0), ("button", 0, False)], host.io.events
    assert host.feed_calls[-1] == ("LEFTMOUSE", "RELEASE", True, False)
    uninstall_and_assert_resolver_cleared(module)


def test_outside_click_uses_the_same_normal_bridge():
    module, session, host = fixture()
    event = FakeEvent("RIGHTMOUSE", "PRESS", local_x=80, local_y_top=80)
    host.feed_event(event, region=FakeRegion())
    assert host.io.events == [("pos", 80.0, 80.0), ("button", 1, True)], host.io.events
    assert host.feed_calls[-1] == ("RIGHTMOUSE", "PRESS", True, False)
    assert host.should_capture(event) is True
    assert not session.close_requested("embedded")
    uninstall_and_assert_resolver_cleared(module)


def test_escape_is_forwarded_then_requests_close():
    module, session, host = fixture()
    event = FakeEvent("ESC", "PRESS", local_x=350, local_y_top=220)
    host.feed_event(event, region=FakeRegion())
    assert host.feed_calls[-1] == ("ESC", "PRESS", False, True)
    assert session.close_requested("embedded")
    assert session.reason == "escape"
    assert host.should_capture(event) is True
    uninstall_and_assert_resolver_cleared(module)


def main():
    test_popup_button_uses_exact_pointer_then_normal_bridge()
    test_outside_click_uses_the_same_normal_bridge()
    test_escape_is_forwarded_then_requests_close()
    print("LumaFold Embedded Secondary input contract tests: PASS")


if __name__ == "__main__": main()
