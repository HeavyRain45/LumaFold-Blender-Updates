from __future__ import annotations

"""Pure-Python state-machine tests for runtime contracts.

These tests intentionally avoid importing the LumaFold package root so they can
run without Blender/bpy on CI.
"""

from pathlib import Path
import importlib.util
import sys

ROOT = Path(__file__).resolve().parents[1]


def load_module(name: str, relative: str):
    path = ROOT / relative
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    # dataclasses on Python 3.13 resolves class annotations through sys.modules
    # while the decorator is executing, so publish the module before exec.
    sys.modules[name] = module
    try:
        spec.loader.exec_module(module)
    except Exception:
        sys.modules.pop(name, None)
        raise
    return module


def test_runtime_session():
    mod = load_module("lf_runtime_session_test", "core/runtime_session.py")
    session = mod.RuntimeSession()

    assert session.popup_open("embedded") is False
    snap = session.publish_popups("embedded", ["A", "B"])
    assert snap.names == ("A", "B")
    assert snap.serial == 1
    assert session.popup_open("embedded") is True
    assert session.popup_named("embedded", "A") is True

    # Publishing the same state must not create a false transition.
    snap2 = session.publish_popups("embedded", ["A", "B"])
    assert snap2.serial == snap.serial

    assert session.request_popup_close("embedded", reason="escape") is True
    req = session.popup_snapshot("embedded")
    assert req.close_requested is True
    assert req.close_reason == "escape"
    session.acknowledge_close_request("embedded")
    assert session.close_requested("embedded") is False

    # Closing the actual popup clears pending close state.
    session.request_popup_close("embedded", reason="outside_click")
    closed = session.publish_popups("embedded", [])
    assert closed.open is False
    assert closed.close_requested is False

    # Host buckets are isolated.
    session.publish_popups("satellite", ["S"])
    assert session.popup_open("satellite") is True
    assert session.popup_open("embedded") is False
    session.clear_all()
    assert session.popup_open("embedded") is False
    assert session.popup_open("satellite") is False


def test_host_controller():
    mod = load_module("lf_host_control_test", "core/host_control.py")
    ctl = mod.HostController()
    events = []
    unsubscribe = ctl.subscribe(lambda snap: events.append(dict(snap)))

    start_generation = ctl.lease.generation
    detach = ctl.begin_detach()
    assert detach.state == mod.DETACHING
    assert detach.owner == "embedded"
    assert ctl.migration_locked is True

    satellite = ctl.grant_satellite(detach.generation)
    assert satellite.state == mod.SATELLITE
    assert satellite.owner == "satellite"
    assert satellite.generation > start_generation
    assert ctl.owns("satellite", satellite.generation)

    attach = ctl.begin_attach()
    assert attach.state == mod.ATTACHING
    assert attach.owner == "none"
    embedded = ctl.grant_embedded()
    assert embedded.state == mod.EMBEDDED
    assert embedded.owner == "embedded"
    assert ctl.owns("embedded", embedded.generation)

    assert len(events) >= 4
    before = len(events)
    unsubscribe()
    d2 = ctl.begin_detach()
    ctl.cancel_detach()
    assert len(events) == before
    assert d2.state in {mod.DETACHING, mod.EMBEDDED}


def test_stale_satellite_generation_rejected():
    mod = load_module("lf_host_control_stale_test", "core/host_control.py")
    ctl = mod.HostController()
    detach = ctl.begin_detach()
    try:
        ctl.grant_satellite(detach.generation + 99)
    except RuntimeError:
        pass
    else:
        raise AssertionError("stale Satellite generation must be rejected")


def main():
    test_runtime_session()
    test_host_controller()
    test_stale_satellite_generation_rejected()
    print("LumaFold pure runtime state tests: PASS")


if __name__ == "__main__":
    main()
