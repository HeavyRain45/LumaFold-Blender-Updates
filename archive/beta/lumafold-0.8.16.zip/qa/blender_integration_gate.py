from __future__ import annotations

"""Real Blender 5.2.1 background integration gate.

This validates Blender truth plus the product-level targeted Brush transaction:
- the public ``sculpt.enter`` command preserves its deferred UI-tick contract;
- the authoritative ``blender.mode`` service establishes real Sculpt truth;
- real Blender Brush Asset discovery and native activation;
- a Quick Brush picker target is latched from the same ``sculpt.state.changed``
  event used by the Embedded UI;
- even if the transient StateStore mirror is cleared before selection, the real
  wrapped ``sculpt.brush.library_activate`` command writes the selected asset to
  the intended Quick Slot immediately;
- the resulting Slot activates a real Blender Brush Asset.

Native activation remains UI-tick deferred in the product.  Background Blender
has no normal GUI timer loop while this script is blocking, so this gate verifies
the wrapped assignment transaction synchronously, then validates the same Slot's
native activation primitive directly.
"""

import bpy
import importlib.util
import json
from pathlib import Path
import sys
import traceback

ROOT = Path(__file__).resolve().parents[1]
RESULT_PATH = ROOT / "blender_integration_result.json"
if "--" in sys.argv:
    rest = sys.argv[sys.argv.index("--") + 1:]
    for idx, value in enumerate(rest):
        if value == "--result-path" and idx + 1 < len(rest):
            RESULT_PATH = Path(rest[idx + 1]).resolve()


def write_result(ok: bool, *, stage: str, detail: str = "", extra=None):
    payload = {
        "ok": bool(ok),
        "stage": str(stage),
        "detail": str(detail),
        "blender_version": bpy.app.version_string,
        "background": bool(bpy.app.background),
        "extra": dict(extra or {}),
    }
    RESULT_PATH.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print("LUMAFOLD_BLENDER_GATE", json.dumps(payload, ensure_ascii=False), flush=True)
    return payload


def load_addon():
    name = "lumafold_ci"
    for key in tuple(sys.modules):
        if key == name or key.startswith(name + "."):
            sys.modules.pop(key, None)
    spec = importlib.util.spec_from_file_location(
        name,
        ROOT / "__init__.py",
        submodule_search_locations=[str(ROOT)],
    )
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    sys.modules[name] = module
    spec.loader.exec_module(module)
    module.register()
    return module


def ensure_mesh():
    if str(getattr(bpy.context, "mode", "OBJECT")) != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")
    bpy.ops.object.select_all(action="DESELECT")
    bpy.ops.mesh.primitive_cube_add(size=2.0, location=(0.0, 0.0, 0.0))
    obj = bpy.context.view_layer.objects.active
    if obj is None or obj.type != "MESH":
        raise RuntimeError("failed to create active Mesh")
    return obj


def rel_identity(item):
    return str((item or {}).get("relative_asset_identifier") or "").replace("\\", "/").casefold()


def current_rel(app):
    snap = dict(app.services.require("blender.brush").current_sculpt_brush() or {})
    return rel_identity(snap), snap


def main():
    addon = None
    try:
        if tuple(bpy.app.version[:3]) != (5, 2, 1):
            raise RuntimeError(f"expected Blender 5.2.1, got {bpy.app.version_string}")
        if not bpy.app.background:
            raise RuntimeError("this CI gate must run in Blender background mode")

        addon = load_addon()
        app = addon.APP
        ensure_mesh()
        app.refresh_context(host_id="embedded")

        request = app.execute("sculpt.enter")
        if not request.ok or "已请求" not in str(request.message):
            raise RuntimeError(
                "sculpt.enter lost deferred request contract: " + str(request.message)
            )
        if str(bpy.context.mode).upper() != "OBJECT":
            raise RuntimeError(
                "background deferred request mutated Blender synchronously; "
                f"mode={bpy.context.mode}"
            )

        mode_service = app.services.require("blender.mode")
        mode_message = mode_service.set_mode("SCULPT")
        if str(bpy.context.mode).upper() != "SCULPT":
            raise RuntimeError(
                "blender.mode failed to establish Sculpt truth; "
                f"message={mode_message}; mode={bpy.context.mode}"
            )
        app.refresh_context(host_id="embedded")
        if str(app.state.context.mode).upper() != "SCULPT":
            raise RuntimeError(
                "LumaFold context did not follow Blender Sculpt truth; "
                f"context={app.state.context.mode}"
            )

        result = app.execute("sculpt.brush.library_refresh")
        if not result.ok:
            raise RuntimeError("Brush Library refresh failed: " + str(result.message))
        sculpt = app.store.namespace("sculpt")
        assets = [dict(item or {}) for item in list(sculpt.get("brush_library_assets") or ()) if rel_identity(item)]
        if len(assets) < 2:
            raise RuntimeError(f"expected >=2 real Brush Assets, got {len(assets)}; errors={sculpt.get('brush_library_errors')}")

        first = assets[0]
        brush_service = app.services.require("blender.brush")
        snap = brush_service.activate_asset(
            asset_library_type=str(first.get("asset_library_type") or "ESSENTIALS"),
            asset_library_identifier=str(first.get("asset_library_identifier") or ""),
            relative_asset_identifier=str(first.get("relative_asset_identifier") or ""),
        )
        current, current_snap = current_rel(app)
        if current != rel_identity(first):
            raise RuntimeError(
                "native Brush Asset activation truth mismatch; "
                f"expected={rel_identity(first)} current={current} snap={current_snap} activate={snap}"
            )

        second = next((item for item in assets[1:] if rel_identity(item) != current), None)
        if second is None:
            raise RuntimeError("could not find a distinct second Brush Asset")
        target_slot = 2

        # Reproduce the actual Embedded picker transaction. The UI publishes the
        # target event before the user clicks a Brush tile. Clear the transient
        # mirror afterwards on purpose; the Runtime policy must retain the target.
        sculpt["quick_replace_slot"] = target_slot
        app.events.emit(
            "sculpt.state.changed",
            {"fields": {"quick_replace_slot": target_slot}, "source": "embedded"},
        )
        sculpt["quick_replace_slot"] = -1
        choose = app.execute(
            "sculpt.brush.library_activate",
            identity=str(second.get("identity") or ""),
        )
        if not choose.ok:
            raise RuntimeError("wrapped library_activate failed: " + str(choose.message))

        slots = list(sculpt.get("quick_brush_slots") or ())
        slot = dict(slots[target_slot] or {})
        expected = rel_identity(second)
        slot_rel = rel_identity(slot)
        if slot_rel != expected:
            raise RuntimeError(
                "wrapped targeted replacement lost the UI target; "
                f"expected={expected} slot={slot_rel} message={choose.message}"
            )
        if int(sculpt.get("quick_replace_slot", -1)) != -1:
            raise RuntimeError("wrapped targeted replacement did not consume its target")

        # The product defers this native mutation to the next GUI UI tick. In a
        # blocking background script, validate the exact resulting Slot directly.
        activate = app.execute("sculpt.brush.activate_slot", slot=target_slot)
        if not activate.ok:
            raise RuntimeError("activate_slot failed: " + str(activate.message))
        current, current_snap = current_rel(app)
        if current != expected:
            raise RuntimeError(
                "Quick Slot did not activate real Blender Brush; "
                f"expected={expected} current={current} snap={current_snap}"
            )

        write_result(
            True,
            stage="complete",
            detail="real Blender wrapped targeted Brush replacement + native Slot activation passed",
            extra={
                "mode_service": str(mode_message),
                "asset_count": len(assets),
                "first_brush": str(first.get("name") or ""),
                "second_brush": str(second.get("name") or ""),
                "target_slot": target_slot,
                "wrapped_message": str(choose.message),
            },
        )
        return 0
    except Exception:
        write_result(False, stage="integration_failure", detail=traceback.format_exc())
        return 2
    finally:
        if addon is not None:
            try:
                addon.unregister()
            except Exception:
                pass


raise SystemExit(main())
