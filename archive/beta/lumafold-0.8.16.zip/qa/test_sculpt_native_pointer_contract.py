from __future__ import annotations

"""Focused contract for dev76+ Blender-native plain-LMB arbitration."""

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ROUTE = (ROOT / "runtime" / "sculpt_route_truth.py").read_text(encoding="utf-8")
ARBITER = (ROOT / "runtime" / "sculpt_native_pointer.py").read_text(encoding="utf-8")
INIT = (ROOT / "__init__.py").read_text(encoding="utf-8")


def require(text: str, token: str, label: str):
    if token not in text:
        raise AssertionError(f"{label} missing: {token}")


def main():
    require(ARBITER, 'bpy.ops.sculpt.brush_stroke(', "native Sculpt invocation")
    require(ARBITER, 'ignore_background_click=True', "Blender over-mesh arbitration")
    require(ARBITER, 'if "PASS_THROUGH" in sculpt_result:', "background pass-through branch")
    require(ARBITER, 'return ROTATE if _invoke_rotate(target) else FALLBACK', "native Rotate promotion")
    require(ARBITER, 'return FALLBACK', "cancel/error fail closed")
    require(ROUTE, '_NATIVE_POINTER.arbitrate_plain_lmb(context, event, target)', "single pointer arbiter route")
    require(ROUTE, '"blender_native_sculpt"', "native Sculpt trace")
    require(ROUTE, '"blender_native_rotate"', "native Rotate trace")
    require(INIT, 'sculpt_native_pointer = _importlib.import_module', "native pointer module wiring")
    require(INIT, 'sculpt_route_truth.install(', "route arbiter wiring")
    require(INIT, 'sculpt_native_pointer,', "native pointer dependency injection")

    if (ROOT / "runtime" / "sculpt_pointer_intent.py").exists():
        raise AssertionError("custom Sculpt surface raycast authority still exists")
    for forbidden in ("scene.ray_cast", ".ray_cast(", "region_2d_to_origin_3d", "region_2d_to_vector_3d"):
        if forbidden in ARBITER:
            raise AssertionError("native pointer arbiter reintroduced custom hit testing: " + forbidden)

    print("Blender-native Sculpt pointer arbitration contract: PASS")


if __name__ == "__main__":
    main()
