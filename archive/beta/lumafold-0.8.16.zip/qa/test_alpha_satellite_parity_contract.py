from __future__ import annotations

"""Pure regression contract for Native Secondary Alpha product parity."""

import base64
import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
UI_INIT = ROOT / "ui" / "__init__.py"
PRODUCT = ROOT / "ui" / "alpha_library_product.py"
SECONDARY = ROOT / "desktop" / "secondary_surface_host_runtime.py"
PREVIEWS = ROOT / "ui" / "preview_textures.py"
SERVICES = ROOT / "services" / "__init__.py"


def fail(message):
    raise AssertionError(message)


def require(text, token, label):
    if token not in text:
        fail(f"{label} missing contract token: {token}")


def load_preview_cache():
    spec = importlib.util.spec_from_file_location("lumafold_preview_cache_gate", PREVIEWS)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module.PreviewTextureCache


def assert_product_binding():
    ui_init = UI_INIT.read_text(encoding="utf-8")
    product = PRODUCT.read_text(encoding="utf-8")
    secondary = SECONDARY.read_text(encoding="utf-8")

    # Secondary imports the public ui.sculpt_view symbol. ui.__init__ must bind
    # that symbol to the same Product wrapper Embedded uses, rather than leaving
    # a stale foundation-only function that lacks add/delete semantics.
    require(
        ui_init,
        "_sculpt_view.draw_alpha_library_foundation = _alpha_library_product.draw_alpha_library_product",
        "shared Alpha product binding",
    )
    require(secondary, "from ui.sculpt_view import draw_brush_library_foundation, draw_alpha_library_foundation", "Secondary public UI import")
    require(secondary, "draw_alpha_library_foundation(", "Secondary Alpha draw")

    require(product, '"add_alpha": "sculpt.alpha.source_add_dialog"', "unified Alpha add command")
    require(product, '"delete_asset": "sculpt.alpha.asset_delete"', "Alpha delete command")
    require(product, 'queue_command = getattr(__main__, "_queue_command", None)', "Native Secondary command adapter")
    require(secondary, "def _queue_command(command_id, **kwargs):", "Secondary command queue")


def assert_satellite_picker_context():
    services = SERVICES.read_text(encoding="utf-8")

    # Satellite commands reach Blender from DesktopBridge/timer callbacks, not
    # from a Blender UI event. INVOKE_DEFAULT therefore must be anchored to a
    # concrete Blender Window/Area instead of trusting bpy.context foreground
    # focus. Silent exception swallowing is forbidden because it made dev65 CI
    # green while real Satellite clicks appeared to do nothing.
    require(services, "def _invoke_blender_window_operator", "Satellite Blender UI invoke helper")
    require(services, 'window_manager", None), "windows"', "real Blender Window enumeration")
    require(services, 'str(getattr(area, "type", "")) == "VIEW_3D"', "VIEW_3D priority")
    require(services, 'str(getattr(item, "type", "")) == "WINDOW"', "WINDOW region selection")
    require(services, "with bpy.context.temp_override(**override):", "explicit Blender context override")
    require(services, "result = operator('INVOKE_DEFAULT')", "operator invoke inside override")
    require(services, 'bpy.ops.lumafold.add_alpha_folder', "Alpha mixed picker operator")
    require(services, 'sculpt_state["alpha_action_status"] = "Alpha 添加窗口已打开"', "successful picker status")
    require(services, 'STATE.last_error = "Satellite Alpha picker invoke failed: " + str(exc)', "picker failure evidence")

    source_dialog_start = services.find("def _alpha_source_add_dialog():")
    source_dialog_end = services.find("def _alpha_user_folder_create_dialog():", source_dialog_start)
    if source_dialog_start < 0 or source_dialog_end < 0:
        fail("Alpha source dialog function range missing")
    source_dialog = services[source_dialog_start:source_dialog_end]
    if "except Exception:\n                pass" in source_dialog:
        fail("Satellite Alpha picker still silently swallows invoke failures")


def assert_native_legacy_row_normalization():
    PreviewTextureCache = load_preview_cache()

    class NativeWGLImguiRenderer:
        def __init__(self):
            self.uploads = []

        def register_rgba_texture(self, width, height, raw):
            self.uploads.append((int(width), int(height), bytes(raw)))
            return len(self.uploads)

        def unregister_texture(self, _tex_id):
            return None

    # Two 1px RGBA rows make orientation unambiguous.
    top = bytes((255, 0, 0, 255))
    bottom = bytes((0, 0, 0, 255))
    renderer = NativeWGLImguiRenderer()
    cache = PreviewTextureCache(renderer)

    legacy = {
        "key": "file|c:/alpha/asymmetric.png",
        "width": 1,
        "height": 2,
        "rgba_b64": base64.b64encode(top + bottom).decode("ascii"),
        "source": "image",
    }
    if not cache.resolve(legacy):
        fail("legacy Alpha preview was not uploaded")
    uploaded = renderer.uploads[-1][2]
    if uploaded != bottom + top:
        fail("Native WGL legacy Alpha preview rows were not flipped exactly once")

    # dev62 product pixels are already top-down. They must remain byte-identical.
    product = {
        "key": "file|c:/alpha/product.png",
        "width": 1,
        "height": 2,
        "rgba_b64": base64.b64encode(top + bottom).decode("ascii"),
        "source": "alpha_data_pixels",
    }
    if not cache.resolve(product):
        fail("product Alpha preview was not uploaded")
    if renderer.uploads[-1][2] != top + bottom:
        fail("top-down Alpha product pixels were flipped again")

    # Brush previews are outside this compatibility shim even if a legacy
    # source happens to use the same generic source label.
    brush = {
        "key": "asset|essentials||brush/foo",
        "width": 1,
        "height": 2,
        "rgba_b64": base64.b64encode(top + bottom).decode("ascii"),
        "source": "image",
    }
    if not cache.resolve(brush):
        fail("Brush preview was not uploaded")
    if renderer.uploads[-1][2] != top + bottom:
        fail("Native Alpha compatibility transform leaked into Brush previews")


def main():
    assert_product_binding()
    assert_satellite_picker_context()
    assert_native_legacy_row_normalization()
    print("Satellite Alpha product parity contract: PASS")


if __name__ == "__main__":
    main()
