from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SYNC = (ROOT / "services" / "sculpt_resource_sync.py").read_text(encoding="utf-8")
ALPHA = (ROOT / "services" / "sculpt_alpha_product.py").read_text(encoding="utf-8")
HOST = (ROOT / "runtime" / "host_input_boundary.py").read_text(encoding="utf-8")

required_sync = (
    "def _alpha_native_token",
    "alpha_token = self._alpha_native_token()",
    "if alpha_token != self._alpha_token:",
    "alpha_snap = dict(alpha_service.current_sculpt_alpha() or {})",
    "def _cached_alpha_preview",
    '"alpha_library_preview_cache"',
    '"primary_alpha_preview_cache"',
    "alpha_light_polls",
    "alpha_full_syncs",
)
for token in required_sync:
    assert token in SYNC, f"missing Alpha idle-sync contract token: {token}"

# The watcher hot path must compare the native in-memory token before asking the
# Alpha service for its canonical snapshot.
token_pos = SYNC.index("alpha_token = self._alpha_native_token()")
change_pos = SYNC.index("if alpha_token != self._alpha_token:", token_pos)
full_pos = SYNC.index("alpha_snap = dict(alpha_service.current_sculpt_alpha() or {})", change_pos)
assert token_pos < change_pos < full_pos

# Preview generation inside the watcher is change-time work only and reuses the
# library cache before building a one-off active preview.
sync_pos = SYNC.index("def _sync_alpha")
cache_pos = SYNC.index("preview = self._cached_alpha_preview(state, identity)", sync_pos)
build_pos = SYNC.index("current_sculpt_alpha_preview", cache_pos)
assert sync_pos < cache_pos < build_pos

# The Alpha owner itself must also be idempotent. Other legitimate consumers
# (Bridge snapshots, activation commands, diagnostics) may ask for current Alpha
# repeatedly; those reads must remain memory-only while Blender native IDs are
# unchanged.
required_alpha = (
    "def _active_native_token",
    "def current_sculpt_alpha(self):",
    "token == self._active_alpha_token",
    "self._active_alpha_snapshot",
    "def current_sculpt_alpha_preview(self, max_edge=64):",
    "token == self._active_preview_token",
    "self._active_preview_payload",
)
for token in required_alpha:
    assert token in ALPHA, f"missing Alpha owner cache contract token: {token}"

state_cache_pos = ALPHA.index("token == self._active_alpha_token")
state_super_pos = ALPHA.index("super().current_sculpt_alpha()", state_cache_pos)
assert state_cache_pos < state_super_pos
preview_cache_pos = ALPHA.index("token == self._active_preview_token")
preview_file_pos = ALPHA.index("self._file_pixels_payload", preview_cache_pos)
assert preview_cache_pos < preview_file_pos

# Embedded keeps a legacy Blender 60 Hz timer for lifecycle compatibility, but
# the modal boundary must coalesce idle TIMER traffic before the old redraw path.
# Real input events are deliberately outside this gate.
required_host = (
    "_IDLE_TIMER_INTERVAL = 0.10",
    "def _admit_idle_timer",
    'if event_type == "TIMER":',
    "if not _admit_idle_timer(self):",
    'return {"RUNNING_MODAL"}',
)
for token in required_host:
    assert token in HOST, f"missing Embedded idle-timer contract token: {token}"

timer_pos = HOST.index('if event_type == "TIMER":')
pointer_pos = HOST.index("if event_type in _POINTER_EVENTS:", timer_pos)
assert timer_pos < pointer_pos

print("Alpha active idle-sync + Embedded idle redraw performance contract PASS")
