from __future__ import annotations

"""Static contract for Blender-native navigation and Sculpt pointer ownership."""

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ADDON = (ROOT / "__init__.py").read_text(encoding="utf-8")
CORE = (ROOT / "runtime" / "sculpt_input_core.py").read_text(encoding="utf-8")
NAV = (ROOT / "runtime" / "sculpt_navigation.py").read_text(encoding="utf-8")
ROUTE = (ROOT / "runtime" / "sculpt_route_truth.py").read_text(encoding="utf-8")
ARBITER = (ROOT / "runtime" / "sculpt_native_pointer.py").read_text(encoding="utf-8")
ALT = (ROOT / "runtime" / "sculpt_alt_gesture.py").read_text(encoding="utf-8")
ALT_ZOOM = (ROOT / "runtime" / "sculpt_alt_zoom.py").read_text(encoding="utf-8")
MASK = (ROOT / "runtime" / "sculpt_mask_gesture.py").read_text(encoding="utf-8")
LOCALITY = (ROOT / "runtime" / "tablet_pointer_locality.py").read_text(encoding="utf-8")


def require(text: str, token: str, label: str):
    if token not in text:
        raise AssertionError(f"{label} missing contract token: {token}")


def main():
    require(NAV, 'bpy.ops.view3d.rotate("INVOKE_DEFAULT")', "native rotate handoff")
    require(NAV, "def try_native_navigation", "stateless navigation adapter")
    require(NAV, "set_navigation_handler", "explicit navigation adapter publication")
    if "_base._native_navigation_handoff =" in NAV:
        raise AssertionError("navigation adapter reverted to symbol monkey patching")

    forbidden_nav = (
        "view_rotation =", ".view_rotation=", "keymap_items.new_modal",
        "_NATIVE_SESSIONS", "_native_session_tick", "_enable_native_shift_snap",
        "_advance_free_orbit", "_pointer_hits_active_sculpt",
    )
    for token in forbidden_nav:
        if token in NAV:
            raise AssertionError("navigation isolation violated by: " + token)

    forbidden_core = (
        "view_rotation =", ".view_rotation=", "_SNAP_DIRS", "_advance_free_orbit",
        "_display_snap_or_free", "view3d.view_orbit", "keymap_items.new_modal",
    )
    for token in forbidden_core:
        if token in CORE:
            raise AssertionError("input core regained ordinary orbit state: " + token)

    require(ADDON, 'sculpt_native_pointer = _importlib.import_module', "native pointer arbiter wiring")
    require(ADDON, 'sculpt_alt_zoom = _importlib.import_module', "continuous Alt zoom module wiring")
    require(ADDON, 'sculpt_alt_gesture = _importlib.import_module', "Alt gesture module wiring")
    require(ADDON, 'sculpt_mask_gesture = _importlib.import_module', "mask gesture module wiring")
    require(ADDON, 'tablet_pointer_locality = _importlib.import_module', "tablet locality module wiring")
    require(ADDON, 'sculpt_alt_gesture.install(real_machine_trace, sculpt_alt_zoom)', "continuous zoom injection")
    require(ADDON, 'sculpt_route_truth.install(', "route authority injection")

    require(ARBITER, 'ignore_background_click=True', "Blender native surface ownership")
    require(ARBITER, 'if "PASS_THROUGH" in sculpt_result:', "Blender background decision")
    require(ARBITER, 'bpy.ops.view3d.rotate("INVOKE_DEFAULT")', "background native rotate")
    require(ROUTE, '_NATIVE_POINTER.arbitrate_plain_lmb(context, event, target)', "single native pointer arbitration")
    require(ROUTE, '_ALT_GESTURE.handle_pointer_press(context, event, target)', "isolated Alt gesture route")
    require(ROUTE, '_MASK_GESTURE.handle_pointer_press(context, event, target)', "single-owner Ctrl mask route")
    require(ROUTE, '"blender_native_sculpt"', "native Sculpt trace")
    require(ROUTE, '"blender_native_rotate"', "native Rotate trace")
    if "_recent_alt()" in ROUTE:
        raise AssertionError("route authority still arms a new gesture from Alt grace")

    require(ALT, 'if not bool(getattr(event, "alt", False)):', "strict Alt gesture start")
    require(ALT, 'bpy.ops.sculpt.brush_stroke(', "native inverse Sculpt")
    require(ALT, 'mode="INVERT"', "native inverse mode")
    require(ALT, 'bpy.ops.object.transfer_mode("INVOKE_DEFAULT")', "native Alt-tap object transfer")
    require(ALT, '_ZOOM.apply(context, dx, dy)', "isolated continuous zoom handoff")
    if "view_distance =" in ALT:
        raise AssertionError("Alt gesture coordinator owns view distance instead of zoom adapter")
    require(ALT_ZOOM, 'rv3d.view_distance =', "continuous ZBrush Scale implementation")
    require(ALT_ZOOM, 'ZOOM_LOG_GAIN = 0.0028325', "validated continuous zoom tuning")
    for forbidden in ("view_rotation =", ".view_rotation=", "keymap_items.new_modal", "bpy.ops.view3d.rotate"):
        if forbidden in ALT_ZOOM:
            raise AssertionError("Alt zoom adapter escaped its distance-only boundary: " + forbidden)

    require(MASK, 'filter_type": "SHARPEN" if sharpen else "SMOOTH"', "native mask smooth/sharpen")
    require(MASK, 'self._start_on_surface = bool(_drag_hits_active_surface(context, event))', "mask-local surface intent")
    require(MASK, 'bpy.ops.paint.mask_flood_fill', "native mask invert/clear")
    require(MASK, 'bpy.ops.paint.mask_box_gesture', "native box-mask mutation")
    require(MASK, 'brush_toggle="MASK"', "native surface mask stroke")
    if '_drag_hits_active_surface(context, event)' in ROUTE:
        raise AssertionError("mask-local hit testing leaked into ordinary route authority")

    require(LOCALITY, "GetCursorPos", "Windows cursor truth")
    require(LOCALITY, "WindowFromPoint", "Windows window-under-cursor truth")
    require(LOCALITY, "MonitorFromPoint", "Windows cursor monitor truth")
    require(LOCALITY, "MonitorFromWindow", "Windows foreground monitor truth")
    require(LOCALITY, '"cursor_foreground_monitor_mismatch"', "cross-monitor duplication evidence")
    require(LOCALITY, '"tablet_api"', "Blender tablet API evidence")
    for forbidden in ("SetCursorPos", "ClipCursor", "SetCapture", "ReleaseCapture"):
        if forbidden in LOCALITY:
            raise AssertionError("tablet locality diagnostics mutate pointer state: " + forbidden)

    native_pos = ROUTE.find('_NATIVE_POINTER.arbitrate_plain_lmb(context, event, target)')
    transient_pos = ROUTE.find('ok = base._invoke_transient(operator_name, target)')
    if native_pos < 0 or transient_pos < 0 or native_pos > transient_pos:
        raise AssertionError("Blender-native pointer arbitration must resolve before legacy transient fallback")

    print("Blender-native navigation + modular ZBrush gesture contract: PASS")


if __name__ == "__main__":
    main()
