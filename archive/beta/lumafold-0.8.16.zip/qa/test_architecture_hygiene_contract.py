from __future__ import annotations

"""Architecture baseline guardrails for post-dev76 development.

This test intentionally checks ownership boundaries rather than product layout.
It should fail when a superseded authority returns or a second source of truth is
introduced into the frozen Host/Input/Alpha paths.
"""

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / "runtime"

LEGACY_RUNTIME_MODULES = (
    "runtime_authority.py",
    "satellite_input_boundary.py",
    "satellite_bridge_performance.py",
    "secondary_dismiss_product.py",
    "sculpt_pointer_intent.py",
    "sculpt_input_activity.py",
    "satellite_input_session.py",
)
LEGACY_IMPORT_TOKENS = (
    "runtime.runtime_authority",
    "runtime.satellite_input_boundary",
    "runtime.satellite_bridge_performance",
    "runtime.secondary_dismiss_product",
    "runtime.sculpt_pointer_intent",
    "sculpt_pointer_intent",
    "runtime.sculpt_input_activity",
    "runtime.satellite_input_session",
)


def require(text: str, token: str, label: str):
    if token not in text:
        raise AssertionError(f"{label} missing: {token}")


def main():
    for name in LEGACY_RUNTIME_MODULES:
        if (RUNTIME / name).exists():
            raise AssertionError("superseded runtime module returned: " + name)

    for path in ROOT.rglob("*.py"):
        rel = path.relative_to(ROOT)
        if rel.parts and rel.parts[0] == "qa":
            continue
        text = path.read_text(encoding="utf-8")
        for token in LEGACY_IMPORT_TOKENS:
            if token in text:
                raise AssertionError(f"legacy authority reference returned in {rel}: {token}")

    host = (ROOT / "core" / "host_control.py").read_text(encoding="utf-8")
    runtime_core = (RUNTIME / "runtime_core.py").read_text(encoding="utf-8")
    sculpt_input = (RUNTIME / "sculpt_input_core.py").read_text(encoding="utf-8")
    route = (RUNTIME / "sculpt_route_truth.py").read_text(encoding="utf-8")
    native_pointer = (RUNTIME / "sculpt_native_pointer.py").read_text(encoding="utf-8")
    bridge = (RUNTIME / "satellite_bridge_authority.py").read_text(encoding="utf-8")
    services = (ROOT / "services" / "__init__.py").read_text(encoding="utf-8")

    require(host, "HOST_CONTROL = HostController()", "single HostController instance")
    require(sculpt_input, "HOST_CONTROL.snapshot()", "Host lease input truth")
    require(sculpt_input, "def set_route_handler", "explicit route slot")
    require(sculpt_input, "def set_navigation_handler", "explicit navigation slot")
    require(sculpt_input, "def set_input_observer", "explicit observer slot")
    require(route, "_context_sculpt_truth", "event-context route truth")
    require(native_pointer, "ignore_background_click=True", "Blender native Sculpt arbitration")
    require(native_pointer, 'bpy.ops.view3d.rotate("INVOKE_DEFAULT")', "Blender native Rotate arbitration")

    for token in (
        "core._bump_generation()",
        "core._RUNNING_SAT_WINDOWS.clear()",
        "core._ensure_satellite_brokers()",
    ):
        if token in runtime_core:
            raise AssertionError("Runtime Core regained broker ownership: " + token)

    for token in ("sync_brush_state", "sync_alpha_state"):
        if token in bridge:
            raise AssertionError("Satellite Store transport regained Blender resource sync: " + token)

    require(services, 'app.services.register("alpha.source_registry"', "Alpha linked-source owner")
    require(services, 'app.services.register("alpha.managed_store"', "Alpha managed-filesystem owner")
    require(services, 'app.services.register("blender.alpha"', "Alpha canonical product service")

    print("Architecture hygiene baseline: PASS")


if __name__ == "__main__":
    main()
