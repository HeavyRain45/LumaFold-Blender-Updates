from __future__ import annotations

"""Real Blender 5.2.1 -> LumaFold Satellite launcher integration gate.

This gate deliberately matches the installed product dependency layout instead
of giving CI a richer runtime than users receive:
- LumaFold vendor contains the pinned slimgui payload only;
- NumPy must come from Blender's own Python installation through the production
  launcher's child environment;
- desktop.launcher.vendor_dir is never monkey-patched.

Production transaction under test:
Blender -> production launcher -> actual LumaFold vendor path -> Blender NumPy
inheritance -> native child -> off-screen WGL first frame -> move/show on-screen
and verify -> satellite_ready -> lease grant/active -> WM_APP_SHOW activation.

The critical dev47 contract is that READY is *visible-ready*. Embedded must not
be retired for a child that rendered successfully but is still at -32000.
"""

import bpy
import ctypes
from ctypes import wintypes
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parents[1]
RESULT_PATH = ROOT / "blender_satellite_launcher_result.json"
RUNTIME_PATH = None
if "--" in sys.argv:
    rest = sys.argv[sys.argv.index("--") + 1:]
    for idx, value in enumerate(rest):
        if value == "--result-path" and idx + 1 < len(rest):
            RESULT_PATH = Path(rest[idx + 1]).resolve()
        if value == "--runtime-path" and idx + 1 < len(rest):
            RUNTIME_PATH = Path(rest[idx + 1]).resolve()

WM_CLOSE = 0x0010
TARGET_X = 120
TARGET_Y = 120


def write_result(ok: bool, stage: str, detail: str = "", extra=None):
    payload = {
        "ok": bool(ok),
        "stage": str(stage),
        "detail": str(detail),
        "blender_version": bpy.app.version_string,
        "background": bool(bpy.app.background),
        "extra": dict(extra or {}),
    }
    RESULT_PATH.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print("LUMAFOLD_BLENDER_SATELLITE_GATE", json.dumps(payload, ensure_ascii=False), flush=True)


def load_addon():
    name = "lumafold_satellite_ci"
    for key in tuple(sys.modules):
        if key == name or key.startswith(name + "."):
            sys.modules.pop(key, None)
    spec = importlib.util.spec_from_file_location(
        name,
        ROOT / "__init__.py",
        submodule_search_locations=[str(ROOT)],
    )
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    sys.modules[name] = module
    spec.loader.exec_module(module)
    module.register()
    return module


def _user32():
    return ctypes.WinDLL("user32", use_last_error=True)


def any_window_for_pid(pid: int):
    user32 = _user32()
    enum_proc_t = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    found = []

    @enum_proc_t
    def callback(hwnd, _lparam):
        owner_pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(owner_pid))
        if int(owner_pid.value) == int(pid):
            found.append(hwnd)
            return False
        return True

    user32.EnumWindows(callback, 0)
    return found[0] if found else None


def window_info_for_pid(pid: int):
    user32 = _user32()
    hwnd = any_window_for_pid(pid)
    if hwnd is None:
        return None
    rect = wintypes.RECT()
    if not user32.GetWindowRect(hwnd, ctypes.byref(rect)):
        return None
    return {
        "hwnd": hwnd,
        "visible": bool(user32.IsWindowVisible(hwnd)),
        "left": int(rect.left),
        "top": int(rect.top),
        "right": int(rect.right),
        "bottom": int(rect.bottom),
    }


def pump_bridge(bridge):
    try:
        bridge._pump_main_thread()
    except Exception:
        pass


def _is_numpy_payload(name: str) -> bool:
    key = str(name or "").casefold()
    return key == "numpy" or key == "numpy.libs" or (key.startswith("numpy-") and key.endswith(".dist-info"))


def install_ci_payload_into_real_vendor(bootstrap_module):
    """Populate production vendor with slimgui but deliberately exclude NumPy."""
    if RUNTIME_PATH is None or not RUNTIME_PATH.is_dir():
        raise RuntimeError(f"CI native runtime path missing: {RUNTIME_PATH}")
    vendor = Path(bootstrap_module.vendor_dir()).resolve()
    shutil.rmtree(vendor, ignore_errors=True)
    vendor.mkdir(parents=True, exist_ok=True)
    for child in RUNTIME_PATH.iterdir():
        if _is_numpy_payload(child.name):
            continue
        dest = vendor / child.name
        if child.is_dir():
            shutil.copytree(child, dest, dirs_exist_ok=True)
        else:
            shutil.copy2(child, dest)

    names = [child.name for child in vendor.iterdir()]
    if not names:
        raise RuntimeError("real LumaFold vendor path remained empty after CI payload install")
    if any(_is_numpy_payload(name) for name in names):
        raise RuntimeError(f"QA accidentally placed NumPy in LumaFold vendor: {names}")
    if not any("slimgui" in name.casefold() for name in names):
        raise RuntimeError(f"slimgui payload missing from real vendor: {names}")
    return vendor


def main():
    addon = None
    proc = None
    actual_vendor = None
    try:
        if tuple(bpy.app.version[:3]) != (5, 2, 1):
            raise RuntimeError(f"expected Blender 5.2.1, got {bpy.app.version_string}")
        if not bpy.app.background:
            raise RuntimeError("launcher gate must run in Blender background mode")

        # Product parity requirement: Blender itself owns NumPy. The independent
        # Satellite child receives this exact package parent via launcher env.
        import numpy as blender_numpy
        blender_numpy_parent = str(Path(blender_numpy.__file__).resolve().parent.parent)

        addon = load_addon()
        launcher = sys.modules[addon.__name__ + ".desktop.launcher"]
        bridge_mod = sys.modules[addon.__name__ + ".desktop.bridge_server"]
        host_mod = sys.modules[addon.__name__ + ".core.host_control"]
        state_mod = sys.modules[addon.__name__ + ".core.state"]
        bootstrap_mod = sys.modules[addon.__name__ + ".runtime.bootstrap"]
        bridge = bridge_mod.BRIDGE
        host_control = host_mod.HOST_CONTROL

        actual_vendor = install_ci_payload_into_real_vendor(bootstrap_mod)
        launcher_vendor = Path(launcher.vendor_dir()).resolve()
        if launcher_vendor != actual_vendor:
            raise RuntimeError(
                f"production launcher vendor mismatch: launcher={launcher_vendor} actual={actual_vendor}"
            )

        child_env = launcher._satellite_child_env()
        child_pythonpath = [p for p in str(child_env.get("PYTHONPATH") or "").split(os.pathsep) if p]
        if blender_numpy_parent not in child_pythonpath:
            raise RuntimeError(
                "production Satellite child env did not inherit Blender NumPy path: "
                f"numpy_parent={blender_numpy_parent} PYTHONPATH={child_pythonpath}"
            )
        if str(actual_vendor) not in child_pythonpath:
            raise RuntimeError("production Satellite child env lost LumaFold vendor path")

        host_control.recover_embedded()
        lease = host_control.begin_detach()
        proc = launcher.launch_satellite_host(
            420, 500, screen_x=TARGET_X, screen_y=TARGET_Y, generation=lease.generation
        )
        python_exe = launcher.find_python_executable()

        # PHASE 1: child renders its first real WGL frame off-screen, then moves
        # the same HWND on-screen and verifies it before READY. Embedded still
        # owns the lease throughout this phase.
        ready_deadline = time.monotonic() + 12.0
        visible_ready = None
        while time.monotonic() < ready_deadline:
            pump_bridge(bridge)
            if proc.poll() is not None:
                raise RuntimeError(
                    f"production Satellite child exited before READY: code={proc.returncode}; "
                    f"bridge_error={bridge.last_error}"
                )
            info = window_info_for_pid(proc.pid)
            if bridge.satellite_ready:
                visible_ready = info
                break
            time.sleep(0.02)

        if not bridge.satellite_ready:
            raise RuntimeError(
                "production Launcher never received visible-ready satellite_ready; "
                f"bridge_error={bridge.last_error} client={bridge.client_name} window={window_info_for_pid(proc.pid)}"
            )
        if visible_ready is None:
            raise RuntimeError("Satellite READY arrived without a native Win32 host")
        if not visible_ready["visible"]:
            raise RuntimeError(f"Satellite READY arrived while HWND was hidden: {visible_ready}")
        if visible_ready["left"] < -10000 or visible_ready["top"] < -10000:
            raise RuntimeError(f"Satellite READY arrived while HWND was still off-screen: {visible_ready}")
        if abs(int(visible_ready["left"]) - TARGET_X) > 16 or abs(int(visible_ready["top"]) - TARGET_Y) > 16:
            raise RuntimeError(f"Satellite visible-ready HWND missed requested target: {visible_ready}")
        if int(bridge.satellite_expected_generation or 0) != int(lease.generation):
            raise RuntimeError(
                "generation mismatch before grant: "
                f"expected={lease.generation} bridge={bridge.satellite_expected_generation}"
            )

        # PHASE 2: mirror operators._external_satellite_handoff_tick exactly.
        # The child is already visible but not authoritative; lease grant makes
        # it the real Host and triggers the normal WM_APP_SHOW activation edge.
        host_control.grant_satellite(lease.generation)
        bridge.satellite_active = True
        state_mod.STATE.host_mode = "satellite"
        snap = host_control.snapshot()
        if snap.get("state") != "SATELLITE" or snap.get("owner") != "satellite":
            raise RuntimeError(f"Host lease did not grant Satellite ownership: {snap}")

        # PHASE 3: child must remain visible/stable after the grant rather than
        # jumping back to the off-screen preflight coordinate.
        show_deadline = time.monotonic() + 3.0
        shown = None
        while time.monotonic() < show_deadline:
            pump_bridge(bridge)
            if proc.poll() is not None:
                raise RuntimeError(f"Satellite died after lease grant: code={proc.returncode}")
            info = window_info_for_pid(proc.pid)
            if info and info["visible"] and info["left"] > -10000 and info["top"] > -10000:
                shown = info
                break
            time.sleep(0.02)

        if shown is None:
            raise RuntimeError(
                "Satellite lost visible-ready state after grant; "
                f"last={window_info_for_pid(proc.pid)} bridge_error={bridge.last_error} requests={bridge.request_count}"
            )

        survival_until = time.monotonic() + 0.75
        while time.monotonic() < survival_until:
            pump_bridge(bridge)
            if proc.poll() is not None:
                raise RuntimeError(f"Satellite died after becoming visible: code={proc.returncode}")
            info = window_info_for_pid(proc.pid)
            if info is None or not info["visible"] or info["left"] < -10000:
                raise RuntimeError(f"Satellite window lost final visible state: {info}")
            time.sleep(0.02)

        _user32().PostMessageW(shown["hwnd"], WM_CLOSE, 0, 0)
        close_deadline = time.monotonic() + 4.0
        while time.monotonic() < close_deadline and proc.poll() is None:
            pump_bridge(bridge)
            time.sleep(0.02)
        if proc.poll() is None:
            raise RuntimeError("Satellite did not close after WM_CLOSE")

        write_result(
            True,
            "complete",
            "slimgui-only vendor + Blender NumPy + offscreen WGL + visible-ready before READY + grant stability passed",
            {
                "python_executable": str(python_exe),
                "runtime_vendor": str(actual_vendor),
                "blender_numpy_parent": blender_numpy_parent,
                "generation": int(lease.generation),
                "request_count": int(bridge.request_count),
                "client": str(bridge.satellite_client or bridge.client_name),
                "ready_left": int(visible_ready["left"]),
                "ready_top": int(visible_ready["top"]),
                "final_left": int(shown["left"]),
                "final_top": int(shown["top"]),
            },
        )
        return 0
    except Exception:
        write_result(False, "integration_failure", traceback.format_exc())
        return 2
    finally:
        if addon is not None:
            try:
                bridge = sys.modules[addon.__name__ + ".desktop.bridge_server"].BRIDGE
                bridge.stop_satellite_process()
                bridge.stop()
            except Exception:
                pass
            try:
                addon.unregister()
            except Exception:
                pass
        elif proc is not None and proc.poll() is None:
            try:
                proc.kill()
            except Exception:
                pass


raise SystemExit(main())
