from __future__ import annotations

from pathlib import Path
import tomllib

ROOT = Path(__file__).resolve().parents[1]
manifest_path = ROOT / "blender_manifest.toml"
data = tomllib.loads(manifest_path.read_text(encoding="utf-8"))

assert data.get("id") == "lumafold"
assert data.get("name") == "LumaFold Blender"
permissions = data.get("permissions") or {}
for key, value in permissions.items():
    assert isinstance(value, str), f"permission reason must be text: {key}"
    assert len(value) <= 64, f"permission reason exceeds Blender limit: {key}={len(value)}"

print("manifest release contract: PASS")
