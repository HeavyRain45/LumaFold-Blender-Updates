from __future__ import annotations

"""Static architecture gate for LumaFold.

Runs with stock Python; Blender is not required. The goal is not to prove runtime
correctness, but to prevent previously-observed architectural regressions from
re-entering the active registration chain.
"""

from pathlib import Path
import ast

ROOT = Path(__file__).resolve().parents[1]
ERRORS: list[str] = []


def fail(message: str) -> None:
    ERRORS.append(message)


def read(path: str) -> str:
    p = ROOT / path
    if not p.is_file():
        fail(f"missing required file: {path}")
        return ""
    return p.read_text(encoding="utf-8")


def parse(path: str) -> ast.AST | None:
    text = read(path)
    if not text:
        return None
    try:
        return ast.parse(text, filename=path)
    except SyntaxError as exc:
        fail(f"syntax error in {path}: {exc}")
        return None


def imported_roots(tree: ast.AST) -> set[str]:
    roots: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                roots.add(alias.name.split(".", 1)[0])
        elif isinstance(node, ast.ImportFrom) and node.module:
            roots.add(node.module.split(".", 1)[0])
    return roots


def call_name(target: ast.AST) -> str:
    if isinstance(target, ast.Name):
        return target.id
    if isinstance(target, ast.Attribute):
        parts = []
        cur = target
        while isinstance(cur, ast.Attribute):
            parts.append(cur.attr)
            cur = cur.value
        if isinstance(cur, ast.Name):
            parts.append(cur.id)
        return ".".join(reversed(parts))
    return ""


def calls_from_node(node: ast.AST) -> set[str]:
    calls: set[str] = set()
    for child in ast.walk(node):
        if isinstance(child, ast.Call):
            name = call_name(child.func)
            if name:
                calls.add(name)
    return calls


def function_defs(tree: ast.AST) -> dict[str, ast.AST]:
    result = {}
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            result.setdefault(node.name, node)
    return result


def calls_in_named_function(tree: ast.AST, name: str) -> set[str]:
    node = function_defs(tree).get(name)
    return calls_from_node(node) if node is not None else set()


def transitive_local_calls(tree: ast.AST, start: str) -> set[str]:
    defs = function_defs(tree)
    visited: set[str] = set()
    all_calls: set[str] = set()

    def walk(name: str):
        if name in visited:
            return
        visited.add(name)
        node = defs.get(name)
        if node is None:
            return
        calls = calls_from_node(node)
        all_calls.update(calls)
        for called in calls:
            if "." not in called and called in defs:
                walk(called)

    walk(start)
    return all_calls


def unsafe_ui_calls(calls: set[str]) -> list[str]:
    bad = []
    forbidden_suffixes = (
        ".is_popup_open", ".begin_popup", ".end_popup",
        ".new_frame", ".render", ".get_draw_data",
        ".create_context", ".destroy_context",
    )
    for name in calls:
        lowered = name.casefold()
        native = lowered.startswith("gpu.") or lowered.startswith("bgl.") or "wgl" in lowered or "opengl" in lowered
        ui_tree = any(name.endswith(suffix) for suffix in forbidden_suffixes)
        if native or ui_tree:
            bad.append(name)
    return sorted(set(bad))


def check_runtime_session() -> None:
    path = "core/runtime_session.py"
    tree = parse(path)
    if tree is None:
        return
    forbidden = {"bpy", "gpu", "bgl", "ctypes", "slimgui", "OpenGL", "win32gui", "win32api"}
    bad = imported_roots(tree) & forbidden
    if bad:
        fail(f"{path} imports forbidden runtime/UI modules: {sorted(bad)}")


def check_runtime_core_modal_safety() -> None:
    path = "runtime/runtime_core.py"
    tree = parse(path)
    if tree is None:
        return
    for fn in ("feed_event", "should_capture"):
        calls = transitive_local_calls(tree, fn)
        bad = unsafe_ui_calls(calls)
        if bad:
            fail(f"{path}:{fn} reaches draw/popup/native-context calls through helper chain: {bad}")

    text = read(path)
    required = (
        "RUNTIME_SESSION.popup_open",
        "RUNTIME_SESSION.request_popup_close",
        "HOST_CONTROL.subscribe",
        "_concrete_view3d_region_under_pointer",
        "_runtime_secondary_rect",
        "def _prime_popup_pointer(",
        "self.io.add_mouse_pos_event",
        "previous = bool(STATE.capture_mouse)",
        "return _ORIGINAL_FEED(self, event, region=region)",
    )
    for token in required:
        if token not in text:
            fail(f"{path} missing required unified popup authority token: {token}")
    if "self.io.add_mouse_button_event" in text:
        fail(f"{path} reintroduced a second direct popup button implementation")


def check_active_registration_chain() -> None:
    text = read("__init__.py")
    forbidden = (
        "secondary_dismiss_product",
        "sculpt_popup_state",
        "satellite_input_boundary",
        "satellite_bridge_performance",
        "runtime_authority",
    )
    for token in forbidden:
        if token in text:
            fail(f"active __init__.py reintroduced historical authority patch: {token}")

    required = (
        "runtime_core.install(",
        "embedded_library_pointer_commit.install(",
        "satellite_bridge_authority.install()",
        "sculpt_library_actions.install()",
        "host_input_boundary.install()",
    )
    for token in required:
        if token not in text:
            fail(f"active __init__.py missing required runtime gate: {token}")

    pointer_bridge = read("runtime/embedded_library_pointer_commit.py")
    for required in (
        "RUNTIME_SESSION.popup_named",
        "_item_contains",
        "_rect_contains",
        "_embedded_brush_popup_actual_rect",
        "##library_asset_",
        "_embedded_brush_pointer_commit_consumed",
    ):
        if required not in pointer_bridge:
            fail(f"Embedded Brush pointer commit lost deterministic inside-popup contract: {required}")

    satellite = read("desktop/satellite_host.py")
    if "sculpt_popup_state" in satellite or "_popup_state.install()" in satellite:
        fail("desktop/satellite_host.py reintroduced duplicate popup-state authority")
    if 'surface_state.get("_secondary_surface_open"' not in satellite:
        fail("desktop/satellite_host.py lost shared sculpt_view popup-state consumption")

    satellite_snapshot = read("runtime/satellite_bridge_authority.py")
    for required in (
        "_BLENDER_TRUTH",
        "def _publish_blender_truth(",
        "def _truth_timer(",
        "def _cached_blender_context_truth(",
        "bpy.app.timers.register(_truth_timer",
        '"mode": mode',
        '"workspace": workspace_name',
    ):
        if required not in satellite_snapshot:
            fail(f"Satellite snapshot lost main-thread Blender truth contract: {required}")


def check_ui_does_not_patch_input_ownership() -> None:
    ui_dir = ROOT / "ui"
    for path in sorted(ui_dir.glob("*.py")):
        text = path.read_text(encoding="utf-8")
        if path.name != "host.py" and ("UIHost.feed_event =" in text or "UIHost.should_capture =" in text):
            fail(f"UI module patches input ownership: {path.relative_to(ROOT)}")


def check_shortcut_key_bridge() -> None:
    text = read("ui/sculpt_shortcut_keys.py")
    if "should_capture" in text:
        fail("ui/sculpt_shortcut_keys.py must not own should_capture")
    if "_make_key_map" not in text:
        fail("ui/sculpt_shortcut_keys.py lost its key-map-only responsibility")


def check_library_action_contract() -> None:
    text = read("runtime/sculpt_library_actions.py")
    required = (
        "bpy.app.timers.register",
        "quick_replace_slot",
        "_ORIGINAL_ASSIGN",
        "_ORIGINAL_ACTIVATE_SLOT",
        "_TARGET_SLOT",
        'APP.events.subscribe("sculpt.state.changed", _on_sculpt_state_changed)',
        'APP.commands.register("sculpt.brush.library_activate", choose_asset)',
    )
    for token in required:
        if token not in text:
            fail(f"sculpt_library_actions missing replacement contract token: {token}")

    view = read("ui/sculpt_view.py")
    assign_at = view.find("on_assign_library_asset_to_slot(identity, target_slot)")
    clear_at = view.find("_clear_replace_target()", assign_at if assign_at >= 0 else 0)
    activate_at = view.find("on_activate_library_asset(identity)", clear_at if clear_at >= 0 else 0)
    if min(assign_at, clear_at, activate_at) < 0 or not (assign_at < clear_at < activate_at):
        fail("ui/sculpt_view.py lost explicit Quick Brush assign -> clear -> activate transaction")


def check_host_transition_contract() -> None:
    text = read("core/host_control.py")
    required = ("def subscribe(", "def _notify(", "self._notify()")
    for token in required:
        if token not in text:
            fail(f"HostController missing transition contract token: {token}")


def check_satellite_render_ready_contract() -> None:
    child = read("desktop/satellite_host.py")
    required_child = (
        "_first_render_ready",
        "_OFFSCREEN_COORD",
        "_runtime.SW_SHOWNOACTIVATE",
        "_runtime.set_client_screen_position",
        "result = _original_draw_frame()",
        "def _show_visible_ready_window()",
        "_owner_work_area",
        "and _show_visible_ready_window()",
        "_first_render_ready.set()",
        "def _network_worker_after_first_render()",
        "_runtime.network_worker = _network_worker_after_first_render",
    )
    for token in required_child:
        if token not in child:
            fail(f"desktop/satellite_host.py missing child visible-ready token: {token}")

    launcher = read("desktop/launcher.py")
    for required in ("def _satellite_child_env()", "import numpy", "PYTHONPATH", "env=_satellite_child_env()"):
        if required not in launcher:
            fail(f"desktop/launcher.py missing Blender NumPy child-runtime contract: {required}")

    guard = read("runtime/satellite_handoff_stability.py")
    for forbidden in (
        "_READY_PREFLIGHT_SECONDS", "_READY_OBSERVED_AT",
        "_VISIBILITY_PENDING", "_ensure_satellite_on_owner_monitor",
        "MonitorFromWindow", "GetWindowRect",
    ):
        if forbidden in guard:
            fail(f"Satellite readiness reintroduced duplicate Blender-side window authority: {forbidden}")
    for required in ("_HANDOFF_TIMEOUT", "child visible-ready", "_heal_stale_child"):
        if required not in guard:
            fail(f"Satellite handoff safety guard missing token: {required}")

    operators = read("operators.py")
    order_ready = operators.find('if bool(getattr(BRIDGE, "satellite_ready", False)):')
    order_shutdown = operators.find("shutdown_active_runtime()", order_ready if order_ready >= 0 else 0)
    if order_ready < 0 or order_shutdown < 0:
        fail("operators.py lost Satellite READY -> shutdown handoff contract")

    launcher_gate = read("qa/blender_satellite_launcher_gate.py")
    if "launcher.vendor_dir =" in launcher_gate:
        fail("Satellite launcher QA bypasses the real LumaFold vendor path")
    for required in (
        "bootstrap_module.vendor_dir()", "off-screen", "visible-ready", "TARGET_X", "TARGET_Y",
        "_is_numpy_payload", "blender_numpy_parent", "_satellite_child_env()",
    ):
        if required not in launcher_gate:
            fail(f"Satellite launcher QA missing real-path/runtime-parity contract: {required}")


def check_no_modal_draw_queries_projectwide() -> None:
    for path in sorted(ROOT.rglob("*.py")):
        if any(part in {".git", "qa"} for part in path.parts):
            continue
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        except Exception:
            continue
        calls = calls_in_named_function(tree, "modal")
        bad = unsafe_ui_calls(calls)
        if bad:
            fail(f"modal draw/native-context violation in {path.relative_to(ROOT)}: {bad}")


def main() -> int:
    check_runtime_session()
    check_runtime_core_modal_safety()
    check_active_registration_chain()
    check_ui_does_not_patch_input_ownership()
    check_shortcut_key_bridge()
    check_library_action_contract()
    check_host_transition_contract()
    check_satellite_render_ready_contract()
    check_no_modal_draw_queries_projectwide()
    if ERRORS:
        print("LumaFold static architecture gate: FAIL")
        for item in ERRORS: print(" -", item)
        return 1
    print("LumaFold static architecture gate: PASS")
    return 0


if __name__ == "__main__": raise SystemExit(main())
