from __future__ import annotations

"""Composition gate for Runtime Core + Brush pointer fallback.

The product installs these two layers together. This gate requires one unified
popup route to satisfy both product behaviors at once:
- exact pointer coordinate is seeded on PRESS/RELEASE;
- normal UIHost button ownership remains in charge;
- an internal Brush release can still be recovered by the item-rect fallback;
- an outside release never becomes a synthetic Brush commit;
- Runtime Core injects View3D region policy through the explicit resolver slot.
"""

from pathlib import Path
import importlib.util
import sys
import types

ROOT = Path(__file__).resolve().parents[1]
POPUP = "LumaFold Brush Library##foundation"


class PopupState:
    def __init__(self, names=(), close_requested=False, close_reason=""):
        self.names = tuple(names); self.serial = 1
        self.close_requested = bool(close_requested); self.close_reason = str(close_reason)


class FakeRuntimeSession:
    def __init__(self): self.names = (POPUP,); self.requested = False; self.reason = ""
    def popup_open(self, host="embedded"): return bool(self.names)
    def popup_named(self, host, name): return host == "embedded" and name in self.names
    def popup_snapshot(self, host="embedded"): return PopupState(self.names, self.requested, self.reason)
    def publish_popups(self, host, names): self.names = tuple(names or ()); return self.popup_snapshot(host)
    def request_popup_close(self, host="embedded", *, reason=""): self.requested = True; self.reason = str(reason); return True
    def close_requested(self, host="embedded"): return self.requested
    def acknowledge_close_request(self, host="embedded"): self.requested = False; self.reason = ""
    def clear_all(self): self.names = (); self.requested = False; self.reason = ""


class FakeHostControl:
    def subscribe(self, callback): return lambda: None


class FakeState:
    capture_mouse = False
    capture_keyboard = False
    host = None
    host_mode = "embedded"


class FakeRegion:
    x = 100; y = 50; width = 800; height = 600


class FakeEvent:
    def __init__(self, event_type, value, local_x, local_y_top):
        self.type = event_type; self.value = value
        self.mouse_x = FakeRegion.x + int(local_x)
        self.mouse_y = FakeRegion.y + int(FakeRegion.height - 1 - local_y_top)
        self.ctrl = self.shift = self.alt = self.oskey = False
        self.unicode = ""


class FakeRenderer:
    def ensure_context(self): pass


class FakeIO:
    def __init__(self): self.events = []
    def add_mouse_pos_event(self, x, y): self.events.append(("pos", float(x), float(y)))
    def add_mouse_button_event(self, button, down): self.events.append(("button", int(button), bool(down)))


class FakeHost:
    def __init__(self):
        self.state = {}; self.feed_calls = []; self.renderer = FakeRenderer(); self.io = FakeIO(); self.closed = False
        self._mouse_owned = {0: False, 1: False, 2: False}
    def _window_region(self): return FakeRegion()
    def feed_event(self, event, *, region=None):
        self.feed_calls.append((event.type, event.value, bool(FakeState.capture_mouse), bool(FakeState.capture_keyboard)))
        button = {"LEFTMOUSE": 0, "RIGHTMOUSE": 1, "MIDDLEMOUSE": 2}.get(event.type)
        if button is not None and event.value in {"PRESS", "RELEASE"}:
            if event.value == "PRESS" and FakeState.capture_mouse:
                self.io.add_mouse_button_event(button, True); self._mouse_owned[button] = True
            elif event.value == "RELEASE" and self._mouse_owned.get(button, False):
                self.io.add_mouse_button_event(button, False); self._mouse_owned[button] = False
        return "base"
    def should_capture(self, event): return False


class FakeSculptCore:
    _RUNNING_SAT_WINDOWS = set()
    region_resolver = None
    @classmethod
    def set_view3d_region_resolver(cls, resolver): cls.region_resolver = resolver
    @staticmethod
    def _clear_gesture_registry(): pass
    @staticmethod
    def _reset_transient_input(host=None): pass
    @staticmethod
    def _bump_generation(): return 1
    @staticmethod
    def _ensure_satellite_brokers(): pass


class FakeInteractions: _SHORTCUT_CAPTURE_ACTIVE = False
class FakeGallery:
    @staticmethod
    def draw_shared_sculpt_compact(*args, **kwargs): return None


class FakeImgui:
    def __init__(self):
        self.item_rect = ((20.0, 30.0), (80.0, 90.0)); self.popup_pos = (10.0, 20.0); self.popup_size = (200.0, 180.0)
    def get_item_rect_min(self): return self.item_rect[0]
    def get_item_rect_max(self): return self.item_rect[1]
    def get_window_pos(self): return self.popup_pos
    def get_window_size(self): return self.popup_size


class FakeFoundation:
    def __init__(self):
        self.square_button = lambda imgui, label, *args, **kwargs: False
        self.image_square_button = lambda imgui, ident, *args, **kwargs: False
        self.draw_brush_library_foundation = self._draw
    def _draw(self, imgui, sculpt, scale, *, library_ui_state=None, on_refresh_library=None,
              on_activate_asset=None, on_toggle_favorite=None, on_assign_asset_to_slot=None,
              on_request_preview=None, resolve_preview_texture=None):
        clicked = self.square_button(imgui, "Clay##library_asset_0", scale, 48.0)
        if clicked and on_activate_asset is not None: on_activate_asset("asset|essentials|clay")
        return clicked


def load_modules():
    prefix = "lumafold_popup_composed_test"
    for key in tuple(sys.modules):
        if key == prefix or key.startswith(prefix + "."): sys.modules.pop(key, None)
    root_pkg = types.ModuleType(prefix); root_pkg.__path__ = [str(ROOT)]
    runtime_pkg = types.ModuleType(prefix + ".runtime"); runtime_pkg.__path__ = [str(ROOT / "runtime")]
    core_pkg = types.ModuleType(prefix + ".core"); core_pkg.__path__ = [str(ROOT / "core")]
    session = FakeRuntimeSession()
    host_mod = types.ModuleType(prefix + ".core.host_control"); host_mod.HOST_CONTROL = FakeHostControl()
    session_mod = types.ModuleType(prefix + ".core.runtime_session"); session_mod.RUNTIME_SESSION = session
    state_mod = types.ModuleType(prefix + ".core.state"); state_mod.STATE = FakeState
    for mod in (root_pkg, runtime_pkg, core_pkg, host_mod, session_mod, state_mod): sys.modules[mod.__name__] = mod
    def load(rel_name, path):
        name = prefix + rel_name
        spec = importlib.util.spec_from_file_location(name, ROOT / path)
        module = importlib.util.module_from_spec(spec); assert spec.loader is not None
        sys.modules[name] = module; spec.loader.exec_module(module); return module
    return load(".runtime.runtime_core", "runtime/runtime_core.py"), load(".runtime.embedded_library_pointer_commit", "runtime/embedded_library_pointer_commit.py"), session


def main():
    FakeSculptCore.region_resolver = None
    runtime_core, pointer, session = load_modules(); foundation = FakeFoundation()
    runtime_core.install(FakeHost, FakeSculptCore, FakeInteractions, FakeGallery)
    assert callable(FakeSculptCore.region_resolver)
    pointer.install(FakeHost, foundation)
    host = FakeHost(); imgui = FakeImgui(); activations = []

    foundation.draw_brush_library_foundation(imgui, {}, 1.0, library_ui_state=host.state, on_activate_asset=activations.append)

    host.feed_event(FakeEvent("LEFTMOUSE", "PRESS", 40, 50), region=FakeRegion())
    host.feed_event(FakeEvent("LEFTMOUSE", "RELEASE", 40, 50), region=FakeRegion())
    assert host.io.events[:4] == [
        ("pos", 40.0, 50.0), ("button", 0, True),
        ("pos", 40.0, 50.0), ("button", 0, False),
    ], host.io.events
    foundation.draw_brush_library_foundation(imgui, {}, 1.0, library_ui_state=host.state, on_activate_asset=activations.append)
    assert activations == ["asset|essentials|clay"], (activations, host.state)

    host.state.pop("_embedded_brush_pointer_commit", None)
    host.feed_event(FakeEvent("LEFTMOUSE", "PRESS", 350, 250), region=FakeRegion())
    host.feed_event(FakeEvent("LEFTMOUSE", "RELEASE", 350, 250), region=FakeRegion())
    assert host.io.events[-4:] == [
        ("pos", 350.0, 250.0), ("button", 0, True),
        ("pos", 350.0, 250.0), ("button", 0, False),
    ], host.io.events
    assert "_embedded_brush_pointer_commit" not in host.state, host.state

    pointer.uninstall(); runtime_core.uninstall()
    assert FakeSculptCore.region_resolver is None
    print("LumaFold composed Embedded popup regression gate: PASS")


if __name__ == "__main__": main()
