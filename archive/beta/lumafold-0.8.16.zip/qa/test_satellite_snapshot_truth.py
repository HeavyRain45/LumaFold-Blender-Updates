from __future__ import annotations

"""Behavior gate for Satellite Blender truth and transport safety.

The real Satellite client reads at most 512 KiB per JSON response. Tests must
therefore prove both semantic truth (Mode/Workspace) and that accumulated visual
preview caches cannot make the state response unparsable.
"""

from pathlib import Path
import importlib.util
import json
import sys
import types

ROOT = Path(__file__).resolve().parents[1]
WIRE_LIMIT = 512 * 1024


class FakeServices:
    def get(self, _service_id): return None
    def all_ids(self): return []


class FakeStore:
    def __init__(self):
        slots = []
        primary = {}
        legacy = {}
        for i in range(48):
            rel = f"brush_{i:02d}.asset"
            identity = f"asset|essentials||{rel}".replace("||", "|")
            payload = {"rgba_b64": "A" * 18000, "width": 64, "height": 64, "key": identity}
            primary[identity] = dict(payload)
            legacy[identity] = dict(payload)
            if i < 16:
                slots.append({
                    "label": f"Brush {i}",
                    "asset_library_type": "ESSENTIALS",
                    "asset_library_identifier": "",
                    "relative_asset_identifier": rel,
                })
        self.sculpt = {
            "quick_rows": 4,
            "quick_brush_slots": slots,
            "brush_size": 100,
            "brush_strength": 1.0,
            "primary_brush_preview_cache": primary,
            "brush_preview_cache": legacy,
            "primary_alpha_preview_cache": {
                f"alpha_{i}": {"rgba_b64": "B" * 18000, "width": 64, "height": 64}
                for i in range(32)
            },
        }
        self.ui = {"ui_scale": 1.0}
    def namespace(self, name): return self.sculpt if name == "sculpt" else self.ui


class FakeStatus:
    active = True
    enabled = True
    reason = ""


class FakeModules:
    def status(self, module_id):
        assert module_id == "sculpt"
        return FakeStatus()
    def all(self): return []


class FakeEvents:
    def tail(self, _count): return []


class FakeCoreContext:
    mode = ""


class FakeState:
    context = FakeCoreContext()
    shared_counter = 0
    shared_value = 0.0
    shared_enabled = True
    shared_text = "LumaFold"
    last_command = "none"
    last_command_message = ""
    last_command_ok = True
    command_count = 0
    event_log = []


class FakeAPP:
    services = FakeServices()
    store = FakeStore()
    modules = FakeModules()
    events = FakeEvents()
    state = FakeState()


class FakeHostControl:
    def snapshot(self): return {"state": "SATELLITE", "owner": "satellite", "generation": 4}


class FakeBridge:
    client_name = "LumaFold Satellite"
    satellite_ready = True
    satellite_active = True
    satellite_closing = False
    satellite_rect = None


class FakeWorkspace:
    def __init__(self, name="Sculpting"):
        self.name = name


class FakeWindow:
    def __init__(self, workspace="Sculpting"):
        self.workspace = FakeWorkspace(workspace)


class FakeObject:
    def __init__(self, mode=""):
        self.mode = mode


class FakeObjects:
    active = None


class FakeViewLayer:
    objects = FakeObjects()


class FakeBpyContext:
    mode = ""
    window = None
    object = None
    active_object = None
    view_layer = FakeViewLayer()


class FakeOperatorContext:
    def __init__(self, mode="SCULPT", workspace="Sculpting", object_mode=""):
        self.mode = mode
        self.window = FakeWindow(workspace)
        self.object = FakeObject(object_mode) if object_mode else None
        self.active_object = self.object


class FakeTimers:
    @staticmethod
    def register(fn, first_interval=0.0): return None


class FakeBpyApp:
    version_string = "5.2.1"
    timers = FakeTimers()


def load_module():
    prefix = "lumafold_sat_snapshot_test"
    for key in tuple(sys.modules):
        if key == prefix or key.startswith(prefix + "."):
            sys.modules.pop(key, None)

    root_pkg = types.ModuleType(prefix); root_pkg.__path__ = [str(ROOT)]
    runtime_pkg = types.ModuleType(prefix + ".runtime"); runtime_pkg.__path__ = [str(ROOT / "runtime")]
    core_pkg = types.ModuleType(prefix + ".core"); core_pkg.__path__ = [str(ROOT / "core")]
    desktop_pkg = types.ModuleType(prefix + ".desktop"); desktop_pkg.__path__ = [str(ROOT / "desktop")]
    modules_pkg = types.ModuleType(prefix + ".modules"); modules_pkg.__path__ = [str(ROOT / "modules")]

    app_mod = types.ModuleType(prefix + ".core.app"); app_mod.APP = FakeAPP()
    host_mod = types.ModuleType(prefix + ".core.host_control"); host_mod.HOST_CONTROL = FakeHostControl()
    bridge_mod = types.ModuleType(prefix + ".desktop.bridge_server"); bridge_mod.BRIDGE = FakeBridge()
    sculpt_mod = types.ModuleType(prefix + ".modules.sculpt")
    sculpt_mod.sync_brush_state = lambda app: None
    sculpt_mod.sync_alpha_state = lambda app: None

    fake_bpy = types.ModuleType("bpy")
    fake_bpy.context = FakeBpyContext()
    fake_bpy.app = FakeBpyApp()

    for mod in (root_pkg, runtime_pkg, core_pkg, desktop_pkg, modules_pkg, app_mod, host_mod, bridge_mod, sculpt_mod):
        sys.modules[mod.__name__] = mod
    sys.modules["bpy"] = fake_bpy

    name = prefix + ".runtime.satellite_bridge_authority"
    spec = importlib.util.spec_from_file_location(name, ROOT / "runtime" / "satellite_bridge_authority.py")
    module = importlib.util.module_from_spec(spec); assert spec.loader is not None
    sys.modules[name] = module; spec.loader.exec_module(module)
    return module, fake_bpy, app_mod.APP, bridge_mod.BRIDGE


def main():
    module, bpy, app, bridge = load_module()

    published = module.publish_context_truth(FakeOperatorContext("SCULPT", "Sculpting"))
    assert published["mode"] == "SCULPT", published
    assert published["workspace"] == "Sculpting", published
    assert bridge.satellite_truth_mode == "SCULPT"

    object_fallback = module.publish_context_truth(FakeOperatorContext("", "Sculpting", object_mode="SCULPT"))
    assert object_fallback["mode"] == "SCULPT", object_fallback

    bpy.context.mode = ""
    bpy.context.window = None
    bpy.context.object = None
    bpy.context.active_object = None
    app.state.context.mode = ""
    module.publish_context_truth(None)
    snapshot = module._satellite_snapshot("LumaFold Satellite")
    status = snapshot["sculpt_status"]
    assert status["mode"] == "SCULPT", status
    assert status["workspace"] == "Sculpting", status
    assert snapshot["module_state"]["sculpt"]["quick_rows"] == 4

    # Critical dev52 transport contract. The Blender-local accumulated preview
    # caches are deliberately > 512 KiB, but the Satellite snapshot may contain
    # only the visible Quick-slot working set and must remain parseable by the
    # real child's fixed receive budget.
    sculpt_wire = snapshot["module_state"]["sculpt"]
    assert "primary_brush_preview_cache" not in sculpt_wire
    assert "primary_alpha_preview_cache" not in sculpt_wire
    assert len(sculpt_wire.get("brush_preview_cache") or {}) <= 16
    encoded = (json.dumps({"ok": True, "state": snapshot}, ensure_ascii=False, separators=(",", ":")) + "\n").encode("utf-8")
    assert len(encoded) < WIRE_LIMIT, len(encoded)

    bad_wire = {
        "ok": True,
        "state": {
            "sculpt_status": {"active": True, "enabled": True, "mode": "", "workspace": ""},
            "module_state": {"sculpt": {"quick_rows": 4}},
        },
    }
    repaired = module._enforce_satellite_wire_truth(bad_wire, "LumaFold Satellite S0.7.3 Window Input Router")
    repaired_status = repaired["state"]["sculpt_status"]
    assert repaired_status["mode"] == "SCULPT", repaired_status
    assert repaired_status["workspace"] == "Sculpting", repaired_status
    assert repaired["state"]["satellite_context_truth"]["mode"] == "SCULPT"

    desktop_wire = {"ok": True, "state": {"sculpt_status": {"mode": ""}}}
    untouched = module._enforce_satellite_wire_truth(desktop_wire, "LumaFold Desktop")
    assert untouched["state"]["sculpt_status"]["mode"] == ""

    updated_truth = module.publish_context_truth(FakeOperatorContext("OBJECT", "Layout"))
    assert updated_truth["mode"] == "OBJECT", updated_truth
    updated = module._satellite_snapshot("LumaFold Satellite")["sculpt_status"]
    assert updated["mode"] == "OBJECT", updated
    assert updated["workspace"] == "Layout", updated

    handoff_source = (ROOT / "runtime" / "satellite_handoff_stability.py").read_text(encoding="utf-8")
    assert "satellite_bridge_authority.publish_context_truth(context)" in handoff_source
    assert handoff_source.find("satellite_bridge_authority.publish_context_truth(context)") < handoff_source.find("result = original_execute(self, context)")

    print("LumaFold Satellite truth + transport budget tests: PASS")


if __name__ == "__main__": main()
