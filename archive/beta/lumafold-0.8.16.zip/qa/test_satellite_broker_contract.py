from __future__ import annotations

"""Pure contract gate for Sculpt broker lifecycle ownership.

Regression covered: Runtime Core and Sculpt Input Core both mutated Satellite
broker lifetime. Repeated Embedded/Satellite toggles could therefore alternate
between stale/new modal ownership.

Contract:
- Runtime Core may reset transient UI/gesture state on every Host transition.
- Runtime Core must never bump the Sculpt broker generation.
- Runtime Core must never clear the running-window registry.
- Runtime Core must never schedule/start brokers.
- Sculpt Input Core remains the single broker lifecycle owner.
- Runtime Core supplies View3D region policy only through the explicit resolver
  slot and clears that slot on uninstall.
"""

from pathlib import Path
import importlib.util
import sys
import types

ROOT = Path(__file__).resolve().parents[1]


class FakeHostControl:
    def subscribe(self, callback):
        self.callback = callback
        return lambda: None


class FakeRuntimeSession:
    def __init__(self):
        self.clear_count = 0

    def clear_all(self):
        self.clear_count += 1

    def popup_named(self, *args, **kwargs):
        return False

    def popup_open(self, *args, **kwargs):
        return False


class FakeState:
    capture_mouse = False
    capture_keyboard = False
    capture_text = False
    host = object()
    host_mode = "embedded"


class FakeTimers:
    def __init__(self):
        self.callbacks = []

    def register(self, callback, first_interval=0.0, **kwargs):
        self.callbacks.append((callback, float(first_interval)))
        return None


class FakeBpy(types.ModuleType):
    def __init__(self, timers):
        super().__init__("bpy")
        self.app = types.SimpleNamespace(timers=timers)


class FakeSculptCore:
    _RUNNING_SAT_WINDOWS = {111, 222}
    clear_count = 0
    reset_count = 0
    bump_count = 0
    ensure_count = 0
    region_resolver = None

    @classmethod
    def reset(cls):
        cls._RUNNING_SAT_WINDOWS = {111, 222}
        cls.clear_count = cls.reset_count = cls.bump_count = cls.ensure_count = 0
        cls.region_resolver = None

    @classmethod
    def set_view3d_region_resolver(cls, resolver):
        cls.region_resolver = resolver

    @classmethod
    def _clear_gesture_registry(cls):
        cls.clear_count += 1

    @classmethod
    def _reset_transient_input(cls, host=None):
        cls.reset_count += 1

    @classmethod
    def _bump_generation(cls):
        cls.bump_count += 1
        return cls.bump_count

    @classmethod
    def _ensure_satellite_brokers(cls):
        cls.ensure_count += 1


class FakeHost:
    @staticmethod
    def feed_event(self, event, *, region=None):
        return None

    @staticmethod
    def should_capture(self, event):
        return False


class FakeInteractions:
    _SHORTCUT_CAPTURE_ACTIVE = False


class FakeGallery:
    @staticmethod
    def draw_shared_sculpt_compact(*args, **kwargs):
        return None


def load_runtime_core(timers):
    prefix = "lumafold_sat_broker_test"
    for key in tuple(sys.modules):
        if key == prefix or key.startswith(prefix + "."):
            sys.modules.pop(key, None)

    root_pkg = types.ModuleType(prefix)
    root_pkg.__path__ = [str(ROOT)]
    runtime_pkg = types.ModuleType(prefix + ".runtime")
    runtime_pkg.__path__ = [str(ROOT / "runtime")]
    core_pkg = types.ModuleType(prefix + ".core")
    core_pkg.__path__ = [str(ROOT / "core")]

    host_control = FakeHostControl()
    session = FakeRuntimeSession()
    host_mod = types.ModuleType(prefix + ".core.host_control")
    host_mod.HOST_CONTROL = host_control
    session_mod = types.ModuleType(prefix + ".core.runtime_session")
    session_mod.RUNTIME_SESSION = session
    state_mod = types.ModuleType(prefix + ".core.state")
    state_mod.STATE = FakeState

    for mod in (root_pkg, runtime_pkg, core_pkg, host_mod, session_mod, state_mod):
        sys.modules[mod.__name__] = mod

    old_bpy = sys.modules.get("bpy")
    sys.modules["bpy"] = FakeBpy(timers)
    try:
        name = prefix + ".runtime.runtime_core"
        spec = importlib.util.spec_from_file_location(name, ROOT / "runtime" / "runtime_core.py")
        module = importlib.util.module_from_spec(spec)
        assert spec.loader is not None
        sys.modules[name] = module
        spec.loader.exec_module(module)
        module.install(FakeHost, FakeSculptCore, FakeInteractions, FakeGallery)
        assert callable(FakeSculptCore.region_resolver)
        return module, session, old_bpy
    except Exception:
        if old_bpy is None:
            sys.modules.pop("bpy", None)
        else:
            sys.modules["bpy"] = old_bpy
        raise


def restore_bpy(old_bpy):
    if old_bpy is None:
        sys.modules.pop("bpy", None)
    else:
        sys.modules["bpy"] = old_bpy


def assert_transition_only_resets_transient(snapshot):
    FakeSculptCore.reset()
    timers = FakeTimers()
    module, session, old_bpy = load_runtime_core(timers)
    try:
        before_registry = set(FakeSculptCore._RUNNING_SAT_WINDOWS)
        module._on_host_transition(snapshot)
        assert session.clear_count == 1
        assert FakeSculptCore.clear_count == 1
        assert FakeSculptCore.reset_count == 1
        assert FakeSculptCore.bump_count == 0, "Runtime Core stole broker generation ownership"
        assert FakeSculptCore.ensure_count == 0, "Runtime Core started a broker"
        assert FakeSculptCore._RUNNING_SAT_WINDOWS == before_registry, "Runtime Core cleared broker registry"
        assert timers.callbacks == [], "Runtime Core scheduled a duplicate broker lifecycle timer"
    finally:
        module.uninstall()
        assert FakeSculptCore.region_resolver is None
        restore_bpy(old_bpy)


def test_repeated_host_transitions_have_one_owner():
    for snapshot in (
        {"state": "EMBEDDED", "owner": "embedded"},
        {"state": "DETACHING", "owner": "embedded"},
        {"state": "SATELLITE", "owner": "satellite"},
        {"state": "ATTACHING", "owner": "satellite"},
        {"state": "EMBEDDED", "owner": "embedded"},
        {"state": "SATELLITE", "owner": "satellite"},
    ):
        assert_transition_only_resets_transient(snapshot)


def main():
    test_repeated_host_transitions_have_one_owner()
    print("LumaFold Sculpt single broker owner contract: PASS")


if __name__ == "__main__":
    main()
