from __future__ import annotations

"""Pure contract gate for Alpha linked-folder ownership."""

import importlib.util
from pathlib import Path
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
REGISTRY = ROOT / "services" / "alpha_source_registry.py"
STORE = ROOT / "services" / "alpha_source_store.py"
LINKED_PRODUCT = ROOT / "services" / "sculpt_alpha_linked_product.py"
SERVICES_INIT = ROOT / "services" / "__init__.py"


def load_registry():
    name = "lumafold_alpha_source_registry_test"
    spec = importlib.util.spec_from_file_location(name, REGISTRY)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module.AlphaSourceRegistryService


def fail(message):
    raise AssertionError(message)


def assert_architecture():
    registry_text = REGISTRY.read_text(encoding="utf-8")
    store_text = STORE.read_text(encoding="utf-8")
    product_text = LINKED_PRODUCT.read_text(encoding="utf-8")
    init_text = SERVICES_INIT.read_text(encoding="utf-8")

    for token in ("import bpy", "from bpy", "import ui", "import runtime", "import desktop"):
        if token in registry_text:
            fail("pure Alpha source registry crossed owner boundary: " + token)

    for text, label in ((registry_text, "registry"), (store_text, "store"), (product_text, "linked product")):
        for token in (".unlink(", ".rmdir(", "os.remove(", "os.unlink(", "shutil.rmtree(", "shutil.move("):
            if token in text:
                fail(f"{label} contains forbidden source-file mutation: {token}")

    required = (
        'app.services.register("alpha.source_registry"',
        'app.commands.register("sculpt.alpha.source_add"',
        'app.commands.register("sculpt.alpha.source_remove"',
        'app.commands.register("sculpt.alpha.asset_hide"',
        'app.commands.register("sculpt.alpha.source_restore_hidden"',
    )
    for token in required:
        if token not in init_text:
            fail("Alpha source integration missing: " + token)

    if "BlenderAlphaLinkedProduct" not in init_text:
        fail("blender.alpha is not wired to linked-folder product layer")
    if "linked roots visible even when empty or temporarily missing" not in product_text:
        fail("linked product lost empty/missing source visibility contract")


def assert_registry_behavior():
    Registry = load_registry()
    state = {Registry.SOURCES_KEY: [], Registry.HIDDEN_KEY: {}}
    image_exts = {".png", ".tif"}

    with tempfile.TemporaryDirectory(prefix="lumafold_alpha_registry_") as temp:
        base = Path(temp)
        source = base / "My Alpha Pack"
        nested = source / "Skin"
        nested.mkdir(parents=True)
        alpha_a = source / "soft.png"
        alpha_b = nested / "detail.tif"
        ignored = source / "notes.txt"
        alpha_a.write_bytes(b"LUMAFOLD_ALPHA_A_123")
        alpha_b.write_bytes(b"LUMAFOLD_ALPHA_B_456")
        ignored.write_text("ignore", encoding="utf-8")
        before_a = alpha_a.read_bytes()
        before_b = alpha_b.read_bytes()

        first, created = Registry.add_folder(state, source)
        if not created:
            fail("first linked folder registration was not created")
        if first.get("label") != source.name:
            fail(f"linked folder label must use real basename: {first}")

        second, created_again = Registry.add_folder(state, str(source))
        if created_again or second.get("id") != first.get("id"):
            fail("duplicate linked folder registration is not idempotent")
        if len(Registry.list_sources(state)) != 1:
            fail("duplicate linked folder produced multiple registry rows")

        scan = Registry.scan(state, image_exts, max_files=64)
        names = {item.get("name") for item in scan.get("assets") or ()}
        if names != {"soft", "detail"}:
            fail(f"recursive Alpha scan mismatch: {names}")
        folders = list(scan.get("folders") or ())
        if len(folders) != 1 or folders[0].get("label") != source.name or folders[0].get("count") != 2:
            fail(f"linked folder scan metadata mismatch: {folders}")

        soft = next(item for item in scan["assets"] if item.get("name") == "soft")
        Registry.hide_identity(state, first["id"], soft["identity"])
        hidden_scan = Registry.scan(state, image_exts, max_files=64)
        if any(item.get("identity") == soft["identity"] for item in hidden_scan.get("assets") or ()):
            fail("hidden linked Alpha reappeared after refresh scan")
        if not alpha_a.is_file() or alpha_a.read_bytes() != before_a:
            fail("hiding an Alpha modified/deleted the source file")

        Registry.unhide_identity(state, first["id"], soft["identity"])
        restored = Registry.scan(state, image_exts, max_files=64)
        if not any(item.get("identity") == soft["identity"] for item in restored.get("assets") or ()):
            fail("unhidden linked Alpha did not return")

        Registry.remove_folder(state, first["id"])
        if Registry.list_sources(state):
            fail("linked folder remained registered after remove")
        if not alpha_a.is_file() or alpha_a.read_bytes() != before_a:
            fail("removing linked folder modified/deleted first source file")
        if not alpha_b.is_file() or alpha_b.read_bytes() != before_b:
            fail("removing linked folder modified/deleted nested source file")

        # Missing folders remain explicit registry records instead of being
        # silently discarded, allowing UI to show and remove/fix the source.
        missing_source = base / "Temporary Pack"
        missing_source.mkdir()
        missing_record, _ = Registry.add_folder(state, missing_source)
        moved = base / "Temporary Pack Moved"
        missing_source.rename(moved)
        missing_scan = Registry.scan(state, image_exts, max_files=64)
        missing_folder = next((f for f in missing_scan.get("folders") or () if f.get("id") == missing_record.get("id")), None)
        if missing_folder is None or not missing_folder.get("missing"):
            fail("externally missing linked folder was silently removed")
        if not any(row.get("id") == missing_record.get("id") for row in Registry.list_sources(state)):
            fail("missing source was removed from persistent registry")


def main():
    assert_architecture()
    assert_registry_behavior()
    print("Alpha linked source registry contract: PASS")


if __name__ == "__main__":
    main()
