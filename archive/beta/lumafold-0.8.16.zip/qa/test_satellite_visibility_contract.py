from __future__ import annotations

"""Behavior gate for child-owned Satellite visible-ready handoff.

Real-machine dev46 proved a post-grant Blender-side HWND verifier could falsely
reject a handoff after process spawn, READY, active state and lease grant had all
succeeded. dev47 therefore has one native-window authority: the Satellite child.
It must prove its own on-screen HWND before sending READY.

This pure-Python gate protects the Blender-side half of that protocol:
- the safety guard may bound the wait for child visible-ready;
- after the original handoff grants Satellite ownership, the guard must not
  start another foreign-window verification loop or roll the Host back;
- a healthy child/lease result is accepted in one original handoff tick.
"""

from pathlib import Path
import importlib.util
import sys
import types

ROOT = Path(__file__).resolve().parents[1]


class Lease:
    def __init__(self):
        self.state = "EMBEDDED"
        self.owner = "embedded"
        self.generation = 1


class FakeHostControl:
    def __init__(self):
        self.lease = Lease()
        self.migration_locked = False

    def cancel_detach(self):
        self.lease.state = "EMBEDDED"
        self.lease.owner = "embedded"

    def recover_embedded(self):
        self.lease.state = "EMBEDDED"
        self.lease.owner = "embedded"
        self.migration_locked = False


class FakeState:
    host_mode = "embedded"
    host = None
    last_error = ""
    status = ""


class FakeProc:
    pid = 4321

    def poll(self):
        return None


class FakeBridge:
    def __init__(self):
        self.satellite_process = FakeProc()
        self.satellite_active = False
        self.last_error = ""

    def stop_satellite_process(self):
        self.satellite_process = None
        self.satellite_active = False


class FakeMoveOperator:
    def execute(self, context):
        return {"FINISHED"}


class FakeOperators(types.SimpleNamespace):
    pass


def load_module():
    prefix = "lumafold_sat_visible_test"
    for key in tuple(sys.modules):
        if key == prefix or key.startswith(prefix + "."):
            sys.modules.pop(key, None)

    root_pkg = types.ModuleType(prefix)
    root_pkg.__path__ = [str(ROOT)]
    runtime_pkg = types.ModuleType(prefix + ".runtime")
    runtime_pkg.__path__ = [str(ROOT / "runtime")]
    core_pkg = types.ModuleType(prefix + ".core")
    core_pkg.__path__ = [str(ROOT / "core")]
    desktop_pkg = types.ModuleType(prefix + ".desktop")
    desktop_pkg.__path__ = [str(ROOT / "desktop")]

    host_control = FakeHostControl()
    bridge = FakeBridge()

    host_mod = types.ModuleType(prefix + ".core.host_control")
    host_mod.HOST_CONTROL = host_control
    host_mod.EMBEDDED = "EMBEDDED"
    host_mod.DETACHING = "DETACHING"
    host_mod.SATELLITE = "SATELLITE"
    state_mod = types.ModuleType(prefix + ".core.state")
    state_mod.STATE = FakeState
    bridge_mod = types.ModuleType(prefix + ".desktop.bridge_server")
    bridge_mod.BRIDGE = bridge

    for mod in (root_pkg, runtime_pkg, core_pkg, desktop_pkg, host_mod, state_mod, bridge_mod):
        sys.modules[mod.__name__] = mod

    name = prefix + ".runtime.satellite_handoff_stability"
    spec = importlib.util.spec_from_file_location(name, ROOT / "runtime" / "satellite_handoff_stability.py")
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module, host_control, bridge


def test_healthy_visible_ready_is_accepted_once():
    module, host_control, bridge = load_module()
    calls = {"tick": 0, "return": 0}

    operators = FakeOperators()
    operators.LUMAFOLD_OT_move_to_satellite = FakeMoveOperator
    operators._MIGRATION_IN_PROGRESS = True
    operators._EXTERNAL_SATELLITE_HANDOFF_RUNNING = True
    operators._RETURN_EMBEDDED_TARGET = {"dummy": True}

    def original_alive():
        return True

    def original_tick():
        calls["tick"] += 1
        # READY reaching this point means the child already proved its own
        # on-screen visible HWND. Mirror production grant.
        host_control.lease.state = "SATELLITE"
        host_control.lease.owner = "satellite"
        bridge.satellite_active = True
        FakeState.host_mode = "satellite"
        operators._EXTERNAL_SATELLITE_HANDOFF_RUNNING = False
        operators._MIGRATION_IN_PROGRESS = False
        return None

    def request_return():
        calls["return"] += 1
        host_control.recover_embedded()
        FakeState.host_mode = "embedded"

    operators._external_satellite_alive = original_alive
    operators._external_satellite_handoff_tick = original_tick
    operators._request_return_from_external_satellite = request_return

    module.install(operators)
    result = operators._external_satellite_handoff_tick()
    assert result is None, result
    assert calls["tick"] == 1, calls
    assert calls["return"] == 0, calls
    assert host_control.lease.state == "SATELLITE"
    assert host_control.lease.owner == "satellite"
    assert FakeState.host_mode == "satellite"
    assert "child visible-ready" in FakeState.status, FakeState.status
    assert not hasattr(module, "_VISIBILITY_PENDING"), "Blender-side foreign HWND authority returned"
    module.uninstall(operators)


def test_timeout_keeps_embedded_authoritative():
    module, host_control, bridge = load_module()
    operators = FakeOperators()
    operators.LUMAFOLD_OT_move_to_satellite = FakeMoveOperator
    operators._MIGRATION_IN_PROGRESS = True
    operators._EXTERNAL_SATELLITE_HANDOFF_RUNNING = True
    operators._RETURN_EMBEDDED_TARGET = {"dummy": True}
    operators._external_satellite_alive = lambda: True
    operators._external_satellite_handoff_tick = lambda: 0.02

    host_control.lease.state = "DETACHING"
    host_control.lease.owner = "embedded"
    module.install(operators)
    module._HANDOFF_STARTED = module.time.monotonic() - module._HANDOFF_TIMEOUT - 0.1
    result = operators._external_satellite_handoff_tick()
    assert result is None, result
    assert host_control.lease.state == "EMBEDDED"
    assert host_control.lease.owner == "embedded"
    assert FakeState.host_mode == "embedded"
    assert "visible-ready timeout" in FakeState.status, FakeState.status
    module.uninstall(operators)


def main():
    test_healthy_visible_ready_is_accepted_once()
    test_timeout_keeps_embedded_authoritative()
    print("LumaFold Satellite child visible-ready contract tests: PASS")


if __name__ == "__main__":
    main()
