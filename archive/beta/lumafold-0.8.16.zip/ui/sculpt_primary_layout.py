from __future__ import annotations

"""Keep the enlarged current Brush preview inside the Primary card padding."""

from .design import px
from . import sculpt_view_foundation as foundation
from . import sculpt_host_controls
from . import sculpt_shortcut_prompt

_INSTALLED = False
_ORIGINAL_DRAW = None


def _offset_cursor(imgui, amount: float):
    try:
        pos = imgui.get_cursor_pos()
        imgui.set_cursor_pos((float(pos[0]) + amount, float(pos[1]) + amount))
        return
    except Exception:
        pass
    try:
        imgui.set_cursor_pos_x(float(imgui.get_cursor_pos_x()) + amount)
    except Exception:
        pass
    try:
        imgui.set_cursor_pos_y(float(imgui.get_cursor_pos_y()) + amount)
    except Exception:
        pass


def install():
    global _INSTALLED, _ORIGINAL_DRAW
    sculpt_host_controls.install()
    sculpt_shortcut_prompt.install()
    if _INSTALLED:
        return
    _ORIGINAL_DRAW = foundation.draw_sculpt_compact

    def draw_with_current_card_padding(imgui, surface_state, sculpt, scale, **kwargs):
        original_begin_child = getattr(imgui, "begin_child", None)
        if not callable(original_begin_child):
            return _ORIGINAL_DRAW(imgui, surface_state, sculpt, scale, **kwargs)

        def begin_child(name, *args, **child_kwargs):
            result = original_begin_child(name, *args, **child_kwargs)
            if str(name) == "##current_brush_card" and result:
                _offset_cursor(imgui, px(6.0, scale))
            return result

        patched = False
        try:
            setattr(imgui, "begin_child", begin_child)
            patched = True
        except Exception:
            patched = False
        try:
            return _ORIGINAL_DRAW(imgui, surface_state, sculpt, scale, **kwargs)
        finally:
            if patched:
                try:
                    setattr(imgui, "begin_child", original_begin_child)
                except Exception:
                    pass

    foundation.draw_sculpt_compact = draw_with_current_card_padding
    _INSTALLED = True
