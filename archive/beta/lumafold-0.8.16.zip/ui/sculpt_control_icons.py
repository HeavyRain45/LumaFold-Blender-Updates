from __future__ import annotations

"""Monochrome Sculpt header controls derived from the user's reference icons.

The four glyphs are stored as a tiny compressed RGBA strip and tinted by the
same ImGui theme colors as the rest of LumaFold.  The image itself carries no
button background, so selected/hover states remain Blender-style theme tokens.
"""

import base64
import zlib

from . import theme as T
from .design import px

_TEX_ID = 0
_WIDTH = 256
_HEIGHT = 64
_CELL = 64
_ORDER = ("zbrush", "blender", "satellite", "embedded")
_DATA_B85 = r"""
c-rlqYiLwQ6vvy5d1;Iq<0IBaqgHDwv0_6_)v8r1R>Uf3m0HABYK4jx6%<9mq9~S@NW@}k5k)B$v4|q=hoFey2T?>sEFvOB6bTX}
gyphK=QL-?ae8;}WA9^b_6+<;jC*(I&Yl0vnRCv}3L#z-48t%C!!QiPFbu;m48t%C!!QiPFbu==c8U^Q_wV@mF-*bI%x%Ch1<Q19
1BOY=I-^XIV*N8rK`~tNo1{zfhvcmS(f`MiCz7<}Pe~2;1*X6lEO{j9l&lloB_nC-<@$e{+-nAZhc<XGVK!T>WSnG}q*79xaGx;~
ZT~reegB!{B5D9ihorg}>wh`k=L`I4iJr1G0U9b1&Sj0HpQOB(_T7Fs=B4l+EAek`=qsu40KE4A$v|v-SSyz%ybTAT?VHj1O&Wjh
?8W+r{&N`bvx~Gr7yg9xK!1bl@2A|szMFLIR|#{<?gY1EHO_k!We>yeck>+MlHmW_K<0l-8v|ZSCK_1h(g6DH!UXqQx^9aT)lc3?
unl$8#{TUjI;bcB|Nr|owvVOR(I(Y572y2Ul0bh!+K{<ljRSiV>~jHqAIJN-fj$862ewOA6;S+d1o}V(SqsoH{<vZ5y-NZ2<#7p{
|4q?9l;0E3W-0Vp^vCs6KlBx={~IZ3z}Vkd^mi0m{2$um7i}#-*8}%)oG_)nM?>h-<*a|t`ZqPty$|Yn3&!<tOa78vk(`s9Li=wK
jtRNms|?47>6kBIivCl$Mu&S?CRyr}6_N##uN-`$Ca;}~(7#uMYZkv{2J7FG{(mrVu5U&kwqC%ebx(3yauC-pmn9D+KT0NPKH_5R
?{~HL+2&%+6Sn^Q<C-PP=dJ95eF5i6hUqKp<D;DpvHo4_|CB*(Q;YSX1=h9KB~NYc;U2#J0>=EIT$Ow-nT!4aRUY72p<?C}V%Gl!
GNyF}gd5+IS`S>qm~fKTI8!|Kan`@H{tp|{E+3#4RB1yESK*uvYyN3C_uG{hHg>P_g~QmfOR__B=gdNx9HahIny=m|RugogpFK5!
e&5*%9s^9%|6T*yWQo={*XGFeNZ~keN7E10ds_2@WiT$NVuN?lClKfSKhr}js3U~uPunN17~u$<)9ZZX_M{Rz2C)C{RaRjCK8y8P
=^^&F&BHuN^W@#ci=y!V!TMI^a`q)upuJOp<J1P5xPDN5K#hrOBYfuNF6ve#+?^*=>*Brcu>OtI|1_+_BGms=A2FQy+I*kZbYhWt
_L*?MKhTu;-)ftfUeHC20joqbetxgTDW2;lr}hx*-zfbL!8Q98jLix3iFwUMn&r}tzUVRj9k>4b68~i;g1(@}fUyz8b^VrMd1`AI
>)#0d_rboM!MMKi$<Os+KXeis5Bx%~H|`AP44g*h;AbW!|7VQkx#q8rDn9sB^yF5VnE(6O;aQsQ3ouRp2V!W0xmsP$OBy}C$5dhy
gFkPuW@DBkesi1S(*JU8?Gj~CW6hF~?=gt{-&7v!3)X+U`X4VjBKcY}N_fvjfos~a{!c_Wd96|FzeL#Y>5aNi01ra80f40e)OV!t
x5u!8^&hML^8wB<xKCpK4IzC_l=>eodU6!IV(u5p<`^Htvn?V%VYek)9@h+q>xx+aiPL|ncr~Z*K#22HRQjiDArtn7s{I4s#{8_o
Cj7-^oojsf8JbxCiP1l3{B_B%SZBx=fLy^FxQ^H?y7LEXL~wcS(<A8L`^lVZ**u##`^7awo_%E=F+!(v##sMm>mSbefn5GJQg4VC
wu<iDpZ#bL+$TB$-xA~y4Ki5&kavGIi@k3d)JII}3x|Bxw<X8x>sbH)X~{I*!<j_;NL*0lSR2EA{6pe^s(^oRXC5)%u=GELXgqCW
dn><2#(@4|TECd!P-nXwpK`;-IMeih%%JBB{@jC_F47`<{u|xXs(w#v*TXtti|~FXNErHGXH#$WZ#A~<!gk0QFb0@t6VC8a=XtFE
toq+)z%zxt@H=cYk+E41zr^)_yU4vSCXF_Mx)#m_o8!Un8>IeW4mz17wnxXdPsOYGtX7Qu;z`8*oq6bUSm(lr)8=susL1i!`iT2_
+A#gcdHzQc`t9!7)U8v~0N8eK;@k*~7Tvl05HDIR`38M~*KEcGx^CDl-0d|BO8+B8&z|G1EcQO!Bi)Z&CVKWlM{NUG5%!A;hq~1J
oJWg1zCP;tU!D12X>*)Kep=e!G7iry+x6N0-HG-1GNxE)KeY9!7T{bj*n<M!ZFP(E#r-b*`sxg+YFuY;)aDAMw{tGm13~D&Do1Qj
jRi3F*_}ytGba73dd?2{`Ioq?Pqy>Ca_#$DBfRYqiu3H#F4SQ<$FrceZ^p;7%vA=8=+A<xLw!SmJ$c*lZz*IGse7x)FUAkojv@YI
i^LHsL)QOM2koEDVT-KH;qwgJE==S2Y|0+MIv+NGm)93ZJnwxdy7%2Y*6Q&9pZ87lX+wFA_G~)G-2V*!|8JbvpONd~S~wr?Df*Q=
FmC?6<P(v7Uv*eaB=$Mj;(FfxdU9{zo9q+dXTOW>pfm;h4NF7R|1HhNv&d&}cWC#%G57#f?oZe;;Wi(2^J)WBdeDD^h~EB%c@FYb
#^L9WLc6sV<HI%hw_#`>sxz)1Xm%ltAwxxXeoQsKekfjFkJp06hLHCf5U{S?G8y|A_~IJ1{$GY`PE`(uRL8|+{)aX^oW=eLLjUT!
2|6_$yS1%%MQj78&#5+O?su}$vz3J&UfW`5tiz5gn*Q%4q~7(YgNHWjT^O%uUhjqwZIaRW8J~%svjmrfq<`@H({qe33vW3mWyJQ&
M5O)AhOGPT)~R0fe@1xw&Vi)r|84^647TiToCBw5Hqd<HABT0ztdQ%{gl)GG{fZfkB@PKO{x>*B|8=5~*brfj0ckQmr3}@7wmo~B
JZQQq0s04D#A=LXwV?m2700eto7h$-{{0BP<`~-1KM8ZrcHM(@y^gW|VqD9dA@^}y*ze;A!}kc~Jo*}xrcP^p-=y#VSs3CNkS2bn
DE7trJ^v%yxo|ZB#Q{xu)(rtZ+m4ug8~XF<#D4Y!$EpjYj<;|<9Ayk*J+U|Fd4bL1)jTtkY^Vhu<2r8q{9VL`92nuf1iAh%@#xn#
UH>Xqv0eQC`>m}UF#w(R9Db0feSUTYY=LDWp6_gfdEpCf?VCaSSNR-g8n}*X6g_()ET4V>OY<k55Z=$;4#LLuQr7s?e|ZA+-$dr_
e8zT_FEBdh`+;Ww`*yEkyc_nFPl}<>+0iU|zE?<%0q+>Bf0Z+Lz{ZAm+9RQl6^~-JaV`Zg_dAUxsRZgD_$ZIKk45b2;leDxhKb)Z
4zaGEN&9UwT>td^<Q+CSBu?cb_OD_C?%||EUEA`=CpekqwRY__FG2o)CLEts6V9vS6QX}=|3XY<EB5)cO?(La!b=UC59par`dNT`
Y~~85xucO>zd|_g!B(Z7`#%#>{GVYM)<45A$)cItfME)j`P>E!!!QiPFbu;m48t%C!!QiPFbu;m48t%C!!S&5<X<(}rFQ
"""


def _rgba() -> bytes:
    packed = "".join(_DATA_B85.split()).encode("ascii")
    raw = zlib.decompress(base64.b85decode(packed))
    expected = _WIDTH * _HEIGHT * 4
    if len(raw) != expected:
        raise RuntimeError(f"Sculpt control icon atlas mismatch: {len(raw)} != {expected}")
    return raw


def ensure(renderer) -> int:
    global _TEX_ID
    if _TEX_ID:
        return _TEX_ID
    _TEX_ID = int(renderer.register_rgba_texture(_WIDTH, _HEIGHT, _rgba()) or 0)
    return _TEX_ID


def reset(renderer=None):
    global _TEX_ID
    if renderer is not None and _TEX_ID:
        try:
            renderer.unregister_texture(_TEX_ID)
        except Exception:
            pass
    _TEX_ID = 0


def _uv(name: str):
    index = _ORDER.index(str(name))
    u0 = index / len(_ORDER)
    u1 = (index + 1) / len(_ORDER)
    return (u0, 0.0), (u1, 1.0)


def icon_button(imgui, name: str, ident: str, scale=1.0, *, box=24.0, glyph=15.0, selected=False, disabled=False, tooltip=None):
    if not _TEX_ID:
        return False
    uv0, uv1 = _uv(name)
    box_px = px(box, scale)
    glyph_px = min(box_px, px(glyph, scale))
    pad = max(0.0, (box_px - glyph_px) * 0.5)
    old_padding = None
    try:
        style = imgui.get_style()
        old_padding = tuple(style.frame_padding)
        style.frame_padding = (pad, pad)
    except Exception:
        old_padding = None
    if selected:
        imgui.push_style_color(imgui.Col.BUTTON, T.SELECTED)
        imgui.push_style_color(imgui.Col.BUTTON_HOVERED, T.SELECTED_HOVER)
        imgui.push_style_color(imgui.Col.BUTTON_ACTIVE, T.SELECTED_SOFT)
    if disabled:
        imgui.begin_disabled(True)
    try:
        clicked = imgui.image_button(
            f"##sculpt_control_{ident}", _TEX_ID, (glyph_px, glyph_px),
            uv0, uv1, (0.0, 0.0, 0.0, 0.0), T.TEXT_PRIMARY,
        )
        if tooltip and imgui.is_item_hovered():
            imgui.set_tooltip(str(tooltip))
        return bool(clicked)
    finally:
        if disabled:
            imgui.end_disabled()
        if selected:
            imgui.pop_style_color(3)
        if old_padding is not None:
            try:
                imgui.get_style().frame_padding = old_padding
            except Exception:
                pass
