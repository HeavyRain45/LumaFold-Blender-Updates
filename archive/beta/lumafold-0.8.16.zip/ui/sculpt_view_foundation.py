from __future__ import annotations

import json
from pathlib import Path
from typing import Callable, MutableMapping, Optional

from . import theme as T
from .components import button, muted, text, square_button, square_action_button, image_square_button
from .design import px, font_scope
from .layout_system import (
    PRIMARY, SECONDARY, BRUSH_LIBRARY, CONTEXT_MENU, SCULPT_PRIMARY, PRIMARY_GRID_GAP, PRIMARY_SLIDER_LABEL_W,
    SECONDARY_TITLE_KIND, SECONDARY_NAV_KIND, SECONDARY_META_KIND, SECONDARY_TILE_KIND,
    centered_group_geometry,
)
from .icons import icon, icon_button


def _load_spec():
    path = Path(__file__).resolve().parent.parent / "assets" / "sculpt_view_v1.json"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if int(data.get("schema_version", 0)) != 1:
            raise ValueError("unsupported sculpt view schema")
        return data
    except Exception:
        return {
            "schema_version": 1,
            "title": "LumaFold Sculpt",
            "preset": "浮台",
            "design_width": 264,
            "design_height": 338,
            "brushes": ["Draw", "Clay", "Crease", "Smooth", "Inflate", "Grab", "Scrape", "Mask"],
            "alphas": ["Round", "Clay", "Noise", "Dots", "Scratches", "Skin"],
        }


SPEC = _load_spec()
BRUSHES = tuple(SPEC.get("brushes") or ())
ALPHAS = tuple(SPEC.get("alphas") or ())
QUICK_COLUMNS = 4
MIN_QUICK_ROWS = 2
MAX_QUICK_ROWS = 4
MAX_QUICK_SLOTS = QUICK_COLUMNS * MAX_QUICK_ROWS

# One secondary-surface specification is consumed by both Embedded popups and
# Native Satellite Secondary Surface windows.  Geometry comes from the frozen
# product layout contract; future modules should not invent local variants.
SECONDARY_SURFACE_SIZES = {
    "brush_library": (BRUSH_LIBRARY.width, BRUSH_LIBRARY.height),
    "alpha_library": (BRUSH_LIBRARY.width, BRUSH_LIBRARY.height),
    "settings": (420.0, 360.0),
    "more": (392.0, 300.0),
}


def secondary_surface_design_size(kind: str = "brush_library"):
    return SECONDARY_SURFACE_SIZES.get(str(kind or "brush_library"), SECONDARY_SURFACE_SIZES["brush_library"])


GRID_GAP = PRIMARY_GRID_GAP
SLIDER_LABEL_W = PRIMARY_SLIDER_LABEL_W


def _slider_row(imgui, label, value, minimum, maximum, scale, fmt):
    """One fixed label column so Size/Strength rails share exact endpoints."""
    start_x = float(imgui.get_cursor_pos_x())
    text(imgui, label, scale, kind="small", color=T.TEXT_SECONDARY)
    imgui.same_line()
    try:
        imgui.set_cursor_pos_x(start_x + px(SLIDER_LABEL_W, scale))
    except Exception:
        pass
    imgui.set_next_item_width(-1.0)
    changed, new_value = imgui.slider_float(
        f"##sculpt_{label}", float(value), float(minimum), float(maximum), fmt
    )
    return bool(changed), float(new_value) if changed else float(value)


def _mode_label(mode: str) -> str:
    mode = str(mode or "").upper()
    return {
        "SCULPT": "雕刻模式",
        "OBJECT": "物体模式",
        "EDIT_MESH": "编辑模式",
        "EDIT": "编辑模式",
    }.get(mode, mode.replace("_", " ").title() if mode else "未知模式")


def _workspace_product(workspace_name: str, blender_mode: str):
    """Map Blender Workspace to the LumaFold product surface without duplicating Blender navigation."""
    raw = str(workspace_name or "").strip()
    key = raw.casefold().replace(" ", "")
    if key in {"modeling", "建模"} or "model" in key or "建模" in raw:
        return "model", "LumaFold Model", "建模模块尚未开发"
    if key in {"sculpting", "sculpt", "雕刻"} or "sculpt" in key or "雕刻" in raw:
        return "sculpt", "LumaFold Sculpt", ""
    if key in {"rendering", "render", "渲染"} or "render" in key or "渲染" in raw:
        return "render", "LumaFold Render", "渲染模块尚未开发"
    # Layout/UV/etc. keep the currently useful Sculpt product whenever Blender
    # is actually in Sculpt Mode; otherwise retain the temporary Sculpt landing.
    if str(blender_mode or "").upper() == "SCULPT":
        return "sculpt", "LumaFold Sculpt", ""
    return "sculpt", "LumaFold Sculpt", ""


def _draw_workspace_placeholder(imgui, scale, *, title, workspace_name, host_label, message, on_toggle_host):
    text(imgui, title, scale, kind="section")
    try:
        imgui.same_line()
        remain = imgui.get_content_region_avail()[0]
        host_w = px(PRIMARY.icon_box, scale)
        if remain > host_w:
            imgui.set_cursor_pos_x(imgui.get_cursor_pos_x() + max(0.0, remain - host_w))
        _host_switch_button(imgui, scale, host_label, on_toggle_host)
    except Exception:
        pass
    muted(imgui, f"Blender 工作区：{workspace_name or '未知'}  ·  Host：{host_label}", scale)
    imgui.separator()
    text(imgui, message, scale, kind="body", color=T.TEXT_SECONDARY)
    muted(imgui, "当前先保持 LumaFold 浮台常驻；对应产品模块接入后会直接替换此占位内容。", scale)


def _host_switch_button(imgui, scale: float, host_label: str, on_toggle_host):
    """Compact product-host control using the shared LumaFold icon atlas."""
    satellite = str(host_label or "").strip() == "卫星"
    tooltip = "卫星 Host · 点击收回浮台" if satellite else "摘出为卫星 Host"
    try:
        clicked = icon_button(
            imgui, "satellite", "host_switch", scale, PRIMARY.icon_glyph,
            selected=satellite, tooltip=tooltip,
        )
    except Exception:
        clicked = square_action_button(imgui, "◉##host_switch" if satellite else "↗##host_switch", scale, PRIMARY.icon_box, tooltip=tooltip)
        if imgui.is_item_hovered():
            imgui.set_tooltip(tooltip)
    if clicked and on_toggle_host is not None:
        on_toggle_host()
    return bool(clicked)


def _slot_identity(slot):
    slot = dict(slot or {})
    rel = str(slot.get("relative_asset_identifier") or "").replace("\\", "/").strip()
    if not rel:
        return ""
    return "asset|{}|{}|{}".format(
        str(slot.get("asset_library_type") or "").casefold(),
        str(slot.get("asset_library_identifier") or "").casefold(),
        rel.casefold(),
    )


def _slot_preview(sculpt, slot):
    key = _slot_identity(slot)
    if not key:
        return {}
    return dict((sculpt.get("brush_preview_cache") or {}).get(key) or {})


def _item_anchor(imgui, scale):
    try:
        rmin = imgui.get_item_rect_min()
        rmax = imgui.get_item_rect_max()
        return {
            "x": float(rmin[0]),
            "y": float(rmax[1]) + px(6.0, scale),
            "button_left": float(rmin[0]),
            "button_top": float(rmin[1]),
            "button_right": float(rmax[0]),
            "button_bottom": float(rmax[1]),
        }
    except Exception:
        return {"x": 0.0, "y": 0.0}


def _quick_slot_widget(imgui, label, ident, scale, width_px, selected, empty, tex_id=0):
    """Quick Brush tile with invariant outer geometry for preview/text states."""
    design_size = max(1.0, float(width_px) / max(0.01, float(scale)))
    tooltip = "添加当前快捷笔刷" if empty else str(label or "快捷笔刷")
    if tex_id:
        clicked = image_square_button(
            imgui, f"quick_preview_{ident}", int(tex_id), scale,
            design_size, selected=selected, tooltip=tooltip,
        )
    else:
        clicked = square_button(
            imgui, f"{label if not empty else '+'}##quick_{ident}", scale,
            design_size, selected=selected, kind="small",
        )
        if imgui.is_item_hovered():
            imgui.set_tooltip(tooltip)
    return bool(clicked)


def _current_asset_identity(sculpt):
    asset = dict(sculpt.get("current_brush_asset") or {})
    rel = str(asset.get("relative_asset_identifier") or "").replace("\\", "/").strip()
    if not rel:
        return ""
    return "asset|{}|{}|{}".format(
        str(asset.get("asset_library_type") or "").casefold(),
        str(asset.get("asset_library_identifier") or "").casefold(),
        rel.casefold(),
    )


def draw_brush_library_foundation(
    imgui,
    sculpt: MutableMapping,
    scale: float,
    *,
    library_ui_state: Optional[MutableMapping] = None,
    on_refresh_library: Optional[Callable[[], None]] = None,
    on_activate_asset: Optional[Callable[[str], None]] = None,
    on_toggle_favorite: Optional[Callable[[str], None]] = None,
    on_assign_asset_to_slot: Optional[Callable[[str, int], None]] = None,
    on_request_preview: Optional[Callable[[list], None]] = None,
    resolve_preview_texture: Optional[Callable[[dict], int]] = None,
):
    """Frozen S0.6.10 Secondary Surface inset/alignment contract.

    Left: fixed scopes + real folders + bottom folder toolbar.
    Right: standalone Search row, divider, scope/count metadata, fixed 8-column
    Brush grid.  Preview and placeholder states occupy the exact same tile box.
    """
    ui = library_ui_state if library_ui_state is not None else {}
    assets = list(sculpt.get("brush_library_assets") or ())
    folders = list(sculpt.get("brush_library_folders") or ())
    favorites = set(str(item) for item in list(sculpt.get("brush_library_favorites") or ()) if str(item or ""))
    preview_cache = dict(sculpt.get("brush_library_preview_cache") or {})
    status = str(sculpt.get("brush_library_status") or "NOT_LOADED")
    scope = str(ui.get("brush_scope") or "all")
    query = str(ui.get("brush_query") or "")
    requested = ui.setdefault("brush_preview_requested", {})

    valid_folder_ids = {str((folder or {}).get("id") or "") for folder in folders}
    if scope.startswith("folder:") and scope[7:] not in valid_folder_ids:
        scope = "all"
        ui["brush_scope"] = scope

    if status in {"NOT_LOADED", "ERROR"} and on_refresh_library is not None and not bool(ui.get("brush_refresh_requested", False)):
        ui["brush_refresh_requested"] = True
        on_refresh_library()
    if status == "READY":
        ui["brush_refresh_requested"] = False

    m = BRUSH_LIBRARY
    left_w = px(m.nav_w, scale)
    split_gap = px(m.split_gap, scale)
    nav_button_w = left_w
    row_h = px(m.row_h, scale)
    tool_h = px(m.toolbar_h, scale)
    gap = px(SECONDARY.gap, scale)
    gap_small = px(SECONDARY.gap_small, scale)

    # SECONDARY HEADER -----------------------------------------------------
    # One shared header row owns the title, search field and action icon.
    # The title uses the left navigation baseline; search starts on the exact
    # same split X as the right content below. No child may invent a second
    # header inset.
    header_start_x = float(imgui.get_cursor_pos_x())
    header_right_x = header_start_x + left_w + split_gap
    try:
        imgui.align_text_to_frame_padding()
    except Exception:
        pass
    text(imgui, "笔刷库", scale, kind=SECONDARY_TITLE_KIND)
    imgui.same_line()
    try:
        imgui.set_cursor_pos_x(header_right_x)
    except Exception:
        pass

    refresh_box = px(SECONDARY.icon_box, scale)
    search_gap = px(SECONDARY.gap, scale)
    header_available_w = max(1.0, float(imgui.get_content_region_avail()[0]))
    search_w = max(px(120.0, scale), header_available_w - refresh_box - search_gap)
    imgui.set_next_item_width(search_w)
    with font_scope(imgui, "body", scale):
        changed, query_new = imgui.input_text("##brush_library_search", query, 128)
    if changed:
        query = str(query_new)
        ui["brush_query"] = query
    if imgui.is_item_hovered() and not query:
        try:
            imgui.set_tooltip("搜索当前范围的笔刷")
        except Exception:
            pass
    imgui.same_line(spacing=search_gap)
    refresh_clicked = False
    try:
        refresh_clicked = icon_button(
            imgui, "refresh", "brush_library_refresh", scale,
            SECONDARY.icon_glyph, tooltip="重新扫描 Blender 笔刷库",
        )
    except Exception:
        refresh_clicked = square_action_button(
            imgui, "↻", scale, SECONDARY.icon_box,
            tooltip="重新扫描 Blender 笔刷库",
        )
    if refresh_clicked and on_refresh_library is not None:
        ui["brush_preview_requested"] = {}
        ui["brush_refresh_requested"] = True
        on_refresh_library()

    imgui.separator()
    content_h = max(1.0, float(imgui.get_content_region_avail()[1]))

    # LEFT NAV -------------------------------------------------------------
    if imgui.begin_child("##brush_library_left", (left_w, content_h)):
        if button(imgui, "全部", scale, nav_button_w / scale, selected=(scope == "all"), kind=SECONDARY_NAV_KIND, height=SECONDARY.row_h):
            scope = "all"
            ui["brush_scope"] = scope
        if button(imgui, "收藏", scale, nav_button_w / scale, selected=(scope == "favorites"), kind=SECONDARY_NAV_KIND, height=SECONDARY.row_h):
            scope = "favorites"
            ui["brush_scope"] = scope

        imgui.separator()
        text(imgui, "文件夹", scale, kind=SECONDARY_META_KIND, color=T.TEXT_SECONDARY)

        # Reserve a fixed bottom toolbar.  The folder list owns only the space
        # above it, so + / − never drift with folder count or scroll position.
        remaining_h = max(1.0, float(imgui.get_content_region_avail()[1]))
        footer_bottom_gap = px(m.footer_bottom_gap, scale)
        folder_list_h = max(px(44.0, scale), remaining_h - tool_h - gap - footer_bottom_gap)
        if imgui.begin_child("##brush_folder_scroll", (0.0, folder_list_h)):
            for folder in folders:
                folder = dict(folder or {})
                folder_id = str(folder.get("id") or "")
                if not folder_id:
                    continue
                label = str(folder.get("label") or "文件夹")
                count = int(folder.get("count") or 0)
                display = label if len(label) <= 11 else (label[:9] + "…")
                selected = scope == ("folder:" + folder_id)
                if button(
                    imgui, f"{display}##folder_{folder_id}", scale,
                    nav_button_w / scale, selected=selected, kind=SECONDARY_META_KIND,
                    height=SECONDARY.row_h,
                ):
                    scope = "folder:" + folder_id
                    ui["brush_scope"] = scope
                if imgui.is_item_hovered():
                    imgui.set_tooltip(f"{label} · {count} 个笔刷")
        imgui.end_child()

        # Folder mutation is intentionally disabled until it can map cleanly to
        # Blender's real asset organization.  The toolbar is centered against the
        # ACTUAL child content rect, never the theoretical nav_w.  This guarantees
        # left remainder == right remainder even if ImGui child padding/DPI changes
        # the usable width by a few pixels.
        imgui.begin_disabled(True)
        tool_gap = gap_small
        toolbar_avail_w = max(1.0, float(imgui.get_content_region_avail()[0]))
        toolbar_side_space, toolbar_group_w, toolbar_right_space = centered_group_geometry(
            toolbar_avail_w, nav_button_w
        )
        if toolbar_side_space > 0.0:
            imgui.set_cursor_pos_x(imgui.get_cursor_pos_x() + toolbar_side_space)
        tool_cell_w = max(px(28.0, scale), (toolbar_group_w - tool_gap) * 0.5)
        button(
            imgui, "+##folder_add", scale, tool_cell_w / scale,
            kind=SECONDARY_NAV_KIND, height=SECONDARY.row_h,
        )
        imgui.same_line(spacing=tool_gap)
        button(
            imgui, "−##folder_remove", scale, tool_cell_w / scale,
            kind=SECONDARY_NAV_KIND, height=SECONDARY.row_h,
        )
        imgui.end_disabled()
    imgui.end_child()

    # RIGHT CONTENT --------------------------------------------------------
    imgui.same_line(spacing=split_gap)
    if imgui.begin_child("##brush_library_right", (0.0, content_h)):
        scope_folder = scope[7:] if scope.startswith("folder:") else ""
        query_cf = query.casefold().strip()
        filtered = []
        for raw in assets:
            item = dict(raw or {})
            identity = str(item.get("identity") or "")
            if not identity:
                continue
            if scope == "favorites" and identity not in favorites:
                continue
            if scope_folder and str(item.get("folder_id") or "") != scope_folder:
                continue
            if query_cf and query_cf not in str(item.get("name") or "").casefold():
                continue
            filtered.append(item)

        scope_name = "全部" if scope == "all" else (
            "收藏" if scope == "favorites" else next(
                (str((f or {}).get("label") or "文件夹") for f in folders
                 if str((f or {}).get("id") or "") == scope_folder),
                "文件夹",
            )
        )
        # Count belongs to the content/grid layer, not the Search row.
        muted(imgui, f"{scope_name} · {len(filtered)}", scale)

        if status == "SCANNING":
            muted(imgui, "正在读取 Blender Asset Library…", scale)
        elif status == "ERROR":
            text(imgui, "笔刷库读取失败", scale, kind=SECONDARY_META_KIND, color=T.DANGER)
            for err in list(sculpt.get("brush_library_errors") or ())[:3]:
                muted(imgui, str(err), scale)
        elif status == "EMPTY":
            muted(imgui, "当前 Blender Asset Library 中没有找到 Brush Asset。", scale)

        cols = 8
        tile_gap = px(m.tile_gap, scale)
        tile_design = float(m.tile)
        tile_px = px(tile_design, scale)
        row_w = tile_px * cols + tile_gap * (cols - 1)
        scrollbar_size = px(m.scrollbar_size, scale)
        min_side_gap = px(m.scrollbar_side_gap_min, scale)
        bottom_gap = px(m.scrollbar_bottom_gap, scale)
        available_grid_w = max(1.0, float(imgui.get_content_region_avail()[0]))
        available_grid_h = max(1.0, float(imgui.get_content_region_avail()[1]))

        # Surface Inset Contract: the scroll child fills the entire right Content
        # Safe Rect. ImGui reserves scrollbar_size inside that child; therefore
        # the remaining gap between tile column 8 and the scrollbar is:
        #   available_grid_w - row_w - scrollbar_size
        # S0.6.7 sizes the Surface so this equals SECONDARY.outer_padding. The
        # scrollbar's right edge is then exactly one outer_padding from the OS
        # Surface edge. There is no nested "extra" gutter outside the child.
        side_gap = max(0.0, available_grid_w - row_w - scrollbar_size)
        target_inset = px(SECONDARY.outer_padding, scale)
        ui["brush_grid_width_warning"] = bool(abs(side_gap - target_inset) > px(0.75, scale))
        grid_child_w = available_grid_w
        grid_child_h = max(1.0, available_grid_h - bottom_gap)
        ui["brush_scrollbar_side_gap_px"] = float(side_gap)
        ui["brush_surface_inset_px"] = float(target_inset)

        # Keep the scrollbar track transparent and stop the scroll child before
        # the rounded lower edge.  Only the rounded grab remains visible, so the
        # lane cannot expose a square inner corner at the Secondary Surface radius.
        pushed_scrollbar_bg = False
        try:
            if hasattr(imgui.Col, "SCROLLBAR_BG"):
                imgui.push_style_color(imgui.Col.SCROLLBAR_BG, (0.0, 0.0, 0.0, 0.0))
                pushed_scrollbar_bg = True
        except Exception:
            pushed_scrollbar_bg = False

        if imgui.begin_child("##brush_asset_grid", (grid_child_w, grid_child_h)):
            current_identity = _current_asset_identity(sculpt)
            preview_batch = []
            visible_identities = set()
            for i, item in enumerate(filtered):
                if i % cols:
                    imgui.same_line(spacing=tile_gap)
                identity = str(item.get("identity") or "")
                name = str(item.get("name") or "Brush")
                preview = dict(preview_cache.get(identity) or {})
                tex_id = 0
                if preview and resolve_preview_texture is not None:
                    try:
                        tex_id = int(resolve_preview_texture(preview) or 0)
                    except Exception:
                        tex_id = 0
                selected = identity == current_identity
                if tex_id:
                    clicked = image_square_button(
                        imgui, f"library_asset_{i}", tex_id, scale,
                        tile_design, selected=selected,
                    )
                else:
                    short = name if len(name) <= 10 else name[:8] + "…"
                    clicked = square_button(
                        imgui, f"{short}##library_asset_{i}", scale,
                        tile_design, selected=selected, kind=SECONDARY_TILE_KIND,
                    )
                if imgui.is_item_hovered():
                    src = str(item.get("source_label") or "Blender")
                    imgui.set_tooltip(f"{name}\n{src}")
                if clicked and on_activate_asset is not None:
                    on_activate_asset(identity)

                item_visible = True
                try:
                    item_visible = bool(imgui.is_item_visible())
                except Exception:
                    item_visible = i < 16
                if item_visible:
                    visible_identities.add(identity)
                if preview:
                    requested.pop(identity, None)
                if (
                    not preview and item_visible and on_request_preview is not None
                    and not requested.get(identity) and len(preview_batch) < 16
                ):
                    requested[identity] = True
                    preview_batch.append(identity)
                try:
                    right_clicked = bool(imgui.is_item_clicked(imgui.MouseButton.RIGHT))
                except Exception:
                    right_clicked = False
                if right_clicked:
                    ui["brush_context_identity"] = identity
                    imgui.open_popup("Brush Asset##library_context")

            for old_identity in tuple(requested.keys()):
                if old_identity not in visible_identities and old_identity not in preview_cache:
                    requested.pop(old_identity, None)
            if preview_batch and on_request_preview is not None:
                on_request_preview(list(preview_batch))

            context_identity = str(ui.get("brush_context_identity") or "")
            if imgui.begin_popup("Brush Asset##library_context"):
                context_item = next(
                    (dict(item or {}) for item in assets
                     if str((item or {}).get("identity") or "") == context_identity),
                    None,
                )
                if context_item:
                    name = str(context_item.get("name") or "Brush")
                    text(imgui, name, scale, kind=SECONDARY_TITLE_KIND)
                    imgui.separator()
                    is_fav = context_identity in favorites
                    if button(
                        imgui, "取消收藏" if is_fav else "加入收藏", scale,
                        142.0, selected=not is_fav, kind=SECONDARY_NAV_KIND, height=SECONDARY.row_h,
                    ):
                        if on_toggle_favorite is not None:
                            on_toggle_favorite(context_identity)
                        try:
                            imgui.close_current_popup()
                        except Exception:
                            pass
                    text(imgui, "设为快捷笔刷", scale, kind=SECONDARY_META_KIND, color=T.TEXT_SECONDARY)
                    slots = list(sculpt.get("quick_brush_slots") or ())
                    rows = max(MIN_QUICK_ROWS, min(MAX_QUICK_ROWS, int(sculpt.get("quick_rows", 2) or 2)))
                    count = min(len(slots), rows * QUICK_COLUMNS)
                    for slot in range(count):
                        if slot % 4:
                            imgui.same_line(spacing=gap_small)
                        if square_button(
                            imgui, f"{slot+1}##asset_to_slot_{slot}", scale,
                            SECONDARY.icon_box, kind=SECONDARY_META_KIND,
                        ):
                            if on_assign_asset_to_slot is not None:
                                on_assign_asset_to_slot(context_identity, slot)
                            try:
                                imgui.close_current_popup()
                            except Exception:
                                pass
                imgui.end_popup()
        imgui.end_child()
        if pushed_scrollbar_bg:
            try:
                imgui.pop_style_color(1)
            except Exception:
                pass
    imgui.end_child()


def _current_alpha_identity(sculpt):
    return str(sculpt.get("current_alpha_identity") or "none")


def draw_alpha_library_foundation(
    imgui,
    sculpt: MutableMapping,
    scale: float,
    *,
    library_ui_state: Optional[MutableMapping] = None,
    on_refresh_library: Optional[Callable[[], None]] = None,
    on_activate_asset: Optional[Callable[[str], None]] = None,
    on_toggle_favorite: Optional[Callable[[str], None]] = None,
    on_request_preview: Optional[Callable[[list], None]] = None,
    on_import_files: Optional[Callable[[], None]] = None,
    resolve_preview_texture: Optional[Callable[[dict], int]] = None,
):
    """Real Sculpt Alpha library using the frozen Secondary Surface contract.

    Data source is Blender Images / file-backed images indexed by blender.alpha.
    The UI intentionally mirrors Brush Library geometry instead of inventing a
    second asset-browser language.
    """
    ui = library_ui_state if library_ui_state is not None else {}
    assets = list(sculpt.get("alpha_library_assets") or ())
    folders = list(sculpt.get("alpha_library_folders") or ())
    favorites = set(str(item) for item in list(sculpt.get("alpha_library_favorites") or ()) if str(item or ""))
    preview_cache = dict(sculpt.get("alpha_library_preview_cache") or {})
    status = str(sculpt.get("alpha_library_status") or "NOT_LOADED")
    scope = str(ui.get("alpha_scope") or "all")
    query = str(ui.get("alpha_query") or "")
    requested = ui.setdefault("alpha_preview_requested", {})

    valid_folder_ids = {str((folder or {}).get("id") or "") for folder in folders}
    if scope.startswith("folder:") and scope[7:] not in valid_folder_ids:
        scope = "all"
        ui["alpha_scope"] = scope

    if status in {"NOT_LOADED", "ERROR"} and on_refresh_library is not None and not bool(ui.get("alpha_refresh_requested", False)):
        ui["alpha_refresh_requested"] = True
        on_refresh_library()
    if status == "READY":
        ui["alpha_refresh_requested"] = False

    m = BRUSH_LIBRARY
    left_w = px(m.nav_w, scale)
    split_gap = px(m.split_gap, scale)
    nav_button_w = left_w
    tool_h = px(m.toolbar_h, scale)
    gap = px(SECONDARY.gap, scale)
    gap_small = px(SECONDARY.gap_small, scale)

    # HEADER: exact same alignment contract as Brush Library.
    header_start_x = float(imgui.get_cursor_pos_x())
    header_right_x = header_start_x + left_w + split_gap
    try:
        imgui.align_text_to_frame_padding()
    except Exception:
        pass
    text(imgui, "Alpha 库", scale, kind=SECONDARY_TITLE_KIND)
    imgui.same_line()
    try:
        imgui.set_cursor_pos_x(header_right_x)
    except Exception:
        pass
    refresh_box = px(SECONDARY.icon_box, scale)
    search_gap = px(SECONDARY.gap, scale)
    header_available_w = max(1.0, float(imgui.get_content_region_avail()[0]))
    search_w = max(px(120.0, scale), header_available_w - refresh_box - search_gap)
    imgui.set_next_item_width(search_w)
    with font_scope(imgui, "body", scale):
        changed, query_new = imgui.input_text("##alpha_library_search", query, 128)
    if changed:
        query = str(query_new)
        ui["alpha_query"] = query
    if imgui.is_item_hovered() and not query:
        try:
            imgui.set_tooltip("搜索当前范围的 Alpha")
        except Exception:
            pass
    imgui.same_line(spacing=search_gap)
    try:
        refresh_clicked = icon_button(imgui, "refresh", "alpha_library_refresh", scale, SECONDARY.icon_glyph, tooltip="重新扫描 Alpha 图片")
    except Exception:
        refresh_clicked = square_action_button(imgui, "↻", scale, SECONDARY.icon_box, tooltip="重新扫描 Alpha 图片")
    if refresh_clicked and on_refresh_library is not None:
        ui["alpha_preview_requested"] = {}
        ui["alpha_refresh_requested"] = True
        on_refresh_library()

    imgui.separator()
    content_h = max(1.0, float(imgui.get_content_region_avail()[1]))

    # LEFT NAV: all / favorites + real source folders. Folder mutation remains
    # disabled until it maps to a real filesystem/Blender operation.
    if imgui.begin_child("##alpha_library_left", (left_w, content_h)):
        if button(imgui, "全部", scale, nav_button_w / scale, selected=(scope == "all"), kind=SECONDARY_NAV_KIND, height=SECONDARY.row_h):
            scope = "all"; ui["alpha_scope"] = scope
        if button(imgui, "收藏", scale, nav_button_w / scale, selected=(scope == "favorites"), kind=SECONDARY_NAV_KIND, height=SECONDARY.row_h):
            scope = "favorites"; ui["alpha_scope"] = scope
        imgui.separator()
        text(imgui, "文件夹", scale, kind=SECONDARY_META_KIND, color=T.TEXT_SECONDARY)
        remaining_h = max(1.0, float(imgui.get_content_region_avail()[1]))
        folder_list_h = max(px(44.0, scale), remaining_h - tool_h - gap - px(m.footer_bottom_gap, scale))
        if imgui.begin_child("##alpha_folder_scroll", (0.0, folder_list_h)):
            for raw in folders:
                folder = dict(raw or {})
                folder_id = str(folder.get("id") or "")
                if not folder_id:
                    continue
                label = str(folder.get("label") or "文件夹")
                count = int(folder.get("count") or 0)
                display = label if len(label) <= 11 else label[:9] + "…"
                selected = scope == "folder:" + folder_id
                if button(imgui, f"{display}##alpha_folder_{folder_id}", scale, nav_button_w / scale, selected=selected, kind=SECONDARY_META_KIND, height=SECONDARY.row_h):
                    scope = "folder:" + folder_id; ui["alpha_scope"] = scope
                if imgui.is_item_hovered():
                    imgui.set_tooltip(f"{label} · {count} 个 Alpha")
        imgui.end_child()
        toolbar_avail_w = max(1.0, float(imgui.get_content_region_avail()[0]))
        side, group_w, _ = centered_group_geometry(toolbar_avail_w, nav_button_w)
        if side > 0:
            imgui.set_cursor_pos_x(imgui.get_cursor_pos_x() + side)
        cell_w = max(px(28.0, scale), (group_w - gap_small) * 0.5)
        if button(imgui, "+##alpha_folder_add", scale, cell_w / scale, kind=SECONDARY_NAV_KIND, height=SECONDARY.row_h):
            if on_import_files is not None:
                on_import_files()
        if imgui.is_item_hovered():
            imgui.set_tooltip("导入 Alpha 图片到当前 Blender 文件")
        imgui.same_line(spacing=gap_small)
        imgui.begin_disabled(True)
        button(imgui, "−##alpha_folder_remove", scale, cell_w / scale, kind=SECONDARY_NAV_KIND, height=SECONDARY.row_h)
        imgui.end_disabled()
        if imgui.is_item_hovered():
            imgui.set_tooltip("删除/移除文件夹将在后续接入真实资产管理")
    imgui.end_child()

    # RIGHT CONTENT: 8-column fixed Alpha preview grid.
    imgui.same_line(spacing=split_gap)
    if imgui.begin_child("##alpha_library_right", (0.0, content_h)):
        scope_folder = scope[7:] if scope.startswith("folder:") else ""
        q = query.casefold().strip()
        filtered = []
        for raw in assets:
            item = dict(raw or {})
            identity = str(item.get("identity") or "")
            if not identity:
                continue
            if scope == "favorites" and identity not in favorites:
                continue
            if scope_folder and str(item.get("folder_id") or "") != scope_folder:
                continue
            if q and q not in str(item.get("name") or "").casefold():
                continue
            filtered.append(item)
        scope_name = "全部" if scope == "all" else ("收藏" if scope == "favorites" else next((str((f or {}).get("label") or "文件夹") for f in folders if str((f or {}).get("id") or "") == scope_folder), "文件夹"))
        muted(imgui, f"{scope_name} · {len(filtered)}", scale)
        if status == "SCANNING":
            muted(imgui, "正在读取 Blender 图片 / Asset Library…", scale)
        elif status == "ERROR":
            text(imgui, "Alpha 库读取失败", scale, kind=SECONDARY_META_KIND, color=T.DANGER)
            for err in list(sculpt.get("alpha_library_errors") or ())[:3]:
                muted(imgui, str(err), scale)
        elif status == "EMPTY":
            muted(imgui, "没有找到可用图片。可在 Blender Asset Library 路径中放入 PNG/TIF 等 Alpha 图片。", scale)

        cols = 8
        tile_gap = px(m.tile_gap, scale)
        tile_design = float(m.tile)
        tile_px = px(tile_design, scale)
        row_w = tile_px * cols + tile_gap * (cols - 1)
        scrollbar_size = px(m.scrollbar_size, scale)
        available_w = max(1.0, float(imgui.get_content_region_avail()[0]))
        available_h = max(1.0, float(imgui.get_content_region_avail()[1]))
        side_gap = max(0.0, available_w - row_w - scrollbar_size)
        target_inset = px(SECONDARY.outer_padding, scale)
        ui["alpha_grid_width_warning"] = bool(abs(side_gap - target_inset) > px(0.75, scale))

        pushed_bg = False
        try:
            if hasattr(imgui.Col, "SCROLLBAR_BG"):
                imgui.push_style_color(imgui.Col.SCROLLBAR_BG, (0.0, 0.0, 0.0, 0.0)); pushed_bg = True
        except Exception:
            pushed_bg = False
        if imgui.begin_child("##alpha_asset_grid", (available_w, available_h)):
            current_identity = _current_alpha_identity(sculpt)
            visible_ids = set(); preview_batch = []
            # "默认" clears the Brush Texture and restores the brush's native falloff.
            entries = []
            if scope == "all" and (not q or "默认".casefold().find(q) >= 0):
                entries.append({"identity": "none", "name": "默认", "source_label": "无纹理"})
            entries.extend(filtered)
            for i, item in enumerate(entries):
                if i % cols:
                    imgui.same_line(spacing=tile_gap)
                identity = str(item.get("identity") or "")
                name = str(item.get("name") or "Alpha")
                preview = dict(preview_cache.get(identity) or {})
                tex_id = 0
                if preview and resolve_preview_texture is not None:
                    try: tex_id = int(resolve_preview_texture(preview) or 0)
                    except Exception: tex_id = 0
                selected = identity == current_identity
                if tex_id:
                    clicked = image_square_button(imgui, f"alpha_asset_{i}", tex_id, scale, tile_design, selected=selected)
                else:
                    short = name if len(name) <= 8 else name[:7] + "…"
                    clicked = square_button(imgui, f"{short}##alpha_asset_{i}", scale, tile_design, selected=selected, kind=SECONDARY_TILE_KIND)
                if imgui.is_item_hovered():
                    imgui.set_tooltip(f"{name}\n{str(item.get('source_label') or 'Blender')}")
                if clicked and on_activate_asset is not None:
                    on_activate_asset(identity)
                item_visible = True
                try: item_visible = bool(imgui.is_item_visible())
                except Exception: item_visible = i < 16
                if item_visible: visible_ids.add(identity)
                if preview: requested.pop(identity, None)
                if identity != "none" and not preview and item_visible and on_request_preview is not None and not requested.get(identity) and len(preview_batch) < 16:
                    requested[identity] = True; preview_batch.append(identity)
                try: right_clicked = bool(imgui.is_item_clicked(imgui.MouseButton.RIGHT))
                except Exception: right_clicked = False
                if right_clicked and identity != "none":
                    ui["alpha_context_identity"] = identity
                    imgui.open_popup("Alpha Asset##library_context")
            for old in tuple(requested.keys()):
                if old not in visible_ids and old not in preview_cache:
                    requested.pop(old, None)
            if preview_batch and on_request_preview is not None:
                on_request_preview(list(preview_batch))

            context_identity = str(ui.get("alpha_context_identity") or "")
            if imgui.begin_popup("Alpha Asset##library_context"):
                item = next((dict(x or {}) for x in assets if str((x or {}).get("identity") or "") == context_identity), None)
                if item:
                    name = str(item.get("name") or "Alpha")
                    text(imgui, name, scale, kind="body")
                    text(imgui, str(item.get("folder_label") or ""), scale, kind="small", color=T.TEXT_SECONDARY)
                    imgui.separator()
                    is_fav = context_identity in favorites
                    action_w = max(px(96.0, scale), float(imgui.get_content_region_avail()[0]))
                    if button(imgui, "取消收藏" if is_fav else "加入收藏", scale, action_w/scale, selected=not is_fav, kind="small", height=CONTEXT_MENU.row_h):
                        if on_toggle_favorite is not None:
                            on_toggle_favorite(context_identity)
                        try: imgui.close_current_popup()
                        except Exception: pass
                imgui.end_popup()
        imgui.end_child()
        if pushed_bg:
            try: imgui.pop_style_color(1)
            except Exception: pass
    imgui.end_child()

def draw_sculpt_compact(
    imgui,
    surface_state: MutableMapping,
    sculpt: MutableMapping,
    scale: float,
    *,
    available: bool = True,
    unavailable_reason: str = "",
    blender_mode: str = "SCULPT",
    blender_workspace: str = "",
    host_label: str = "浮台",
    can_enter_sculpt: bool = False,
    on_enter_sculpt: Optional[Callable[[], None]] = None,
    on_state_changed: Optional[Callable[[dict], None]] = None,
    on_notice: Optional[Callable[[str], None]] = None,
    on_more: Optional[Callable[[], None]] = None,
    on_assign_current_to_slot: Optional[Callable[[int], None]] = None,
    on_clear_slot: Optional[Callable[[int], None]] = None,
    on_reset_slots: Optional[Callable[[], None]] = None,
    on_set_quick_rows: Optional[Callable[[int], None]] = None,
    on_refresh_brush_library: Optional[Callable[[], None]] = None,
    on_activate_library_asset: Optional[Callable[[str], None]] = None,
    on_toggle_brush_favorite: Optional[Callable[[str], None]] = None,
    on_assign_library_asset_to_slot: Optional[Callable[[str, int], None]] = None,
    on_request_brush_preview: Optional[Callable[[str], None]] = None,
    on_open_brush_library: Optional[Callable[[dict], None]] = None,
    on_open_alpha_library: Optional[Callable[[dict], None]] = None,
    on_refresh_alpha_library: Optional[Callable[[], None]] = None,
    on_activate_alpha_asset: Optional[Callable[[str], None]] = None,
    on_toggle_alpha_favorite: Optional[Callable[[str], None]] = None,
    on_request_alpha_preview: Optional[Callable[[list], None]] = None,
    on_import_alpha_files: Optional[Callable[[], None]] = None,
    on_toggle_host: Optional[Callable[[], None]] = None,
    resolve_preview_texture: Optional[Callable[[dict], int]] = None,
):
    """Host-independent Sculpt product view shared by 浮台 / 卫星."""
    if not BRUSHES:
        text(imgui, "Sculpt View 资源规格不可用", scale, kind="small", color=T.DANGER)
        return

    product_id, product_title, product_message = _workspace_product(blender_workspace, blender_mode)
    if product_id != "sculpt":
        _draw_workspace_placeholder(
            imgui, scale, title=product_title, workspace_name=blender_workspace,
            host_label=host_label, message=product_message, on_toggle_host=on_toggle_host,
        )
        return

    changed_fields = {}
    slots = list(sculpt.get("quick_brush_slots") or ())
    if not slots:
        slots = [{"slot_id": f"quick_{i+1:02d}", "label": label if i < len(BRUSHES) else "", "empty": i >= len(BRUSHES), "relative_asset_identifier": "__fallback__" if i < len(BRUSHES) else ""} for i, label in enumerate(list(BRUSHES) + [""] * (MAX_QUICK_SLOTS - len(BRUSHES)))]
    rows = max(MIN_QUICK_ROWS, min(MAX_QUICK_ROWS, int(sculpt.get("quick_rows", 2) or 2)))
    visible_count = min(len(slots), rows * QUICK_COLUMNS)
    current = max(0, min(len(slots) - 1, int(sculpt.get("quick_slot", 0) or 0)))
    active_slot = int(sculpt.get("active_quick_slot", current))
    current_alpha_name = str(sculpt.get("current_alpha_name") or "默认")
    current_brush_name = str(sculpt.get("current_brush_name") or (slots[current] or {}).get("label") or "当前笔刷")

    # Product header: LumaFold follows Blender's real Mode; Host is only where
    # this same View lives. Workspace is intentionally not duplicated here.
    text(imgui, "LumaFold Sculpt", scale, kind="section")
    try:
        imgui.same_line()
        remain = imgui.get_content_region_avail()[0]
        host_w = px(24.0, scale)
        if remain > host_w:
            imgui.set_cursor_pos_x(imgui.get_cursor_pos_x() + max(0.0, remain - host_w))
        _host_switch_button(imgui, scale, host_label, on_toggle_host)
    except Exception:
        pass
    muted(imgui, f"Blender 模式：{_mode_label(blender_mode)}  ·  Host：{host_label}", scale)

    in_sculpt = str(blender_mode or "").upper() == "SCULPT"
    if not available or not in_sculpt:
        text(imgui, f"当前 Blender：{_mode_label(blender_mode)}", scale, kind="small", color=T.TEXT_SECONDARY)
        if unavailable_reason and not available:
            muted(imgui, unavailable_reason, scale)
        if can_enter_sculpt and on_enter_sculpt is not None:
            if button(imgui, "进入雕刻模式", scale, 132.0, selected=True):
                on_enter_sculpt()
        else:
            muted(imgui, "LumaFold 不会因为点击笔刷自动切换 Blender Mode。", scale)
        return

    # Product-state cards: current Brush is the main visual anchor; current
    # Alpha replaces the old always-visible 1..6 row and opens its library.
    available_w = max(px(SCULPT_PRIMARY.min_content_w, scale), imgui.get_content_region_avail()[0])
    gap = px(GRID_GAP, scale)
    alpha_card_w = px(SCULPT_PRIMARY.alpha_card_w, scale)
    brush_card_w = max(px(144.0, scale), available_w - alpha_card_w - gap)
    card_h = px(SCULPT_PRIMARY.current_card_h, scale)

    if imgui.begin_child("##current_brush_card", (brush_card_w, card_h)):
        preview = dict(sculpt.get("current_brush_preview") or {})
        tex_id = 0
        if preview and resolve_preview_texture is not None:
            try:
                tex_id = int(resolve_preview_texture(preview) or 0)
            except Exception:
                tex_id = 0
        if tex_id:
            image_size = px(SCULPT_PRIMARY.current_preview, scale)
            imgui.image_with_bg(
                tex_id, (image_size, image_size), (0.0, 0.0), (1.0, 1.0),
                T.SURFACE_2, (1.0, 1.0, 1.0, 1.0),
            )
            imgui.same_line()
            try:
                imgui.begin_group()
                text(imgui, "当前笔刷", scale, kind="small", color=T.TEXT_SECONDARY)
                text(imgui, current_brush_name, scale, kind="body")
                imgui.end_group()
            except Exception:
                text(imgui, current_brush_name, scale, kind="body")
        else:
            text(imgui, "当前笔刷", scale, kind="small", color=T.TEXT_SECONDARY)
            text(imgui, current_brush_name, scale, kind="section")
    imgui.end_child()

    imgui.same_line(spacing=gap)
    alpha_preview = dict(sculpt.get("current_alpha_preview") or {})
    alpha_tex_id = 0
    if alpha_preview and resolve_preview_texture is not None:
        try:
            alpha_tex_id = int(resolve_preview_texture(alpha_preview) or 0)
        except Exception:
            alpha_tex_id = 0
    if alpha_tex_id:
        alpha_clicked = image_square_button(
            imgui, "current_alpha_card", alpha_tex_id, scale,
            min(SCULPT_PRIMARY.alpha_card_w, SCULPT_PRIMARY.current_card_h),
            selected=False, tooltip=f"当前 Alpha：{current_alpha_name}",
        )
    else:
        alpha_clicked = imgui.button(
            f"Alpha\n{current_alpha_name}##current_alpha_card", (alpha_card_w, card_h)
        )
    alpha_anchor = _item_anchor(imgui, scale)
    surface_state["sculpt_alpha_library_anchor"] = dict(alpha_anchor)
    if alpha_clicked:
        if on_open_alpha_library is not None:
            on_open_alpha_library(dict(alpha_anchor))
        else:
            popup_name = "LumaFold Alpha Library##foundation"
            try:
                if imgui.is_popup_open(popup_name):
                    surface_state["sculpt_alpha_library_popup_close_requested"] = True
                else:
                    imgui.open_popup(popup_name)
            except Exception:
                imgui.open_popup(popup_name)

    changed, value = _slider_row(
        imgui, "大小 Size", sculpt.get("brush_size", 72.0), 1.0, 300.0, scale, "%.0f px"
    )
    if changed:
        sculpt["brush_size"] = value
        changed_fields["brush_size"] = value

    changed, value = _slider_row(
        imgui, "强度 Strength", sculpt.get("brush_strength", 0.50), 0.0, 1.0, scale, "%.2f"
    )
    if changed:
        sculpt["brush_strength"] = value
        changed_fields["brush_strength"] = value

    imgui.separator()
    text(imgui, "快捷笔刷", scale, kind="small", color=T.TEXT_SECONDARY)
    imgui.same_line()
    try:
        # Right-align the row preset without introducing another settings page.
        row_label = f"{rows} 行"
        label_w = imgui.calc_text_size(row_label)[0]
        avail_right = imgui.get_content_region_avail()[0]
        combo_w = px(SCULPT_PRIMARY.quick_combo_w, scale)
        if avail_right > combo_w:
            imgui.set_cursor_pos_x(imgui.get_cursor_pos_x() + max(0.0, avail_right - combo_w))
        imgui.set_next_item_width(combo_w)
    except Exception:
        imgui.set_next_item_width(px(SCULPT_PRIMARY.quick_combo_w, scale))
    with font_scope(imgui, "small", scale):
        row_changed, row_index = imgui.combo("##quick_rows", rows - MIN_QUICK_ROWS, ["2 行", "3 行", "4 行"])
    if row_changed:
        rows = int(row_index) + MIN_QUICK_ROWS
        sculpt["quick_rows"] = rows
        sculpt["slot_count"] = rows * QUICK_COLUMNS
        if on_set_quick_rows is not None:
            on_set_quick_rows(rows)

    avail = max(px(SCULPT_PRIMARY.min_content_w, scale), imgui.get_content_region_avail()[0])
    grid_gap = px(GRID_GAP, scale)
    slot_w = max(px(SCULPT_PRIMARY.quick_tile_min, scale), (avail - grid_gap * (QUICK_COLUMNS - 1)) / QUICK_COLUMNS)
    preview_cache = sculpt.get("brush_preview_cache") or {}
    for i in range(visible_count):
        slot = dict(slots[i] or {})
        empty = bool(slot.get("empty")) or not str(slot.get("relative_asset_identifier") or "")
        label = str(slot.get("label") or "+") if not empty else "+"
        if i % QUICK_COLUMNS:
            imgui.same_line(spacing=grid_gap)
        tex_id = 0
        payload = _slot_preview({"brush_preview_cache": preview_cache}, slot)
        if payload and resolve_preview_texture is not None:
            try:
                tex_id = int(resolve_preview_texture(payload) or 0)
            except Exception:
                tex_id = 0
        left_clicked = _quick_slot_widget(
            imgui, label, i, scale, slot_w, selected=(i == active_slot and not empty), empty=empty, tex_id=tex_id,
        )
        try:
            right_clicked = bool(imgui.is_item_clicked(imgui.MouseButton.RIGHT))
        except Exception:
            right_clicked = False
        if right_clicked:
            surface_state["sculpt_slot_menu_index"] = i
            imgui.open_popup("Quick Brush Slot##context")
        if left_clicked:
            if empty:
                if on_assign_current_to_slot is not None:
                    on_assign_current_to_slot(i)
            else:
                sculpt["quick_slot"] = i
                sculpt["active_quick_slot"] = i
                changed_fields["quick_slot"] = i
                current = i
                active_slot = i

    menu_index = int(surface_state.get("sculpt_slot_menu_index", -1))
    slot_popup = "Quick Brush Slot##context"
    try:
        popup_open = bool(imgui.is_popup_open(slot_popup))
    except Exception:
        popup_open = False
    if popup_open:
        menu_w = px(CONTEXT_MENU.width, scale)
        if hasattr(imgui, "set_next_window_size_constraints"):
            try:
                imgui.set_next_window_size_constraints(
                    (menu_w, 0.0),
                    (menu_w, px(180.0, scale)),
                )
            except Exception:
                pass
    if imgui.begin_popup(slot_popup):
        if 0 <= menu_index < len(slots):
            menu_slot = dict(slots[menu_index] or {})
            menu_empty = bool(menu_slot.get("empty")) or not str(menu_slot.get("relative_asset_identifier") or "")
            menu_label = str(menu_slot.get("label") or f"槽位 {menu_index + 1}")
            # Context-menu hierarchy is deliberately lighter than the primary surface.
            text(imgui, f"槽位 {menu_index + 1}", scale, kind="body")
            text(
                imgui, "空槽位" if menu_empty else menu_label, scale,
                kind="small", color=T.TEXT_SECONDARY,
            )
            imgui.separator()
            action_w = max(px(96.0, scale), float(imgui.get_content_region_avail()[0]))
            if button(
                imgui, "替换为当前笔刷", scale, action_w / scale, selected=True,
                kind="small", height=CONTEXT_MENU.row_h,
            ):
                if on_assign_current_to_slot is not None:
                    on_assign_current_to_slot(menu_index)
                try:
                    imgui.close_current_popup()
                except Exception:
                    pass
            if not menu_empty and button(
                imgui, "清空槽位", scale, action_w / scale,
                kind="small", height=CONTEXT_MENU.row_h,
            ):
                if on_clear_slot is not None:
                    on_clear_slot(menu_index)
                try:
                    imgui.close_current_popup()
                except Exception:
                    pass
        imgui.end_popup()

    imgui.separator()
    bottom_avail = max(px(SCULPT_PRIMARY.min_content_w, scale), imgui.get_content_region_avail()[0])
    bottom_gap = px(GRID_GAP, scale)
    bottom_w = max(px(SCULPT_PRIMARY.bottom_button_min, scale), (bottom_avail - bottom_gap) / 2.0)
    brush_library_clicked = button(imgui, "笔刷库", scale, bottom_w / scale)
    brush_anchor = _item_anchor(imgui, scale)
    surface_state["sculpt_brush_library_anchor"] = dict(brush_anchor)
    if brush_library_clicked:
        if on_open_brush_library is not None:
            on_open_brush_library(dict(brush_anchor))
        else:
            popup_name = "LumaFold Brush Library##foundation"
            try:
                if imgui.is_popup_open(popup_name):
                    surface_state["sculpt_brush_library_popup_close_requested"] = True
                else:
                    imgui.open_popup(popup_name)
            except Exception:
                imgui.open_popup(popup_name)
    imgui.same_line(spacing=bottom_gap)
    if button(imgui, "更多", scale, bottom_w / scale):
        if on_more:
            on_more()

    # Embedded Brush Library popup uses the exact same size/content contract as
    # the native Secondary Surface.
    brush_popup = "LumaFold Brush Library##foundation"
    anchor = dict(surface_state.get("sculpt_brush_library_anchor") or {})
    try:
        sw, sh = secondary_surface_design_size("brush_library")
        imgui.set_next_window_size((px(sw, scale), px(sh, scale)), imgui.Cond.ALWAYS)
        if anchor:
            imgui.set_next_window_pos((float(anchor.get("x", 0.0)), float(anchor.get("y", 0.0))), imgui.Cond.APPEARING)
    except Exception:
        pass
    if imgui.begin_popup(brush_popup):
        if bool(surface_state.pop("sculpt_brush_library_popup_close_requested", False)):
            try:
                imgui.close_current_popup()
            except Exception:
                pass
        else:
            draw_brush_library_foundation(
                imgui, sculpt, scale, library_ui_state=surface_state,
                on_refresh_library=on_refresh_brush_library,
                on_activate_asset=on_activate_library_asset,
                on_toggle_favorite=on_toggle_brush_favorite,
                on_assign_asset_to_slot=on_assign_library_asset_to_slot,
                on_request_preview=on_request_brush_preview,
                resolve_preview_texture=resolve_preview_texture,
            )
        imgui.end_popup()

    # Embedded Alpha popup mirrors the exact same Secondary Surface contract.
    alpha_popup = "LumaFold Alpha Library##foundation"
    alpha_anchor = dict(surface_state.get("sculpt_alpha_library_anchor") or {})
    try:
        sw, sh = secondary_surface_design_size("alpha_library")
        imgui.set_next_window_size((px(sw, scale), px(sh, scale)), imgui.Cond.ALWAYS)
        if alpha_anchor:
            imgui.set_next_window_pos((float(alpha_anchor.get("x", 0.0)), float(alpha_anchor.get("y", 0.0))), imgui.Cond.APPEARING)
    except Exception:
        pass
    if imgui.begin_popup(alpha_popup):
        if bool(surface_state.pop("sculpt_alpha_library_popup_close_requested", False)):
            try:
                imgui.close_current_popup()
            except Exception:
                pass
        else:
            draw_alpha_library_foundation(
                imgui, sculpt, scale, library_ui_state=surface_state,
                on_refresh_library=on_refresh_alpha_library,
                on_activate_asset=on_activate_alpha_asset,
                on_toggle_favorite=on_toggle_alpha_favorite,
                on_request_preview=on_request_alpha_preview,
                on_import_files=on_import_alpha_files,
                resolve_preview_texture=resolve_preview_texture,
            )
        imgui.end_popup()

    if changed_fields and on_state_changed:
        on_state_changed(dict(changed_fields))
