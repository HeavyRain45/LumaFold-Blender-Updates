from __future__ import annotations

"""Stable Sculpt product presentation refinements.

This layer leaves the validated Brush/Alpha foundation intact and patches only
presentation seams that were previously carried by the dev11 polish module:

* Quick Brush context menu is actions-only, with Edit Shortcut first.
* Normal context actions never use Selected blue; blue remains a state token.
* Current Brush / Alpha cards are content-sized first and truly square in height.
* Header glyphs share one size/group rhythm.
* ZBrush/Blender control artwork is cleaned at runtime without introducing a
  second icon set.
"""

import math

from . import sculpt_interactions
from . import sculpt_control_icons as control_icons
from . import sculpt_view
from . import sculpt_view_foundation as foundation
from .design import px
from .layout_system import SculptPrimaryMetrics

_INSTALLED = False
_ORIGINAL_DRAW = None
_ORIGINAL_RGBA = None


def _clean_control_rgba(raw: bytes) -> bytes:
    """Remove reference-image artefacts without introducing a second icon set."""
    data = bytearray(raw)
    width = 256
    cell = 64

    def clear_pixel(x: int, y: int, alpha_scale: float = 0.0):
        if not (0 <= x < width and 0 <= y < 64):
            return
        off = (y * width + x) * 4
        if alpha_scale <= 0.0:
            data[off:off + 4] = b"\x00\x00\x00\x00"
            return
        data[off + 3] = max(0, min(255, int(round(data[off + 3] * alpha_scale))))

    for y in range(64):
        for x in range(cell):
            near_source_frame = (
                6 <= x <= 57 and 6 <= y <= 56
                and (x <= 10 or x >= 53 or y <= 10 or y >= 52)
            )
            if near_source_frame:
                clear_pixel(x, y)

    bx0 = cell
    cx, cy = 38.0, 35.0
    inner_r, outer_r = 5.2, 7.0
    for y in range(64):
        for lx in range(cell):
            d = math.hypot(float(lx) - cx, float(y) - cy)
            if d <= inner_r:
                clear_pixel(bx0 + lx, y)
            elif d < outer_r:
                clear_pixel(bx0 + lx, y, (d - inner_r) / (outer_r - inner_r))

    return bytes(data)


def _install_artwork_cleanup():
    global _ORIGINAL_RGBA
    if _ORIGINAL_RGBA is not None:
        return
    _ORIGINAL_RGBA = control_icons._rgba

    def cleaned_rgba():
        return _clean_control_rgba(_ORIGINAL_RGBA())

    control_icons._rgba = cleaned_rgba


def _host_switch_button(imgui, scale: float, host_label: str, on_toggle_host):
    satellite = str(host_label or "").strip() == "卫星"
    name = "embedded" if satellite else "satellite"
    tooltip = "返回 Blender 浮台" if satellite else "切换到卫星窗口"
    clicked = control_icons.icon_button(
        imgui, name, "host_switch_dev11", scale,
        box=24.0, glyph=18.0, selected=False, tooltip=tooltip,
    )
    if clicked and on_toggle_host is not None:
        on_toggle_host()
    return bool(clicked)


def _draw_input_profile_switch(imgui, sculpt, scale, blender_mode, *, host_x: float, on_state_changed=None):
    in_sculpt = str(blender_mode or "").upper() == "SCULPT"
    preferred = sculpt_view._normalize_input_profile(sculpt.get("input_profile", "blender"))
    effective = preferred if in_sculpt else "blender"

    side = 24.0
    inner_gap = 4.0
    host_group_gap = 12.0
    group_w = px(side * 2.0 + inner_gap, scale)
    start_x = max(0.0, float(host_x) - group_w - px(host_group_gap, scale))
    try:
        imgui.set_cursor_pos_x(start_x)
    except Exception:
        return

    z_clicked = control_icons.icon_button(
        imgui, "zbrush", "profile_zbrush_dev11", scale,
        box=side, glyph=18.0,
        selected=(effective == "zbrush"), disabled=not in_sculpt,
        tooltip=sculpt_view._profile_tooltip("zbrush", in_sculpt),
    )
    imgui.same_line(spacing=px(inner_gap, scale))
    b_clicked = control_icons.icon_button(
        imgui, "blender", "profile_blender_dev11", scale,
        box=side, glyph=18.0,
        selected=(effective == "blender"), disabled=not in_sculpt,
        tooltip=sculpt_view._profile_tooltip("blender", in_sculpt),
    )

    requested = None
    if in_sculpt:
        if z_clicked:
            requested = "zbrush"
        elif b_clicked:
            requested = "blender"
    if requested is not None and requested != preferred:
        sculpt["input_profile"] = requested
        if on_state_changed is not None:
            on_state_changed({"input_profile": requested})


def _context_menu_draw_wrapper(imgui, surface_state, sculpt, scale, **kwargs):
    """Render the frozen slot popup as three plain action rows only."""
    original_begin_popup = getattr(imgui, "begin_popup", None)
    original_end_popup = getattr(imgui, "end_popup", None)
    original_separator = getattr(imgui, "separator", None)
    original_text = foundation.text
    original_button = foundation.button
    if not all(callable(x) for x in (original_begin_popup, original_end_popup, original_separator)):
        return _ORIGINAL_DRAW(imgui, surface_state, sculpt, scale, **kwargs)

    state = {"quick_context": False}

    def begin_popup(name, *args, **popup_kwargs):
        opened = original_begin_popup(name, *args, **popup_kwargs)
        if str(name) == "Quick Brush Slot##context" and opened:
            state["quick_context"] = True
        return opened

    def end_popup(*args, **popup_kwargs):
        try:
            return original_end_popup(*args, **popup_kwargs)
        finally:
            if state["quick_context"]:
                state["quick_context"] = False

    def separator(*args, **separator_kwargs):
        if state["quick_context"]:
            return None
        return original_separator(*args, **separator_kwargs)

    def text_product(imgui_arg, value, scale_arg=1.0, **text_kwargs):
        if state["quick_context"]:
            return None
        return original_text(imgui_arg, value, scale_arg, **text_kwargs)

    def button_product(imgui_arg, label, scale_arg=1.0, width=0.0, **button_kwargs):
        if not state["quick_context"]:
            return original_button(imgui_arg, label, scale_arg, width, **button_kwargs)

        label_text = str(label or "")
        if label_text == "替换为当前笔刷":
            edit_kwargs = dict(button_kwargs)
            edit_kwargs["selected"] = False
            if original_button(imgui_arg, "编辑快捷键", scale_arg, width, **edit_kwargs):
                slot = int(surface_state.get("sculpt_slot_menu_index", -1))
                if slot >= 0:
                    sculpt_view._prepare_shortcut_editor(surface_state, sculpt, slot)
                try:
                    imgui_arg.close_current_popup()
                except Exception:
                    pass
                return False
            replace_kwargs = dict(button_kwargs)
            replace_kwargs["selected"] = False
            return original_button(imgui_arg, label, scale_arg, width, **replace_kwargs)

        if label_text == "清空槽位":
            old_index = surface_state.get("sculpt_slot_menu_index", -1)
            surface_state["sculpt_slot_menu_index"] = -1
            try:
                clear_kwargs = dict(button_kwargs)
                clear_kwargs["selected"] = False
                return original_button(imgui_arg, label, scale_arg, width, **clear_kwargs)
            finally:
                surface_state["sculpt_slot_menu_index"] = old_index

        clean_kwargs = dict(button_kwargs)
        clean_kwargs["selected"] = False
        return original_button(imgui_arg, label, scale_arg, width, **clean_kwargs)

    patched = []
    try:
        setattr(imgui, "begin_popup", begin_popup); patched.append((imgui, "begin_popup", original_begin_popup))
        setattr(imgui, "end_popup", end_popup); patched.append((imgui, "end_popup", original_end_popup))
        setattr(imgui, "separator", separator); patched.append((imgui, "separator", original_separator))
        foundation.text = text_product
        foundation.button = button_product
        return _ORIGINAL_DRAW(imgui, surface_state, sculpt, scale, **kwargs)
    finally:
        foundation.text = original_text
        foundation.button = original_button
        for owner, name, original in reversed(patched):
            try:
                setattr(owner, name, original)
            except Exception:
                pass


def install():
    global _INSTALLED, _ORIGINAL_DRAW
    if _INSTALLED:
        return

    _install_artwork_cleanup()

    old = foundation.SCULPT_PRIMARY
    foundation.SCULPT_PRIMARY = SculptPrimaryMetrics(
        min_content_w=old.min_content_w,
        alpha_card_w=64.0,
        current_card_h=64.0,
        current_preview=52.0,
        quick_combo_w=old.quick_combo_w,
        quick_tile_min=old.quick_tile_min,
        bottom_button_min=old.bottom_button_min,
        slider_label_w=old.slider_label_w,
        grid_gap=old.grid_gap,
    )

    foundation._host_switch_button = _host_switch_button
    sculpt_view._draw_input_profile_switch = _draw_input_profile_switch

    _ORIGINAL_DRAW = foundation.draw_sculpt_compact
    foundation.draw_sculpt_compact = _context_menu_draw_wrapper
    _INSTALLED = True
