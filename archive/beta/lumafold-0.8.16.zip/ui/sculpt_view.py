from __future__ import annotations

from typing import Callable, MutableMapping, Optional

# The already real-machine-passed Brush/Alpha product foundation stays frozen.
# This public composition layer owns lightweight product additions and visual
# composition without replacing Blender-owned Brush/Alpha preview data.
from .sculpt_view_foundation import *  # noqa: F401,F403
from . import sculpt_view_foundation as _foundation
from .design import px
from .sculpt_more_view import draw_more_foundation


_INPUT_PROFILE_BLENDER = "blender"
_INPUT_PROFILE_ZBRUSH = "zbrush"
_SHORTCUT_MODIFIERS = (("Alt", "ALT"), ("Ctrl", "CTRL"), ("Shift", "SHIFT"), ("无", "NONE"))
_SHORTCUT_KEYS = (
    ("1", "ONE"), ("2", "TWO"), ("3", "THREE"), ("4", "FOUR"), ("5", "FIVE"),
    ("6", "SIX"), ("7", "SEVEN"), ("8", "EIGHT"), ("9", "NINE"), ("0", "ZERO"),
) + tuple((ch, ch) for ch in "ABCDEFGHIJKLMNOPQRSTUVWXYZ")


def _normalize_input_profile(value) -> str:
    key = str(value or "").strip().casefold()
    return _INPUT_PROFILE_ZBRUSH if key in {"zbrush", "z"} else _INPUT_PROFILE_BLENDER


def _profile_tooltip(profile: str, in_sculpt: bool) -> str:
    if profile == _INPUT_PROFILE_ZBRUSH:
        base = "ZBrush 雕刻逻辑"
    else:
        base = "Blender 雕刻逻辑"
    return base if in_sculpt else (base + " · 仅在雕刻模式切换")


def _draw_input_profile_switch(
    imgui,
    sculpt: MutableMapping,
    scale: float,
    blender_mode: str,
    *,
    host_x: float,
    on_state_changed: Optional[Callable[[dict], None]] = None,
):
    """Draw the two high-frequency Sculpt input-profile controls beside Host."""
    in_sculpt = str(blender_mode or "").upper() == "SCULPT"
    preferred = _normalize_input_profile(sculpt.get("input_profile", _INPUT_PROFILE_BLENDER))
    effective = preferred if in_sculpt else _INPUT_PROFILE_BLENDER

    side = 22.0
    gap = 4.0
    host_gap = 5.0
    group_w = px(side * 2.0 + gap, scale)
    start_x = max(0.0, float(host_x) - group_w - px(host_gap, scale))

    try:
        imgui.set_cursor_pos_x(start_x)
    except Exception:
        return

    z_clicked = _foundation.square_button(
        imgui, "Z##sculpt_input_profile_zbrush", scale, side,
        selected=(effective == _INPUT_PROFILE_ZBRUSH), disabled=not in_sculpt, kind="small",
    )
    try:
        if imgui.is_item_hovered():
            imgui.set_tooltip(_profile_tooltip(_INPUT_PROFILE_ZBRUSH, in_sculpt))
    except Exception:
        pass

    imgui.same_line(spacing=px(gap, scale))
    b_clicked = _foundation.square_button(
        imgui, "B##sculpt_input_profile_blender", scale, side,
        selected=(effective == _INPUT_PROFILE_BLENDER), disabled=not in_sculpt, kind="small",
    )
    try:
        if imgui.is_item_hovered():
            imgui.set_tooltip(_profile_tooltip(_INPUT_PROFILE_BLENDER, in_sculpt))
    except Exception:
        pass

    requested = None
    if in_sculpt:
        if z_clicked:
            requested = _INPUT_PROFILE_ZBRUSH
        elif b_clicked:
            requested = _INPUT_PROFILE_BLENDER
    if requested is not None and requested != preferred:
        sculpt["input_profile"] = requested
        if on_state_changed is not None:
            on_state_changed({"input_profile": requested})


def _slot_identity(slot) -> str:
    try:
        return str(_foundation._slot_identity(slot) or "")
    except Exception:
        slot = dict(slot or {})
        rel = str(slot.get("relative_asset_identifier") or "").replace("\\", "/").strip()
        if not rel:
            return ""
        return "asset|{}|{}|{}".format(
            str(slot.get("asset_library_type") or "").casefold(),
            str(slot.get("asset_library_identifier") or "").casefold(),
            rel.casefold(),
        )


def _preview_for_slot(sculpt: MutableMapping, slot):
    identity = _slot_identity(slot)
    if not identity:
        return {}
    for key in ("brush_preview_cache", "primary_brush_preview_cache", "brush_library_preview_cache"):
        payload = dict((sculpt.get(key) or {}).get(identity) or {})
        if payload.get("rgba_b64"):
            return payload
    return {}


def _warm_quick_brush_previews(
    sculpt: MutableMapping,
    surface_state: MutableMapping,
    *,
    on_refresh_brush_library=None,
    on_request_brush_preview=None,
):
    """Lazily ask Blender for the visible Quick Brush Asset previews."""
    slots = list(sculpt.get("quick_brush_slots") or ())
    rows = max(2, min(4, int(sculpt.get("quick_rows", 2) or 2)))
    visible = slots[: min(len(slots), rows * 4)]
    identities = []
    for slot in visible:
        identity = _slot_identity(slot)
        if identity and not _preview_for_slot(sculpt, slot):
            identities.append(identity)

    requested = surface_state.setdefault("_quick_visual_preview_requested", {})
    for slot in visible:
        identity = _slot_identity(slot)
        if identity and _preview_for_slot(sculpt, slot):
            requested.pop(identity, None)

    if not identities:
        surface_state["_quick_visual_refresh_requested"] = False
        return

    status = str(sculpt.get("brush_library_status") or "NOT_LOADED")
    if status in {"NOT_LOADED", "ERROR", "EMPTY"}:
        if on_refresh_brush_library is not None and not bool(surface_state.get("_quick_visual_refresh_requested", False)):
            surface_state["_quick_visual_refresh_requested"] = True
            requested.clear()
            on_refresh_brush_library()
        return

    if status == "SCANNING":
        return

    surface_state["_quick_visual_refresh_requested"] = False
    batch = []
    for identity in identities:
        if requested.get(identity):
            continue
        requested[identity] = True
        batch.append(identity)
        if len(batch) >= 8:
            break
    if batch and on_request_brush_preview is not None:
        on_request_brush_preview(list(batch))


def _u32_rgba(r: int, g: int, b: int, a: int = 255):
    return ((int(a) & 255) << 24) | ((int(b) & 255) << 16) | ((int(g) & 255) << 8) | (int(r) & 255)


def _draw_list_text(imgui, draw_list, pos, value: str, scale: float, *, kind="small", color=None):
    if not value:
        return
    col = color if color is not None else _u32_rgba(238, 238, 238, 255)
    try:
        with _foundation.font_scope(imgui, kind, scale):
            draw_list.add_text((float(pos[0]), float(pos[1])), int(col), str(value))
    except Exception:
        try:
            draw_list.add_text((float(pos[0]), float(pos[1])), int(col), str(value))
        except Exception:
            pass


def _visual_quick_slot_widget(
    imgui,
    sculpt: MutableMapping,
    label,
    ident,
    scale,
    width_px,
    selected,
    empty,
    tex_id=0,
):
    """One Quick Brush tile: Blender preview + name + actual shortcut badge."""
    design_size = max(1.0, float(width_px) / max(0.01, float(scale)))
    clicked = _foundation.square_button(
        imgui,
        f"##quick_visual_{ident}",
        scale,
        design_size,
        selected=bool(selected),
        kind="small",
    )
    try:
        rmin = imgui.get_item_rect_min()
        rmax = imgui.get_item_rect_max()
        x0, y0 = float(rmin[0]), float(rmin[1])
        x1, y1 = float(rmax[0]), float(rmax[1])
        draw = imgui.get_window_draw_list()
    except Exception:
        return bool(clicked)

    side = max(1.0, min(x1 - x0, y1 - y0))
    pad = px(3.0, scale)
    name_h = px(15.0, scale)
    image_side = max(px(18.0, scale), min(side - pad * 2.0, side - name_h - pad * 1.25))
    image_x = x0 + (side - image_side) * 0.5
    image_y = y0 + pad

    if int(tex_id or 0):
        try:
            draw.add_image(
                int(tex_id),
                (image_x, image_y),
                (image_x + image_side, image_y + image_side),
                (0.0, 0.0), (1.0, 1.0), _u32_rgba(255, 255, 255, 255),
            )
        except Exception:
            try:
                draw.add_image(int(tex_id), (image_x, image_y), (image_x + image_side, image_y + image_side))
            except Exception:
                pass

    shortcut = ""
    try:
        shortcuts = list(sculpt.get("quick_shortcuts") or ())
        if 0 <= int(ident) < len(shortcuts):
            shortcut = str(shortcuts[int(ident)] or "")
    except Exception:
        shortcut = ""

    if shortcut:
        try:
            with _foundation.font_scope(imgui, "small", scale):
                tw, th = imgui.calc_text_size(shortcut)
            bx0, by0 = x0 + px(3.0, scale), y0 + px(3.0, scale)
            bx1 = min(x1 - px(2.0, scale), bx0 + float(tw) + px(6.0, scale))
            by1 = by0 + float(th) + px(3.0, scale)
            draw.add_rect_filled((bx0, by0), (bx1, by1), _u32_rgba(30, 30, 30, 205), px(3.0, scale))
            _draw_list_text(imgui, draw, (bx0 + px(3.0, scale), by0 + px(1.0, scale)), shortcut, scale)
        except Exception:
            _draw_list_text(imgui, draw, (x0 + pad, y0 + pad), shortcut, scale)

    display_name = "+" if empty else str(label or "Brush")
    if empty:
        try:
            with _foundation.font_scope(imgui, "body", scale):
                tw, th = imgui.calc_text_size(display_name)
            _draw_list_text(
                imgui, draw,
                (x0 + (side - float(tw)) * 0.5, y0 + (side - float(th)) * 0.5),
                display_name, scale, kind="body",
            )
        except Exception:
            pass
    else:
        try:
            with _foundation.font_scope(imgui, "small", scale):
                text_value = display_name
                max_w = side - px(6.0, scale)
                while len(text_value) > 3 and imgui.calc_text_size(text_value)[0] > max_w:
                    text_value = text_value[:-2] + "…"
                tw, th = imgui.calc_text_size(text_value)
            strip_y = y1 - name_h
            draw.add_rect_filled((x0 + px(2.0, scale), strip_y), (x1 - px(2.0, scale), y1 - px(2.0, scale)), _u32_rgba(32, 32, 32, 185), px(2.0, scale))
            _draw_list_text(
                imgui, draw,
                (x0 + (side - float(tw)) * 0.5, strip_y + max(0.0, (name_h - float(th)) * 0.5 - px(1.0, scale))),
                text_value, scale,
            )
        except Exception:
            pass

    try:
        if imgui.is_item_hovered():
            if empty:
                tip = "添加当前快捷笔刷"
            else:
                tip = str(label or "快捷笔刷")
                if shortcut:
                    tip += " · " + shortcut
                tip += "\n图标：打开笔刷库替换槽位 · 名称：切换笔刷 · 右键：槽位菜单"
            imgui.set_tooltip(tip)
    except Exception:
        pass
    return bool(clicked)


def _prepare_visual_caches(sculpt: MutableMapping):
    """Expose accumulated real previews to the frozen foundation for one frame."""
    brush_primary = dict(sculpt.get("primary_brush_preview_cache") or {})
    alpha_primary = dict(sculpt.get("primary_alpha_preview_cache") or {})

    brush_library_original = sculpt.get("brush_library_preview_cache")
    alpha_library_original = sculpt.get("alpha_library_preview_cache")

    brush_merged = dict(brush_library_original or {})
    brush_merged.update(brush_primary)
    alpha_merged = dict(alpha_library_original or {})
    alpha_merged.update(alpha_primary)
    sculpt["brush_library_preview_cache"] = brush_merged
    sculpt["alpha_library_preview_cache"] = alpha_merged

    if not dict(sculpt.get("current_brush_preview") or {}):
        current_identity = ""
        try:
            current_identity = str(_foundation._current_asset_identity(sculpt) or "")
        except Exception:
            pass
        if current_identity and current_identity in brush_merged:
            sculpt["current_brush_preview"] = dict(brush_merged[current_identity])

    current_alpha = str(sculpt.get("current_alpha_identity") or "none")
    if current_alpha != "none" and not dict(sculpt.get("current_alpha_preview") or {}) and current_alpha in alpha_merged:
        sculpt["current_alpha_preview"] = dict(alpha_merged[current_alpha])

    return brush_library_original, alpha_library_original


def _binding_for_slot(sculpt: MutableMapping, slot: int):
    bindings = list(sculpt.get("quick_hotkey_bindings") or ())
    if 0 <= int(slot) < len(bindings):
        raw = dict(bindings[int(slot)] or {})
        key = str(raw.get("type") or "").upper()
        if key:
            modifier = "ALT" if raw.get("alt") else "CTRL" if raw.get("ctrl") else "SHIFT" if raw.get("shift") else "NONE"
            return modifier, key
    labels = list(sculpt.get("quick_shortcuts") or ())
    text_value = str(labels[int(slot)] or "") if 0 <= int(slot) < len(labels) else ""
    modifier, key_label = "NONE", ""
    parts = [part.strip() for part in text_value.split("+") if part.strip()]
    if len(parts) >= 2:
        modifier = parts[0].upper()
        key_label = parts[-1].upper()
    elif parts:
        key_label = parts[-1].upper()
    key_map = {label.upper(): event for label, event in _SHORTCUT_KEYS}
    key = key_map.get(key_label)
    if not key:
        default_index = int(slot) % 8
        key = _SHORTCUT_KEYS[default_index][1]
        modifier = "ALT" if int(slot) < 8 else "CTRL"
    if modifier not in {item[1] for item in _SHORTCUT_MODIFIERS}:
        modifier = "NONE"
    return modifier, key


def _prepare_shortcut_editor(surface_state, sculpt, slot: int):
    modifier, key = _binding_for_slot(sculpt, slot)
    mod_values = [item[1] for item in _SHORTCUT_MODIFIERS]
    key_values = [item[1] for item in _SHORTCUT_KEYS]
    surface_state["_quick_shortcut_editor_slot"] = int(slot)
    surface_state["_quick_shortcut_modifier_index"] = mod_values.index(modifier) if modifier in mod_values else 0
    surface_state["_quick_shortcut_key_index"] = key_values.index(key) if key in key_values else 0
    surface_state["_quick_shortcut_editor_open_requested"] = True


def _emit_shortcut_request(surface_state, sculpt, on_state_changed, *, slot: int, modifier="ALT", key="ONE", action="set"):
    serial = int(surface_state.get("_quick_shortcut_request_serial", 0) or 0) + 1
    surface_state["_quick_shortcut_request_serial"] = serial
    request = {
        "serial": serial,
        "slot": int(slot),
        "modifier": str(modifier),
        "key": str(key),
        "action": str(action),
    }
    sculpt["quick_shortcut_request"] = dict(request)
    if on_state_changed is not None:
        on_state_changed({"quick_shortcut_request": dict(request)})


def _draw_shortcut_editor(imgui, surface_state, sculpt, scale, on_state_changed):
    popup = "编辑快捷键##quick_shortcut_product"
    if bool(surface_state.pop("_quick_shortcut_editor_open_requested", False)):
        try:
            imgui.open_popup(popup)
        except Exception:
            pass

    try:
        imgui.set_next_window_size((px(232.0, scale), 0.0), imgui.Cond.APPEARING)
    except Exception:
        pass
    if not imgui.begin_popup(popup):
        return

    slot = int(surface_state.get("_quick_shortcut_editor_slot", 0) or 0)
    labels = list(sculpt.get("quick_shortcuts") or ())
    current = str(labels[slot] or "未绑定") if 0 <= slot < len(labels) else "未绑定"
    _foundation.text(imgui, f"槽位 {slot + 1} · 编辑快捷键", scale, kind="body")
    _foundation.text(imgui, f"当前：{current}", scale, kind="small", color=_foundation.T.TEXT_SECONDARY)
    imgui.separator()

    mod_labels = [item[0] for item in _SHORTCUT_MODIFIERS]
    key_labels = [item[0] for item in _SHORTCUT_KEYS]
    mod_index = max(0, min(len(mod_labels) - 1, int(surface_state.get("_quick_shortcut_modifier_index", 0) or 0)))
    key_index = max(0, min(len(key_labels) - 1, int(surface_state.get("_quick_shortcut_key_index", 0) or 0)))

    _foundation.text(imgui, "修饰键", scale, kind="small", color=_foundation.T.TEXT_SECONDARY)
    imgui.same_line()
    imgui.set_next_item_width(px(72.0, scale))
    with _foundation.font_scope(imgui, "small", scale):
        changed, mod_index_new = imgui.combo("##quick_shortcut_modifier", mod_index, mod_labels)
    if changed:
        mod_index = int(mod_index_new)
        surface_state["_quick_shortcut_modifier_index"] = mod_index

    imgui.same_line(spacing=px(6.0, scale))
    _foundation.text(imgui, "按键", scale, kind="small", color=_foundation.T.TEXT_SECONDARY)
    imgui.same_line()
    imgui.set_next_item_width(px(72.0, scale))
    with _foundation.font_scope(imgui, "small", scale):
        changed, key_index_new = imgui.combo("##quick_shortcut_key", key_index, key_labels)
    if changed:
        key_index = int(key_index_new)
        surface_state["_quick_shortcut_key_index"] = key_index

    imgui.spacing()
    action_w = max(px(62.0, scale), (float(imgui.get_content_region_avail()[0]) - px(12.0, scale)) / 3.0)
    if _foundation.button(imgui, "保存", scale, action_w / scale, selected=True, kind="small", height=_foundation.CONTEXT_MENU.row_h):
        _emit_shortcut_request(
            surface_state, sculpt, on_state_changed,
            slot=slot,
            modifier=_SHORTCUT_MODIFIERS[mod_index][1],
            key=_SHORTCUT_KEYS[key_index][1],
        )
        try:
            imgui.close_current_popup()
        except Exception:
            pass
    imgui.same_line(spacing=px(6.0, scale))
    if _foundation.button(imgui, "默认", scale, action_w / scale, kind="small", height=_foundation.CONTEXT_MENU.row_h):
        _emit_shortcut_request(surface_state, sculpt, on_state_changed, slot=slot, action="reset")
        try:
            imgui.close_current_popup()
        except Exception:
            pass
    imgui.same_line(spacing=px(6.0, scale))
    if _foundation.button(imgui, "取消", scale, action_w / scale, kind="small", height=_foundation.CONTEXT_MENU.row_h):
        try:
            imgui.close_current_popup()
        except Exception:
            pass
    imgui.end_popup()


def draw_sculpt_compact(
    imgui,
    surface_state: MutableMapping,
    sculpt: MutableMapping,
    scale: float,
    *,
    available: bool = True,
    unavailable_reason: str = "",
    blender_mode: str = "SCULPT",
    blender_workspace: str = "",
    host_label: str = "浮台",
    can_enter_sculpt: bool = False,
    on_enter_sculpt: Optional[Callable[[], None]] = None,
    on_state_changed: Optional[Callable[[dict], None]] = None,
    on_notice: Optional[Callable[[str], None]] = None,
    on_more: Optional[Callable[[], None]] = None,
    on_assign_current_to_slot: Optional[Callable[[int], None]] = None,
    on_clear_slot: Optional[Callable[[int], None]] = None,
    on_reset_slots: Optional[Callable[[], None]] = None,
    on_set_quick_rows: Optional[Callable[[int], None]] = None,
    on_refresh_brush_library: Optional[Callable[[], None]] = None,
    on_activate_library_asset: Optional[Callable[[str], None]] = None,
    on_toggle_brush_favorite: Optional[Callable[[str], None]] = None,
    on_assign_library_asset_to_slot: Optional[Callable[[str, int], None]] = None,
    on_request_brush_preview: Optional[Callable[[str], None]] = None,
    on_open_brush_library: Optional[Callable[[dict], None]] = None,
    on_open_alpha_library: Optional[Callable[[dict], None]] = None,
    on_refresh_alpha_library: Optional[Callable[[], None]] = None,
    on_activate_alpha_asset: Optional[Callable[[str], None]] = None,
    on_toggle_alpha_favorite: Optional[Callable[[str], None]] = None,
    on_request_alpha_preview: Optional[Callable[[list], None]] = None,
    on_import_alpha_files: Optional[Callable[[], None]] = None,
    on_toggle_host: Optional[Callable[[], None]] = None,
    resolve_preview_texture: Optional[Callable[[dict], int]] = None,
):
    """Compose the frozen Sculpt foundation with current product additions."""
    satellite = str(host_label or "").strip() == "卫星"
    more_popup = "LumaFold More##foundation"
    brush_popup = "LumaFold Brush Library##foundation"
    alpha_popup = "LumaFold Alpha Library##foundation"

    def _publish_replace_target(slot: int):
        sculpt["quick_replace_slot"] = int(slot)
        if on_state_changed is not None:
            on_state_changed({"quick_replace_slot": int(slot)})

    def _clear_replace_target():
        try:
            current = int(sculpt.get("quick_replace_slot", -1))
        except Exception:
            current = -1
        if current != -1:
            sculpt["quick_replace_slot"] = -1
            if on_state_changed is not None:
                on_state_changed({"quick_replace_slot": -1})

    def _open_targeted_library(slot: int, anchor):
        _publish_replace_target(slot)
        anchor = dict(anchor or {})
        surface_state["sculpt_brush_library_anchor"] = anchor
        if on_open_brush_library is not None:
            on_open_brush_library(anchor)
        else:
            try:
                imgui.open_popup(brush_popup)
            except Exception:
                pass

    def _activate_library_product(identity: str):
        identity = str(identity or "")
        try:
            target_slot = int(sculpt.get("quick_replace_slot", -1))
        except Exception:
            target_slot = -1

        if target_slot >= 0 and on_assign_library_asset_to_slot is not None:
            # Embedded targeted replacement is an explicit product transaction:
            # the UI knows both the selected Brush and the exact target Slot, so
            # assign them directly instead of asking Runtime to infer intent from
            # a transient cross-frame flag. Assignment is state-only; native
            # Blender Brush activation remains deferred by library_activate.
            on_assign_library_asset_to_slot(identity, target_slot)
            _clear_replace_target()
            if on_activate_library_asset is not None:
                on_activate_library_asset(identity)
        else:
            # Fallback keeps legacy/Satellite-compatible behavior when a host
            # does not provide the explicit assignment callback.
            if on_activate_library_asset is not None:
                on_activate_library_asset(identity)
            if target_slot >= 0:
                _clear_replace_target()

        if target_slot >= 0 and not satellite:
            try:
                imgui.close_current_popup()
            except Exception:
                pass

    def _more_clicked():
        anchor = _foundation._item_anchor(imgui, scale)
        surface_state["sculpt_more_anchor"] = dict(anchor)
        if satellite:
            if on_more is not None:
                on_more()
            return
        try:
            if imgui.is_popup_open(more_popup):
                surface_state["sculpt_more_popup_close_requested"] = True
            else:
                imgui.open_popup(more_popup)
        except Exception:
            imgui.open_popup(more_popup)
        if on_more is not None:
            on_more()

    _warm_quick_brush_previews(
        sculpt,
        surface_state,
        on_refresh_brush_library=on_refresh_brush_library,
        on_request_brush_preview=on_request_brush_preview,
    )

    original_host_switch = _foundation._host_switch_button
    original_quick_widget = _foundation._quick_slot_widget
    original_slot_preview = _foundation._slot_preview
    original_button = _foundation.button
    original_muted = _foundation.muted
    product_id, _product_title, _product_message = _foundation._workspace_product(blender_workspace, blender_mode)
    brush_library_original, alpha_library_original = _prepare_visual_caches(sculpt)

    def _host_switch_with_profile(imgui_arg, scale_arg, host_label_arg, on_toggle_host_arg):
        if product_id == "sculpt":
            try:
                host_x = float(imgui_arg.get_cursor_pos_x())
                _draw_input_profile_switch(
                    imgui_arg, sculpt, scale_arg, blender_mode,
                    host_x=host_x, on_state_changed=on_state_changed,
                )
                imgui_arg.same_line(spacing=px(5.0, scale_arg))
                imgui_arg.set_cursor_pos_x(host_x)
            except Exception:
                pass
        return original_host_switch(imgui_arg, scale_arg, host_label_arg, on_toggle_host_arg)

    def _quick_widget(imgui_arg, label, ident, scale_arg, width_px, selected, empty, tex_id=0):
        clicked = _visual_quick_slot_widget(
            imgui_arg, sculpt, label, ident, scale_arg, width_px, selected, empty, tex_id,
        )
        if not clicked or bool(empty):
            return bool(clicked)
        try:
            rmax = imgui_arg.get_item_rect_max()
            mouse = imgui_arg.get_mouse_pos()
            name_top = float(rmax[1]) - px(15.0, scale_arg)
            clicked_preview = float(mouse[1]) < name_top
        except Exception:
            clicked_preview = True
        if clicked_preview:
            _open_targeted_library(int(ident), _foundation._item_anchor(imgui_arg, scale_arg))
            return False
        return True

    def _button_product(imgui_arg, label, scale_arg=1.0, width=0.0, **kwargs):
        text_label = str(label or "")
        if text_label == "笔刷库":
            clicked = original_button(imgui_arg, label, scale_arg, width, **kwargs)
            if clicked:
                _clear_replace_target()
            return clicked
        if text_label == "清空槽位":
            menu_index = int(surface_state.get("sculpt_slot_menu_index", -1))
            if menu_index >= 0:
                if original_button(
                    imgui_arg, "编辑快捷键", scale_arg, width,
                    selected=False,
                    disabled=bool(kwargs.get("disabled", False)),
                    kind=str(kwargs.get("kind", "small")),
                    height=kwargs.get("height"),
                ):
                    _prepare_shortcut_editor(surface_state, sculpt, menu_index)
                    try:
                        imgui_arg.close_current_popup()
                    except Exception:
                        pass
            return original_button(imgui_arg, label, scale_arg, width, **kwargs)
        return original_button(imgui_arg, label, scale_arg, width, **kwargs)

    def _muted_product(imgui_arg, value, scale_arg=1.0):
        value_text = str(value or "")
        if value_text.startswith("Blender 模式：") and "Host：" in value_text:
            return None
        return original_muted(imgui_arg, value, scale_arg)

    def _slot_preview_with_primary(_ignored_state, slot):
        return _preview_for_slot(sculpt, slot)

    _foundation._host_switch_button = _host_switch_with_profile
    _foundation._quick_slot_widget = _quick_widget
    _foundation._slot_preview = _slot_preview_with_primary
    _foundation.button = _button_product
    _foundation.muted = _muted_product
    try:
        _foundation.draw_sculpt_compact(
            imgui, surface_state, sculpt, scale,
            available=available,
            unavailable_reason=unavailable_reason,
            blender_mode=blender_mode,
            blender_workspace=blender_workspace,
            host_label=host_label,
            can_enter_sculpt=can_enter_sculpt,
            on_enter_sculpt=on_enter_sculpt,
            on_state_changed=on_state_changed,
            on_notice=on_notice,
            on_more=_more_clicked,
            on_assign_current_to_slot=on_assign_current_to_slot,
            on_clear_slot=on_clear_slot,
            on_reset_slots=on_reset_slots,
            on_set_quick_rows=on_set_quick_rows,
            on_refresh_brush_library=on_refresh_brush_library,
            on_activate_library_asset=_activate_library_product,
            on_toggle_brush_favorite=on_toggle_brush_favorite,
            on_assign_library_asset_to_slot=on_assign_library_asset_to_slot,
            on_request_brush_preview=on_request_brush_preview,
            on_open_brush_library=on_open_brush_library,
            on_open_alpha_library=on_open_alpha_library,
            on_refresh_alpha_library=on_refresh_alpha_library,
            on_activate_alpha_asset=on_activate_alpha_asset,
            on_toggle_alpha_favorite=on_toggle_alpha_favorite,
            on_request_alpha_preview=on_request_alpha_preview,
            on_import_alpha_files=on_import_alpha_files,
            on_toggle_host=on_toggle_host,
            resolve_preview_texture=resolve_preview_texture,
        )
    finally:
        _foundation._host_switch_button = original_host_switch
        _foundation._quick_slot_widget = original_quick_widget
        _foundation._slot_preview = original_slot_preview
        _foundation.button = original_button
        _foundation.muted = original_muted
        if brush_library_original is None:
            sculpt.pop("brush_library_preview_cache", None)
        else:
            sculpt["brush_library_preview_cache"] = brush_library_original
        if alpha_library_original is None:
            sculpt.pop("alpha_library_preview_cache", None)
        else:
            sculpt["alpha_library_preview_cache"] = alpha_library_original

    _draw_shortcut_editor(imgui, surface_state, sculpt, scale, on_state_changed)

    if not satellite:
        anchor = dict(surface_state.get("sculpt_more_anchor") or {})
        try:
            sw, sh = _foundation.secondary_surface_design_size("more")
            imgui.set_next_window_size((px(sw, scale), px(sh, scale)), imgui.Cond.ALWAYS)
            if anchor:
                imgui.set_next_window_pos(
                    (float(anchor.get("x", 0.0)), float(anchor.get("y", 0.0))),
                    imgui.Cond.APPEARING,
                )
        except Exception:
            pass

        if imgui.begin_popup(more_popup):
            if bool(surface_state.pop("sculpt_more_popup_close_requested", False)):
                try:
                    imgui.close_current_popup()
                except Exception:
                    pass
            else:
                draw_more_foundation(
                    imgui, sculpt, scale,
                    on_set_quick_rows=on_set_quick_rows,
                    on_reset_quick_slots=on_reset_slots,
                    on_refresh_brush_library=on_refresh_brush_library,
                    on_refresh_alpha_library=on_refresh_alpha_library,
                    on_import_alpha_files=on_import_alpha_files,
                )
            imgui.end_popup()

    popup_names = (
        brush_popup,
        alpha_popup,
        more_popup,
        "Quick Brush Slot##context",
        "编辑快捷键##quick_shortcut_product",
    )
    any_popup = False
    for popup_name in popup_names:
        try:
            if imgui.is_popup_open(popup_name):
                any_popup = True
                break
        except Exception:
            continue
    surface_state["_secondary_surface_open"] = bool(any_popup)
