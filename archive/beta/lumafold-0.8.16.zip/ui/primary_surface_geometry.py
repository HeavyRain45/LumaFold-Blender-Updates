from __future__ import annotations

"""Single geometry authority for the Sculpt Primary Surface.

Embedded and Satellite render the same Primary View.  Hosts may translate this
pure design-unit contract to their own coordinate space, but must not invent
row deltas, measure an already-visible frame and compensate afterwards, or
maintain a second geometry model.
"""

from dataclasses import dataclass

from .layout_system import PRIMARY, SCULPT_PRIMARY

QUICK_COLUMNS = 4
MIN_QUICK_ROWS = 2
MAX_QUICK_ROWS = 4


@dataclass(frozen=True)
class PrimarySurfaceGeometry:
    width_design: float
    height_design: float
    rows: int
    quick_tile_design: float
    row_pitch_design: float


def clamp_quick_rows(rows: int) -> int:
    return max(MIN_QUICK_ROWS, min(MAX_QUICK_ROWS, int(rows)))


def quick_tile_design(width_design: float) -> float:
    content_w = max(
        float(SCULPT_PRIMARY.min_content_w),
        float(width_design) - float(PRIMARY.outer_padding) * 2.0,
    )
    gaps = float(SCULPT_PRIMARY.grid_gap) * float(QUICK_COLUMNS - 1)
    return max(
        float(SCULPT_PRIMARY.quick_tile_min),
        (content_w - gaps) / float(QUICK_COLUMNS),
    )


def quick_row_pitch_design(width_design: float) -> float:
    return quick_tile_design(width_design) + float(SCULPT_PRIMARY.grid_gap)


def normalize_base_height_design(
    measured_height_design: float,
    *,
    rows: int,
    width_design: float,
) -> float:
    """Normalize one valid Primary measurement to the canonical 2-row base."""
    row_count = clamp_quick_rows(rows)
    extra = float(row_count - MIN_QUICK_ROWS) * quick_row_pitch_design(width_design)
    return max(1.0, float(measured_height_design) - extra)


def primary_surface_geometry(
    *,
    width_design: float,
    base_height_design: float,
    rows: int,
) -> PrimarySurfaceGeometry:
    row_count = clamp_quick_rows(rows)
    pitch = quick_row_pitch_design(width_design)
    return PrimarySurfaceGeometry(
        width_design=float(width_design),
        height_design=float(base_height_design) + float(row_count - MIN_QUICK_ROWS) * pitch,
        rows=row_count,
        quick_tile_design=quick_tile_design(width_design),
        row_pitch_design=pitch,
    )
