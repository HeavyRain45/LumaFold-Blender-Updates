from __future__ import annotations

"""Stable popup lifetime bridge for Embedded/Satellite Sculpt surfaces.

Dear ImGui owns the actual popup stack.  The Blender-side input router only
needs one coarse fact: whether a product popup is currently open.  Keep that
fact in the shared surface_state after every draw so outside-click / Escape
routing never depends on historical module names or stale capture flags.
"""

from . import sculpt_view_foundation as foundation

_INSTALLED = False
_ORIGINAL_DRAW = None

_POPUPS = (
    "Quick Brush Slot##context",
    "编辑快捷键##quick_shortcut_product",
    "LumaFold Brush Library##foundation",
    "LumaFold Alpha Library##foundation",
    "Brush Asset##library_context",
    "Alpha Asset##library_context",
)


def _any_popup_open(imgui) -> bool:
    for name in _POPUPS:
        try:
            if bool(imgui.is_popup_open(name)):
                return True
        except Exception:
            continue
    return False


def install():
    global _INSTALLED, _ORIGINAL_DRAW
    if _INSTALLED:
        return
    original = getattr(foundation, "draw_sculpt_compact", None)
    if not callable(original):
        return
    _ORIGINAL_DRAW = original

    def draw_with_popup_state(imgui, surface_state, sculpt, scale, **kwargs):
        try:
            return _ORIGINAL_DRAW(imgui, surface_state, sculpt, scale, **kwargs)
        finally:
            try:
                surface_state["_secondary_surface_open"] = _any_popup_open(imgui)
            except Exception:
                pass

    foundation.draw_sculpt_compact = draw_with_popup_state
    _INSTALLED = True


def uninstall():
    global _INSTALLED, _ORIGINAL_DRAW
    if not _INSTALLED:
        return
    if callable(_ORIGINAL_DRAW):
        foundation.draw_sculpt_compact = _ORIGINAL_DRAW
    _ORIGINAL_DRAW = None
    _INSTALLED = False
