import bpy
import json
from pathlib import Path
from . import theme as T
from .components import button, compact_value_row, muted, property_slider, section, segmented, text, thumbnail_button
from .design import px
from .fonts import get_font_info
from .icons import get_icon_info, icon, icon_button
from .sculpt_view import draw_sculpt_compact as draw_shared_sculpt_compact
from ..modules.sculpt import sync_brush_state, sync_alpha_state


SCALE_PRESETS = (1.00, 1.25, 1.50, 2.00)


from ..core.app import APP
from ..core.state import STATE

def _scale_selector(imgui, state, scale):
    text(imgui, "UI scale", scale, kind="small", color=T.TEXT_SECONDARY)
    imgui.same_line()
    current = float(state.setdefault("ui_scale", 1.25))
    for i, preset in enumerate(SCALE_PRESETS):
        if i:
            imgui.same_line()
        label = f"{int(preset * 100)}%##scale{i}"
        if button(imgui, label, scale, 58.0, selected=abs(current - preset) < 0.001):
            state["ui_scale"] = preset
            state["requested_scale"] = preset


def _font_gate(imgui, state, scale):
    info = state.get("font_info") or get_font_info()
    section(imgui, "Font + CJK gate", "Blender font first · local Windows fallback · no bundled font files", scale)
    muted(imgui, f"Base: {info.get('base', 'unknown')}   CJK: {info.get('cjk', 'none')}", scale)
    if info.get("error"):
        text(imgui, str(info["error"]), scale, kind="small", color=T.TEXT_SECONDARY)
    text(imgui, "English  AaBbCc  0123456789  0.025 m  5200 K", scale)
    text(imgui, "中文显示  雕刻 · 建模 · 材质 · 灯光 · 渲染 · 资产", scale)
    text(imgui, "Mixed  LumaFold 灯光 Light  ·  Render 渲染  ·  125%", scale)

    imgui.spacing()
    text(imgui, "Native IME composition/result probe", scale, kind="small", color=T.TEXT_SECONDARY)
    imgui.set_next_item_width(-1.0)
    changed, value = imgui.input_text("##cjk_input", state.setdefault("cjk_input", ""), 256)
    if changed:
        state["cjk_input"] = value
    # Store the active InputText rectangle in region-local, top-left coordinates.
    # UIHost converts this to the Blender HWND client coordinate system.
    rmin = imgui.get_item_rect_min()
    rmax = imgui.get_item_rect_max()
    state["ime_input_active"] = bool(imgui.is_item_active())
    state["ime_anchor"] = (float(rmin[0]), float(rmin[1]), float(rmax[1] - rmin[1]))
    info = state.get("ime_info") or {}
    status = "ACTIVE" if info.get("associated") else ("READY" if info.get("available") else "UNAVAILABLE")
    hook = "HOOKED" if info.get("hook_installed") else "idle"
    muted(imgui, f"IME: {status} / {hook}  HWND: {info.get('hwnd', 0)}  candidate updates: {info.get('position_updates', 0)}", scale)
    if info.get("error"):
        muted(imgui, f"IME bridge: {info.get('error')}", scale)
    events = " · ".join(state.get("ime_events", [])[-4:]) or "none yet"
    chars = "".join(state.get("ime_unicode", [])[-10:]) or "none yet"
    native_results = " · ".join(state.get("ime_results", [])[-3:]) or "none yet"
    composition = info.get("composition_text") or "none"
    muted(imgui, f"Native composition: {composition}", scale)
    muted(imgui, f"Native committed result: {native_results}", scale)
    muted(imgui, f"IME messages/results: {info.get('ime_message_count', 0)} / {info.get('result_count', 0)}", scale)
    muted(imgui, f"Blender IME events: {events}   unicode fallback: {chars}", scale)
    muted(imgui, "Click the field, switch to Chinese IME, type pinyin and choose a candidate. The committed Chinese should enter this field.", scale)



def _icon_gate(imgui, state, scale):
    info = state.get("icon_info") or get_icon_info()
    section(imgui, "Icon system", "One shared anti-aliased atlas · no per-module GPU line drawing", scale)
    muted(imgui, f"Atlas: {info.get('atlas', 'pending')}   Cell: {info.get('cell', 0)} px   Icons: {info.get('count', 0)}", scale)

    # Visual calibration: the same source artwork at multiple integer sizes.
    for j, size in enumerate((16.0, 20.0, 24.0)):
        if j:
            imgui.same_line()
        icon(imgui, "search", scale, size)
        imgui.same_line()
        icon(imgui, "box", scale, size)
        imgui.same_line()
        icon(imgui, "light", scale, size)
        imgui.same_line()
        icon(imgui, "image", scale, size)
        if j != 2:
            imgui.same_line(spacing=px(18.0, scale))

    imgui.spacing()
    selected = int(state.setdefault("icon_selected", 0))
    names = ("cursor", "move", "rotate", "search", "plus", "pin", "panel", "play")
    for i, name in enumerate(names):
        if i:
            imgui.same_line()
        if icon_button(imgui, name, f"gallery_{name}", scale, 18.0, selected=(selected == i), tooltip=name.title()):
            state["icon_selected"] = i
    muted(imgui, "Vector artwork is rasterized once into the atlas; modules only request icon tokens.", scale)

def _draw_foundation(imgui, state, scale):
    section(imgui, "Host migration gate", "Embedded → adaptive satellite app shell · shared transferable state", scale)
    mode = str(state.get("host_mode", "embedded")).upper()
    muted(imgui, f"Current host: {mode}   Window ptr: {state.get('host_window_pointer', 0)}", scale)
    if mode == "SATELLITE":
        text(imgui, "This LumaFold surface owns a adaptive LumaFold app shell inside a separate OS top-level window.", scale, kind="small")
        muted(imgui, "LumaFold now owns the full region with a responsive app layout. Resize it or move it to another monitor; close it to return.", scale)
    else:
        muted(imgui, "Use the N-panel button: Open Adaptive Satellite. State such as scale, sliders and text is transferred.", scale)
    imgui.spacing()
    _font_gate(imgui, state, scale)
    imgui.spacing()
    _icon_gate(imgui, state, scale)
    imgui.spacing()
    section(imgui, "Typography", "Dynamic size hierarchy · pixel-snapped · module-independent", scale)
    text(imgui, "Primary text  ·  0123456789  ·  0.025 m", scale)
    text(imgui, "Section / Tool Name · LumaFold", scale, kind="section")
    muted(imgui, "Secondary text  ·  ALT + 1  ·  Ctrl + Shift", scale)

    imgui.spacing()
    section(imgui, "Controls", "Shared tokens: Sculpt / Model / Light / Render", scale)
    if button(imgui, "Normal", scale, 118.0):
        state["last_action"] = "Normal"
    imgui.same_line()
    if button(imgui, "Selected", scale, 118.0, selected=True):
        state["last_action"] = "Selected"
    imgui.same_line()
    button(imgui, "Disabled", scale, 118.0, disabled=True)

    state["segment"] = segmented(imgui, ["Union", "Difference", "Intersect"], state.setdefault("segment", 0), scale)
    state["strength"] = property_slider(imgui, "Strength", state.setdefault("strength", 0.42), 0.0, 1.0, scale, "%.2f")

    text(imgui, "Solver", scale, kind="small", color=T.TEXT_SECONDARY)
    imgui.set_next_item_width(-1.0)
    changed, solver = imgui.combo("##solver", state.setdefault("solver", 0), ["Exact", "Fast"])
    if changed:
        state["solver"] = solver

    imgui.spacing()
    section(imgui, "Thumbnail grid", "Placeholder rhythm for Brush / Alpha / Asset browsers", scale)
    avail = imgui.get_content_region_avail()[0]
    target = max(px(82.0, scale), min(px(98.0, scale), (avail - px(24.0, scale)) / 4.0))
    width_design = target / scale
    for i in range(8):
        if i % 4:
            imgui.same_line()
        if thumbnail_button(imgui, "Brush", i + 1, state.get("thumb") == i, scale, width_design):
            state["thumb"] = i


def _draw_hud_preview(imgui, state, scale):
    section(imgui, "HUD language", "Compact surfaces use the same font, typography and controls", scale)
    compact_value_row(imgui, "WIDTH", f"{state.setdefault('bevel', 0.025):.3f} m", scale)
    state["bevel"] = property_slider(imgui, "", state["bevel"], 0.0, 0.100, scale, "%.3f")
    compact_value_row(imgui, "SEGMENTS", str(state.setdefault("segments", 3)), scale)
    changed, segments = imgui.slider_int("##segments", state["segments"], 1, 12)
    if changed:
        state["segments"] = segments
    state["hud_mode"] = segmented(imgui, ["Angle", "Weight", "Clamp"], state.setdefault("hud_mode", 0), scale, 88.0)
    muted(imgui, "建模 HUD / Modeling HUD", scale)


def _draw_stress(imgui, state, scale):
    section(imgui, "Interaction gate", "Keep this window open while using Blender outside it", scale)
    muted(imgui, "Outside LumaFold: orbit / pan / wheel / G R S / Edit Mode / Sculpt stroke", scale)
    muted(imgui, "Inside LumaFold: drag windows / scroll / sliders / popup / keyboard focus", scale)
    imgui.spacing()
    state["stress"] = property_slider(imgui, "Continuous drag", state.setdefault("stress", 0.50), 0.0, 1.0, scale, "%.2f")
    if button(imgui, "Open context popup", scale, 170.0):
        imgui.open_popup("LumaFold P0.8 Popup")
    if imgui.begin_popup("LumaFold P0.8 Popup"):
        text(imgui, "Context surface / 上下文", scale, kind="section")
        imgui.separator()
        imgui.menu_item("Replace")
        imgui.menu_item("Clear")
        imgui.menu_item("Pin")
        imgui.end_popup()


def _draw_core(imgui, state, scale):
    core = APP.state
    section(imgui, "Shared Core", "Host-independent State + Command bus · Core Alpha A0.3", scale)
    muted(imgui, "This data lives outside UIHost and must survive Embedded → Satellite migration.", scale)
    imgui.spacing()

    compact_value_row(imgui, "SHARED COUNTER", str(core.shared_counter), scale)
    if button(imgui, "+1 via Command", scale, 150.0, selected=True):
        APP.execute("core.counter.increment", amount=1)
    imgui.same_line()
    if button(imgui, "Reset", scale, 90.0):
        APP.execute("core.counter.reset")

    imgui.spacing()
    core.shared_value = property_slider(imgui, "Shared value", core.shared_value, 0.0, 1.0, scale, "%.2f")
    changed, enabled = imgui.checkbox("Shared enabled##core", bool(core.shared_enabled))
    if changed:
        core.shared_enabled = bool(enabled)
        core.log(f"shared_enabled = {core.shared_enabled}")

    imgui.spacing()
    section(imgui, "Blender command probe", "UI calls named commands; Blender implementation stays behind Core", scale)
    if button(imgui, "Nudge active X +0.10", scale, 190.0):
        APP.execute("blender.object.nudge_x", delta=0.10)
    imgui.same_line()
    if button(imgui, "Rename active", scale, 150.0):
        APP.execute("blender.object.rename_active", name="LumaFold_Object")

    status_color = T.SELECTED if core.last_command_ok else T.DANGER
    text(imgui, f"Last: {core.last_command}", scale, kind="small", color=status_color)
    muted(imgui, core.last_command_message or "No command yet", scale)
    muted(imgui, f"Executed commands: {core.command_count}", scale)

    imgui.spacing()
    section(imgui, "Host abstraction", "Same Core, different surfaces", scale)
    current = str(state.get("host_mode", "embedded"))
    for spec in APP.hosts.all():
        suffix = " · CURRENT" if spec.host_id == current else ""
        label = f"{spec.label}{suffix}"
        text(imgui, label, scale, kind="small", color=T.TEXT_PRIMARY if spec.host_id == current else T.TEXT_SECONDARY)
        caps = []
        if spec.embedded:
            caps.append("embedded")
        if spec.detachable:
            caps.append("detach")
        if spec.desktop_like:
            caps.append("desktop-like")
        caps.append("shared-process" if spec.shared_process else "bridge")
        muted(imgui, " / ".join(caps), scale)

    if core.event_log:
        imgui.spacing()
        section(imgui, "Core event tail", None, scale)
        for entry in core.event_log[-5:]:
            muted(imgui, entry, scale)




def _workspace_header(imgui, title, subtitle, context, status, scale):
    color = T.SELECTED if status.active else T.TEXT_SECONDARY
    text(imgui, title, scale, kind="title")
    muted(imgui, subtitle, scale)
    imgui.spacing()
    text(imgui, f"{context.mode}  ·  {context.active_object_name or 'No active object'}  ·  {context.active_object_type or '-'}", scale, kind="small", color=T.TEXT_SECONDARY)
    text(imgui, "[ READY ]" if status.active else "[ UNAVAILABLE ]", scale, kind="section", color=(T.SELECTED if status.active else T.DANGER))
    if not status.active:
        text(imgui, status.reason, scale, kind="small", color=T.DANGER)
    imgui.separator()
    imgui.spacing()


def _sculpt_product_state():
    return APP.store.namespace("sculpt", {
        "quick_slot": 0,
        "brush_size": 72.0,
        "brush_strength": 0.50,
        "alpha_slot": 0,
        "embedded_preset": "compact",
        "satellite_preset": "compact",
    })


def _load_sculpt_view_spec():
    path = Path(__file__).resolve().parent.parent / "assets" / "sculpt_view_v1.json"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if int(data.get("schema_version", 0)) != 1:
            raise ValueError("unsupported sculpt view schema")
        return data
    except Exception:
        return {
            "schema_version": 1, "title": "LumaFold Sculpt", "preset": "Compact",
            "design_width": 264, "design_height": 338,
            "brushes": ["Draw", "Clay", "Crease", "Smooth", "Inflate", "Grab", "Scrape", "Mask"],
            "alphas": ["Round", "Clay", "Noise", "Dots", "Scratches", "Skin"],
            "labels": {},
        }

_SCULPT_VIEW_SPEC = _load_sculpt_view_spec()
_SCULPT_BRUSHES = tuple(_SCULPT_VIEW_SPEC.get("brushes") or ())
_SCULPT_ALPHAS = tuple(_SCULPT_VIEW_SPEC.get("alphas") or ())


def _compact_slider_row(imgui, label, value, minimum, maximum, scale, fmt):
    text(imgui, label, scale, kind="small", color=T.TEXT_SECONDARY)
    imgui.same_line()
    imgui.set_next_item_width(px(205.0, scale))
    changed, new_value = imgui.slider_float(f"##sculpt_{label}", float(value), float(minimum), float(maximum), fmt)
    return float(new_value) if changed else float(value)


def _draw_sculpt_compact(imgui, state, scale, context, status, sculpt):
    """Embedded product surface: high-frequency controls with a strict obstruction budget."""
    current = int(sculpt.get("quick_slot", 0)) % len(_SCULPT_BRUSHES)
    alpha = int(sculpt.get("alpha_slot", 0)) % len(_SCULPT_ALPHAS)

    # One compact header row instead of the engineering workspace header.
    text(imgui, "LumaFold Sculpt", scale, kind="section")
    imgui.same_line()
    muted(imgui, "紧凑预设 Compact", scale)
    if not status.active:
        text(imgui, "当前上下文不可用", scale, kind="small", color=T.DANGER)
        muted(imgui, status.reason, scale)
        if status.enabled and context.mode != "SCULPT":
            if button(imgui, "进入雕刻模式", scale, 132.0, selected=True):
                APP.execute("sculpt.enter")
                APP.refresh_context(host_id="embedded")
        return

    # Current brush + current alpha stay in the same high-frequency surface.
    text(imgui, "当前", scale, kind="small", color=T.TEXT_SECONDARY)
    imgui.same_line()
    if button(imgui, f"{_SCULPT_BRUSHES[current]}  ·  Alpha {_SCULPT_ALPHAS[alpha]}##current_pair", scale, 246.0, selected=True):
        pass

    sculpt["brush_size"] = _compact_slider_row(
        imgui, "大小 Size", sculpt.get("brush_size", 72.0), 1.0, 300.0, scale, "%.0f px"
    )
    sculpt["brush_strength"] = _compact_slider_row(
        imgui, "强度 Strength", sculpt.get("brush_strength", 0.50), 0.0, 1.0, scale, "%.2f"
    )

    imgui.separator()
    text(imgui, "快捷笔刷", scale, kind="small", color=T.TEXT_SECONDARY)
    avail = max(px(300.0, scale), imgui.get_content_region_avail()[0])
    slot_w = max(px(66.0, scale), (avail - px(21.0, scale)) / 4.0)
    for i, label in enumerate(_SCULPT_BRUSHES):
        if i % 4:
            imgui.same_line()
        if button(imgui, f"{label}##compact_brush_{i}", scale, slot_w / scale, selected=(i == current)):
            sculpt["quick_slot"] = i
            APP.events.emit("sculpt.quick_slot.changed", {"slot": i, "label": label})

    imgui.spacing()
    text(imgui, "Alpha", scale, kind="small", color=T.TEXT_SECONDARY)
    alpha_w = max(px(44.0, scale), (avail - px(35.0, scale)) / 6.0)
    for i, label in enumerate(_SCULPT_ALPHAS):
        if i:
            imgui.same_line()
        if button(imgui, f"{i+1}##compact_alpha_{i}", scale, alpha_w / scale, selected=(i == alpha)):
            sculpt["alpha_slot"] = i

    imgui.separator()
    if button(imgui, "笔刷库", scale, 92.0):
        state["sculpt_product_notice"] = "笔刷库：S0.2 接入 Blender 原生 Brush Assets"
    imgui.same_line()
    if button(imgui, "Alpha 库", scale, 92.0):
        state["sculpt_product_notice"] = "Alpha 库：S0.2 接入真实 Alpha 资源"
    imgui.same_line()
    if button(imgui, "更多", scale, 72.0):
        state["page"] = 4
    if state.get("sculpt_product_notice"):
        muted(imgui, str(state["sculpt_product_notice"]), scale)


def _product_tile(imgui, label, suffix, selected, scale, width, height=50.0):
    if selected:
        imgui.push_style_color(imgui.Col.BUTTON, T.SELECTED_SOFT)
        imgui.push_style_color(imgui.Col.BUTTON_HOVERED, T.SELECTED_HOVER)
        imgui.push_style_color(imgui.Col.BUTTON_ACTIVE, T.SELECTED)
    try:
        return imgui.button(f"{label}\n{suffix}", (px(width, scale), px(height, scale)))
    finally:
        if selected:
            imgui.pop_style_color(3)


def _draw_sculpt_expanded(imgui, state, scale, context, status, sculpt):
    """Satellite product surface: same state, more room for management on a second screen."""
    current = int(sculpt.get("quick_slot", 0)) % len(_SCULPT_BRUSHES)
    alpha = int(sculpt.get("alpha_slot", 0)) % len(_SCULPT_ALPHAS)

    text(imgui, "雕刻工作台 / Sculpt Workspace", scale, kind="title")
    muted(imgui, "展开预设 Expanded · 副屏常驻 · 与 Blender 内嵌界面共享同一状态", scale)
    if not status.active:
        text(imgui, "[ 当前上下文不可用 ]", scale, kind="section", color=T.DANGER)
        muted(imgui, status.reason, scale)
        return

    # Compact current-state band. Brush and Alpha are intentionally one surface.
    imgui.push_style_color(imgui.Col.CHILD_BG, T.SURFACE_1)
    try:
        if imgui.begin_child("##sculpt_current_band", (0.0, px(118.0, scale))):
            text(imgui, f"当前笔刷  {_SCULPT_BRUSHES[current]}", scale, kind="section", color=T.SELECTED)
            imgui.same_line()
            text(imgui, f"当前 Alpha  {_SCULPT_ALPHAS[alpha]}", scale, kind="section")
            sculpt["brush_size"] = property_slider(
                imgui, "大小 Size", float(sculpt.get("brush_size", 72.0)), 1.0, 300.0, scale, "%.0f px"
            )
            sculpt["brush_strength"] = property_slider(
                imgui, "强度 Strength", float(sculpt.get("brush_strength", 0.50)), 0.0, 1.0, scale, "%.2f"
            )
        imgui.end_child()
    finally:
        imgui.pop_style_color()

    imgui.spacing()
    section(imgui, "快捷笔刷 / Quick Brush", "8 个高频槽位 · 与内嵌预设完全同步", scale)
    avail = imgui.get_content_region_avail()[0]
    tile_w = max(88.0, (avail / scale - 24.0) / 4.0)
    for i, label in enumerate(_SCULPT_BRUSHES):
        if i % 4:
            imgui.same_line()
        if _product_tile(imgui, label, f"Slot {i+1}", i == current, scale, tile_w):
            sculpt["quick_slot"] = i
            APP.events.emit("sculpt.quick_slot.changed", {"slot": i, "label": label})

    imgui.spacing()
    section(imgui, "Alpha", "同界面高频 Alpha 槽位 · 后续接入真实资源缩略图", scale)
    alpha_w = max(76.0, (avail / scale - 35.0) / 6.0)
    for i, label in enumerate(_SCULPT_ALPHAS):
        if i:
            imgui.same_line()
        if _product_tile(imgui, label, f"A{i+1}", i == alpha, scale, alpha_w, 44.0):
            sculpt["alpha_slot"] = i

    imgui.spacing()
    if button(imgui, "打开笔刷库", scale, 150.0):
        state["sculpt_product_notice"] = "笔刷库将在 S0.2 接入 Blender 原生 Brush Assets"
    imgui.same_line()
    if button(imgui, "打开 Alpha 库", scale, 150.0):
        state["sculpt_product_notice"] = "Alpha 库将在 S0.2 接入真实 Alpha 资源"
    imgui.same_line()
    if button(imgui, "布局预设", scale, 120.0):
        state["sculpt_product_notice"] = "当前官方预设：Embedded / Satellite 均为 Compact 同尺寸"
    if state.get("sculpt_product_notice"):
        muted(imgui, str(state["sculpt_product_notice"]), scale)


def _draw_sculpt_workspace(imgui, state, scale):
    host_id = str(state.get("host_mode", "embedded"))
    context, _ = APP.refresh_context(host_id=host_id)
    try:
        workspace_name = str(getattr(getattr(bpy.context.window, "workspace", None), "name", "") or "")
    except Exception:
        workspace_name = str(state.get("blender_workspace") or "")
    state["blender_workspace"] = workspace_name
    status = APP.modules.status("sculpt")
    sculpt = _sculpt_product_state()
    sync_brush_state(APP)
    sync_alpha_state(APP)

    def _enter_sculpt():
        APP.execute("sculpt.enter")
        APP.refresh_context(host_id=host_id)

    def _state_changed(fields):
        if "quick_slot" in fields:
            slot = int(fields["quick_slot"])
            result = APP.execute("sculpt.brush.activate_slot", slot=slot)
            if not result.ok:
                state["sculpt_product_notice"] = "笔刷切换失败：" + str(result.message)
            else:
                state["sculpt_product_notice"] = str(result.message)
            sync_brush_state(APP)
        APP.events.emit("sculpt.state.changed", {"fields": dict(fields), "source": host_id})

    def _slot_command(command_id, *, slot=None):
        kwargs = {} if slot is None else {"slot": int(slot)}
        result = APP.execute(command_id, **kwargs)
        state["sculpt_product_notice"] = str(result.message) if result.ok else ("操作失败：" + str(result.message))
        sync_brush_state(APP)

    def _set_quick_rows(rows):
        result = APP.execute("sculpt.brush.set_quick_rows", rows=int(rows))
        state["sculpt_product_notice"] = str(result.message) if result.ok else ("布局修改失败：" + str(result.message))

    def _defer_library_command(command_id, *, pending_key, **kwargs):
        pending = state.setdefault("_brush_library_pending", {})
        if pending.get(pending_key):
            return
        pending[pending_key] = True
        def _run():
            try:
                result = APP.execute(command_id, **kwargs)
                if not result.ok:
                    state["sculpt_product_notice"] = "笔刷库操作失败：" + str(result.message)
                sync_brush_state(APP)
                sync_alpha_state(APP)
            finally:
                pending.pop(pending_key, None)
            return None
        try:
            bpy.app.timers.register(_run, first_interval=0.0)
        except Exception:
            pending.pop(pending_key, None)

    def _refresh_brush_library():
        _defer_library_command("sculpt.brush.library_refresh", pending_key="refresh")

    def _request_brush_previews(identities):
        ids = [str(item) for item in list(identities or ()) if str(item or "")]
        if not ids:
            return
        key = "preview:" + "|".join(ids)
        _defer_library_command("sculpt.brush.library_preview", pending_key=key, identities=ids)

    def _library_action(command_id, **kwargs):
        result = APP.execute(command_id, **kwargs)
        state["sculpt_product_notice"] = str(result.message) if result.ok else ("笔刷库操作失败：" + str(result.message))
        sync_brush_state(APP)
        sync_alpha_state(APP)

    def _refresh_alpha_library():
        _defer_library_command("sculpt.alpha.library_refresh", pending_key="alpha_refresh")

    def _request_alpha_previews(identities):
        ids = [str(item) for item in list(identities or ()) if str(item or "")]
        if not ids:
            return
        key = "alpha_preview:" + "|".join(ids)
        _defer_library_command("sculpt.alpha.library_preview", pending_key=key, identities=ids)

    def _alpha_action(command_id, **kwargs):
        # Alpha activation may need to switch an external Essentials brush to a
        # local editable proxy. Never mutate Blender brush/asset state inside
        # the active ImGui draw traversal; run it on the next Blender UI tick.
        action_key = "alpha_action:" + str(command_id) + ":" + str(kwargs.get("identity", ""))
        pending = state.setdefault("_alpha_library_pending", {})
        if pending.get(action_key):
            return
        pending[action_key] = True
        def _run():
            try:
                result = APP.execute(command_id, **kwargs)
                state["sculpt_product_notice"] = str(result.message) if result.ok else ("Alpha 库操作失败：" + str(result.message))
                sync_brush_state(APP)
                sync_alpha_state(APP)
            finally:
                pending.pop(action_key, None)
            return None
        try:
            bpy.app.timers.register(_run, first_interval=0.0)
        except Exception as exc:
            pending.pop(action_key, None)
            state["sculpt_product_notice"] = "Alpha 库操作失败：" + str(exc)

    def _import_alpha_files():
        # File selector must be invoked outside the ImGui draw frame.
        if bool(state.get("_alpha_import_pending", False)):
            return
        state["_alpha_import_pending"] = True
        def _run():
            try:
                bpy.ops.lumafold.import_alpha_images('INVOKE_DEFAULT')
            except Exception as exc:
                state["sculpt_product_notice"] = "Alpha 导入失败：" + str(exc)
            finally:
                state["_alpha_import_pending"] = False
            return None
        try:
            bpy.app.timers.register(_run, first_interval=0.0)
        except Exception as exc:
            state["_alpha_import_pending"] = False
            state["sculpt_product_notice"] = "Alpha 导入失败：" + str(exc)

    def _toggle_host():
        # Never launch a Blender operator from inside the ImGui draw frame.
        # Defer one tick, resolve the exact View3D that owns the embedded UIHost,
        # then execute with an explicit context override.  This also makes the
        # control independent of whichever Blender editor currently has focus.
        if bool(state.get("_host_toggle_pending", False)):
            return
        state["_host_toggle_pending"] = True

        def _deferred_host_toggle():
            try:
                host = STATE.host
                if host is None or getattr(host, "closed", False):
                    state["sculpt_product_notice"] = "卫星切换失败：浮台 Host 不可用"
                    return None
                wm = bpy.context.window_manager
                for window in tuple(wm.windows):
                    try:
                        if window.as_pointer() != host.window_pointer:
                            continue
                    except Exception:
                        continue
                    screen = getattr(window, "screen", None)
                    if screen is None:
                        continue
                    for area in screen.areas:
                        try:
                            matches = area.type == 'VIEW_3D' and area.as_pointer() == host.area_pointer
                        except Exception:
                            matches = False
                        if not matches:
                            continue
                        region = next((r for r in area.regions if r.type == 'WINDOW'), None)
                        if region is None:
                            continue
                        with bpy.context.temp_override(window=window, area=area, region=region):
                            result = bpy.ops.lumafold.move_to_satellite('EXEC_DEFAULT')
                        if 'FINISHED' not in set(result):
                            state["sculpt_product_notice"] = "卫星切换未完成：" + str(result)
                        return None
                state["sculpt_product_notice"] = "卫星切换失败：找不到浮台所属 3D View"
            except Exception as exc:
                state["sculpt_product_notice"] = "卫星切换失败：" + str(exc)
            finally:
                state["_host_toggle_pending"] = False
            return None

        try:
            bpy.app.timers.register(_deferred_host_toggle, first_interval=0.0)
        except Exception as exc:
            state["_host_toggle_pending"] = False
            state["sculpt_product_notice"] = "卫星切换失败：" + str(exc)

    draw_shared_sculpt_compact(
        imgui, state, sculpt, scale,
        available=bool(status.active),
        unavailable_reason=str(status.reason or ""),
        blender_mode=str(context.mode or ""),
        blender_workspace=str(state.get("blender_workspace") or ""),
        host_label="浮台",
        can_enter_sculpt=bool(status.enabled and context.mode != "SCULPT"),
        on_enter_sculpt=_enter_sculpt,
        on_state_changed=_state_changed,
        on_more=lambda: state.__setitem__("sculpt_product_notice", "更多：后续进入统一 Secondary Surface，不再占用主浮台。"),
        on_assign_current_to_slot=lambda slot: _slot_command("sculpt.brush.assign_current_to_slot", slot=slot),
        on_clear_slot=lambda slot: _slot_command("sculpt.brush.clear_slot", slot=slot),
        on_reset_slots=lambda: _slot_command("sculpt.brush.reset_quick_slots"),
        on_set_quick_rows=_set_quick_rows,
        on_refresh_brush_library=_refresh_brush_library,
        on_activate_library_asset=lambda identity: _library_action("sculpt.brush.library_activate", identity=str(identity)),
        on_toggle_brush_favorite=lambda identity: _library_action("sculpt.brush.library_toggle_favorite", identity=str(identity)),
        on_assign_library_asset_to_slot=lambda identity, slot: _library_action("sculpt.brush.library_assign_slot", identity=str(identity), slot=int(slot)),
        on_request_brush_preview=_request_brush_previews,
        on_refresh_alpha_library=_refresh_alpha_library,
        on_activate_alpha_asset=lambda identity: _alpha_action("sculpt.alpha.library_activate", identity=str(identity)),
        on_toggle_alpha_favorite=lambda identity: _alpha_action("sculpt.alpha.library_toggle_favorite", identity=str(identity)),
        on_request_alpha_preview=_request_alpha_previews,
        on_import_alpha_files=_import_alpha_files,
        on_toggle_host=_toggle_host,
        resolve_preview_texture=state.get("_preview_texture_resolver"),
    )

def _draw_model_workspace(imgui, state, scale):
    host_id = str(state.get("host_mode", "embedded"))
    context, _ = APP.refresh_context(host_id=host_id)
    status = APP.modules.status("model")
    model = APP.store.namespace("model", {"bevel_width": 0.02, "bevel_segments": 3})

    _workspace_header(
        imgui,
        "建模工作区 / Model",
        "上下文建模控制 · 所有命令统一经过 LumaFold Core",
        context,
        status,
        scale,
    )

    section(imgui, "倒角 / Bevel", "通过 Model 模块调用 Blender 修改器", scale)
    if status.active:
        model["bevel_width"] = property_slider(
            imgui, "Width", float(model.get("bevel_width", 0.02)), 0.0, 0.10, scale, "%.3f"
        )
        text(imgui, "Segments", scale, kind="small", color=T.TEXT_SECONDARY)
        imgui.set_next_item_width(-1.0)
        changed, segs = imgui.slider_int("##model_workspace_segments", int(model.get("bevel_segments", 3)), 1, 12)
        if changed:
            model["bevel_segments"] = int(segs)
    else:
        muted(imgui, f"Width {float(model.get('bevel_width', 0.02)):.3f} · Segments {int(model.get('bevel_segments', 3))}", scale)

    if button(imgui, "添加 / 更新倒角", scale, 185.0, selected=status.active, disabled=not status.active):
        APP.execute(
            "model.add_bevel",
            width=float(model["bevel_width"]),
            segments=int(model["bevel_segments"]),
        )
    imgui.same_line()
    if button(imgui, "X 方向移动 +0.10", scale, 145.0, disabled=not status.active):
        APP.execute("model.nudge_x", delta=0.10)

    imgui.spacing()
    section(imgui, "上下文规则", "当前模式不适用时工具会自动禁用", scale)
    muted(imgui, "Object Mode: Bevel + Transform available", scale)
    muted(imgui, "Edit Mesh: Model stays active", scale)
    muted(imgui, "Sculpt Mode: Model workspace becomes unavailable", scale)

    imgui.spacing()
    section(imgui, "模块状态", "同一状态会直接出现在卫星窗口", scale)
    compact_value_row(imgui, "BEVEL WIDTH", f"{float(model.get('bevel_width', 0.02)):.3f}", scale)
    compact_value_row(imgui, "SEGMENTS", str(int(model.get("bevel_segments", 3))), scale)
    muted(imgui, f"Lifecycle: {model.get('lifecycle', 'REGISTERED')} · Last command: {APP.state.last_command}", scale)

def _draw_light_workspace(imgui, state, scale):
    host_id = str(state.get("host_mode", "embedded"))
    context, caps = APP.refresh_context(host_id=host_id)
    status = APP.modules.status("light")
    light = APP.store.namespace("light", {"energy": 1000.0, "size": 3.0, "bound_light": ""})
    service = APP.services.require("blender.light")
    summary = service.active_summary()

    _workspace_header(
        imgui,
        "灯光工作区 / Light",
        "场景灯光控制 · 跨领域模块验证",
        context,
        status,
        scale,
    )

    section(imgui, "灯光对象 / Light", "选择现有灯光，或创建面积灯", scale)
    is_light = bool(summary)
    if is_light:
        if light.get("bound_light") != summary["name"]:
            light["bound_light"] = summary["name"]
            light["energy"] = summary["energy"]
            if summary.get("size", 0.0) > 0.0:
                light["size"] = summary["size"]
        text(imgui, f"{summary['name']}  ·  {summary['type']}", scale, kind="section", color=T.SELECTED)
        muted(imgui, "Selected Blender Light is the authoritative scene object", scale)
    else:
        text(imgui, "NO LIGHT SELECTED", scale, kind="section", color=T.DANGER)
        muted(imgui, "Light workspace stays available in Object Mode so it can create/select lights.", scale)

    if button(imgui, "使用场景第一个灯光", scale, 175.0, disabled=not status.active):
        APP.execute("light.select_first")
        APP.refresh_context(host_id=host_id)
    imgui.same_line()
    if button(imgui, "创建面积灯 Area Light", scale, 165.0, selected=not is_light, disabled=not status.active):
        APP.execute("light.create_area", energy=float(light["energy"]), size=float(light["size"]))
        APP.refresh_context(host_id=host_id)

    imgui.spacing()
    section(imgui, "面积灯参数", "参数保存在 Core，应用时由 Light Service 写入 Blender", scale)
    light["energy"] = property_slider(imgui, "Power", float(light.get("energy", 1000.0)), 0.0, 5000.0, scale, "%.0f")
    light["size"] = property_slider(imgui, "Size", float(light.get("size", 3.0)), 0.01, 10.0, scale, "%.2f")
    if button(imgui, "应用到当前灯光", scale, 210.0, selected=is_light and status.active, disabled=not (status.active and is_light)):
        APP.execute("light.apply", energy=float(light["energy"]), size=float(light["size"]))

    imgui.spacing()
    section(imgui, "上下文规则", "Light 是场景模块，不是只针对 Mesh 的模块", scale)
    muted(imgui, "Object Mode: workspace READY", scale)
    muted(imgui, "Sculpt / Edit Mesh: workspace UNAVAILABLE", scale)
    muted(imgui, "Cube selected: workspace stays READY, but light editing waits for a Light selection", scale)

    imgui.spacing()
    section(imgui, "模块状态", "暂存参数会同步显示到卫星窗口", scale)
    compact_value_row(imgui, "POWER", f"{float(light.get('energy', 1000.0)):.0f} W", scale)
    compact_value_row(imgui, "SIZE", f"{float(light.get('size', 3.0)):.2f} m", scale)
    muted(imgui, f"Lifecycle: {light.get('lifecycle', 'REGISTERED')} · Last command: {APP.state.last_command}", scale)



def _draw_render_workspace(imgui, state, scale):
    host_id = str(state.get("host_mode", "embedded"))
    context, _ = APP.refresh_context(host_id=host_id)
    status = APP.modules.status("render")
    render = APP.store.namespace("render", {
        "resolution_x": 1920,
        "resolution_y": 1080,
        "percentage": 100,
    })
    service = APP.services.require("blender.render")
    summary = service.summary()

    _workspace_header(
        imgui,
        "渲染工作区 / Render",
        "场景级输出设置 · Render 模块",
        context,
        status,
        scale,
    )

    section(imgui, "场景渲染 / Render", "Object / Edit / Sculpt 模式下都保持可用", scale)
    text(imgui, f"Engine  ·  {summary['engine']}", scale, kind="section", color=T.SELECTED)
    muted(imgui, f"Scene currently: {summary['resolution_x']} × {summary['resolution_y']}  @  {summary['percentage']}%", scale)
    if button(imgui, "从场景同步", scale, 150.0, disabled=not status.active):
        APP.execute("render.sync_from_scene")

    imgui.spacing()
    section(imgui, "分辨率 / Resolution", "参数保存在 Core，应用后写入 Blender 场景", scale)
    text(imgui, "Width", scale, kind="small", color=T.TEXT_SECONDARY)
    imgui.set_next_item_width(-1.0)
    changed, rx = imgui.slider_int("##render_width", int(render.get("resolution_x", 1920)), 320, 7680)
    if changed:
        render["resolution_x"] = int(rx)
    text(imgui, "Height", scale, kind="small", color=T.TEXT_SECONDARY)
    imgui.set_next_item_width(-1.0)
    changed, ry = imgui.slider_int("##render_height", int(render.get("resolution_y", 1080)), 240, 4320)
    if changed:
        render["resolution_y"] = int(ry)
    text(imgui, "Render Scale", scale, kind="small", color=T.TEXT_SECONDARY)
    imgui.set_next_item_width(-1.0)
    changed, pct = imgui.slider_int("##render_percentage", int(render.get("percentage", 100)), 10, 100)
    if changed:
        render["percentage"] = int(pct)

    if button(imgui, "HD 1920×1080", scale, 150.0, disabled=not status.active):
        render["resolution_x"], render["resolution_y"] = 1920, 1080
        APP.execute("render.preset_hd")
    imgui.same_line()
    if button(imgui, "4K 3840×2160", scale, 150.0, disabled=not status.active):
        render["resolution_x"], render["resolution_y"] = 3840, 2160
        APP.execute("render.preset_4k")
    imgui.spacing()
    if button(imgui, "应用渲染设置", scale, 210.0, selected=status.active, disabled=not status.active):
        APP.execute(
            "render.apply",
            resolution_x=int(render["resolution_x"]),
            resolution_y=int(render["resolution_y"]),
            percentage=int(render["percentage"]),
        )

    imgui.spacing()
    section(imgui, "上下文规则", "Render 是场景级模块，不依赖当前选中对象", scale)
    muted(imgui, "Object Mode: READY", scale)
    muted(imgui, "Edit Mesh: READY", scale)
    muted(imgui, "Sculpt Mode: READY", scale)
    muted(imgui, "No active object: READY", scale)

    imgui.spacing()
    section(imgui, "模块状态", "输出参数会同步显示到卫星窗口", scale)
    compact_value_row(imgui, "RESOLUTION", f"{int(render.get('resolution_x', 1920))} × {int(render.get('resolution_y', 1080))}", scale)
    compact_value_row(imgui, "SCALE", f"{int(render.get('percentage', 100))}%", scale)
    muted(imgui, f"Lifecycle: {render.get('lifecycle', 'REGISTERED')} · Last command: {APP.state.last_command}", scale)

def _module_loaded(module_id):
    loader = getattr(APP, "module_loader", None)
    if loader is None:
        return APP.modules.get(module_id) is not None
    record = loader.get(module_id)
    return bool(record and record.loaded and APP.modules.get(module_id) is not None)


def _workspace_nav_labels(state):
    host_id = str(state.get("host_mode", "embedded"))
    APP.refresh_context(host_id=host_id)
    labels = []
    for module_id, label in (("sculpt", "雕刻"), ("model", "建模"), ("light", "灯光"), ("render", "渲染")):
        if not _module_loaded(module_id):
            labels.append(f"{label} UNLOADED")
            continue
        status = APP.modules.status(module_id)
        # N/A means the module is loaded but the current Blender selection/mode
        # doesn't satisfy its capability rules.  This is deliberately distinct
        # from a real SDK unload.
        labels.append(label if status.active else f"{label} N/A")
    labels.extend(("平台", "核心", "视觉"))
    return labels




def _queue_module_action(state, action, module_id):
    # Never mutate registries while Dear ImGui is traversing the current frame.
    # UIHost applies this at the next frame boundary before imgui.new_frame().
    state["pending_module_action"] = (str(action), str(module_id))
    state["module_action_status"] = f"已排队执行 {action}: {module_id}"


def _queue_persistence_action(state, action):
    # Restoring state can change several module namespaces at once. Apply it at the
    # next UI frame boundary so the current ImGui traversal always sees one snapshot.
    state["pending_persistence_action"] = str(action)
    state["persistence_action_status"] = "已排队执行：" + str(action)




def _queue_freeze_action(state, action):
    # A1.0 real Blender regression changes mode/selection temporarily. Execute it
    # at the next frame boundary, never while ImGui is traversing this frame.
    state["pending_freeze_action"] = str(action)
    state["contract_action_status"] = "已排队执行：" + str(action)


def _draw_architecture_freeze(imgui, state, scale):
    manager = APP.contract
    section(imgui, "A1.0 架构冻结基线 / Frozen Architecture Baseline", "稳定契约 · 真实 Blender 回归 · SDK v1", scale)
    muted(imgui, "A1.0 已冻结模块面向 Core 的公共契约；后续产品模块在这个基线上开发，Core 内部仍可在不破坏契约的前提下优化。", scale)
    muted(imgui, "真实回归会临时创建测试 Mesh / Light、切换 Sculpt、修改渲染设置，然后自动恢复选择、模式、参数和模块状态。", scale)

    if button(imgui, "运行 A1.0 基线验证", scale, 220.0, selected=True):
        _queue_freeze_action(state, "final")
    imgui.same_line()
    if button(imgui, "运行真实 Blender 回归", scale, 210.0):
        _queue_freeze_action(state, "blender")
    if button(imgui, "运行平台回归 13 项", scale, 190.0):
        _queue_freeze_action(state, "platform")
    imgui.same_line()
    if button(imgui, "生成 SDK v1 文档", scale, 170.0):
        _queue_freeze_action(state, "freeze_docs")
    if button(imgui, "对比 A1.0 契约基线", scale, 190.0):
        _queue_freeze_action(state, "compare")
    imgui.same_line()
    if button(imgui, "保存 A1.0 契约基线", scale, 150.0):
        _queue_freeze_action(state, "save")

    text(imgui, f"SDK Contract：v1 · Core API=1 · 指纹 {manager.fingerprint()}", scale, kind="small", color=T.SELECTED)
    muted(imgui, "契约基线：" + (manager.path_display() or "不可用"), scale)
    muted(imgui, "SDK 文档：" + (manager.sdk_reference_path_display() or "不可用"), scale)

    action = state.get("contract_action_status")
    if action:
        danger = any(word in str(action) for word in ("FAIL", "失败", "DRIFT", "PENDING"))
        text(imgui, str(action), scale, kind="small", color=(T.DANGER if danger else T.SELECTED))

    ready, readiness = manager.a1_readiness()
    imgui.spacing()
    section(imgui, "A1.0 架构冻结状态", None, scale)
    text(imgui, readiness, scale, kind="section", color=(T.SELECTED if ready else T.TEXT_SECONDARY))
    platform_ok = manager.last_report.ok
    blender_ok = manager.last_blender_report.ok
    contract_ok = manager.last_compare_ok is True
    docs_ok = manager.sdk_doc_frozen
    for label, ok, detail in (
        ("平台契约回归", platform_ok, manager.last_report.status),
        ("真实 Blender 回归", blender_ok, manager.last_blender_report.status),
        ("A1.0 契约基线", contract_ok, "MATCH" if contract_ok else "尚未建立/匹配"),
        ("SDK v1 文档", docs_ok, manager.sdk_doc_message),
    ):
        text(imgui, f"{'PASS' if ok else 'WAIT'} · {label}", scale, kind="small", color=(T.SELECTED if ok else T.TEXT_SECONDARY))
        muted(imgui, "    " + str(detail), scale)

    report = manager.last_report
    if report.checks:
        imgui.spacing()
        section(imgui, "平台契约回归结果", None, scale)
        text(imgui, report.status, scale, kind="section", color=(T.SELECTED if report.ok else T.DANGER))
        for item in report.checks:
            status = "PASS" if item.passed else "FAIL"
            color = T.SELECTED if item.passed else T.DANGER
            text(imgui, f"{status} · {item.label}", scale, kind="small", color=color)
            if item.detail:
                muted(imgui, "    " + item.detail, scale)

    real = manager.last_blender_report
    if real.checks:
        imgui.spacing()
        section(imgui, "真实 Blender 操作回归", None, scale)
        text(imgui, real.status, scale, kind="section", color=(T.SELECTED if real.ok else T.DANGER))
        for item in real.checks:
            status = "PASS" if item.passed else "FAIL"
            color = T.SELECTED if item.passed else T.DANGER
            text(imgui, f"{status} · {item.label}", scale, kind="small", color=color)
            if item.detail:
                muted(imgui, "    " + item.detail, scale)

    muted(imgui, "A1.0 的公共 Core / Module SDK 契约已冻结。后续优先开发雕刻、建模等产品模块；新增底层能力必须经过版本策略和回归门。", scale)

def _draw_package_lifecycle(imgui, state, scale):
    loader = getattr(APP, "module_loader", None)
    section(imgui, "模块包生命周期 A0.14 / Package Lifecycle", "安装 · 更新 · 降级确认 · 禁用/启用 · 卸载", scale)
    muted(imgui, "A0.14 把 .lfmod 从“能安装”推进到可维护生命周期：版本替换必须经过 Core 的版本策略。", scale)
    muted(imgui, "降级和相同版本覆盖不会静默发生；禁用会持久保存，重新启动后也不会自动加载。", scale)
    if loader is None:
        text(imgui, "模块加载器不可用", scale, kind="small", color=T.DANGER)
        return

    if button(imgui, "安装 v1.0 基线", scale, 170.0, selected=not loader.lifecycle_status().get("installed")):
        _queue_module_action(state, "life_install_v1", "lifecycle_demo")
    imgui.same_line()
    if button(imgui, "升级到 v1.1", scale, 160.0):
        _queue_module_action(state, "life_update_v2", "lifecycle_demo")
    if button(imgui, "尝试降级到 v1.0", scale, 180.0):
        _queue_module_action(state, "life_downgrade_block", "lifecycle_demo")
    imgui.same_line()
    if button(imgui, "确认降级到 v1.0", scale, 180.0):
        _queue_module_action(state, "life_downgrade_confirm", "lifecycle_demo")
    if button(imgui, "禁用模块", scale, 130.0):
        _queue_module_action(state, "life_disable", "lifecycle_demo")
    imgui.same_line()
    if button(imgui, "重新启用", scale, 130.0):
        _queue_module_action(state, "life_enable", "lifecycle_demo")
    imgui.same_line()
    if button(imgui, "运行自检", scale, 130.0):
        _queue_module_action(state, "life_ping", "lifecycle_demo")
    if button(imgui, "卸载测试模块", scale, 160.0):
        _queue_module_action(state, "life_uninstall", "lifecycle_demo")
    imgui.same_line()
    if button(imgui, "清理 A0.14 测试", scale, 160.0):
        _queue_module_action(state, "life_cleanup", "lifecycle_demo")

    status = loader.lifecycle_status()
    imgui.spacing()
    section(imgui, "生命周期状态", None, scale)
    if status.get("installed"):
        enabled_cn = "已启用 ENABLED" if status.get("enabled") else "已禁用 DISABLED"
        loaded_cn = "已加载 LOADED" if status.get("loaded") else "未加载 UNLOADED"
        text(imgui, f"生命周期测试模块：v{status.get('version')} · {enabled_cn} · {loaded_cn}", scale, kind="small", color=(T.SELECTED if status.get("loaded") else T.TEXT_SECONDARY))
        muted(imgui, f"模块状态会跨版本保留 · 自检次数：{int(status.get('ping_count', 0))}", scale)
    else:
        muted(imgui, "生命周期测试模块：未安装 NOT INSTALLED", scale)
    if getattr(loader, "last_lifecycle_message", ""):
        message = str(loader.last_lifecycle_message)
        danger = any(key in message for key in ("BLOCKED", "失败", "ERROR"))
        text(imgui, "最近操作：" + message, scale, kind="small", color=(T.DANGER if danger else T.SELECTED))
    history = tuple(getattr(loader, "lifecycle_history", ())[-4:])
    if history:
        muted(imgui, "最近历史：" + "  |  ".join(history), scale)
    muted(imgui, "卸载默认只删除模块代码，用户状态保留；“清理 A0.14 测试”才会连测试状态一起清除。", scale)


def _draw_permission_system(imgui, state, scale):
    loader = getattr(APP, "module_loader", None)
    section(imgui, "权限与信任 A0.13.1 / Permission & Trust", "内置可信 · 未知外部 · 显式信任 · 加载前权限门", scale)
    muted(imgui, "A0.13.1 是加载前策略门：UNKNOWN 外部模块只能使用只读基线；敏感权限必须先获得显式信任。", scale)
    muted(imgui, "注意：这不是 Python 安全沙箱。模块一旦被信任并在 Blender Python 进程内执行，仍可使用 Python 本身的能力。", scale)
    if loader is None:
        text(imgui, "模块加载器不可用", scale, kind="small", color=T.DANGER)
        return

    if button(imgui, "安装 / 准备 A0.13 权限示例", scale, 210.0, selected=bool(loader.get("perm_sensitive"))):
        _queue_module_action(state, "perm_install", "permission_demo")
    imgui.same_line()
    if button(imgui, "尝试加载未知敏感模块", scale, 210.0):
        _queue_module_action(state, "perm_block", "perm_sensitive")
    if button(imgui, "信任并加载敏感模块", scale, 190.0):
        _queue_module_action(state, "perm_trust_load", "perm_sensitive")
    imgui.same_line()
    if button(imgui, "撤销敏感模块信任", scale, 190.0):
        _queue_module_action(state, "perm_revoke", "perm_sensitive")
    if button(imgui, "清理 A0.13 权限示例", scale, 190.0):
        _queue_module_action(state, "perm_cleanup", "permission_demo")

    demo = APP.store.namespace("permission_demo", {"sensitive_execution_count": 0})
    readonly = loader.get("perm_readonly")
    sensitive = loader.get("perm_sensitive")
    if readonly or sensitive:
        imgui.spacing()
        section(imgui, "权限状态", None, scale)
        if readonly:
            readonly_loaded = bool(readonly.loaded and APP.modules.get("perm_readonly") is not None)
            text(imgui, f"只读外部模块：{'已加载 LOADED' if readonly_loaded else '未加载 UNLOADED'} · 信任={readonly.trust_level.upper()} · 权限 blender.read", scale, kind="small", color=(T.SELECTED if readonly_loaded else T.TEXT_SECONDARY))
        if sensitive:
            sensitive_loaded = bool(sensitive.loaded and APP.modules.get("perm_sensitive") is not None)
            trust_cn = {"trusted": "已信任 TRUSTED", "unknown": "未知 UNKNOWN", "blocked": "已阻止 BLOCKED", "builtin": "内置 BUILTIN"}.get(sensitive.trust_level, sensitive.trust_level)
            text(imgui, f"敏感外部模块：{'已加载 LOADED' if sensitive_loaded else '未加载 UNLOADED'} · {trust_cn}", scale, kind="small", color=(T.SELECTED if sensitive_loaded else T.TEXT_SECONDARY))
            muted(imgui, "声明权限：blender.write / files.write", scale)
            if sensitive.permission_denied or sensitive.permission_unknown:
                denied = list(sensitive.permission_denied) + list(sensitive.permission_unknown)
                text(imgui, "加载前权限门：已阻止 · " + " / ".join(denied), scale, kind="small", color=T.DANGER)
            elif sensitive.trust_level == "trusted":
                text(imgui, "加载前权限门：已授权 ALLOWED", scale, kind="small", color=T.SELECTED)
        text(imgui, f"敏感模块实际执行次数：{int(demo.get('sensitive_execution_count', 0))}", scale, kind="small", color=T.TEXT_SECONDARY)
        if demo.get("last_message"):
            text(imgui, str(demo.get("last_message")), scale, kind="small", color=T.SELECTED)
    muted(imgui, "信任记录：" + (APP.security.trust_file_display() or "不可用"), scale)


def _draw_persistence_system(imgui, state, scale):
    manager = APP.persistence
    section(imgui, "状态持久化 A0.12 / State Persistence", "磁盘保存 · 原子写入 · 冷启动恢复 · 版本迁移", scale)
    muted(imgui, "模块参数和稳定 UI 偏好进入 Core 状态文件；运行时对象、任务线程和生命周期计数不会写入磁盘。", scale)
    muted(imgui, "正常关闭 LumaFold / Blender 会自动保存；启动插件时会在模块注册后自动恢复。", scale)

    if button(imgui, "写入 A0.12 测试值", scale, 190.0, selected=True):
        _queue_persistence_action(state, "seed")
    imgui.same_line()
    if button(imgui, "保存状态到磁盘", scale, 180.0):
        _queue_persistence_action(state, "save")
    if button(imgui, "扰动当前内存值", scale, 190.0):
        _queue_persistence_action(state, "mutate")
    imgui.same_line()
    if button(imgui, "从磁盘恢复", scale, 180.0):
        _queue_persistence_action(state, "load")
    if button(imgui, "运行 v1 → v2 迁移测试", scale, 190.0):
        _queue_persistence_action(state, "migrate")
    imgui.same_line()
    if button(imgui, "清理迁移测试文件", scale, 180.0):
        _queue_persistence_action(state, "cleanup_probe")

    status = state.get("persistence_action_status")
    if status:
        color = T.DANGER if ("失败" in str(status) or "FAILED" in str(status)) else T.SELECTED
        text(imgui, str(status), scale, kind="small", color=color)

    sculpt = APP.store.namespace("sculpt", {
        "quick_slot": 0, "brush_size": 72.0, "brush_strength": 0.50, "alpha_slot": 0,
    })
    model = APP.store.namespace("model", {"bevel_width": 0.02, "bevel_segments": 3})
    render = APP.store.namespace("render", {"resolution_x": 1920, "resolution_y": 1080, "percentage": 100})
    marker = APP.store.namespace("persistence_demo", {"marker": "未设置"})

    imgui.spacing()
    section(imgui, "当前持久状态快照", None, scale)
    text(imgui, f"雕刻：槽 {int(sculpt.get('quick_slot', 0)) + 1} · Size {float(sculpt.get('brush_size', 0.0)):.0f} · Strength {float(sculpt.get('brush_strength', 0.0)):.2f} · Alpha {int(sculpt.get('alpha_slot', 0)) + 1}", scale, kind="small", color=T.TEXT_SECONDARY)
    text(imgui, f"建模：Bevel {float(model.get('bevel_width', 0.0)):.3f} · Segments {int(model.get('bevel_segments', 0))}", scale, kind="small", color=T.TEXT_SECONDARY)
    text(imgui, f"渲染：{int(render.get('resolution_x', 0))} × {int(render.get('resolution_y', 0))} · {int(render.get('percentage', 0))}%", scale, kind="small", color=T.TEXT_SECONDARY)
    text(imgui, f"Core Shared Value：{float(APP.state.shared_value):.2f} · 标记：{marker.get('marker', '-')}", scale, kind="small", color=T.TEXT_SECONDARY)

    try:
        path = str(manager.default_path())
    except Exception:
        path = "不可用"
    muted(imgui, "状态文件：" + path, scale)
    report = manager.last_report
    if report is not None:
        report_color = T.SELECTED if report.ok else T.DANGER
        text(imgui, f"最近状态操作：{report.status} · schema {report.source_schema} → {report.target_schema}", scale, kind="small", color=report_color)
        if report.message:
            muted(imgui, report.message, scale)
        if report.issues:
            text(imgui, "迁移/恢复提示：" + "; ".join(report.issues), scale, kind="small", color=T.DANGER)


def _start_task_demo(kind: str):
    import threading
    import time

    demo = APP.store.namespace("task_demo", {
        "active_task_id": "",
        "callback_count": 0,
        "last_callback_thread": "",
    })

    if kind == "complete":
        label = "正常后台任务"
        steps, delay = 60, 0.05
        fail_at = -1
    elif kind == "cancel":
        label = "可取消后台任务"
        steps, delay = 120, 0.05
        fail_at = -1
    elif kind == "failure":
        label = "故障隔离任务"
        steps, delay = 50, 0.04
        fail_at = 28
    else:
        raise ValueError(kind)

    def worker(ctx):
        for i in range(steps):
            ctx.check_cancelled()
            if i == fail_at:
                raise RuntimeError("A0.11 预期故障：后台任务测试异常")
            time.sleep(delay)
            ctx.update((i + 1) / steps, f"后台处理中 {(i + 1) * 100 // steps}%")
        return {"steps": steps, "kind": kind}

    def on_complete(record):
        demo["callback_count"] = int(demo.get("callback_count", 0)) + 1
        demo["last_callback_thread"] = threading.current_thread().name
        APP.state.log(f"task.completed: {record.task_id} · main-thread handoff")
        APP.events.emit("task.completed", {"task": record.task_id, "owner": record.owner})

    def on_cancel(record):
        demo["last_callback_thread"] = threading.current_thread().name
        APP.state.log(f"task.cancelled: {record.task_id}")
        APP.events.emit("task.cancelled", {"task": record.task_id})

    def on_error(record):
        demo["last_callback_thread"] = threading.current_thread().name
        APP.state.log(f"task.failed: {record.task_id} · {record.error}")
        APP.events.emit("task.failed", {"task": record.task_id, "error": record.error})

    task_id = APP.tasks.submit(
        label, worker, owner="task_demo",
        on_complete=on_complete, on_cancel=on_cancel, on_error=on_error,
    )
    demo["active_task_id"] = task_id
    return task_id


def _draw_task_system(imgui, state, scale):
    demo = APP.store.namespace("task_demo", {
        "active_task_id": "",
        "callback_count": 0,
        "last_callback_thread": "",
    })
    section(imgui, "任务系统 A0.11 / Task System", "后台执行 · 进度 · 取消 · 主线程安全回收", scale)
    muted(imgui, "后台 Worker 不允许直接碰 Blender 数据；完成/失败/取消回调统一回到 Blender UI 主线程。", scale)

    if button(imgui, "启动正常后台任务", scale, 190.0, selected=True):
        state["task_action_status"] = "已启动：" + _start_task_demo("complete")
    imgui.same_line()
    if button(imgui, "启动可取消任务", scale, 180.0):
        state["task_action_status"] = "已启动：" + _start_task_demo("cancel")

    active_id = str(demo.get("active_task_id", ""))
    active = APP.tasks.get(active_id) if active_id else None
    cancel_disabled = active is None or active.done or active.status == "CANCELLING"
    if button(imgui, "取消当前任务", scale, 190.0, disabled=cancel_disabled):
        ok = APP.tasks.cancel(active_id)
        state["task_action_status"] = "取消请求已发送" if ok else "当前没有可取消任务"
    imgui.same_line()
    if button(imgui, "运行故障隔离任务", scale, 180.0):
        state["task_action_status"] = "已启动：" + _start_task_demo("failure")

    if button(imgui, "清理已完成记录", scale, 190.0):
        count = APP.tasks.clear_finished()
        state["task_action_status"] = f"已清理 {count} 条任务记录"

    if state.get("task_action_status"):
        text(imgui, str(state["task_action_status"]), scale, kind="small", color=T.SELECTED)

    records = APP.tasks.all()[:6]
    if records:
        imgui.spacing()
        section(imgui, "任务状态", None, scale)
        for record in records:
            if record.status == "COMPLETED":
                color = T.SELECTED
                status_cn = "已完成 COMPLETED"
            elif record.status == "CANCELLED":
                color = T.TEXT_SECONDARY
                status_cn = "已取消 CANCELLED"
            elif record.status == "FAILED":
                color = T.DANGER
                status_cn = "失败已隔离 FAILED"
            elif record.status == "CANCELLING":
                color = T.TEXT_SECONDARY
                status_cn = "正在取消 CANCELLING"
            elif record.status == "RUNNING":
                color = T.SELECTED
                status_cn = "运行中 RUNNING"
            else:
                color = T.TEXT_SECONDARY
                status_cn = record.status
            text(imgui, f"{record.label} · {status_cn}", scale, kind="small", color=color)
            muted(imgui, f"进度：{int(record.progress * 100):3d}% · {record.message} · id={record.task_id}", scale)
            if record.worker_thread:
                muted(imgui, "Worker：" + record.worker_thread + (" · 主线程回收：" + record.callback_thread if record.callback_thread else ""), scale)
            if record.error:
                text(imgui, "错误：" + record.error, scale, kind="small", color=T.DANGER)

    muted(imgui, f"完成回调次数：{int(demo.get('callback_count', 0))} · 最近回调线程：{demo.get('last_callback_thread') or '尚未回收'}", scale)


def _draw_unloaded_workspace(imgui, state, scale, module_id, label):
    text(imgui, f"{label} 工作区", scale, kind="title")
    text(imgui, "[ 模块已卸载 / MODULE UNLOADED ]", scale, kind="section", color=T.DANGER)
    muted(imgui, "这个模块已真正卸载；它和“当前上下文不适用 N/A”不是一回事。", scale)
    imgui.spacing()
    if button(imgui, f"加载 {label} 模块##load_workspace_{module_id}", scale, 210.0, selected=True):
        _queue_module_action(state, "load", module_id)


def _draw_sdk_manager(imgui, state, scale):
    loader = getattr(APP, "module_loader", None)
    section(imgui, "模块平台 A1.0 / Module SDK", "Frozen Core Baseline · SDK Contract v1", scale)
    muted(imgui, "A1.0：架构基线已冻结。平台页保留回归、包生命周期、权限、任务与持久化等开发者诊断入口。", scale)
    muted(imgui, "状态说明：N/A = 当前对象/模式不适用；UNLOADED = 模块已卸载；BLOCKED = 安装/依赖检查未通过。", scale)
    action_status = state.get("module_action_status")
    if action_status:
        text(imgui, str(action_status), scale, kind="small", color=T.SELECTED)
    if loader is None:
        text(imgui, "模块加载器不可用", scale, kind="section", color=T.DANGER)
        return

    _draw_architecture_freeze(imgui, state, scale)
    imgui.spacing()

    _draw_package_lifecycle(imgui, state, scale)
    imgui.spacing()

    _draw_permission_system(imgui, state, scale)
    imgui.spacing()

    _draw_persistence_system(imgui, state, scale)
    imgui.spacing()

    _draw_task_system(imgui, state, scale)
    imgui.spacing()

    section(imgui, "服务契约 A0.10.1 / Service Contract", "验证提供者、消费者、自动解析和卸载保护", scale)
    muted(imgui, "正常链：服务提供模块提供 demo.greeter；服务消费模块只声明 requires_services，不 import 提供模块。", scale)
    if button(imgui, "安装 A0.10 服务示例", scale, 190.0, selected=True):
        _queue_module_action(state, "service_install", "service_demo")
    imgui.same_line()
    if button(imgui, "自动准备并加载消费者", scale, 200.0):
        _queue_module_action(state, "service_load", "svc_consumer")
    if button(imgui, "调用共享服务", scale, 190.0):
        _queue_module_action(state, "service_call", "demo.greeter")
    imgui.same_line()
    if button(imgui, "尝试卸载服务提供者", scale, 200.0):
        _queue_module_action(state, "service_unload_provider", "svc_provider")
    if button(imgui, "检查缺失服务阻止", scale, 190.0):
        _queue_module_action(state, "service_missing", "svc_missing")
    imgui.same_line()
    if button(imgui, "清理 A0.10 服务示例", scale, 190.0):
        _queue_module_action(state, "service_cleanup", "service_demo")

    svc_provider = loader.get("svc_provider")
    svc_consumer = loader.get("svc_consumer")
    svc_missing = loader.get("svc_missing")
    if any((svc_provider, svc_consumer, svc_missing)):
        imgui.spacing()
        section(imgui, "服务状态", None, scale)
        if svc_provider:
            provider_loaded = bool(svc_provider.loaded and APP.modules.get("svc_provider") is not None)
            text(imgui, f"服务提供模块：{'已加载 LOADED' if provider_loaded else '未加载 UNLOADED'}", scale, kind="small", color=(T.SELECTED if provider_loaded else T.TEXT_SECONDARY))
        if svc_consumer:
            consumer_loaded = bool(svc_consumer.loaded and APP.modules.get("svc_consumer") is not None)
            text(imgui, f"服务消费模块：{'已加载 LOADED' if consumer_loaded else '未加载 UNLOADED'} · requires demo.greeter", scale, kind="small", color=(T.SELECTED if consumer_loaded else T.TEXT_SECONDARY))
        service = APP.services.get("demo.greeter")
        if service is not None:
            owner = APP.services.owner_of("demo.greeter")
            version = APP.services.version_of("demo.greeter")
            consumers = APP.services.consumers_of("demo.greeter")
            text(imgui, f"服务契约：demo.greeter v{version} · 提供者 {owner}", scale, kind="small", color=T.SELECTED)
            muted(imgui, "当前消费者：" + (", ".join(consumers) if consumers else "无"), scale)
        if getattr(loader, "last_service_demo_order", ()):
            muted(imgui, "Core 计算的服务加载顺序：" + " → ".join(loader.last_service_demo_order), scale)
        if getattr(loader, "last_service_demo_message", ""):
            text(imgui, str(loader.last_service_demo_message), scale, kind="small", color=T.SELECTED)
        if svc_missing and (svc_missing.compatibility_issues or svc_missing.error):
            reason = "; ".join(svc_missing.compatibility_issues) or svc_missing.error
            text(imgui, "缺失服务测试：已阻止 BLOCKED · " + str(reason), scale, kind="small", color=T.DANGER)
    imgui.spacing()

    section(imgui, "依赖图 A0.9.1 / Dependency Graph", "验证加载顺序、卸载保护和故障隔离", scale)
    muted(imgui, "正常链：依赖基础模块 → 依赖上层模块。点击加载上层时，Core 应自动先加载基础模块。", scale)
    if button(imgui, "安装 A0.9 依赖示例", scale, 190.0, selected=True):
        _queue_module_action(state, "dep_install", "dependency_demo")
    imgui.same_line()
    if button(imgui, "自动加载正常依赖链", scale, 200.0):
        _queue_module_action(state, "dep_load", "dep_tool")
    if button(imgui, "尝试卸载基础模块", scale, 190.0):
        _queue_module_action(state, "dep_unload_base", "dep_base")
    imgui.same_line()
    if button(imgui, "运行故障依赖链", scale, 180.0):
        _queue_module_action(state, "dep_fault", "dep_fault_tool")
    if button(imgui, "清理 A0.9 依赖示例", scale, 190.0):
        _queue_module_action(state, "dep_cleanup", "dependency_demo")

    dep_base = loader.get("dep_base")
    dep_tool = loader.get("dep_tool")
    dep_fault_base = loader.get("dep_fault_base")
    dep_fault_tool = loader.get("dep_fault_tool")
    if any((dep_base, dep_tool, dep_fault_base, dep_fault_tool)):
        imgui.spacing()
        section(imgui, "依赖状态", None, scale)
        if dep_base:
            text(imgui, f"基础模块：{'已加载 LOADED' if dep_base.loaded else '未加载 UNLOADED'}", scale, kind="small", color=(T.SELECTED if dep_base.loaded else T.TEXT_SECONDARY))
        if dep_tool:
            text(imgui, f"上层模块：{'已加载 LOADED' if dep_tool.loaded else '未加载 UNLOADED'} · 依赖 dep_base", scale, kind="small", color=(T.SELECTED if dep_tool.loaded else T.TEXT_SECONDARY))
        protected_by = loader.dependents_of("dep_base", loaded_only=True) if dep_base else []
        if protected_by:
            text(imgui, "卸载保护：基础模块正在被 " + ", ".join(protected_by) + " 使用", scale, kind="small", color=T.SELECTED)
        if dep_fault_base and dep_fault_base.error:
            text(imgui, "故障基础：已隔离 ISOLATED · " + dep_fault_base.error, scale, kind="small", color=T.DANGER)
        if dep_fault_tool and (dep_fault_tool.error or dep_fault_tool.dependency_blocked_by):
            reason = dep_fault_tool.dependency_note or dep_fault_tool.error
            text(imgui, "故障上层：依赖阻止 BLOCKED · " + str(reason), scale, kind="small", color=T.DANGER)
        try:
            order = loader.resolve_load_order(["dep_tool"]) if dep_tool else []
            if order:
                muted(imgui, "Core 计算的加载顺序：" + " → ".join(order), scale)
        except Exception as exc:
            text(imgui, "依赖图错误：" + str(exc), scale, kind="small", color=T.DANGER)
    imgui.spacing()

    section(imgui, "模块包安装门 A0.8 / Package Gate", "真正的 .lfmod(ZIP) 包先读取 manifest，不会在检查阶段执行 module.py", scale)
    muted(imgui, "检查内容：包结构 / Core API / Blender 版本 / 模块依赖 / 路径安全。", scale)
    muted(imgui, "注意：这是兼容性与故障隔离门，不是 Python 安全沙箱；真正加载后模块代码仍运行在 Blender Python 中。", scale)
    muted(imgui, "模块包目录：" + (loader.package_root_display or "不可用"), scale)
    if button(imgui, "安装兼容测试包", scale, 180.0, selected=True):
        _queue_module_action(state, "package_good", "package_demo")
    imgui.same_line()
    if button(imgui, "检查不兼容测试包", scale, 190.0):
        _queue_module_action(state, "package_bad", "package_incompatible")
    imgui.same_line()
    if button(imgui, "安装故障测试包", scale, 180.0):
        _queue_module_action(state, "package_faulty", "package_faulty")
    if button(imgui, "清理 A0.8 测试包", scale, 180.0):
        _queue_module_action(state, "package_cleanup", "demo_packages")

    report = getattr(loader, "last_package_report", None)
    if report and getattr(report, "status", ""):
        imgui.spacing()
        section(imgui, "最近一次包检查", None, scale)
        status_color = T.SELECTED if getattr(report, "compatible", False) else T.DANGER
        text(imgui, str(report.status), scale, kind="section", color=status_color)
        if getattr(report, "name", "") or getattr(report, "module_id", ""):
            muted(imgui, f"模块：{getattr(report, 'name', '')} · id={getattr(report, 'module_id', '')} · v{getattr(report, 'version', '')}", scale)
        if getattr(report, "package_path", ""):
            muted(imgui, "包文件：" + str(report.package_path), scale)
        if getattr(report, "file_count", 0):
            muted(imgui, f"文件数：{report.file_count} · 解压体积：{report.unpacked_bytes} bytes", scale)
        for issue in tuple(getattr(report, "issues", ()) or ()):
            text(imgui, "• " + str(issue), scale, kind="small", color=T.DANGER)
        if getattr(report, "load_error", ""):
            text(imgui, "模块加载错误已隔离：" + str(report.load_error), scale, kind="small", color=T.DANGER)
        elif getattr(report, "loaded", False):
            muted(imgui, "模块已经通过安装门并成功加载。", scale)

    imgui.spacing()
    section(imgui, "外部模块目录 / External Modules", "已安装模块放在 Blender 用户目录，升级 LumaFold 不会被覆盖", scale)
    muted(imgui, loader.external_root_display or "外部模块目录不可用", scale)
    if button(imgui, "安装 A0.7 文件夹示例", scale, 190.0):
        _queue_module_action(state, "install_demo", "external_demo")
    imgui.same_line()
    if button(imgui, "删除 A0.7 文件夹示例", scale, 190.0):
        _queue_module_action(state, "remove_demo", "external_demo")

    if button(imgui, "重新扫描模块 / Rescan", scale, 190.0):
        try:
            loader.discover()
            APP.events.emit("module.discovery.rescan", {"count": len(loader.records)})
            state["module_action_status"] = f"扫描完成：发现 {len(loader.records)} 个模块"
        except Exception as exc:
            APP.state.log(f"module discovery failed: {exc}")
    imgui.same_line()
    muted(imgui, f"已发现：{len(loader.records)}", scale)
    imgui.spacing()

    for record in loader.all_records():
        manifest = record.manifest
        status = APP.modules.status(manifest.module_id)
        loaded = bool(record.loaded and APP.modules.get(manifest.module_id) is not None)
        color = T.SELECTED if loaded else T.TEXT_SECONDARY
        source_cn = "内置" if record.source == "builtin" else "外部"
        permission_blocked = bool(record.source == "external" and (record.permission_denied or record.permission_unknown))
        if record.source == "external" and not getattr(record, "enabled", True):
            state_cn = "已禁用 DISABLED"
            color = T.TEXT_SECONDARY
        elif record.source == "external" and (not record.compatible or permission_blocked):
            state_cn = "已阻止 BLOCKED"
            color = T.DANGER
        else:
            state_cn = "已加载 LOADED" if loaded else "已卸载 UNLOADED"
        text(imgui, f"{manifest.name}  ·  {manifest.version}  ·  {state_cn}", scale, kind="section", color=color)
        muted(imgui, f"来源：{source_cn} · id={manifest.module_id} · 分类={manifest.category} · API={manifest.api_version}", scale)
        muted(imgui, manifest.description or "无模块说明", scale)
        muted(imgui, "支持 Host：" + " / ".join(manifest.hosts), scale)
        if record.source == "external":
            compat_cn = "通过 COMPATIBLE" if record.compatible else "阻止 BLOCKED"
            text(imgui, "兼容性：" + compat_cn, scale, kind="small", color=(T.SELECTED if record.compatible else T.DANGER))
            trust_cn = {"trusted": "已信任 TRUSTED", "unknown": "未知 UNKNOWN", "blocked": "已阻止 BLOCKED", "builtin": "内置 BUILTIN"}.get(record.trust_level, record.trust_level)
            trust_color = T.SELECTED if record.trust_level == "trusted" else T.TEXT_SECONDARY
            text(imgui, "信任级别：" + trust_cn, scale, kind="small", color=trust_color)
            if record.permission_denied or record.permission_unknown:
                denied = list(record.permission_denied) + list(record.permission_unknown)
                text(imgui, "权限门：BLOCKED · " + " / ".join(denied), scale, kind="small", color=T.DANGER)
            elif manifest.permissions:
                muted(imgui, "权限门：ALLOWED", scale)
            if manifest.blender_min:
                muted(imgui, "Blender 最低版本：" + manifest.blender_min, scale)
            if manifest.requires_modules:
                muted(imgui, "依赖模块：" + " / ".join(manifest.requires_modules), scale)
            if getattr(record, "dependency_blocked_by", ()):
                text(imgui, "依赖阻止：" + " / ".join(record.dependency_blocked_by), scale, kind="small", color=T.DANGER)
            if manifest.permissions:
                muted(imgui, "声明权限：" + " / ".join(manifest.permissions), scale)
            for issue in record.compatibility_issues:
                text(imgui, "• " + issue, scale, kind="small", color=T.DANGER)
            muted(imgui, "外部文件：" + record.source_path, scale)
        if record.error:
            text(imgui, "加载错误：" + record.error, scale, kind="small", color=T.DANGER)

        if loaded:
            if button(imgui, f"卸载 Unload##sdk_unload_{manifest.module_id}", scale, 145.0):
                _queue_module_action(state, "unload", manifest.module_id)
            imgui.same_line()
            if button(imgui, f"重载 Reload##sdk_reload_{manifest.module_id}", scale, 145.0):
                _queue_module_action(state, "reload", manifest.module_id)
        else:
            can_load = not (record.source == "external" and (not record.compatible or record.permission_denied or record.permission_unknown))
            if button(imgui, f"加载 Load##sdk_load_{manifest.module_id}", scale, 145.0, selected=can_load, disabled=not can_load):
                _queue_module_action(state, "load", manifest.module_id)

        if loaded:
            muted(imgui, f"当前上下文：{'可用 ACTIVE' if status.active else '暂不可用 N/A'} · {status.reason}", scale)
            spec = APP.modules.get(manifest.module_id)
            muted(imgui, f"加载次数：{record.load_count} · 命令数：{len(spec.commands) if spec else 0}", scale)
            if manifest.self_test:
                if button(imgui, f"运行模块自检##selftest_{manifest.module_id}", scale, 170.0, selected=True):
                    result = APP.execute(manifest.self_test)
                    state["module_action_status"] = result.message
        imgui.separator()
        imgui.spacing()

    section(imgui, "A0.9 依赖规则", "模块依赖开始进入正式 Core 规则", scale)
    muted(imgui, "1. Core 根据 manifest.requires_modules 建立依赖图，并按依赖优先顺序加载", scale)
    muted(imgui, "2. 上层模块已加载时，基础依赖不能被单独卸载，避免运行时断链", scale)
    muted(imgui, "3. 依赖加载失败时，上层模块不会执行；错误只沿该依赖链传播", scale)
    muted(imgui, "4. 不相关模块继续正常工作；后续模块可安全建立共享服务层", scale)
    imgui.spacing()
    section(imgui, "A0.8 模块包规范", "第三方包进入 Core 前必须先过这一层", scale)
    muted(imgui, "1. 文件扩展名建议 .lfmod，本质为 ZIP；根目录必须有 manifest.toml + module.py", scale)
    muted(imgui, "2. manifest 声明 package_format / api_version / Blender 版本 / 依赖模块 / 权限", scale)
    muted(imgui, "3. Preflight 只读 manifest 和包结构，不 import module.py", scale)
    muted(imgui, "4. 不兼容包直接 BLOCKED；单个模块加载失败只记录错误，不关闭 LumaFold", scale)
    muted(imgui, "5. 真正的权限沙箱/签名机制属于后续安全阶段，A0.8 不做虚假承诺", scale)

def _draw_modules(imgui, state, scale):
    _draw_sdk_manager(imgui, state, scale)
    imgui.spacing()
    imgui.separator()
    imgui.spacing()
    host_id = str(state.get("host_mode", "embedded"))
    context, caps = APP.refresh_context(host_id=host_id)
    section(imgui, "平台诊断 / Platform", "上下文激活 · 能力判断 · 生命周期", scale)
    muted(
        imgui,
        f"Context: {context.mode} · {context.active_object_name or 'No active object'} · "
        f"{context.active_object_type or '-'} · host={context.host_id}",
        scale,
    )
    if caps is not None:
        muted(imgui, "Context capabilities: " + (" · ".join(caps.available) or "none"), scale)
    muted(imgui, "模块只声明需要什么；是否可用由 Core 统一判断。", scale)
    imgui.spacing()

    for spec in APP.modules.all():
        status = APP.modules.status(spec.module_id)
        status_color = T.SELECTED if status.active else T.TEXT_SECONDARY
        text(imgui, f"{spec.label}  ·  {spec.version}  ·  {'ACTIVE' if status.active else 'INACTIVE'}", scale, kind="section", color=status_color)
        muted(imgui, spec.description, scale)
        muted(imgui, "Requires: " + (" · ".join(spec.requires) or "none"), scale)
        muted(imgui, "Modes: " + (" / ".join(spec.modes) or "any") + "    Host: " + host_id, scale)
        if not status.active:
            text(imgui, f"Why inactive: {status.reason}", scale, kind="small", color=T.DANGER)

        if spec.module_id == "sculpt":
            sculpt_state = APP.store.namespace("sculpt")
            if button(imgui, "Enter Sculpt Mode", scale, 170.0, selected=(context.mode == "SCULPT"), disabled=not status.active):
                APP.execute("sculpt.enter")
                APP.refresh_context(host_id=host_id)
            imgui.same_line()
            if button(imgui, "Return Object", scale, 145.0, disabled=not status.enabled):
                APP.execute("sculpt.exit_to_object")
                APP.refresh_context(host_id=host_id)
            muted(
                imgui,
                f"Lifecycle: {sculpt_state.get('lifecycle', 'REGISTERED')} · activations={sculpt_state.get('activation_count', 0)} · last_mode={sculpt_state.get('last_mode', 'OBJECT')}",
                scale,
            )

        elif spec.module_id == "model":
            model_state = APP.store.namespace("model", {"bevel_width": 0.02, "bevel_segments": 3})
            if status.active:
                model_state["bevel_width"] = property_slider(
                    imgui, "Bevel width", float(model_state.get("bevel_width", 0.02)), 0.0, 0.10, scale, "%.3f"
                )
                changed, segs = imgui.slider_int(
                    "Bevel segments##module_model", int(model_state.get("bevel_segments", 3)), 1, 12
                )
                if changed:
                    model_state["bevel_segments"] = int(segs)
            else:
                muted(imgui, f"Bevel width {float(model_state.get('bevel_width', 0.02)):.3f} · segments {int(model_state.get('bevel_segments', 3))}", scale)

            if button(imgui, "添加 / 更新倒角", scale, 180.0, selected=status.active, disabled=not status.active):
                APP.execute(
                    "model.add_bevel",
                    width=float(model_state["bevel_width"]),
                    segments=int(model_state["bevel_segments"]),
                )
            imgui.same_line()
            if button(imgui, "X 方向移动 +0.10", scale, 145.0, disabled=not status.active):
                APP.execute("model.nudge_x", delta=0.10)
            muted(
                imgui,
                f"Lifecycle: {model_state.get('lifecycle', 'REGISTERED')} · activations={model_state.get('activation_count', 0)}",
                scale,
            )

        muted(imgui, "Provides: " + " · ".join(spec.capabilities), scale)
        muted(imgui, "Commands: " + " · ".join(spec.commands), scale)
        imgui.separator()
        imgui.spacing()

    section(imgui, "平台上下文服务", "同一套上下文解析供所有模块使用", scale)
    muted(imgui, "Services: " + " · ".join(APP.services.all_ids()), scale)
    muted(imgui, "Capability checks: " + " · ".join(APP.capabilities.all_ids()), scale)
    events = APP.events.tail(8)
    if events:
        imgui.spacing()
        text(imgui, "Lifecycle / Context Event Bus tail", scale, kind="small", color=T.TEXT_SECONDARY)
        for event in events:
            muted(imgui, f"{event.topic}  ·  {event.payload}", scale)

    status_color = T.SELECTED if APP.state.last_command_ok else T.DANGER
    imgui.spacing()
    text(imgui, f"Last command: {APP.state.last_command}", scale, kind="small", color=status_color)
    muted(imgui, APP.state.last_command_message or "No module command executed yet", scale)

def _draw_page_contents(imgui, state, scale):
    page = int(state.setdefault("page", 0))
    module_pages = {
        0: ("sculpt", "Sculpt", _draw_sculpt_workspace),
        1: ("model", "Model", _draw_model_workspace),
        2: ("light", "Light", _draw_light_workspace),
        3: ("render", "Render", _draw_render_workspace),
    }
    if page in module_pages:
        module_id, label, draw_fn = module_pages[page]
        if _module_loaded(module_id):
            draw_fn(imgui, state, scale)
        else:
            _draw_unloaded_workspace(imgui, state, scale, module_id, label)
    elif page == 4:
        _draw_modules(imgui, state, scale)
    elif page == 5:
        _draw_core(imgui, state, scale)
    else:
        _draw_foundation(imgui, state, scale)


def _product_title_for_workspace(workspace_name, mode):
    raw = str(workspace_name or "")
    key = raw.casefold().replace(" ", "")
    if key in {"modeling", "建模"} or "model" in key or "建模" in raw:
        return "LumaFold Model"
    if key in {"rendering", "render", "渲染"} or "render" in key or "渲染" in raw:
        return "LumaFold Render"
    return "LumaFold Sculpt"


def _draw_unified_host_surface(imgui, state, scale):
    """One product UI tree for Embedded and Satellite.

    S0.6.7 keeps the 浮台 product tree declarative and owned by one active Host at a time:
    Sculpt never shows a scrollbar when every card already fits, and the Host
    container follows the exact compact surface height.  Embedded/Satellite
    still render the same widget tree; Host only decides where it lives.
    """
    host_mode = str(state.get("host_mode", "embedded")).lower()
    satellite = host_mode == "satellite"
    display_w, display_h = state.get("display_size", (1280.0, 720.0))
    # Product shell is mode-aware, not a second Blender Workspace selector.
    state["page"] = 0
    current_page = 0
    sculpt_page = True

    # Width is a product preset. Height is deliberately *not* hard-coded for
    # Sculpt: it is measured from the actual card stack and reused on the next
    # frame / during Host migration.
    compact_w_design = float(state.get("compact_surface_w", float(_SCULPT_VIEW_SPEC.get("design_width", 264.0))) or float(_SCULPT_VIEW_SPEC.get("design_width", 264.0)))
    # Keep width stable even if an older persisted measurement was wider.
    compact_w_design = float(_SCULPT_VIEW_SPEC.get("design_width", 264.0))
    measured_h_design = float(state.get("compact_surface_h", float(_SCULPT_VIEW_SPEC.get("design_height", 338.0))) or float(_SCULPT_VIEW_SPEC.get("design_height", 338.0)))
    compact_w = px(compact_w_design, scale)
    fallback_h = px(max(320.0, min(620.0, measured_h_design)), scale)

    auto_resize_flag = getattr(imgui.WindowFlags, "ALWAYS_AUTO_RESIZE", 0)
    no_scrollbar_flag = getattr(imgui.WindowFlags, "NO_SCROLLBAR", 0)
    no_scroll_mouse_flag = getattr(imgui.WindowFlags, "NO_SCROLL_WITH_MOUSE", 0)

    if sculpt_page:
        # Dear ImGui can auto-fit to content while a size constraint pins only
        # the width.  This is the preferred path; the fallback uses the previous
        # measured height and still disables redundant scrollbars.
        constrained = False
        if hasattr(imgui, "set_next_window_size_constraints"):
            try:
                imgui.set_next_window_size_constraints(
                    (compact_w, px(240.0, scale)),
                    (compact_w, px(900.0, scale)),
                )
                constrained = True
            except Exception:
                constrained = False
        if not constrained:
            imgui.set_next_window_size((compact_w, fallback_h), imgui.Cond.ALWAYS)

    if satellite:
        # Satellite uses the 浮台 footprint measured by Embedded before
        # detach. It does not auto-fit or report a new OS size while visible.
        imgui.set_next_window_pos((0.0, 0.0), imgui.Cond.ALWAYS)
        imgui.set_next_window_size((float(display_w), float(display_h)), imgui.Cond.ALWAYS)
        flags = (
            imgui.WindowFlags.NO_TITLE_BAR
            | imgui.WindowFlags.NO_RESIZE
            | imgui.WindowFlags.NO_MOVE
            | imgui.WindowFlags.NO_COLLAPSE
            | imgui.WindowFlags.NO_SAVED_SETTINGS
        )
        if sculpt_page:
            flags |= no_scrollbar_flag | no_scroll_mouse_flag
        title = "LumaFold Unified Host##satellite"
        visible, opened = imgui.begin(title, flags=flags)
        state["opened"] = True
    else:
        pos_x = max(px(18.0, scale), float(display_w) - compact_w - px(24.0, scale))
        pos_y = px(64.0, scale)
        if bool(state.get("embedded_restore_pending", False)):
            rx = float(state.get("embedded_restore_pos_x", pos_x) or pos_x)
            ry = float(state.get("embedded_restore_pos_y", pos_y) or pos_y)
            imgui.set_next_window_pos((rx, ry), imgui.Cond.ALWAYS)
            state["embedded_restore_pending"] = False
        else:
            imgui.set_next_window_pos((pos_x, pos_y), imgui.Cond.FIRST_USE_EVER)
        if not sculpt_page:
            imgui.set_next_window_size((compact_w, fallback_h), imgui.Cond.ALWAYS)
        flags = imgui.WindowFlags.NO_COLLAPSE | imgui.WindowFlags.NO_RESIZE
        if sculpt_page:
            flags |= auto_resize_flag | no_scrollbar_flag | no_scroll_mouse_flag
        display_title = _product_title_for_workspace(state.get("blender_workspace", ""), state.get("blender_mode", ""))
        visible, opened = imgui.begin(f"{display_title} · 浮台###lumafold_primary_embedded", closable=True, flags=flags)
        state["opened"] = opened

    if visible:
        # Product shell no longer duplicates Blender Workspace/Mode navigation.
        # This primary surface is Sculpt; Blender Workspace remains entirely Blender-owned.
        state["page"] = 0
        _draw_page_contents(imgui, state, scale)

        # Record the actual surface size only for Sculpt. Embedded passes this
        # measurement to Satellite, so detach starts at the same footprint.
        if not satellite:
            try:
                surface_w, surface_h = imgui.get_window_size()
                if surface_w > 0.0 and surface_h > 0.0:
                    state["compact_surface_w"] = float(surface_w) / max(0.01, scale)
                    state["compact_surface_h"] = float(surface_h) / max(0.01, scale)
                    state["desired_satellite_client_px"] = (float(surface_w), float(surface_h))
                    try:
                        wp = imgui.get_window_pos()
                        state["embedded_window_pos_x"] = float(wp[0])
                        state["embedded_window_pos_y"] = float(wp[1])
                        state["embedded_last_valid_pos_x"] = float(wp[0])
                        state["embedded_last_valid_pos_y"] = float(wp[1])
                    except Exception:
                        pass
            except Exception:
                pass
    imgui.end()


def draw_gallery(imgui, state):
    scale = float(state.setdefault("style_scale", state.setdefault("ui_scale", 1.25)))
    _draw_unified_host_surface(imgui, state, scale)
