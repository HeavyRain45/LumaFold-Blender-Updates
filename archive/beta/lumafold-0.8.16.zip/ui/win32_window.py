from __future__ import annotations

import ctypes
import os
import sys
from ctypes import wintypes


class POINT(ctypes.Structure):
    _fields_ = [("x", wintypes.LONG), ("y", wintypes.LONG)]


class RECT(ctypes.Structure):
    _fields_ = [("left", wintypes.LONG), ("top", wintypes.LONG), ("right", wintypes.LONG), ("bottom", wintypes.LONG)]


def _api():
    if sys.platform != "win32":
        return None
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
    user32.GetWindowThreadProcessId.restype = wintypes.DWORD
    user32.IsWindowVisible.argtypes = [wintypes.HWND]
    user32.IsWindowVisible.restype = wintypes.BOOL
    user32.GetClientRect.argtypes = [wintypes.HWND, ctypes.POINTER(RECT)]
    user32.GetClientRect.restype = wintypes.BOOL
    user32.ClientToScreen.argtypes = [wintypes.HWND, ctypes.POINTER(POINT)]
    user32.ClientToScreen.restype = wintypes.BOOL
    return user32


def find_process_hwnd(preferred: int = 0) -> int:
    user32 = _api()
    if user32 is None:
        return 0
    pid = os.getpid()

    def same_pid(hwnd):
        out = wintypes.DWORD(0)
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(out))
        return int(out.value) == pid

    if preferred and same_pid(preferred):
        return int(preferred)

    fg = user32.GetForegroundWindow()
    if fg and same_pid(fg):
        return int(fg)

    found = []
    ENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    @ENUMPROC
    def enum_proc(hwnd, _lp):
        if same_pid(hwnd) and user32.IsWindowVisible(hwnd):
            rect = RECT()
            if user32.GetClientRect(hwnd, ctypes.byref(rect)):
                area = max(0, rect.right - rect.left) * max(0, rect.bottom - rect.top)
                found.append((area, int(hwnd)))
        return True

    user32.EnumWindows(enum_proc, 0)
    if not found:
        return 0
    found.sort(reverse=True)
    return found[0][1]


def view3d_region_screen_rect(region, hwnd: int = 0):
    """Return View3D WINDOW region screen rect in top-left screen coordinates."""
    user32 = _api()
    if user32 is None:
        return None
    hwnd = find_process_hwnd(hwnd)
    if not hwnd:
        return None
    client = RECT()
    origin = POINT(0, 0)
    if not user32.GetClientRect(hwnd, ctypes.byref(client)):
        return None
    if not user32.ClientToScreen(hwnd, ctypes.byref(origin)):
        return None
    client_h = int(client.bottom - client.top)
    left = int(origin.x + int(region.x))
    top = int(origin.y + client_h - (int(region.y) + int(region.height)))
    return {
        "left": left,
        "top": top,
        "right": left + int(region.width),
        "bottom": top + int(region.height),
        "width": int(region.width),
        "height": int(region.height),
    }


def imgui_local_to_screen(region, pos, hwnd: int = 0):
    r = view3d_region_screen_rect(region, hwnd)
    if not r:
        return None
    return (int(round(r["left"] + float(pos[0]))), int(round(r["top"] + float(pos[1]))))
