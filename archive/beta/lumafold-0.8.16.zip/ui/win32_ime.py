"""Safe Win32 IME placement bridge for LumaFold.

S0.8.4-dev24 deliberately removes the old Python WndProc subclass from Blender's
TOP-LEVEL HWND.  A Python callback must not sit in Blender's native window
procedure chain across hot reloads, third-party subclasses, Workspace switches,
or teardown races.  Stability of Blender's own window chrome and event loop has
priority over intercepting IME result strings.

This bridge now does one narrow, non-owning job only:
- while a LumaFold text field is active, resolve the foreground Blender HWND;
- borrow Blender's existing HIMC with ImmGetContext;
- position composition/candidate windows;
- immediately release the HIMC with ImmReleaseContext.

It never calls SetWindowLongPtr/GWLP_WNDPROC, never installs a native callback,
never replaces Blender's IME context, and never owns a Windows message.
Committed text therefore relies on Blender events / ImGui input forwarding.  The
old extra Chinese-result interception is intentionally disabled until a safe,
Blender-native text-input path is available.
"""
from __future__ import annotations

import ctypes
import os
import sys
from collections import deque
from ctypes import wintypes


class _POINT(ctypes.Structure):
    _fields_ = [("x", wintypes.LONG), ("y", wintypes.LONG)]


class _RECT(ctypes.Structure):
    _fields_ = [
        ("left", wintypes.LONG),
        ("top", wintypes.LONG),
        ("right", wintypes.LONG),
        ("bottom", wintypes.LONG),
    ]


class _CANDIDATEFORM(ctypes.Structure):
    _fields_ = [
        ("dwIndex", wintypes.DWORD),
        ("dwStyle", wintypes.DWORD),
        ("ptCurrentPos", _POINT),
        ("rcArea", _RECT),
    ]


class _COMPOSITIONFORM(ctypes.Structure):
    _fields_ = [
        ("dwStyle", wintypes.DWORD),
        ("ptCurrentPos", _POINT),
        ("rcArea", _RECT),
    ]


class Win32IMEBridge:
    CFS_POINT = 0x0002
    CFS_CANDIDATEPOS = 0x0040

    def __init__(self):
        self.available = sys.platform == "win32"
        self.hwnd = 0
        self.himc = 0
        self.previous_himc = 0
        self.associated = False
        self.last_anchor = None
        self.error = ""
        self.activation_count = 0
        self.position_updates = 0

        # Compatibility diagnostics retained for existing UI/debug surfaces.
        # They must stay false/zero in dev24 safe mode.
        self.hook_installed = False
        self.hook_hwnd = 0
        self.original_wndproc = 0
        self._wndproc_ptr = 0
        self.hook_count = 0
        self.restore_count = 0
        self.ime_message_count = 0
        self.result_count = 0
        self.composition_count = 0
        self.composing = False
        self.composition_text = ""
        self.last_result = ""
        self._committed = deque(maxlen=32)
        self._message_log = deque(maxlen=12)

        if not self.available:
            self.error = "Win32 IME placement is only available on Windows"
            return
        try:
            self.user32 = ctypes.WinDLL("user32", use_last_error=True)
            self.imm32 = ctypes.WinDLL("imm32", use_last_error=True)
            self._configure_api()
            self.hwnd = self._find_current_process_window()
            if not self.hwnd:
                raise RuntimeError("Could not resolve Blender HWND")
        except Exception as exc:
            self.available = False
            self.error = f"{type(exc).__name__}: {exc}"

    def _configure_api(self):
        self.user32.GetForegroundWindow.restype = wintypes.HWND
        self.user32.GetWindowThreadProcessId.argtypes = [
            wintypes.HWND,
            ctypes.POINTER(wintypes.DWORD),
        ]
        self.user32.GetWindowThreadProcessId.restype = wintypes.DWORD
        self.user32.IsWindowVisible.argtypes = [wintypes.HWND]
        self.user32.IsWindowVisible.restype = wintypes.BOOL
        self.user32.GetClientRect.argtypes = [wintypes.HWND, ctypes.POINTER(_RECT)]
        self.user32.GetClientRect.restype = wintypes.BOOL

        self.imm32.ImmGetContext.argtypes = [wintypes.HWND]
        self.imm32.ImmGetContext.restype = wintypes.HANDLE
        self.imm32.ImmReleaseContext.argtypes = [wintypes.HWND, wintypes.HANDLE]
        self.imm32.ImmReleaseContext.restype = wintypes.BOOL
        self.imm32.ImmSetCompositionWindow.argtypes = [
            wintypes.HANDLE,
            ctypes.POINTER(_COMPOSITIONFORM),
        ]
        self.imm32.ImmSetCompositionWindow.restype = wintypes.BOOL
        self.imm32.ImmSetCandidateWindow.argtypes = [
            wintypes.HANDLE,
            ctypes.POINTER(_CANDIDATEFORM),
        ]
        self.imm32.ImmSetCandidateWindow.restype = wintypes.BOOL

    def _pid_for_hwnd(self, hwnd):
        pid = wintypes.DWORD(0)
        self.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        return int(pid.value)

    def _find_current_process_window(self):
        pid = os.getpid()
        fg = self.user32.GetForegroundWindow()
        if fg and self._pid_for_hwnd(fg) == pid:
            return int(fg)

        found = []
        ENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

        @ENUMPROC
        def enum_proc(hwnd, _lparam):
            try:
                if self._pid_for_hwnd(hwnd) == pid and self.user32.IsWindowVisible(hwnd):
                    rect = _RECT()
                    if self.user32.GetClientRect(hwnd, ctypes.byref(rect)):
                        area = max(0, rect.right - rect.left) * max(0, rect.bottom - rect.top)
                        found.append((area, int(hwnd)))
            except Exception:
                pass
            return True

        self.user32.EnumWindows(enum_proc, 0)
        if not found:
            return 0
        found.sort(reverse=True)
        return int(found[0][1])

    def _ensure_hwnd(self):
        if not self.available:
            return False
        try:
            fg = self.user32.GetForegroundWindow()
            if fg and self._pid_for_hwnd(fg) == os.getpid():
                self.hwnd = int(fg)
            elif not self.hwnd:
                self.hwnd = self._find_current_process_window()
        except Exception as exc:
            self.error = f"HWND {type(exc).__name__}: {exc}"
            return False
        return bool(self.hwnd)

    def _release_borrowed_context(self):
        if self.himc and self.hwnd:
            try:
                self.imm32.ImmReleaseContext(self.hwnd, self.himc)
            except Exception:
                pass
        self.himc = 0
        self.associated = False

    def update(self, *, active: bool, region, anchor):
        """Position the existing Blender IME context without owning it."""
        if not self.available:
            return
        if not active or region is None or not anchor:
            self._release_borrowed_context()
            self.last_anchor = None
            self.composing = False
            self.composition_text = ""
            return
        if not self._ensure_hwnd():
            return

        # Never keep an HIMC across frames. Borrow -> position -> release.
        self._release_borrowed_context()
        himc = self.imm32.ImmGetContext(self.hwnd)
        if not himc:
            return
        self.himc = int(himc)
        self.associated = True
        self.activation_count += 1
        try:
            rect = _RECT()
            if not self.user32.GetClientRect(self.hwnd, ctypes.byref(rect)):
                return
            client_h = int(rect.bottom - rect.top)
            ax, ay, ah = anchor
            client_x = int(round(float(region.x) + float(ax)))
            region_top = client_h - int(region.y + region.height)
            client_y = int(round(region_top + float(ay) + float(ah) + 3.0))
            pos = (client_x, client_y)
            if self.last_anchor == pos:
                return
            self.last_anchor = pos

            comp = _COMPOSITIONFORM()
            comp.dwStyle = self.CFS_POINT
            comp.ptCurrentPos = _POINT(client_x, client_y)
            self.imm32.ImmSetCompositionWindow(himc, ctypes.byref(comp))

            cand = _CANDIDATEFORM()
            cand.dwIndex = 0
            cand.dwStyle = self.CFS_CANDIDATEPOS
            cand.ptCurrentPos = _POINT(client_x, client_y)
            self.imm32.ImmSetCandidateWindow(himc, ctypes.byref(cand))
            self.position_updates += 1
        except Exception as exc:
            self.error = f"{type(exc).__name__}: {exc}"
        finally:
            self._release_borrowed_context()

    def drain_committed(self):
        # Native result interception is intentionally disabled in safe mode.
        out = []
        while self._committed:
            out.append(self._committed.popleft())
        return out

    def info(self):
        return {
            "available": bool(self.available),
            "safe_mode": True,
            "hwnd": int(self.hwnd or 0),
            "context": int(self.himc or 0),
            "associated": bool(self.associated),
            "activation_count": int(self.activation_count),
            "position_updates": int(self.position_updates),
            "anchor": self.last_anchor,
            "hook_installed": False,
            "hook_count": 0,
            "restore_count": 0,
            "ime_message_count": 0,
            "result_count": 0,
            "composition_count": 0,
            "composing": False,
            "composition_text": "",
            "last_result": "",
            "message_log": [],
            "error": self.error,
        }

    def shutdown(self):
        self._release_borrowed_context()
        self.last_anchor = None
        self.composing = False
        self.composition_text = ""
        self.available = False
