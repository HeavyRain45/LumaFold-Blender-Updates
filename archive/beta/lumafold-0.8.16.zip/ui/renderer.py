import ctypes

import gpu
import numpy as np
from gpu_extras.batch import batch_for_shader
from mathutils import Matrix


class BlenderImguiRenderer:
    def __init__(self, imgui):
        self.imgui = imgui
        self.context = imgui.create_context()
        self.io = imgui.get_io()
        self.io.delta_time = 1.0 / 60.0
        self.io.display_framebuffer_scale = (1.0, 1.0)
        self.io.backend_flags |= imgui.BackendFlags.RENDERER_HAS_VTX_OFFSET
        self.io.backend_flags |= imgui.BackendFlags.RENDERER_HAS_TEXTURES
        self._textures = {}
        self._next_tex_id = 1
        self._shader = self._create_shader()

    def ensure_context(self):
        self.imgui.set_current_context(self.context)

    def _create_shader(self):
        info_out = gpu.types.GPUStageInterfaceInfo("lumafold_imgui_iface")
        info_out.smooth("VEC2", "uv_interp")
        info_out.smooth("VEC4", "color_interp")
        info_out.smooth("VEC2", "pos_interp")

        info = gpu.types.GPUShaderCreateInfo()
        info.push_constant("MAT4", "ModelViewProjectionMatrix")
        info.push_constant("VEC4", "ClipRect")
        info.sampler(0, "FLOAT_2D", "Texture")
        info.vertex_in(0, "VEC2", "Position")
        info.vertex_in(1, "VEC2", "UV")
        info.vertex_in(2, "VEC4", "Color")
        info.vertex_out(info_out)
        info.fragment_out(0, "VEC4", "FragColor")
        info.vertex_source("""
        void main() {
            uv_interp = UV;
            color_interp = Color;
            pos_interp = Position;
            gl_Position = ModelViewProjectionMatrix * vec4(Position.xy, 0.0, 1.0);
        }
        """)
        info.fragment_source("""
        void main() {
            if (pos_interp.x < ClipRect.x || pos_interp.y < ClipRect.y ||
                pos_interp.x > ClipRect.z || pos_interp.y > ClipRect.w) discard;
            vec4 c = color_interp * texture(Texture, uv_interp);
            FragColor = c;
        }
        """)
        return gpu.shader.create_from_info(info)

    def _push_texture(self, tex):
        tex_id = self._next_tex_id
        self._next_tex_id += 1
        self._textures[tex_id] = tex
        return tex_id

    @staticmethod
    def _texture_buffer(width, height, rgba_bytes):
        pixels = np.frombuffer(rgba_bytes, dtype=np.uint8)
        expected = int(width) * int(height) * 4
        if pixels.size != expected:
            raise ValueError(f"RGBA texture size mismatch: {pixels.size} != {expected}")
        floats = pixels.astype(np.float32) / 255.0
        return gpu.types.Buffer("FLOAT", (int(height), int(width), 4), floats)

    def register_rgba_texture(self, width, height, rgba_bytes):
        """Upload a linear/ordinary application-owned RGBA8 texture."""
        buf = self._texture_buffer(width, height, rgba_bytes)
        tex = gpu.types.GPUTexture((int(width), int(height)), format="RGBA8", data=buf)
        return self._push_texture(tex)

    def register_srgb_texture(self, width, height, rgba_bytes):
        """Upload UI artwork authored as sRGB bytes.

        Blender's POST_PIXEL framebuffer is color-managed. Uploading Blender
        PreviewImage bytes as plain RGBA8 makes the sampler treat sRGB codes as
        linear values, so the framebuffer transfer brightens them a second time.
        Using Blender's native SRGB8_A8 texture format makes sampling decode the
        preview to linear first, matching Blender's own Asset Shelf appearance.
        """
        buf = self._texture_buffer(width, height, rgba_bytes)
        tex = gpu.types.GPUTexture((int(width), int(height)), format="SRGB8_A8", data=buf)
        return self._push_texture(tex)

    def unregister_texture(self, tex_id):
        self._textures.pop(int(tex_id), None)

    def _destroy_texture(self, tex_data):
        tex_id = tex_data.get_tex_id()
        self._textures.pop(tex_id, None)
        tex_data.set_tex_id(0)
        tex_data.set_status(self.imgui.TextureStatus.DESTROYED)

    def _update_texture(self, tex_data):
        status = tex_data.status
        if status in (self.imgui.TextureStatus.WANT_CREATE, self.imgui.TextureStatus.WANT_UPDATES):
            old = tex_data.get_tex_id()
            if old:
                self._textures.pop(old, None)
            pixels = np.frombuffer(tex_data.get_pixels(), dtype=np.uint8).astype(np.float32) / 255.0
            buf = gpu.types.Buffer("FLOAT", (tex_data.width, tex_data.height, 4), pixels)
            gpu_tex = gpu.types.GPUTexture((tex_data.width, tex_data.height), format="RGBA8", data=buf)
            tex_data.set_tex_id(self._push_texture(gpu_tex))
            tex_data.set_status(self.imgui.TextureStatus.OK)
        elif status == self.imgui.TextureStatus.WANT_DESTROY and tex_data.unused_frames > 0:
            self._destroy_texture(tex_data)

    def render(self, draw_data, width, height):
        if width <= 0 or height <= 0:
            return
        if getattr(draw_data, "textures", None) is not None:
            for tex_data in draw_data.textures:
                self._update_texture(tex_data)

        old_vm = gpu.matrix.get_model_view_matrix()
        old_pm = gpu.matrix.get_projection_matrix()
        proj = Matrix(((2.0 / width, 0, 0, -1),
                       (0, -2.0 / height, 0, 1),
                       (0, 0, 1, 0),
                       (0, 0, 0, 1)))
        gpu.matrix.push()
        gpu.matrix.load_matrix(Matrix.Identity(4))
        gpu.matrix.load_projection_matrix(proj)
        shader = self._shader
        shader.bind()
        gpu.state.blend_set("ALPHA")
        gpu.state.depth_mask_set(False)
        gpu.state.face_culling_set("NONE")
        gpu.state.depth_test_set("NONE")
        gpu.state.scissor_test_set(False)

        try:
            idx_type = ctypes.c_ushort if self.imgui.INDEX_SIZE == 2 else ctypes.c_uint
            floats_per_vertex = self.imgui.VERTEX_SIZE // ctypes.sizeof(ctypes.c_float)
            for draw_list in draw_data.commands_lists:
                idx_ptr = ctypes.cast(draw_list.idx_buffer_data, ctypes.POINTER(idx_type))
                idx_buf = np.ctypeslib.as_array(idx_ptr, shape=(draw_list.idx_buffer_size,))
                vtx_ptr = ctypes.cast(draw_list.vtx_buffer_data, ctypes.POINTER(ctypes.c_float))
                vtx_buf = np.ctypeslib.as_array(
                    vtx_ptr,
                    shape=(draw_list.vtx_buffer_size * floats_per_vertex,),
                ).reshape((-1, floats_per_vertex))
                vertices = vtx_buf[:, 0:2]
                uvs = vtx_buf[:, 2:4]
                colors = np.ascontiguousarray(vtx_buf[:, 4:]).view(np.uint8).reshape((-1, 4)).astype(np.float32) / 255.0

                for cmd in draw_list.commands:
                    tex_id = cmd.tex_ref.get_tex_id()
                    tex = self._textures.get(tex_id)
                    if tex is None:
                        continue
                    x1, y1, x2, y2 = cmd.clip_rect
                    shader.uniform_sampler("Texture", tex)
                    shader.uniform_float("ClipRect", (x1, y1, x2, y2))
                    indices = idx_buf[cmd.idx_offset: cmd.idx_offset + cmd.elem_count].astype(np.int32)
                    # vtx_offset support: translate command-local indices into the shared vertex buffer.
                    if cmd.vtx_offset:
                        indices = indices + int(cmd.vtx_offset)
                    batch = batch_for_shader(
                        shader,
                        "TRIS",
                        {"Position": vertices, "UV": uvs, "Color": colors},
                        indices=indices,
                    )
                    batch.draw(shader)
        finally:
            gpu.state.blend_set("NONE")
            gpu.state.depth_mask_set(True)
            gpu.matrix.pop()
            gpu.matrix.load_matrix(old_vm)
            gpu.matrix.load_projection_matrix(old_pm)

    def shutdown(self):
        self.ensure_context()
        try:
            for tex_data in self.imgui.get_platform_io().textures:
                if tex_data.get_tex_id():
                    self._destroy_texture(tex_data)
        except Exception:
            pass
        self._textures.clear()
        self.imgui.destroy_context(self.context)
        self.context = None
