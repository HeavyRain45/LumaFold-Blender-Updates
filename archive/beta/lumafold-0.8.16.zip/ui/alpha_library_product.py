from __future__ import annotations

"""Alpha Library lightweight asset-management composition.

This module keeps the existing Alpha Library structure intact and turns its
existing folder controls into useful product behavior. Mutations cross the
boundary exclusively through named Core commands; the UI never edits files or
scans the filesystem itself.

Product semantics:

* left-click ``+`` keeps the one-confirm mixed Alpha picker;
* right-click ``+`` opens the tiny "新建 LumaFold 文件夹" action;
* linked folders can be removed without touching user source files;
* LumaFold-managed subfolders can be deleted from LumaFold's own user-data root;
* individually imported Alpha images live only in ``全部``;
* right-click ``删除 Alpha`` deletes a LumaFold-managed copy, but merely hides an
  Alpha that belongs to an externally linked folder.
"""

from typing import Any

from . import sculpt_view_foundation as foundation

_INSTALLED = False
_ORIGINAL_DRAW = None


def _command_for_action(action: str):
    return {
        "add_alpha": "sculpt.alpha.source_add_dialog",
        "create_folder": "sculpt.alpha.user_folder_create_dialog",
        "remove_folder": "sculpt.alpha.folder_remove",
        "delete_asset": "sculpt.alpha.asset_delete",
        "restore_hidden": "sculpt.alpha.source_restore_hidden",
    }.get(str(action or ""), "")


def _dispatch_product_action(action: str, **kwargs):
    """Send one public Alpha command through the current host boundary."""
    command_id = _command_for_action(action)
    if not command_id:
        return False

    # Blender/Embedded path. Import bpy only at action time so the same UI module
    # remains importable by the standalone Secondary Surface Python process.
    try:
        import bpy  # type: ignore  # noqa: F401
    except Exception:
        bpy = None

    if bpy is not None:
        try:
            from ..core.app import APP
            APP.execute(command_id, **dict(kwargs))
            return True
        except Exception:
            return False

    # Native Secondary path. secondary_surface_host_runtime deliberately owns
    # network transport; the product UI asks only for its tiny command adapter.
    try:
        import __main__
        queue_command = getattr(__main__, "_queue_command", None)
        if callable(queue_command):
            queue_command(command_id, **dict(kwargs))
            return True
    except Exception:
        pass
    return False


def _folder_for_scope(folders, scope: str):
    scope = str(scope or "")
    if not scope.startswith("folder:"):
        return None
    folder_id = scope[7:]
    for raw in list(folders or ()):
        folder = dict(raw or {})
        if str(folder.get("id") or "") == folder_id:
            return folder
    return None


def _linked_item(item):
    item = dict(item or {})
    source_id = str(item.get("linked_source_id") or "")
    if not source_id and str(item.get("source_type") or "") == "linked":
        folder_id = str(item.get("folder_id") or "")
        if folder_id.startswith("alpha|linked|"):
            source_id = folder_id
    return source_id


def _managed_item(item):
    item = dict(item or {})
    folder_id = str(item.get("folder_id") or "")
    return bool(item.get("managed", False)) or folder_id.startswith("alpha|lumafold_user|")


def _draw_folder_context(imgui, scale: float, folder: dict):
    folder_id = str(folder.get("id") or "")
    if not folder_id or not bool(folder.get("removable", False)):
        return
    popup_name = "Alpha Folder##product_context"
    if not imgui.begin_popup(popup_name):
        return
    try:
        managed = bool(folder.get("managed", False)) or str(folder.get("source_type") or "") == "managed"
        hidden_count = max(0, int(folder.get("hidden_count", 0) or 0))
        visible_count = max(0, int(folder.get("count", 0) or 0))
        total_count = max(visible_count + hidden_count, int(folder.get("total_count", 0) or 0))
        missing = bool(folder.get("missing", False))

        foundation.text(imgui, str(folder.get("label") or "Alpha 文件夹"), scale, kind="body")
        foundation.text(
            imgui,
            "LumaFold 用户文件夹" if managed else "本地文件夹 · LumaFold 只保存链接",
            scale,
            kind="small",
            color=foundation.T.TEXT_SECONDARY,
        )
        foundation.text(
            imgui,
            f"{total_count} 个 Alpha" if managed else f"可见 {visible_count} · 隐藏 {hidden_count} · 共 {total_count}",
            scale,
            kind="small",
            color=foundation.T.TEXT_SECONDARY,
        )
        if missing:
            foundation.text(
                imgui,
                "文件夹路径当前不可用 · 仍可安全移除链接",
                scale,
                kind="small",
                color=foundation.T.TEXT_SECONDARY,
            )
        imgui.separator()
        width = max(foundation.px(112.0, scale), float(imgui.get_content_region_avail()[0]))

        if not managed:
            restore_label = f"恢复隐藏 Alpha ({hidden_count})" if hidden_count else "恢复隐藏 Alpha"
            if foundation.button(
                imgui, restore_label, scale, width / scale,
                kind="small", height=foundation.CONTEXT_MENU.row_h,
                disabled=(hidden_count <= 0),
            ):
                _dispatch_product_action("restore_hidden", source_id=folder_id)
                try:
                    imgui.close_current_popup()
                except Exception:
                    pass

        remove_label = "删除文件夹" if managed else "从 LumaFold 移除文件夹"
        if foundation.button(
            imgui, remove_label, scale, width / scale,
            kind="small", height=foundation.CONTEXT_MENU.row_h,
        ):
            _dispatch_product_action("remove_folder", folder_id=folder_id)
            try:
                imgui.close_current_popup()
            except Exception:
                pass
        foundation.text(
            imgui,
            "删除该 LumaFold 文件夹及其中由 LumaFold 管理的 Alpha" if managed else "不会删除硬盘中的文件夹或 Alpha 文件",
            scale,
            kind="small",
            color=foundation.T.TEXT_SECONDARY,
        )
    finally:
        imgui.end_popup()


def _draw_add_context(imgui, scale: float):
    popup_name = "Alpha Add##product_context"
    if not imgui.begin_popup(popup_name):
        return
    try:
        width = max(foundation.px(150.0, scale), float(imgui.get_content_region_avail()[0]))
        if foundation.button(
            imgui, "新建 LumaFold 文件夹", scale, width / scale,
            kind="small", height=foundation.CONTEXT_MENU.row_h,
        ):
            _dispatch_product_action("create_folder")
            try:
                imgui.close_current_popup()
            except Exception:
                pass
        foundation.text(
            imgui,
            "左键 + 仍用于添加 Alpha 图片或链接本地文件夹",
            scale,
            kind="small",
            color=foundation.T.TEXT_SECONDARY,
        )
    finally:
        imgui.end_popup()


def draw_alpha_library_product(imgui, sculpt, scale, **kwargs):
    """Compose lightweight folder management over the frozen Alpha UI."""
    if _ORIGINAL_DRAW is None:
        return None

    ui = kwargs.get("library_ui_state")
    if ui is None:
        ui = {}
        kwargs["library_ui_state"] = ui
    folders = list((sculpt or {}).get("alpha_library_folders") or ())
    assets = list((sculpt or {}).get("alpha_library_assets") or ())

    original_button = foundation.button
    original_begin_disabled = getattr(imgui, "begin_disabled", None)
    original_end_disabled = getattr(imgui, "end_disabled", None)
    original_begin_popup = getattr(imgui, "begin_popup", None)
    original_end_popup = getattr(imgui, "end_popup", None)
    original_set_tooltip = getattr(imgui, "set_tooltip", None)

    state = {
        "skip_remove_disabled": False,
        "alpha_asset_popup": False,
        "alpha_folder_context_id": "",
    }

    def selected_folder():
        return _folder_for_scope(folders, str(ui.get("alpha_scope") or "all"))

    def button_product(imgui_arg, label, scale_arg=1.0, width=0.0, **button_kwargs):
        label_text = str(label or "")

        # Keep the fastest existing behavior: left-click opens the mixed picker.
        # Right-click exposes only the optional managed-folder creation action.
        if label_text == "+##alpha_folder_add":
            clicked = original_button(imgui_arg, label, scale_arg, width, **button_kwargs)
            if clicked:
                _dispatch_product_action("add_alpha")
            try:
                right_clicked = bool(imgui_arg.is_item_clicked(imgui_arg.MouseButton.RIGHT))
            except Exception:
                right_clicked = False
            if right_clicked:
                try:
                    imgui_arg.open_popup("Alpha Add##product_context")
                except Exception:
                    pass
            _draw_add_context(imgui_arg, scale_arg)
            state["skip_remove_disabled"] = True
            return False

        if label_text == "−##alpha_folder_remove":
            folder = selected_folder()
            removable = bool(folder and folder.get("removable", False))
            clean = dict(button_kwargs)
            clean["disabled"] = not removable
            clicked = original_button(imgui_arg, label, scale_arg, width, **clean)
            if clicked and removable:
                _dispatch_product_action("remove_folder", folder_id=str(folder.get("id") or ""))
                ui["alpha_scope"] = "all"
            return False

        result = original_button(imgui_arg, label, scale_arg, width, **button_kwargs)

        # Folder right-click exposes only operations already represented by the
        # left navigation. No new navigation structure is introduced here.
        marker = "##alpha_folder_"
        if marker in label_text:
            folder_id = label_text.split(marker, 1)[1]
            try:
                right_clicked = bool(imgui_arg.is_item_clicked(imgui_arg.MouseButton.RIGHT))
            except Exception:
                right_clicked = False
            if right_clicked:
                state["alpha_folder_context_id"] = folder_id
                try:
                    imgui_arg.open_popup("Alpha Folder##product_context")
                except Exception:
                    pass
            folder = next(
                (dict(raw or {}) for raw in folders if str((raw or {}).get("id") or "") == str(folder_id)),
                None,
            )
            if folder:
                _draw_folder_context(imgui_arg, scale_arg, folder)
        return result

    def begin_disabled_product(disabled=True):
        if state.get("skip_remove_disabled"):
            # The frozen foundation deliberately disabled '-' before real source
            # ownership existed. Product policy now decides it from folder truth.
            state["skip_remove_disabled"] = False
            state["remove_disable_noop"] = True
            return None
        if callable(original_begin_disabled):
            return original_begin_disabled(disabled)
        return None

    def end_disabled_product():
        if state.pop("remove_disable_noop", False):
            return None
        if callable(original_end_disabled):
            return original_end_disabled()
        return None

    def begin_popup_product(name, *args, **popup_kwargs):
        opened = original_begin_popup(name, *args, **popup_kwargs) if callable(original_begin_popup) else False
        if str(name) == "Alpha Asset##library_context" and opened:
            state["alpha_asset_popup"] = True
        return opened

    def end_popup_product(*args, **popup_kwargs):
        if state.get("alpha_asset_popup"):
            state["alpha_asset_popup"] = False
            identity = str(ui.get("alpha_context_identity") or "")
            item = next(
                (dict(raw or {}) for raw in assets if str((raw or {}).get("identity") or "") == identity),
                None,
            )
            source_id = _linked_item(item)
            managed = _managed_item(item)
            if source_id or managed:
                try:
                    imgui.separator()
                    width = max(foundation.px(112.0, scale), float(imgui.get_content_region_avail()[0]))
                    if original_button(
                        imgui, "删除 Alpha", scale, width / scale,
                        kind="small", height=foundation.CONTEXT_MENU.row_h,
                    ):
                        _dispatch_product_action(
                            "delete_asset",
                            identity=identity,
                            filepath=str((item or {}).get("filepath") or ""),
                            folder_id=str((item or {}).get("folder_id") or ""),
                            source_id=source_id,
                        )
                        try:
                            imgui.close_current_popup()
                        except Exception:
                            pass
                    foundation.text(
                        imgui,
                        "删除 LumaFold 管理的副本" if managed else "只从 LumaFold 隐藏；本地原文件不会删除",
                        scale,
                        kind="small",
                        color=foundation.T.TEXT_SECONDARY,
                    )
                except Exception:
                    pass
        if callable(original_end_popup):
            return original_end_popup(*args, **popup_kwargs)
        return None

    def tooltip_product(value: Any):
        text = str(value or "")
        if text == "导入 Alpha 图片到当前 Blender 文件":
            text = "左键：添加 Alpha 图片或链接本地文件夹 · 右键：新建 LumaFold 文件夹"
        elif text == "删除/移除文件夹将在后续接入真实资产管理":
            folder = selected_folder()
            if folder and bool(folder.get("removable", False)):
                managed = bool(folder.get("managed", False)) or str(folder.get("source_type") or "") == "managed"
                text = "删除该 LumaFold 文件夹" if managed else "从 LumaFold 移除该文件夹 · 本地文件不会删除"
            else:
                text = "请选择一个可管理的 Alpha 文件夹"
        if callable(original_set_tooltip):
            return original_set_tooltip(text)
        return None

    patched = []
    foundation.button = button_product
    try:
        if callable(original_begin_disabled):
            setattr(imgui, "begin_disabled", begin_disabled_product)
            patched.append((imgui, "begin_disabled", original_begin_disabled))
        if callable(original_end_disabled):
            setattr(imgui, "end_disabled", end_disabled_product)
            patched.append((imgui, "end_disabled", original_end_disabled))
        if callable(original_begin_popup):
            setattr(imgui, "begin_popup", begin_popup_product)
            patched.append((imgui, "begin_popup", original_begin_popup))
        if callable(original_end_popup):
            setattr(imgui, "end_popup", end_popup_product)
            patched.append((imgui, "end_popup", original_end_popup))
        if callable(original_set_tooltip):
            setattr(imgui, "set_tooltip", tooltip_product)
            patched.append((imgui, "set_tooltip", original_set_tooltip))
        return _ORIGINAL_DRAW(imgui, sculpt, scale, **kwargs)
    finally:
        foundation.button = original_button
        for owner, name, original in reversed(patched):
            try:
                setattr(owner, name, original)
            except Exception:
                pass


def install():
    global _INSTALLED, _ORIGINAL_DRAW
    if _INSTALLED:
        return
    _ORIGINAL_DRAW = foundation.draw_alpha_library_foundation
    foundation.draw_alpha_library_foundation = draw_alpha_library_product
    _INSTALLED = True


def uninstall():
    global _INSTALLED, _ORIGINAL_DRAW
    if not _INSTALLED:
        return
    if _ORIGINAL_DRAW is not None:
        foundation.draw_alpha_library_foundation = _ORIGINAL_DRAW
    _ORIGINAL_DRAW = None
    _INSTALLED = False
