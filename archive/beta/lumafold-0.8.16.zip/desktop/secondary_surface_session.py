from __future__ import annotations

"""Product-level open semantics for Satellite Secondary surfaces.

The native runtime owns child-process/HWND mechanics and outside/ESC dismissal.
Product controls express an idempotent *open this surface* intent instead of a
window toggle.  Repeating the same intent while the requested surface is already
visible must never close it; closing remains owned by outside click / Escape.

This separation prevents one UI click (or two near-identical product callbacks)
from becoming an accidental open-then-close race while preserving the runtime's
existing lazy child launch and pending-open queue.

The production Satellite wrapper imports this module immediately after its native
runtime.  Install the companion Primary geometry lifecycle at the same desktop
session boundary so Secondary opening and Primary layout epochs remain separate
owners while sharing one explicit Satellite composition point.
"""

from desktop import primary_geometry_session as _primary_geometry_session
from desktop import satellite_host_runtime as _satellite_runtime

_primary_geometry_session.install(_satellite_runtime)


def open_surface(runtime, kind: str = "brush_library", anchor=None):
    kind = str(kind or "brush_library")
    anchor = dict(anchor or {})

    proc, hwnd = runtime._ensure_secondary_surface(wait=False)
    if proc is None:
        return None

    # Child creation is asynchronous.  The runtime already owns one pending-open
    # slot; keep the newest product intent there until the HWND becomes ready.
    if hwnd is None:
        runtime.secondary_pending_request = (kind, anchor)
        return proc

    try:
        already_visible = bool(runtime.user32.IsWindowVisible(hwnd))
    except Exception:
        already_visible = False

    # OPEN is idempotent. Do not route a repeated product intent back through the
    # legacy toggle branch, because that branch intentionally hides same-kind UI.
    if already_visible and str(runtime.secondary_kind or "") == kind:
        return proc

    return runtime._toggle_secondary_surface(kind, anchor)
