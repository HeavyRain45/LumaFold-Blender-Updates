from __future__ import annotations

"""State-preserving transport policy for Native Secondary surfaces.

Secondary workers are allowed to replace their local UI snapshot only with an
actual state-bearing bridge response. Mutation commands normally return an
acknowledgement, not the full Store snapshot. This adapter turns a successful
mutation into an acknowledgement + immediate get_state transaction so command
responses can never blank the Native Secondary UI.
"""

_INSTALLED = False
_RUNTIME = None
_ORIGINAL_REQUEST = None


def _state_bearing(response) -> bool:
    return bool(
        isinstance(response, dict)
        and bool(response.get("ok"))
        and isinstance(response.get("state"), dict)
    )


def install(runtime_module):
    global _INSTALLED, _RUNTIME, _ORIGINAL_REQUEST
    if _INSTALLED:
        return
    original = getattr(runtime_module, "request", None)
    if not callable(original):
        raise RuntimeError("Secondary transport request adapter is unavailable")

    _RUNTIME = runtime_module
    _ORIGINAL_REQUEST = original

    def request(payload, timeout=1.5):
        payload = dict(payload or {})
        response = original(payload, timeout=timeout)
        if not isinstance(response, dict) or not bool(response.get("ok")):
            return response

        # Real get_state responses already carry the authoritative snapshot.
        if _state_bearing(response):
            return response

        # Commands/set-state acknowledgements must never be interpreted as an
        # empty snapshot by the Secondary worker. Pull fresh Store truth now,
        # while keeping the original command result fields for diagnostics.
        action = str(payload.get("action") or "")
        if action == "get_state":
            return response
        try:
            fresh = original({"action": "get_state"}, timeout=timeout)
        except Exception:
            return response
        if not _state_bearing(fresh):
            return response

        merged = dict(response)
        merged["state"] = dict(fresh.get("state") or {})
        merged["post_action_state"] = True
        return merged

    runtime_module.request = request
    _INSTALLED = True


def uninstall():
    global _INSTALLED, _RUNTIME, _ORIGINAL_REQUEST
    if not _INSTALLED:
        return
    if _RUNTIME is not None and callable(_ORIGINAL_REQUEST):
        _RUNTIME.request = _ORIGINAL_REQUEST
    _RUNTIME = None
    _ORIGINAL_REQUEST = None
    _INSTALLED = False
