# Standalone LumaFold Desktop Host P0.11.
# stdlib + Win32 only: no bpy, no slimgui, no third-party dependency.
from __future__ import annotations

import argparse
import ctypes
from ctypes import wintypes
import json
import queue
import socket
import threading
import time


def _wt(name, fallback):
    return getattr(wintypes, name, fallback)

HANDLE = _wt("HANDLE", ctypes.c_void_p)
HWND = _wt("HWND", HANDLE)
HDC = _wt("HDC", HANDLE)
HINSTANCE = _wt("HINSTANCE", HANDLE)
HMODULE = _wt("HMODULE", HINSTANCE)
HMENU = _wt("HMENU", HANDLE)
HICON = _wt("HICON", HANDLE)
HCURSOR = _wt("HCURSOR", HANDLE)
HBRUSH = _wt("HBRUSH", HANDLE)
HFONT = _wt("HFONT", HANDLE)
HGDIOBJ = _wt("HGDIOBJ", HANDLE)
ATOM = _wt("ATOM", ctypes.c_ushort)

parser = argparse.ArgumentParser(add_help=False)
parser.add_argument("--port", type=int, required=True)
parser.add_argument("--token", required=True)
parser.add_argument("--parent-pid", type=int, required=True)
ARGS = parser.parse_args()

HOST = "127.0.0.1"
CLIENT = "LumaFold Desktop Host P0.11.1"

# ---------- Win32 DLLs / robust signatures ----------
user32 = ctypes.WinDLL("user32", use_last_error=True)
gdi32 = ctypes.WinDLL("gdi32", use_last_error=True)
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

LRESULT = ctypes.c_ssize_t
COLORREF = wintypes.DWORD
LPVOID = ctypes.c_void_p

WM_DESTROY = 0x0002
WM_PAINT = 0x000F
WM_CLOSE = 0x0010
WM_SIZE = 0x0005
WM_ERASEBKGND = 0x0014
WM_GETMINMAXINFO = 0x0024
WM_DPICHANGED = 0x02E0
WM_LBUTTONDOWN = 0x0201
WM_LBUTTONUP = 0x0202
WM_MOUSEMOVE = 0x0200
WM_APP_UPDATE = 0x8001
SRCCOPY = 0x00CC0020
CS_HREDRAW = 0x0002
CS_VREDRAW = 0x0001
WS_OVERLAPPEDWINDOW = 0x00CF0000
WS_VISIBLE = 0x10000000
CW_USEDEFAULT = 0x80000000
IDC_ARROW = 32512
SW_SHOW = 5
DT_LEFT = 0x00000000
DT_CENTER = 0x00000001
DT_RIGHT = 0x00000002
DT_VCENTER = 0x00000004
DT_SINGLELINE = 0x00000020
TRANSPARENT = 1
SWP_NOZORDER = 0x0004
SWP_NOACTIVATE = 0x0010
PROCESS_PER_MONITOR_DPI_AWARE = 2
DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2 = ctypes.c_void_p(-4)


def RGB(r, g, b):
    return r | (g << 8) | (b << 16)


class PAINTSTRUCT(ctypes.Structure):
    _fields_ = [
        ("hdc", HDC), ("fErase", wintypes.BOOL), ("rcPaint", wintypes.RECT),
        ("fRestore", wintypes.BOOL), ("fIncUpdate", wintypes.BOOL), ("rgbReserved", ctypes.c_byte * 32),
    ]


class POINT(ctypes.Structure):
    _fields_ = [("x", wintypes.LONG), ("y", wintypes.LONG)]


class MINMAXINFO(ctypes.Structure):
    _fields_ = [
        ("ptReserved", POINT), ("ptMaxSize", POINT), ("ptMaxPosition", POINT),
        ("ptMinTrackSize", POINT), ("ptMaxTrackSize", POINT),
    ]


WNDPROC = ctypes.WINFUNCTYPE(ctypes.c_ssize_t, HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM)


class WNDCLASSEXW(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.UINT), ("style", wintypes.UINT), ("lpfnWndProc", WNDPROC),
        ("cbClsExtra", ctypes.c_int), ("cbWndExtra", ctypes.c_int), ("hInstance", HINSTANCE),
        ("hIcon", HICON), ("hCursor", HANDLE), ("hbrBackground", HBRUSH),
        ("lpszMenuName", wintypes.LPCWSTR), ("lpszClassName", wintypes.LPCWSTR), ("hIconSm", HICON),
    ]

# Core signatures.
user32.RegisterClassExW.argtypes = [ctypes.POINTER(WNDCLASSEXW)]; user32.RegisterClassExW.restype = ATOM
user32.CreateWindowExW.argtypes = [wintypes.DWORD,wintypes.LPCWSTR,wintypes.LPCWSTR,wintypes.DWORD,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_int,HWND,HMENU,HINSTANCE,LPVOID]; user32.CreateWindowExW.restype = HWND
user32.DefWindowProcW.argtypes = [HWND,wintypes.UINT,wintypes.WPARAM,wintypes.LPARAM]; user32.DefWindowProcW.restype = LRESULT
user32.LoadCursorW.argtypes = [HINSTANCE,wintypes.LPCWSTR]; user32.LoadCursorW.restype = HCURSOR
user32.BeginPaint.argtypes = [HWND,ctypes.POINTER(PAINTSTRUCT)]; user32.BeginPaint.restype = HDC
user32.EndPaint.argtypes = [HWND,ctypes.POINTER(PAINTSTRUCT)]; user32.EndPaint.restype = wintypes.BOOL
user32.GetClientRect.argtypes = [HWND,ctypes.POINTER(wintypes.RECT)]; user32.GetClientRect.restype = wintypes.BOOL
user32.FillRect.argtypes = [HDC,ctypes.POINTER(wintypes.RECT),HBRUSH]; user32.FillRect.restype = ctypes.c_int
user32.DrawTextW.argtypes = [HDC,wintypes.LPCWSTR,ctypes.c_int,ctypes.POINTER(wintypes.RECT),wintypes.UINT]; user32.DrawTextW.restype = ctypes.c_int
user32.InvalidateRect.argtypes = [HWND,ctypes.POINTER(wintypes.RECT),wintypes.BOOL]; user32.InvalidateRect.restype = wintypes.BOOL
user32.SetCapture.argtypes = [HWND]; user32.SetCapture.restype = HWND
user32.ReleaseCapture.argtypes = []; user32.ReleaseCapture.restype = wintypes.BOOL
user32.DestroyWindow.argtypes = [HWND]; user32.DestroyWindow.restype = wintypes.BOOL
user32.PostQuitMessage.argtypes = [ctypes.c_int]; user32.PostQuitMessage.restype = None
user32.ShowWindow.argtypes = [HWND,ctypes.c_int]; user32.ShowWindow.restype = wintypes.BOOL
user32.UpdateWindow.argtypes = [HWND]; user32.UpdateWindow.restype = wintypes.BOOL
user32.GetMessageW.argtypes = [ctypes.POINTER(wintypes.MSG),HWND,wintypes.UINT,wintypes.UINT]; user32.GetMessageW.restype = wintypes.BOOL
user32.TranslateMessage.argtypes = [ctypes.POINTER(wintypes.MSG)]; user32.TranslateMessage.restype = wintypes.BOOL
user32.DispatchMessageW.argtypes = [ctypes.POINTER(wintypes.MSG)]; user32.DispatchMessageW.restype = LRESULT
user32.PostMessageW.argtypes = [HWND,wintypes.UINT,wintypes.WPARAM,wintypes.LPARAM]; user32.PostMessageW.restype = wintypes.BOOL
user32.SetWindowPos.argtypes = [HWND,HWND,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_int,wintypes.UINT]; user32.SetWindowPos.restype = wintypes.BOOL

# Optional DPI APIs are resolved defensively for older Windows builds.
if hasattr(user32, "SetProcessDpiAwarenessContext"):
    user32.SetProcessDpiAwarenessContext.argtypes = [ctypes.c_void_p]
    user32.SetProcessDpiAwarenessContext.restype = wintypes.BOOL
if hasattr(user32, "SetProcessDPIAware"):
    user32.SetProcessDPIAware.argtypes = []
    user32.SetProcessDPIAware.restype = wintypes.BOOL
if hasattr(user32, "GetDpiForWindow"):
    user32.GetDpiForWindow.argtypes = [HWND]
    user32.GetDpiForWindow.restype = wintypes.UINT

kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]; kernel32.GetModuleHandleW.restype = HMODULE
kernel32.OpenProcess.argtypes = [wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]; kernel32.OpenProcess.restype = HANDLE
kernel32.GetExitCodeProcess.argtypes = [HANDLE,ctypes.POINTER(wintypes.DWORD)]; kernel32.GetExitCodeProcess.restype = wintypes.BOOL
kernel32.CloseHandle.argtypes = [HANDLE]; kernel32.CloseHandle.restype = wintypes.BOOL

gdi32.CreateSolidBrush.argtypes = [COLORREF]; gdi32.CreateSolidBrush.restype = HBRUSH
gdi32.CreatePen.argtypes = [ctypes.c_int,ctypes.c_int,COLORREF]; gdi32.CreatePen.restype = HANDLE
gdi32.CreateFontW.argtypes = [ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_int,wintypes.DWORD,wintypes.DWORD,wintypes.DWORD,wintypes.DWORD,wintypes.DWORD,wintypes.DWORD,wintypes.DWORD,wintypes.DWORD,wintypes.LPCWSTR]; gdi32.CreateFontW.restype = HFONT
gdi32.SelectObject.argtypes = [HDC,HGDIOBJ]; gdi32.SelectObject.restype = HGDIOBJ
gdi32.DeleteObject.argtypes = [HGDIOBJ]; gdi32.DeleteObject.restype = wintypes.BOOL
gdi32.MoveToEx.argtypes = [HDC,ctypes.c_int,ctypes.c_int,ctypes.c_void_p]; gdi32.MoveToEx.restype = wintypes.BOOL
gdi32.LineTo.argtypes = [HDC,ctypes.c_int,ctypes.c_int]; gdi32.LineTo.restype = wintypes.BOOL
gdi32.SetBkMode.argtypes = [HDC,ctypes.c_int]; gdi32.SetBkMode.restype = ctypes.c_int
gdi32.SetTextColor.argtypes = [HDC,COLORREF]; gdi32.SetTextColor.restype = COLORREF
gdi32.CreateCompatibleDC.argtypes = [HDC]; gdi32.CreateCompatibleDC.restype = HDC
gdi32.DeleteDC.argtypes = [HDC]; gdi32.DeleteDC.restype = wintypes.BOOL
gdi32.CreateCompatibleBitmap.argtypes = [HDC,ctypes.c_int,ctypes.c_int]; gdi32.CreateCompatibleBitmap.restype = HANDLE
gdi32.BitBlt.argtypes = [HDC,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_int,HDC,ctypes.c_int,ctypes.c_int,wintypes.DWORD]; gdi32.BitBlt.restype = wintypes.BOOL


def enable_dpi_awareness():
    try:
        if hasattr(user32, "SetProcessDpiAwarenessContext") and user32.SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2):
            return "Per-Monitor V2"
    except Exception:
        pass
    try:
        shcore = ctypes.WinDLL("shcore", use_last_error=True)
        shcore.SetProcessDpiAwareness.argtypes = [ctypes.c_int]
        shcore.SetProcessDpiAwareness.restype = ctypes.c_long
        if shcore.SetProcessDpiAwareness(PROCESS_PER_MONITOR_DPI_AWARE) == 0:
            return "Per-Monitor"
    except Exception:
        pass
    try:
        if hasattr(user32, "SetProcessDPIAware") and user32.SetProcessDPIAware():
            return "System DPI"
    except Exception:
        pass
    return "Legacy DPI"

DPI_MODE = enable_dpi_awareness()

# ---------- bridge client ----------
state_lock = threading.Lock()
bridge_state = {}
connected = False
last_error = "Connecting..."
actions = queue.Queue()
closing = False
hwnd_main = None
last_rtt_ms = 0.0
sync_count = 0
reconnect_count = 0
was_connected = False
last_sync_monotonic = 0.0
last_state_revision = 0


def request(payload, timeout=1.5):
    global last_rtt_ms
    payload = dict(payload)
    payload["token"] = ARGS.token
    payload["client"] = CLIENT
    started = time.perf_counter()
    with socket.create_connection((HOST, ARGS.port), timeout=timeout) as sock:
        sock.settimeout(timeout)
        sock.sendall((json.dumps(payload, ensure_ascii=False) + "\n").encode("utf-8"))
        data = b""
        while b"\n" not in data and len(data) < 512 * 1024:
            chunk = sock.recv(65536)
            if not chunk:
                break
            data += chunk
    last_rtt_ms = (time.perf_counter() - started) * 1000.0
    if not data:
        raise RuntimeError("empty bridge response")
    return json.loads(data.split(b"\n", 1)[0].decode("utf-8"))


def parent_alive():
    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
    STILL_ACTIVE = 259
    handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, ARGS.parent_pid)
    if not handle:
        return False
    code = wintypes.DWORD()
    ok = kernel32.GetExitCodeProcess(handle, ctypes.byref(code))
    kernel32.CloseHandle(handle)
    return bool(ok and code.value == STILL_ACTIVE)


def network_worker():
    global connected, last_error, closing, bridge_state, sync_count, reconnect_count, was_connected, last_sync_monotonic, last_state_revision
    failures = 0
    while not closing:
        if not parent_alive():
            if hwnd_main:
                user32.PostMessageW(hwnd_main, WM_CLOSE, 0, 0)
            return
        try:
            try:
                action = actions.get(timeout=0.16)
            except queue.Empty:
                action = {"action": "get_state"}
            resp = request(action)
            if not resp.get("ok"):
                raise RuntimeError(resp.get("error") or "bridge request failed")
            with state_lock:
                if "state" in resp:
                    incoming = resp["state"]
                    # Keep the desktop's local slider authoritative while the
                    # user owns the drag gesture. This prevents a slightly older
                    # bridge snapshot from visually snapping the thumb back.
                    bridge_state = incoming
                    last_state_revision += 1
            if not was_connected and sync_count > 0:
                reconnect_count += 1
            connected = True
            was_connected = True
            failures = 0
            last_error = ""
            sync_count += 1
            last_sync_monotonic = time.monotonic()
        except Exception as exc:
            connected = False
            was_connected = False
            failures += 1
            last_error = str(exc)
            time.sleep(min(0.05 * failures, 0.5))
        if hwnd_main:
            user32.PostMessageW(hwnd_main, WM_APP_UPDATE, 0, 0)

# ---------- UI state ----------
RECTS = {}
slider_drag = False
local_slider = 0.35
font_main = None
font_small = None
font_title = None
font_big = None
current_dpi = 96
ui_scale = 1.0


def S(v):
    return int(round(float(v) * ui_scale))


def rect(x1, y1, x2, y2):
    return wintypes.RECT(S(x1), S(y1), S(x2), S(y2))


def raw_rect(x1, y1, x2, y2):
    return wintypes.RECT(int(x1), int(y1), int(x2), int(y2))


def fill(hdc, r, color):
    brush = gdi32.CreateSolidBrush(color)
    user32.FillRect(hdc, ctypes.byref(r), brush)
    gdi32.DeleteObject(brush)


def line(hdc, x1, y1, x2, y2, color):
    pen = gdi32.CreatePen(0, max(1, S(1)), color)
    old = gdi32.SelectObject(hdc, pen)
    gdi32.MoveToEx(hdc, S(x1), S(y1), None)
    gdi32.LineTo(hdc, S(x2), S(y2))
    gdi32.SelectObject(hdc, old)
    gdi32.DeleteObject(pen)


def text(hdc, value, r, color, font=None, flags=DT_LEFT | DT_VCENTER | DT_SINGLELINE):
    old = gdi32.SelectObject(hdc, font) if font else None
    gdi32.SetBkMode(hdc, TRANSPARENT)
    gdi32.SetTextColor(hdc, color)
    user32.DrawTextW(hdc, str(value), -1, ctypes.byref(r), flags)
    if old:
        gdi32.SelectObject(hdc, old)


def button(hdc, key, label, r, accent=False):
    RECTS[key] = r
    fill(hdc, r, RGB(78, 142, 216) if accent else RGB(74, 74, 77))
    text(hdc, label, r, RGB(246, 246, 246), font_main, DT_CENTER | DT_VCENTER | DT_SINGLELINE)


def inside(x, y, r):
    return r.left <= x < r.right and r.top <= y < r.bottom


def get_xy(lparam):
    return ctypes.c_short(lparam & 0xFFFF).value, ctypes.c_short((lparam >> 16) & 0xFFFF).value


def enqueue(action):
    actions.put(action)


def update_slider(x):
    global local_slider
    r = RECTS.get("slider")
    if not r:
        return
    local_slider = max(0.0, min(1.0, (x - r.left) / max(1.0, r.right - r.left)))
    # Repaint only the slider/value band while dragging. The main UI is still
    # double-buffered, but this also avoids needless work on every mouse move.
    dirty = wintypes.RECT(r.left, max(0, r.top - S(34)), r.right, r.bottom + S(6))
    user32.InvalidateRect(hwnd_main, ctypes.byref(dirty), False)


def recreate_fonts():
    global font_main, font_small, font_title, font_big
    old = (font_main, font_small, font_title, font_big)
    font_main = create_font(S(17), 400)
    font_small = create_font(S(14), 400)
    font_title = create_font(S(22), 600)
    font_big = create_font(S(28), 600)
    for obj in old:
        if obj:
            gdi32.DeleteObject(obj)


def set_dpi(dpi):
    global current_dpi, ui_scale
    dpi = max(72, min(384, int(dpi or 96)))
    if dpi == current_dpi and font_main is not None:
        return
    current_dpi = dpi
    ui_scale = dpi / 96.0
    recreate_fonts()


def paint_ui(hwnd, hdc):
    global local_slider
    cr = wintypes.RECT(); user32.GetClientRect(hwnd, ctypes.byref(cr))
    w_px, h_px = cr.right, cr.bottom
    w, h = w_px / ui_scale, h_px / ui_scale
    fill(hdc, cr, RGB(54, 54, 57))

    pad = 24
    sidebar = 190 if w >= 760 else 0
    text(hdc, "LumaFold", rect(pad, 12, w - pad, 52), RGB(244,244,244), font_title)
    status_text = "CONNECTED · Blender" if connected else "RECONNECTING..."
    status_color = RGB(94,190,124) if connected else RGB(220,150,82)
    text(hdc, status_text, rect(w-300,18,w-pad,46), status_color, font_small, DT_RIGHT|DT_VCENTER|DT_SINGLELINE)
    line(hdc,pad,58,w-pad,58,RGB(78,78,81))

    with state_lock:
        s = dict(bridge_state)
    if s and not slider_drag:
        local_slider = float(s.get("shared_value", local_slider))

    content_x = pad
    if sidebar:
        fill(hdc, rect(pad,76,pad+sidebar,h-24), RGB(48,48,51))
        text(hdc,"DESKTOP HOST",rect(pad+16,88,pad+sidebar-12,116),RGB(170,170,174),font_small)
        text(hdc,"Core",rect(pad+16,130,pad+sidebar-12,160),RGB(245,245,245),font_main)
        for i,label in enumerate(("Sculpt","Model","Light","Render")):
            text(hdc,label,rect(pad+16,166+i*36,pad+sidebar-12,196+i*36),RGB(150,150,154),font_main)
        text(hdc,"HOST HEALTH",rect(pad+16,330,pad+sidebar-12,356),RGB(170,170,174),font_small)
        text(hdc,f"DPI {current_dpi} · {ui_scale*100:.0f}%",rect(pad+16,360,pad+sidebar-12,384),RGB(145,145,149),font_small)
        text(hdc,f"RTT {last_rtt_ms:.1f} ms",rect(pad+16,386,pad+sidebar-12,410),RGB(145,145,149),font_small)
        text(hdc,f"Sync {sync_count}",rect(pad+16,412,pad+sidebar-12,436),RGB(145,145,149),font_small)
        text(hdc,f"Reconnects {reconnect_count}",rect(pad+16,438,pad+sidebar-12,462),RGB(145,145,149),font_small)
        content_x = pad + sidebar + 28

    maxw = max(360, min(700, w-content_x-pad))
    y=78
    text(hdc,"Desktop Core",rect(content_x,y,content_x+maxw,y+36),RGB(245,245,245),font_title); y+=40
    text(hdc,"Independent process · live shared state · P0.11.1",rect(content_x,y,content_x+maxw,y+24),RGB(160,160,164),font_small); y+=42

    card=rect(content_x,y,content_x+maxw,y+118); fill(hdc,card,RGB(62,62,65))
    text(hdc,"SHARED COUNTER",rect(content_x+16,y+12,content_x+maxw-16,y+36),RGB(172,172,176),font_small)
    text(hdc,str(s.get("shared_counter","—")),rect(content_x+16,y+36,content_x+150,y+82),RGB(245,245,245),font_big)
    button(hdc,"inc","+1 via Command",rect(content_x+160,y+48,content_x+305,y+86),True)
    button(hdc,"reset","Reset",rect(content_x+315,y+48,content_x+410,y+86))
    enabled=bool(s.get("shared_enabled",True))
    button(hdc,"enabled",("Shared ON" if enabled else "Shared OFF"),rect(content_x+420,y+48,content_x+535,y+86),enabled)
    y += 136

    text(hdc,f"Shared value     {local_slider:.2f}",rect(content_x,y,content_x+maxw,y+26),RGB(220,220,223),font_main); y+=30
    track=rect(content_x,y,content_x+maxw,y+18); RECTS["slider"]=track
    fill(hdc,raw_rect(track.left,track.top+S(7),track.right,track.top+S(11)),RGB(82,82,86))
    knobx=int(track.left+local_slider*(track.right-track.left))
    fill(hdc,raw_rect(knobx-S(5),track.top+S(2),knobx+S(5),track.top+S(16)),RGB(78,142,216)); y+=42

    text(hdc,"Blender command bridge",rect(content_x,y,content_x+maxw,y+28),RGB(245,245,245),font_main); y+=34
    button(hdc,"nudge","Nudge active X +0.10",rect(content_x,y,content_x+190,y+40),True)
    button(hdc,"rename","Rename active",rect(content_x+200,y,content_x+350,y+40)); y+=58

    active=s.get("active_object") or {}; loc=active.get("location") or []
    obj_line=f"Active: {active.get('name','none')}"
    if len(loc)==3: obj_line += f"    X {loc[0]:.3f}   Y {loc[1]:.3f}   Z {loc[2]:.3f}"
    text(hdc,obj_line,rect(content_x,y,content_x+maxw,y+28),RGB(190,190,194),font_small); y+=30
    text(hdc,f"Last: {s.get('last_command','none')}",rect(content_x,y,content_x+maxw,y+24),RGB(123,177,232),font_small); y+=24
    msg=s.get("last_command_message",last_error or "Waiting for Blender...")
    text(hdc,msg,rect(content_x,y,content_x+maxw,y+24),RGB(170,170,174),font_small)

    age=(time.monotonic()-last_sync_monotonic) if last_sync_monotonic else 0.0
    footer=f"{DPI_MODE} · DPI {current_dpi} · RTT {last_rtt_ms:.1f} ms · sync age {age:.2f}s · resize / move between monitors"
    text(hdc,footer,rect(pad,h-40,w-pad,h-14),RGB(135,135,139),font_small)


@WNDPROC
def wndproc(hwnd,msg,wparam,lparam):
    global slider_drag,closing,hwnd_main
    if msg==WM_ERASEBKGND:
        return 1
    if msg==WM_PAINT:
        # Double-buffer the entire client area. P0.11 painted directly to the
        # screen HDC, so frequent bridge refreshes / slider movement could show
        # the background-cleared frame before controls were redrawn.
        ps=PAINTSTRUCT(); hdc=user32.BeginPaint(hwnd,ctypes.byref(ps))
        memdc = None; bitmap = None; oldbmp = None
        try:
            cr = wintypes.RECT(); user32.GetClientRect(hwnd, ctypes.byref(cr))
            width = max(1, cr.right-cr.left); height = max(1, cr.bottom-cr.top)
            memdc = gdi32.CreateCompatibleDC(hdc)
            bitmap = gdi32.CreateCompatibleBitmap(hdc, width, height)
            if memdc and bitmap:
                oldbmp = gdi32.SelectObject(memdc, bitmap)
                paint_ui(hwnd, memdc)
                gdi32.BitBlt(hdc, 0, 0, width, height, memdc, 0, 0, SRCCOPY)
            else:
                paint_ui(hwnd, hdc)
        finally:
            if memdc:
                if oldbmp: gdi32.SelectObject(memdc, oldbmp)
                if bitmap: gdi32.DeleteObject(bitmap)
                gdi32.DeleteDC(memdc)
            user32.EndPaint(hwnd,ctypes.byref(ps))
        return 0
    if msg in (WM_SIZE,WM_APP_UPDATE):
        user32.InvalidateRect(hwnd,None,False); return 0
    if msg==WM_DPICHANGED:
        dpi=wparam & 0xFFFF
        set_dpi(dpi)
        suggested=ctypes.cast(lparam,ctypes.POINTER(wintypes.RECT)).contents
        user32.SetWindowPos(hwnd,None,suggested.left,suggested.top,suggested.right-suggested.left,suggested.bottom-suggested.top,SWP_NOZORDER|SWP_NOACTIVATE)
        user32.InvalidateRect(hwnd,None,False); return 0
    if msg==WM_GETMINMAXINFO:
        mmi=ctypes.cast(lparam,ctypes.POINTER(MINMAXINFO)).contents
        mmi.ptMinTrackSize.x=S(640); mmi.ptMinTrackSize.y=S(520); return 0
    if msg==WM_LBUTTONDOWN:
        x,y=get_xy(lparam)
        for key in ("inc","reset","enabled","nudge","rename"):
            r=RECTS.get(key)
            if r and inside(x,y,r):
                if key=="inc": enqueue({"action":"command","command_id":"core.counter.increment","kwargs":{"amount":1}})
                elif key=="reset": enqueue({"action":"command","command_id":"core.counter.reset","kwargs":{}})
                elif key=="enabled":
                    with state_lock: enabled=bool(bridge_state.get("shared_enabled",True))
                    enqueue({"action":"set_state","fields":{"shared_enabled":not enabled}})
                elif key=="nudge": enqueue({"action":"command","command_id":"blender.object.nudge_x","kwargs":{"delta":0.10}})
                elif key=="rename": enqueue({"action":"command","command_id":"blender.object.rename_active","kwargs":{"name":"LumaFold_Desktop"}})
                return 0
        r=RECTS.get("slider")
        if r and inside(x,y,r):
            slider_drag=True; user32.SetCapture(hwnd); update_slider(x); return 0
    if msg==WM_MOUSEMOVE and slider_drag:
        x,_=get_xy(lparam); update_slider(x); return 0
    if msg==WM_LBUTTONUP and slider_drag:
        x,_=get_xy(lparam); update_slider(x); slider_drag=False; user32.ReleaseCapture()
        # Commit once at gesture end. Local value remains authoritative until
        # the bridge returns the committed snapshot.
        enqueue({"action":"set_state","fields":{"shared_value":local_slider}}); return 0
    if msg==WM_CLOSE:
        closing=True; user32.DestroyWindow(hwnd); return 0
    if msg==WM_DESTROY:
        closing=True; user32.PostQuitMessage(0); return 0
    return user32.DefWindowProcW(hwnd,msg,wparam,lparam)


def create_font(height,weight=400):
    return gdi32.CreateFontW(-max(1,int(height)),0,0,0,weight,0,0,0,1,0,0,5,0,"Segoe UI")


def main():
    global hwnd_main,current_dpi,ui_scale
    hinst=kernel32.GetModuleHandleW(None)
    class_name="LumaFoldDesktopHostP0111"
    wc=WNDCLASSEXW(); wc.cbSize=ctypes.sizeof(WNDCLASSEXW); wc.style=CS_HREDRAW|CS_VREDRAW; wc.lpfnWndProc=wndproc; wc.hInstance=hinst
    cursor_resource=ctypes.cast(ctypes.c_void_p(IDC_ARROW),wintypes.LPCWSTR)
    wc.hCursor=user32.LoadCursorW(None,cursor_resource); wc.hbrBackground=gdi32.CreateSolidBrush(RGB(54,54,57)); wc.lpszClassName=class_name
    if not user32.RegisterClassExW(ctypes.byref(wc)):
        err=ctypes.get_last_error()
        if err!=1410: raise ctypes.WinError(err)

    # Bootstrap at 96dpi, then query the actual monitor after HWND creation.
    set_dpi(96)
    hwnd_main=user32.CreateWindowExW(0,class_name,"LumaFold Desktop Host · P0.11.1",WS_OVERLAPPEDWINDOW|WS_VISIBLE,CW_USEDEFAULT,CW_USEDEFAULT,S(980),S(700),None,None,hinst,None)
    if not hwnd_main: raise ctypes.WinError()
    if hasattr(user32,"GetDpiForWindow"):
        try: set_dpi(user32.GetDpiForWindow(hwnd_main))
        except Exception: pass
    user32.ShowWindow(hwnd_main,SW_SHOW); user32.UpdateWindow(hwnd_main)
    threading.Thread(target=network_worker,name="LumaFoldDesktopNetwork",daemon=True).start()

    msg=wintypes.MSG()
    while user32.GetMessageW(ctypes.byref(msg),None,0,0)>0:
        user32.TranslateMessage(ctypes.byref(msg)); user32.DispatchMessageW(ctypes.byref(msg))

    for obj in (font_main,font_small,font_title,font_big):
        if obj: gdi32.DeleteObject(obj)


if __name__=="__main__":
    main()
