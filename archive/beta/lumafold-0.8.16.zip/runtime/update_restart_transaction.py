from __future__ import annotations

"""Process-isolated LumaFold update transaction.

Never replace the running LumaFold extension in the Blender process that owns
its modal handlers, ImGui/WGL hosts or native modules. The product process only
arms a clean helper Blender. The helper starts with --factory-startup, waits
for the product Blender PID to exit, upgrades the package, then relaunches
Blender normally.

The status file is also the durable receipt for a rehearsal. The old product
records source version/channel before exit, the standalone helper records the
native upgrade phases and the version actually present on disk, and the newly
started product reconciles the receipt with the version that actually loaded.
"""

import json
import os
from pathlib import Path
import subprocess
import tempfile
import time
import uuid

import bpy

_HELPER_NAME = "lumafold_update_helper.py"
_STATUS_NAME = "update_transaction.json"
_LOG_NAME = "update_transaction.log"
_STATUS_SCHEMA = 3
_ACTIVE_STATES = {"armed", "waiting_for_exit", "upgrading"}
_TERMINAL_STATES = {"installed", "no_update", "failed"}


def _transaction_root() -> Path:
    root = Path(tempfile.gettempdir()) / "LumaFold" / "update"
    root.mkdir(parents=True, exist_ok=True)
    return root


def _status_path() -> Path:
    root = Path(bpy.utils.user_resource('CONFIG', path="lumafold", create=True))
    return root / _STATUS_NAME


def _write_status(payload: dict) -> None:
    path = _status_path()
    normalized = dict(payload or {})
    normalized["schema"] = _STATUS_SCHEMA
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(normalized, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def read_status() -> dict:
    try:
        raw = json.loads(_status_path().read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            return {}
        return raw
    except Exception:
        return {}


def reconcile_loaded_version(current_version: str) -> dict:
    """Finalize an installed receipt from the newly loaded product process."""
    status = read_status()
    if str(status.get("state", "") or "") != "installed":
        return status
    loaded = str(current_version or "").strip()
    if not loaded:
        return status
    if str(status.get("loaded_version", "") or "") == loaded and status.get("completed_at"):
        return status
    status["loaded_version"] = loaded
    status["completed_at"] = float(time.time())
    installed = str(status.get("installed_version", "") or "").strip()
    if installed and installed != loaded:
        status["state"] = "failed"
        status["error"] = f"更新后的磁盘版本为 {installed}，但 Blender 实际加载了 {loaded}"
    _write_status(status)
    return status


def transaction_summary(status: dict | None = None) -> str:
    data = dict(status if status is not None else read_status())
    state = str(data.get("state", "") or "")
    source = str(data.get("source_version", "") or "").strip()
    loaded = str(data.get("loaded_version", "") or "").strip()
    channel = str(data.get("channel", "") or "").strip().lower()
    channel_label = "Beta" if channel == "beta" else ("Stable" if channel == "stable" else "")
    if state == "installed":
        if source and loaded:
            suffix = f" · {channel_label}" if channel_label else ""
            return f"上次更新成功：v{source} → v{loaded}{suffix}"
        return "上次更新已安装并完成重启"
    if state == "no_update":
        return "当前已经是该更新通道的最新版本"
    if state == "failed":
        return "上次更新失败，可查看错误信息后重试"
    if state in _ACTIVE_STATES:
        return "LumaFold 更新事务正在进行"
    return ""


def _helper_source() -> str:
    # Deliberately standalone: this file is executed by a factory-startup Blender
    # and must never import the LumaFold package that is being replaced.
    return r'''from __future__ import annotations
import argparse
import ctypes
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import tomllib
import traceback
import bpy


def _write(path: Path, payload: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def _receipt(args, state: str, **extra):
    payload = {
        "schema": 3,
        "attempt_id": args.attempt_id,
        "state": state,
        "target": args.pkg_id,
        "source_version": args.source_version,
        "channel": args.channel,
        "started_at": float(args.started_at),
        "updated_at": float(time.time()),
    }
    payload.update(extra)
    return payload


def _wait_for_process_exit(pid: int, timeout_s: float = 300.0):
    PROCESS_SYNCHRONIZE = 0x00100000
    kernel32 = ctypes.windll.kernel32
    handle = kernel32.OpenProcess(PROCESS_SYNCHRONIZE, False, int(pid))
    if not handle:
        return
    try:
        WAIT_OBJECT_0 = 0x00000000
        WAIT_TIMEOUT = 0x00000102
        deadline = time.monotonic() + timeout_s
        while time.monotonic() < deadline:
            result = kernel32.WaitForSingleObject(handle, 500)
            if result == WAIT_OBJECT_0:
                return
            if result != WAIT_TIMEOUT:
                raise RuntimeError(f"WaitForSingleObject failed: {result}")
        raise TimeoutError("Timed out waiting for Blender to exit")
    finally:
        kernel32.CloseHandle(handle)


def _installed_version(repo, pkg_id: str) -> str:
    directory = str(getattr(repo, "directory", "") or "").strip()
    if not directory:
        return ""
    manifest = Path(directory) / pkg_id / "blender_manifest.toml"
    try:
        data = tomllib.loads(manifest.read_text(encoding="utf-8"))
    except Exception:
        return ""
    return str(data.get("version", "") or "").strip()


def _norm_dir(value: str) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    try:
        return os.path.normcase(os.path.abspath(text))
    except Exception:
        return os.path.normcase(text)


def main():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--wait-pid", type=int, required=True)
    parser.add_argument("--repo-url", required=True)
    parser.add_argument("--repo-directory", required=True)
    parser.add_argument("--repo-module", default="lumafold_remote")
    parser.add_argument("--pkg-id", default="lumafold")
    parser.add_argument("--status-path", required=True)
    parser.add_argument("--log-path", required=True)
    parser.add_argument("--blender-exe", required=True)
    parser.add_argument("--attempt-id", required=True)
    parser.add_argument("--source-version", default="")
    parser.add_argument("--channel", default="")
    parser.add_argument("--started-at", type=float, required=True)
    args = parser.parse_args(sys.argv[sys.argv.index("--") + 1:])
    status_path = Path(args.status_path)
    log_path = Path(args.log_path)
    try:
        _write(status_path, _receipt(args, "waiting_for_exit"))
        _wait_for_process_exit(args.wait_pid)
        _write(status_path, _receipt(args, "upgrading"))

        extensions = bpy.context.preferences.extensions
        repos = extensions.repos
        repo = None
        repo_raw_index = -1
        target_directory = _norm_dir(args.repo_directory)
        if not target_directory:
            raise RuntimeError("Helper received an empty LumaFold repository directory")

        # --factory-startup intentionally discards the user's repository preferences.
        # Re-attach the exact repository directory that owns the installed package;
        # matching by URL alone would create a fresh empty repository and leave
        # package_upgrade_all with nothing installed to upgrade.
        for index, item in enumerate(repos):
            if _norm_dir(str(getattr(item, "directory", "") or "")) == target_directory:
                repo = item
                repo_raw_index = int(index)
                break
        if repo is None:
            repo = repos.new(
                name="LumaFold Update Helper",
                module=args.repo_module,
                custom_directory=args.repo_directory,
                remote_url=args.repo_url,
                source='USER',
            )
            repo_raw_index = len(repos) - 1
        repo.enabled = True
        try:
            repo.use_remote_url = True
            repo.remote_url = args.repo_url
        except Exception:
            pass

        repo_directory = str(getattr(repo, "directory", "") or "").strip()
        if not repo_directory:
            raise RuntimeError("Helper could not resolve LumaFold repository directory")
        if _norm_dir(repo_directory) != target_directory:
            raise RuntimeError(
                f"Helper mounted wrong repository directory: {repo_directory} != {args.repo_directory}"
            )

        installed_before_sync = _installed_version(repo, args.pkg_id)
        if not installed_before_sync:
            raise RuntimeError(
                f"Helper could not find installed package {args.pkg_id} in {repo_directory}"
            )

        # repo_sync accepts directory identity directly and therefore does not
        # depend on Blender's filtered operator repo_index contract.
        sync_result = set(bpy.ops.extensions.repo_sync(repo_directory=repo_directory) or ())
        if "CANCELLED" in sync_result:
            raise RuntimeError("Helper repository sync was cancelled")

        before = installed_before_sync or str(args.source_version or "")

        # package_upgrade_all(use_active_only=True) resolves the active repository
        # from preferences.extensions.active_repo. The exact repository is now
        # mounted on the real installed custom_directory, so this operation is
        # scoped to the live LumaFold installation rather than a factory-startup copy.
        if repo_raw_index < 0:
            raise RuntimeError("Helper could not resolve LumaFold repository index")
        extensions.active_repo = int(repo_raw_index)
        with bpy.context.temp_override(extension_repo=repo):
            upgrade_result = set(bpy.ops.extensions.package_upgrade_all(use_active_only=True) or ())
        if "CANCELLED" in upgrade_result:
            raise RuntimeError("Helper package upgrade was cancelled")

        after = _installed_version(repo, args.pkg_id)
        if not after:
            raise RuntimeError("Helper could not read installed LumaFold version after upgrade")
        if before and after == before:
            _write(status_path, _receipt(
                args,
                "no_update",
                installed_version=after,
                completed_at=float(time.time()),
            ))
        else:
            _write(status_path, _receipt(
                args,
                "installed",
                installed_version=after,
                installed_at=float(time.time()),
            ))
        subprocess.Popen([args.blender_exe], close_fds=True)
    except Exception as exc:
        text = traceback.format_exc()
        log_path.parent.mkdir(parents=True, exist_ok=True)
        log_path.write_text(text, encoding="utf-8")
        _write(status_path, _receipt(
            args,
            "failed",
            error=f"{type(exc).__name__}: {exc}",
            log=str(log_path),
            failed_at=float(time.time()),
        ))
        subprocess.Popen([args.blender_exe], close_fds=True)
        raise


if __name__ == "__main__":
    main()
'''


def arm(*, repo, extension_id: str, source_version: str = "", channel: str = "") -> dict:
    """Launch the isolated helper and return transaction metadata."""
    blender_exe = str(getattr(bpy.app, "binary_path", "") or "")
    if not blender_exe or not Path(blender_exe).is_file():
        raise RuntimeError("无法定位当前 Blender 可执行文件")

    repo_url = str(getattr(repo, "remote_url", "") or "").strip()
    if not repo_url:
        raise RuntimeError("LumaFold 更新仓库 URL 为空")
    repo_directory = str(getattr(repo, "directory", "") or "").strip()
    if not repo_directory:
        raise RuntimeError("LumaFold 更新仓库目录为空")
    repo_module = str(getattr(repo, "module", "") or "lumafold_remote")

    root = _transaction_root()
    helper_path = root / _HELPER_NAME
    log_path = root / _LOG_NAME
    helper_path.write_text(_helper_source(), encoding="utf-8")
    try:
        log_path.unlink(missing_ok=True)
    except Exception:
        pass

    status_path = _status_path()
    attempt_id = uuid.uuid4().hex
    started_at = float(time.time())
    receipt = {
        "schema": _STATUS_SCHEMA,
        "attempt_id": attempt_id,
        "state": "armed",
        "target": str(extension_id),
        "source_version": str(source_version or ""),
        "channel": str(channel or ""),
        "started_at": started_at,
        "updated_at": started_at,
    }
    _write_status(receipt)
    command = [
        blender_exe,
        "--factory-startup",
        "--background",
        "--online-mode",
        "--python",
        str(helper_path),
        "--",
        "--wait-pid",
        str(os.getpid()),
        "--repo-url",
        repo_url,
        "--repo-directory",
        repo_directory,
        "--repo-module",
        repo_module,
        "--pkg-id",
        str(extension_id),
        "--status-path",
        str(status_path),
        "--log-path",
        str(log_path),
        "--blender-exe",
        blender_exe,
        "--attempt-id",
        attempt_id,
        "--source-version",
        str(source_version or ""),
        "--channel",
        str(channel or ""),
        "--started-at",
        str(started_at),
    ]
    creationflags = 0
    if os.name == "nt":
        creationflags = int(getattr(subprocess, "CREATE_NO_WINDOW", 0)) | int(getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
    proc = subprocess.Popen(
        command,
        cwd=str(root),
        close_fds=True,
        creationflags=creationflags,
    )
    receipt["helper_pid"] = int(proc.pid)
    receipt["updated_at"] = float(time.time())
    _write_status(receipt)
    return {
        "attempt_id": attempt_id,
        "pid": int(proc.pid),
        "status_path": str(status_path),
        "log_path": str(log_path),
    }
