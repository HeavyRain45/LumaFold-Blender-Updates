from __future__ import annotations

"""Alpha file/folder selector product integration.

The Alpha ``+`` action is one native Blender File Browser transaction:

* select a folder -> LumaFold links that folder non-destructively;
* select one or more image files -> only those files are imported into the
  managed LumaFold user Alpha library root, where they appear in ``全部``.

Folder linking never copies, moves, renames or deletes source files. Historical
``lumafold.import_alpha_images`` remains available and keeps its managed-copy
semantics. A separate tiny native dialog creates optional LumaFold-owned
subfolders without changing the Alpha Library layout.
"""

from pathlib import Path

import bpy

from ..core.app import APP
from ..core.state import STATE


_ORIGINAL_EXECUTE = None
_FOLDER_OPERATOR_ADDED = False
_CREATE_FOLDER_OPERATOR_ADDED = False
_IMAGE_FILTER = "*.png;*.jpg;*.jpeg;*.tif;*.tiff;*.bmp;*.tga;*.exr;*.hdr"


def _product_execute(self, context):
    selected = [
        Path(self.directory) / item.name
        for item in self.files
        if str(item.name or "").strip()
    ]
    if not selected:
        self.report({'INFO'}, "没有选择 Alpha 图片")
        return {'CANCELLED'}

    try:
        service = APP.services.require("blender.alpha")
        importer = getattr(service, "import_alpha_files", None)
        if importer is None:
            raise RuntimeError("当前 Alpha Service 不支持持久化导入")
        result = dict(importer(selected, load_current=True) or {})
    except Exception as exc:
        STATE.last_error = f"Alpha persistent import failed: {type(exc).__name__}: {exc}"
        self.report({'ERROR'}, str(exc))
        return {'CANCELLED'}

    imported = int(result.get("count", 0) or 0)
    failed = [str(item) for item in list(result.get("errors") or ()) if str(item or "")]
    try:
        refresh = APP.execute("sculpt.alpha.library_refresh")
        if not refresh.ok:
            failed.append("刷新失败: " + str(refresh.message))
    except Exception as exc:
        failed.append("刷新失败: " + str(exc))

    if failed:
        STATE.last_error = "\n".join(failed[-8:])
    elif STATE.last_error.startswith("Alpha persistent import failed"):
        STATE.last_error = ""

    if imported:
        self.report({'INFO'}, f"已导入 {imported} 个 Alpha；可在“全部”中查看")
        return {'FINISHED'}

    self.report({'ERROR'}, failed[-1] if failed else "Alpha 导入失败")
    return {'CANCELLED'}


def _selection_paths(operator):
    """Resolve exactly what the user selected in Blender's File Browser.

    ``DIR_PATH`` made Blender enter a folder first and only then allowed the
    current directory to be confirmed.  The mixed selector is FILE_PATH based:
    an explicit highlighted folder arrives through ``filepath``; image files
    arrive through ``files`` + ``directory``.  The current directory is used
    only as a compatibility fallback when Blender explicitly supplies it.
    """
    raw_directory = str(getattr(operator, "directory", "") or "").strip()
    directory = Path(raw_directory).expanduser() if raw_directory else None
    selected = []

    for item in list(getattr(operator, "files", ()) or ()):
        name = str(getattr(item, "name", "") or "").strip()
        if name:
            selected.append((directory if directory is not None else Path()) / name)

    if not selected:
        raw_filepath = str(getattr(operator, "filepath", "") or "").strip()
        if raw_filepath:
            selected.append(Path(raw_filepath).expanduser())

    if not selected and directory is not None:
        selected.append(directory)

    resolved = []
    seen = set()
    for path in selected:
        try:
            path = path.resolve()
        except Exception:
            path = Path(path)
        key = str(path).casefold()
        if key in seen:
            continue
        seen.add(key)
        resolved.append(path)
    return resolved


class LUMAFOLD_OT_add_alpha_folder(bpy.types.Operator):
    """One native selector for linked folders and individually imported files."""

    bl_idname = "lumafold.add_alpha_folder"
    bl_label = "添加 Alpha"
    bl_description = "选择文件夹直接链接；选择一张或多张图片则只添加所选 Alpha 到“全部”"

    filepath: bpy.props.StringProperty(
        name="Alpha 来源",
        description="选择一个 Alpha 文件夹，或选择一张/多张 Alpha 图片",
        subtype='FILE_PATH',
        default="",
    )
    directory: bpy.props.StringProperty(subtype='DIR_PATH', options={'HIDDEN'}, default="")
    files: bpy.props.CollectionProperty(
        type=bpy.types.OperatorFileListElement,
        options={'HIDDEN', 'SKIP_SAVE'},
    )
    filter_glob: bpy.props.StringProperty(default=_IMAGE_FILTER, options={'HIDDEN'})
    check_existing: bpy.props.BoolProperty(default=False, options={'HIDDEN'})

    def invoke(self, context, event):
        try:
            context.window_manager.fileselect_add(self)
            return {'RUNNING_MODAL'}
        except Exception as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}

    def execute(self, context):
        paths = _selection_paths(self)
        alpha_service = APP.services.require("blender.alpha")
        folders = [path for path in paths if path.is_dir()]
        image_files = [
            path for path in paths
            if path.is_file() and path.suffix.casefold() in alpha_service.IMAGE_EXTS
        ]
        unsupported = [path for path in paths if path.is_file() and path not in image_files]

        if not folders and not image_files:
            message = "没有选择有效的 Alpha 文件夹或图片"
            if unsupported:
                message += "（不支持：" + ", ".join(path.name for path in unsupported[:4]) + "）"
            self.report({'INFO'}, message)
            return {'CANCELLED'}

        messages = []
        errors = []

        for folder in folders:
            try:
                result = APP.execute("sculpt.alpha.source_add", path=str(folder))
                if getattr(result, "ok", False):
                    messages.append(str(getattr(result, "message", "Alpha 文件夹已添加")))
                else:
                    errors.append(str(getattr(result, "message", "添加 Alpha 文件夹失败")))
            except Exception as exc:
                errors.append(f"{folder.name}: {type(exc).__name__}: {exc}")

        if image_files:
            try:
                importer = getattr(alpha_service, "import_alpha_files", None)
                if importer is None:
                    raise RuntimeError("当前 Alpha Service 不支持图片导入")
                imported = dict(importer(image_files, load_current=True) or {})
                count = int(imported.get("count", 0) or 0)
                if count:
                    messages.append(f"已添加 {count} 个 Alpha 图片到“全部”")
                errors.extend(str(item) for item in list(imported.get("errors") or ()) if str(item or ""))
                refresh = APP.execute("sculpt.alpha.library_refresh")
                if not getattr(refresh, "ok", False):
                    errors.append("刷新失败: " + str(getattr(refresh, "message", "")))
            except Exception as exc:
                errors.append(f"Alpha 图片导入失败: {type(exc).__name__}: {exc}")

        if unsupported:
            errors.append("已忽略不支持的文件：" + ", ".join(path.name for path in unsupported[:4]))

        if errors:
            STATE.last_error = "\n".join(errors[-8:])
        elif STATE.last_error.startswith(("Alpha source add failed", "Alpha 图片导入失败")):
            STATE.last_error = ""

        if messages:
            summary = "；".join(messages[:3])
            if errors:
                summary += "；部分项目未添加"
            self.report({'INFO'}, summary)
            return {'FINISHED'}

        self.report({'ERROR'}, errors[-1] if errors else "Alpha 添加失败")
        return {'CANCELLED'}


class LUMAFOLD_OT_create_alpha_folder(bpy.types.Operator):
    """Create one real folder inside the LumaFold-managed Alpha root."""

    bl_idname = "lumafold.create_alpha_folder"
    bl_label = "新建 Alpha 文件夹"
    bl_description = "在 LumaFold 用户 Alpha 目录中创建一个可管理的文件夹"

    name: bpy.props.StringProperty(
        name="文件夹名称",
        description="新建 LumaFold Alpha 文件夹名称",
        default="新建文件夹",
        maxlen=96,
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=320)

    def execute(self, context):
        try:
            service = APP.services.require("blender.alpha")
            creator = getattr(service, "create_user_folder", None)
            if creator is None:
                raise RuntimeError("当前 Alpha Service 不支持新建文件夹")
            result = dict(creator(self.name) or {})
            refresh = APP.execute("sculpt.alpha.library_refresh")
            if not getattr(refresh, "ok", False):
                raise RuntimeError("文件夹已创建，但 Alpha 库刷新失败: " + str(getattr(refresh, "message", "")))
            label = str(result.get("name") or self.name)
            self.report({'INFO'}, ("已新建" if result.get("created", True) else "文件夹已存在：") + label)
            return {'FINISHED'}
        except Exception as exc:
            STATE.last_error = f"Alpha folder create failed: {type(exc).__name__}: {exc}"
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}


def install(operators_module):
    global _ORIGINAL_EXECUTE, _FOLDER_OPERATOR_ADDED, _CREATE_FOLDER_OPERATOR_ADDED
    cls = getattr(operators_module, "LUMAFOLD_OT_import_alpha_images", None)
    if cls is None:
        return False
    if _ORIGINAL_EXECUTE is None:
        _ORIGINAL_EXECUTE = getattr(cls, "execute", None)
    cls.execute = _product_execute
    try:
        cls.bl_description = "选择 Alpha 图片并复制到 LumaFold 用户 Alpha 库；单图只出现在“全部”"
    except Exception:
        pass

    classes = tuple(getattr(operators_module, "CLASSES", ()) or ())
    additions = []
    if LUMAFOLD_OT_add_alpha_folder not in classes:
        additions.append(LUMAFOLD_OT_add_alpha_folder)
        _FOLDER_OPERATOR_ADDED = True
    if LUMAFOLD_OT_create_alpha_folder not in classes:
        additions.append(LUMAFOLD_OT_create_alpha_folder)
        _CREATE_FOLDER_OPERATOR_ADDED = True
    if additions:
        operators_module.CLASSES = classes + tuple(additions)
    return True


def uninstall(operators_module):
    global _ORIGINAL_EXECUTE, _FOLDER_OPERATOR_ADDED, _CREATE_FOLDER_OPERATOR_ADDED
    cls = getattr(operators_module, "LUMAFOLD_OT_import_alpha_images", None)
    if cls is not None and _ORIGINAL_EXECUTE is not None:
        cls.execute = _ORIGINAL_EXECUTE
    _ORIGINAL_EXECUTE = None

    if _FOLDER_OPERATOR_ADDED or _CREATE_FOLDER_OPERATOR_ADDED:
        classes = tuple(getattr(operators_module, "CLASSES", ()) or ())
        operators_module.CLASSES = tuple(
            item for item in classes
            if item not in {LUMAFOLD_OT_add_alpha_folder, LUMAFOLD_OT_create_alpha_folder}
        )
    _FOLDER_OPERATOR_ADDED = False
    _CREATE_FOLDER_OPERATOR_ADDED = False
