from __future__ import annotations

"""Temporary real-machine path tracing for dev45.

This module is deliberately diagnostic-only. It does not decide input ownership,
popup lifetime, Brush behavior, or Host migration. Thin wrappers record which
already-existing production stage was actually reached on the user's Blender.

The trace is written to the OS temp directory so it survives Embedded Host
shutdown during a Satellite handoff:
    %TEMP%/LumaFold/real_machine_trace_dev45.jsonl
"""

import json
import os
from pathlib import Path
import tempfile
import threading
import time
import traceback

import bpy

from ..core.app import APP
from ..core.host_control import HOST_CONTROL
from ..core.runtime_session import RUNTIME_SESSION
from ..core.state import STATE


_TRACE_DIR = Path(tempfile.gettempdir()) / "LumaFold"
_TRACE_PATH = _TRACE_DIR / "real_machine_trace_dev45.jsonl"
_TRACE_LOCK = threading.Lock()
_MAX_TRACE_BYTES = 512 * 1024
_INSTALLED = False
_UI_REGISTERED = False
_ORIGINALS = {}
_UNSUBSCRIBERS = []
_LAST_POPUPS = ()
_LAST_HOST_PENDING = False
_MONITOR_SERIAL = 0


def trace_path() -> Path:
    _TRACE_DIR.mkdir(parents=True, exist_ok=True)
    return _TRACE_PATH


def _safe(value, depth=0):
    if depth >= 3:
        return str(value)[:240]
    if value is None or isinstance(value, (bool, int, float)):
        return value
    if isinstance(value, str):
        return value[:600]
    if isinstance(value, dict):
        return {str(k)[:80]: _safe(v, depth + 1) for k, v in list(value.items())[:24]}
    if isinstance(value, (list, tuple, set)):
        return [_safe(v, depth + 1) for v in list(value)[:24]]
    return str(value)[:240]


def trace(stage: str, **data) -> None:
    """Append one compact JSONL stage record. Failure is always non-fatal."""
    try:
        path = trace_path()
        payload = {
            "time": time.time(),
            "mono": time.monotonic(),
            "pid": os.getpid(),
            "thread": threading.current_thread().name,
            "stage": str(stage),
            "data": _safe(data),
        }
        line = json.dumps(payload, ensure_ascii=False, separators=(",", ":")) + "\n"
        with _TRACE_LOCK:
            try:
                if path.exists() and path.stat().st_size > _MAX_TRACE_BYTES:
                    old = path.read_text(encoding="utf-8", errors="replace")[-(_MAX_TRACE_BYTES // 2):]
                    path.write_text(old, encoding="utf-8")
            except Exception:
                pass
            with path.open("a", encoding="utf-8") as handle:
                handle.write(line)
    except Exception:
        pass


def clear_trace(reason: str = "manual") -> None:
    try:
        path = trace_path()
        with _TRACE_LOCK:
            path.write_text("", encoding="utf-8")
    except Exception:
        pass
    trace("TRACE_RESET", reason=str(reason))


def tail_entries(limit: int = 80):
    try:
        lines = trace_path().read_text(encoding="utf-8", errors="replace").splitlines()
    except Exception:
        return []
    result = []
    for line in lines[-max(1, int(limit)):]:
        try:
            item = json.loads(line)
        except Exception:
            continue
        if isinstance(item, dict):
            result.append(item)
    return result


def _brief_data(data) -> str:
    data = dict(data or {})
    priority = (
        "event", "value", "command", "slot", "identity", "result", "pid", "child_code",
        "ready", "active", "lease", "owner", "generation", "status", "error",
    )
    parts = []
    for key in priority:
        if key not in data:
            continue
        value = data.get(key)
        text = str(value).replace("\n", " ")
        if len(text) > 90:
            text = text[:87] + "..."
        parts.append(f"{key}={text}")
        if len(parts) >= 5:
            break
    return " · ".join(parts)


def tail_text(limit: int = 100) -> str:
    rows = []
    for item in tail_entries(limit):
        try:
            clock = time.strftime("%H:%M:%S", time.localtime(float(item.get("time", 0.0))))
        except Exception:
            clock = "--:--:--"
        stage = str(item.get("stage") or "?")
        brief = _brief_data(item.get("data") or {})
        rows.append(f"{clock} | {stage}" + (f" | {brief}" if brief else ""))
    return "\n".join(rows)


def _sculpt_snapshot():
    try:
        sculpt = APP.store.namespace("sculpt")
        slots = list(sculpt.get("quick_brush_slots") or ())
        return {
            "quick_replace_slot": int(sculpt.get("quick_replace_slot", -1) or -1),
            "active_quick_slot": int(sculpt.get("active_quick_slot", -1) or -1),
            "quick_slot": int(sculpt.get("quick_slot", -1) or -1),
            "current_brush_name": str(sculpt.get("current_brush_name") or ""),
            "slot_labels": [str((slot or {}).get("label") or "") for slot in slots[:16]],
            "brush_action_status": str(sculpt.get("brush_action_status") or ""),
        }
    except Exception as exc:
        return {"snapshot_error": f"{type(exc).__name__}: {exc}"}


def _trace_state_changed(payload):
    fields = dict((payload or {}).get("fields") or {})
    if "quick_replace_slot" in fields:
        trace(
            "BRUSH_TARGET_STATE",
            value=fields.get("quick_replace_slot"),
            source=(payload or {}).get("source"),
            sculpt=_sculpt_snapshot(),
        )


def _trace_assigned_asset(payload):
    trace("BRUSH_ASSIGNED_EVENT", payload=dict(payload or {}), sculpt=_sculpt_snapshot())


def _trace_selection_complete(payload):
    trace("BRUSH_SELECTION_COMPLETED", payload=dict(payload or {}), sculpt=_sculpt_snapshot())


def _wrap_command(command_id: str):
    commands = getattr(APP.commands, "_commands", {})
    original = commands.get(command_id)
    if not callable(original):
        trace("TRACE_COMMAND_MISSING", command=command_id)
        return
    key = "command:" + command_id
    if key in _ORIGINALS:
        return
    _ORIGINALS[key] = original

    def wrapped(*args, **kwargs):
        compact_kwargs = {k: v for k, v in kwargs.items() if k in {"identity", "slot", "rows"}}
        trace("BRUSH_COMMAND_BEGIN", command=command_id, kwargs=compact_kwargs, sculpt=_sculpt_snapshot())
        try:
            result = original(*args, **kwargs)
            trace("BRUSH_COMMAND_RETURN", command=command_id, result=str(result), sculpt=_sculpt_snapshot())
            return result
        except Exception as exc:
            trace(
                "BRUSH_COMMAND_ERROR",
                command=command_id,
                error=f"{type(exc).__name__}: {exc}",
                traceback=traceback.format_exc()[-2400:],
                sculpt=_sculpt_snapshot(),
            )
            raise

    APP.commands.register(command_id, wrapped)


def _wrap_host_input(host_class):
    original = getattr(host_class, "feed_event", None)
    if not callable(original) or "host_feed_event" in _ORIGINALS:
        return
    _ORIGINALS["host_feed_event"] = original

    def traced_feed_event(self, event, *, region=None):
        try:
            event_type = str(getattr(event, "type", "") or "")
            value = str(getattr(event, "value", "") or "").upper()
            snapshot = RUNTIME_SESSION.popup_snapshot("embedded")
            names = tuple(getattr(snapshot, "names", ()) or ())
            brush_open = "LumaFold Brush Library##foundation" in names
            if brush_open and event_type in {"LEFTMOUSE", "RIGHTMOUSE", "MIDDLEMOUSE"} and value in {"PRESS", "RELEASE"}:
                local = None
                if region is not None:
                    try:
                        local = [
                            float(event.mouse_x - region.x),
                            float(region.height - 1 - (event.mouse_y - region.y)),
                        ]
                    except Exception:
                        local = None
                trace(
                    "BRUSH_POPUP_POINTER",
                    event=event_type,
                    value=value,
                    local=local,
                    popup_names=list(names),
                    capture_mouse=bool(STATE.capture_mouse),
                )
        except Exception:
            pass
        return original(self, event, region=region)

    host_class.feed_event = traced_feed_event


def _wrap_draw(gallery_module):
    global _LAST_POPUPS, _LAST_HOST_PENDING
    original = getattr(gallery_module, "draw_shared_sculpt_compact", None)
    if not callable(original) or "gallery_draw" in _ORIGINALS:
        return
    _ORIGINALS["gallery_draw"] = original
    _LAST_POPUPS = ()
    _LAST_HOST_PENDING = False

    def traced_draw(*args, **kwargs):
        global _LAST_POPUPS, _LAST_HOST_PENDING
        result = original(*args, **kwargs)
        try:
            surface_state = args[1] if len(args) > 1 else kwargs.get("surface_state")
            pending = bool((surface_state or {}).get("_host_toggle_pending", False))
            if pending != _LAST_HOST_PENDING:
                trace("SAT_UI_PENDING_ON" if pending else "SAT_UI_PENDING_OFF", status=str(STATE.status or ""))
                _LAST_HOST_PENDING = pending

            snapshot = RUNTIME_SESSION.popup_snapshot("embedded")
            names = tuple(getattr(snapshot, "names", ()) or ())
            if names != _LAST_POPUPS:
                trace("POPUP_SNAPSHOT", names=list(names))
                _LAST_POPUPS = names
        except Exception:
            pass
        return result

    gallery_module.draw_shared_sculpt_compact = traced_draw


def _satellite_log_tail(launch_function=None, limit: int = 3000) -> str:
    try:
        globals_dict = getattr(launch_function, "__globals__", {}) if launch_function is not None else {}
        path_fn = globals_dict.get("_satellite_log_path")
        path = Path(path_fn()) if callable(path_fn) else (_TRACE_DIR / "satellite_host_s07_2.log")
        text = path.read_text(encoding="utf-8", errors="replace")
        return text[-int(limit):]
    except Exception:
        return ""


def _start_satellite_monitor(operators_module, proc, generation: int, launch_function):
    global _MONITOR_SERIAL
    _MONITOR_SERIAL += 1
    serial = int(_MONITOR_SERIAL)
    started = time.monotonic()
    last_key = None

    def monitor():
        nonlocal last_key
        if serial != _MONITOR_SERIAL:
            return None
        try:
            bridge = operators_module.BRIDGE
            current_proc = getattr(bridge, "satellite_process", None) or proc
            child_code = current_proc.poll() if current_proc is not None else "missing"
            lease = HOST_CONTROL.snapshot()
            payload = {
                "child_code": child_code,
                "ready": bool(getattr(bridge, "satellite_ready", False)),
                "active": bool(getattr(bridge, "satellite_active", False)),
                "closing": bool(getattr(bridge, "satellite_closing", False)),
                "client": str(getattr(bridge, "satellite_client", "") or ""),
                "bridge_error": str(getattr(bridge, "last_error", "") or ""),
                "lease": str(lease.get("state") or ""),
                "owner": str(lease.get("owner") or ""),
                "generation": int(lease.get("generation", 0) or 0),
                "host_mode": str(getattr(STATE, "host_mode", "") or ""),
                "status": str(getattr(STATE, "status", "") or ""),
            }
            key = json.dumps(_safe(payload), ensure_ascii=False, sort_keys=True)
            if key != last_key:
                trace("SAT_STATE", elapsed_ms=round((time.monotonic() - started) * 1000.0, 1), **payload)
                last_key = key

            if payload["active"] and payload["lease"] == "SATELLITE" and payload["owner"] == "satellite":
                trace("SAT_HANDOFF_ACTIVE", elapsed_ms=round((time.monotonic() - started) * 1000.0, 1), **payload)
                return None
            if child_code not in (None, "missing"):
                trace("SAT_CHILD_EXIT", child_code=child_code, log_tail=_satellite_log_tail(launch_function))
                return None
            if time.monotonic() - started >= 10.0:
                trace("SAT_MONITOR_TIMEOUT", log_tail=_satellite_log_tail(launch_function), **payload)
                return None
            return 0.10
        except Exception as exc:
            trace("SAT_MONITOR_ERROR", error=f"{type(exc).__name__}: {exc}")
            return None

    try:
        bpy.app.timers.register(monitor, first_interval=0.05)
    except Exception as exc:
        trace("SAT_MONITOR_REGISTER_ERROR", error=f"{type(exc).__name__}: {exc}")


def _wrap_operators(operators_module):
    toggle_cls = getattr(operators_module, "LUMAFOLD_OT_toggle_p0", None)
    if toggle_cls is not None and "toggle_invoke" not in _ORIGINALS:
        original_invoke = toggle_cls.invoke
        _ORIGINALS["toggle_invoke"] = original_invoke

        def traced_invoke(self, context, event):
            starting_fresh = not bool(getattr(STATE, "running", False)) and str(getattr(STATE, "host_mode", "embedded")) != "satellite"
            if starting_fresh:
                clear_trace("embedded_host_open")
            trace(
                "HOST_TOGGLE_INVOKE",
                running=bool(getattr(STATE, "running", False)),
                host_mode=str(getattr(STATE, "host_mode", "")),
                lease=HOST_CONTROL.snapshot(),
            )
            try:
                result = original_invoke(self, context, event)
                trace("HOST_TOGGLE_RETURN", result=list(result), status=str(STATE.status or ""))
                return result
            except Exception as exc:
                trace("HOST_TOGGLE_ERROR", error=f"{type(exc).__name__}: {exc}", traceback=traceback.format_exc()[-2400:])
                raise

        toggle_cls.invoke = traced_invoke

    move_cls = getattr(operators_module, "LUMAFOLD_OT_move_to_satellite", None)
    if move_cls is not None and "sat_execute" not in _ORIGINALS:
        original_execute = move_cls.execute
        _ORIGINALS["sat_execute"] = original_execute

        def traced_execute(self, context):
            trace(
                "SAT_OPERATOR_ENTER",
                area_type=str(getattr(getattr(context, "area", None), "type", "") or ""),
                running=bool(getattr(STATE, "running", False)),
                host_mode=str(getattr(STATE, "host_mode", "") or ""),
                lease=HOST_CONTROL.snapshot(),
            )
            try:
                result = original_execute(self, context)
                trace(
                    "SAT_OPERATOR_RETURN",
                    result=list(result),
                    status=str(getattr(STATE, "status", "") or ""),
                    last_error=str(getattr(STATE, "last_error", "") or "")[-1200:],
                    lease=HOST_CONTROL.snapshot(),
                )
                return result
            except Exception as exc:
                trace("SAT_OPERATOR_EXCEPTION", error=f"{type(exc).__name__}: {exc}", traceback=traceback.format_exc()[-2400:])
                raise

        move_cls.execute = traced_execute

    launch = getattr(operators_module, "launch_satellite_host", None)
    if callable(launch) and "sat_launch" not in _ORIGINALS:
        _ORIGINALS["sat_launch"] = launch

        def traced_launch(client_width, client_height, *, screen_x, screen_y, generation):
            globals_dict = getattr(launch, "__globals__", {})
            python_exe = ""
            numpy_parent = ""
            vendor = ""
            try:
                finder = globals_dict.get("find_python_executable")
                if callable(finder):
                    python_exe = str(finder())
                env_fn = globals_dict.get("_satellite_child_env")
                if callable(env_fn):
                    env = dict(env_fn())
                    py_path = str(env.get("PYTHONPATH") or "")
                    numpy_parent = py_path.split(os.pathsep)[1] if len(py_path.split(os.pathsep)) > 1 else ""
                vendor_fn = globals_dict.get("vendor_dir")
                if callable(vendor_fn):
                    vendor = str(vendor_fn())
            except Exception as exc:
                trace("SAT_ENV_PROBE_ERROR", error=f"{type(exc).__name__}: {exc}")
            trace(
                "SAT_LAUNCH_CALL",
                width=int(client_width), height=int(client_height), x=int(screen_x), y=int(screen_y),
                generation=int(generation), python=python_exe, numpy_parent=numpy_parent, vendor=vendor,
            )
            try:
                proc = launch(
                    client_width, client_height,
                    screen_x=screen_x, screen_y=screen_y, generation=generation,
                )
                trace(
                    "SAT_CHILD_SPAWNED",
                    pid=int(getattr(proc, "pid", 0) or 0),
                    child_code=proc.poll(),
                    bridge_port=int(getattr(operators_module.BRIDGE, "port", 0) or 0),
                )
                _start_satellite_monitor(operators_module, proc, int(generation), launch)
                return proc
            except Exception as exc:
                trace(
                    "SAT_LAUNCH_ERROR",
                    error=f"{type(exc).__name__}: {exc}",
                    bridge_error=str(getattr(operators_module.BRIDGE, "last_error", "") or ""),
                    log_tail=_satellite_log_tail(launch),
                    traceback=traceback.format_exc()[-2400:],
                )
                raise

        operators_module.launch_satellite_host = traced_launch


def install(operators_module, gallery_module) -> None:
    """Install trace-only hooks after production authorities are already active."""
    global _INSTALLED
    if _INSTALLED:
        return

    _wrap_host_input(operators_module.UIHost)
    _wrap_draw(gallery_module)
    _wrap_operators(operators_module)

    for command_id in (
        "sculpt.brush.library_assign_slot",
        "sculpt.brush.library_activate",
        "sculpt.brush.activate_slot",
    ):
        _wrap_command(command_id)

    for topic, callback in (
        ("sculpt.state.changed", _trace_state_changed),
        ("sculpt.quick_slot.assigned_asset", _trace_assigned_asset),
        ("sculpt.brush_library.selection_completed", _trace_selection_complete),
    ):
        try:
            unsub = APP.events.subscribe(topic, callback)
            if callable(unsub):
                _UNSUBSCRIBERS.append(unsub)
        except Exception as exc:
            trace("TRACE_SUBSCRIBE_ERROR", topic=topic, error=f"{type(exc).__name__}: {exc}")

    trace("TRACE_INSTALLED", build="dev45")
    _INSTALLED = True


def uninstall(operators_module, gallery_module) -> None:
    global _INSTALLED, _MONITOR_SERIAL
    if not _INSTALLED:
        return
    _MONITOR_SERIAL += 1

    for unsubscribe in tuple(_UNSUBSCRIBERS):
        try:
            unsubscribe()
        except Exception:
            pass
    _UNSUBSCRIBERS.clear()

    for command_id in (
        "sculpt.brush.library_assign_slot",
        "sculpt.brush.library_activate",
        "sculpt.brush.activate_slot",
    ):
        original = _ORIGINALS.pop("command:" + command_id, None)
        if callable(original):
            APP.commands.register(command_id, original)

    original = _ORIGINALS.pop("host_feed_event", None)
    if callable(original):
        operators_module.UIHost.feed_event = original
    original = _ORIGINALS.pop("gallery_draw", None)
    if callable(original):
        gallery_module.draw_shared_sculpt_compact = original
    original = _ORIGINALS.pop("toggle_invoke", None)
    if callable(original):
        operators_module.LUMAFOLD_OT_toggle_p0.invoke = original
    original = _ORIGINALS.pop("sat_execute", None)
    if callable(original):
        operators_module.LUMAFOLD_OT_move_to_satellite.execute = original
    original = _ORIGINALS.pop("sat_launch", None)
    if callable(original):
        operators_module.launch_satellite_host = original

    _INSTALLED = False


class LUMAFOLD_OT_copy_real_machine_trace(bpy.types.Operator):
    bl_idname = "lumafold.copy_real_machine_trace"
    bl_label = "复制实机追踪"
    bl_description = "复制最近的 Quick Brush / Satellite 实机路径追踪，直接粘贴到聊天即可"

    def execute(self, context):
        text = tail_text(140)
        context.window_manager.clipboard = text or "LumaFold trace is empty"
        self.report({'INFO'}, f"已复制实机追踪 · {trace_path()}")
        return {'FINISHED'}


class LUMAFOLD_OT_clear_real_machine_trace(bpy.types.Operator):
    bl_idname = "lumafold.clear_real_machine_trace"
    bl_label = "清空实机追踪"
    bl_description = "清空本次实机路径追踪"

    def execute(self, context):
        clear_trace("manual_clear")
        self.report({'INFO'}, "实机追踪已清空")
        return {'FINISHED'}


class LUMAFOLD_PT_real_machine_trace(bpy.types.Panel):
    bl_label = "LumaFold · 实机追踪"
    bl_idname = "LUMAFOLD_PT_real_machine_trace"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'LumaFold'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.label(text="dev45 · 只记录路径，不改变功能", icon='INFO')
        row = col.row(align=True)
        row.operator("lumafold.copy_real_machine_trace", text="复制追踪 Copy Trace", icon='COPYDOWN')
        row.operator("lumafold.clear_real_machine_trace", text="清空", icon='TRASH')
        col.label(text=str(trace_path())[-96:])
        entries = tail_entries(12)
        if not entries:
            col.label(text="暂无追踪事件")
            return
        box = col.box()
        for item in entries:
            stage = str(item.get("stage") or "?")
            brief = _brief_data(item.get("data") or {})
            line = stage + (" · " + brief if brief else "")
            box.label(text=line[:118])


_TRACE_CLASSES = (
    LUMAFOLD_OT_copy_real_machine_trace,
    LUMAFOLD_OT_clear_real_machine_trace,
    LUMAFOLD_PT_real_machine_trace,
)


def register_ui() -> None:
    global _UI_REGISTERED
    if _UI_REGISTERED:
        return
    for cls in _TRACE_CLASSES:
        bpy.utils.register_class(cls)
    _UI_REGISTERED = True


def unregister_ui() -> None:
    global _UI_REGISTERED
    if not _UI_REGISTERED:
        return
    for cls in reversed(_TRACE_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    _UI_REGISTERED = False
