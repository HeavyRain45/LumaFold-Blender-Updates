from __future__ import annotations

"""Event-context authority for Sculpt input routing.

The universal broker receives Blender's live modal ``context``. Route truth
comes from that context, never from global ``bpy.context`` during Host migration.

Plain LMB ownership is resolved by Blender itself before any LumaFold transient:
- Blender Sculpt ``brush_stroke(ignore_background_click=True)`` owns surface hits;
- only Blender's explicit PASS_THROUGH may promote the press to native Rotate;
- CANCELLED/errors fail closed and never become Rotate.

ZBrush-specific modifier gestures are delegated to isolated gesture modules.
Ctrl/Ctrl+Alt LMB is fully owned by the mask gesture module so tap/filter and
drag/mask behavior cannot fight separate route branches.
"""

_INSTALLED = False
_BASE = None
_TRACE = None
_NATIVE_POINTER = None
_ALT_GESTURE = None
_MASK_GESTURE = None


def _trace(reason: str, context, event, **extra):
    if _TRACE is None:
        return
    try:
        payload = {
            "reason": str(reason),
            "event": str(getattr(event, "type", "") or ""),
            "value": str(getattr(event, "value", "") or "").upper(),
            "mode": str(getattr(context, "mode", "") or ""),
            "area_type": str(getattr(getattr(context, "area", None), "type", "") or ""),
            "region_type": str(getattr(getattr(context, "region", None), "type", "") or ""),
        }
        payload.update(extra)
        _TRACE.trace("SCULPT_ROUTE_DECISION", **payload)
    except Exception:
        pass


def _context_sculpt_truth(base, context) -> bool:
    try:
        if str(getattr(context, "mode", "") or "").upper() != "SCULPT":
            return False
        obj = getattr(context, "sculpt_object", None)
        if obj is None:
            objects = getattr(getattr(context, "view_layer", None), "objects", None)
            obj = getattr(objects, "active", None) if objects is not None else None
        return bool(obj is not None and getattr(obj, "type", "") == "MESH")
    except Exception:
        return False


def _route_event_context_authority(context, event, *, host=None) -> bool:
    base = _BASE
    if base is None:
        return False

    event_type = str(getattr(event, "type", "") or "")
    event_value = str(getattr(event, "value", "") or "").upper()

    if event_type == "WINDOW_DEACTIVATE":
        base._reset_transient_input(host)
        base._clear_gesture_registry()
        _trace("window_deactivate", context, event)
        return False

    base._note_alt(event)

    if not base._product_active():
        _trace("product_inactive", context, event)
        return False
    if base._shortcut_capture_active():
        _trace("shortcut_capture", context, event)
        return False
    if not _context_sculpt_truth(base, context):
        _trace("context_not_sculpt", context, event)
        return False
    if bool(
        getattr(base.STATE, "capture_keyboard", False)
        or getattr(base.STATE, "capture_text", False)
    ):
        _trace("ui_keyboard_capture", context, event)
        return False

    slot = base._quick_slot_for_event(event)
    if slot is not None:
        _trace("quick_slot", context, event, slot=int(slot))
        return base._activate_quick_slot(slot)

    if base._profile() != "zbrush":
        _trace("profile_not_zbrush", context, event, profile=base._profile())
        return False
    if event_value != "PRESS" or event_type not in base._POINTER_BUTTONS:
        return False

    target = base._view3d_region_under_pointer(context, event)
    if target is None:
        _trace("no_view3d_target", context, event)
        return False
    if host is not None and base._pointer_over_host(host, event):
        _trace("pointer_over_embedded_host", context, event)
        return False

    ctrl = bool(getattr(event, "ctrl", False))
    alt = bool(getattr(event, "alt", False))

    # One Ctrl owner. Tap filtering never depends on a custom surface hit test;
    # the mask module classifies only after a real drag threshold is crossed.
    if event_type == "LEFTMOUSE" and ctrl and _MASK_GESTURE is not None:
        handled = _MASK_GESTURE.handle_pointer_press(context, event, target)
        if handled is not None:
            _trace(
                "zbrush_mask_gesture" if handled else "zbrush_mask_gesture_failed",
                context,
                event,
            )
            return bool(handled)

    # Alt-only left gestures use strict current-event Alt truth. Historical Alt
    # timestamps may not arm a new gesture.
    if event_type == "LEFTMOUSE" and alt and not ctrl and _ALT_GESTURE is not None:
        handled = _ALT_GESTURE.handle_pointer_press(context, event, target)
        if handled is not None:
            _trace(
                "zbrush_alt_gesture" if handled else "zbrush_alt_gesture_failed",
                context,
                event,
            )
            return bool(handled)

    if event_type == "LEFTMOUSE" and not ctrl and not alt and _NATIVE_POINTER is not None:
        outcome = _NATIVE_POINTER.arbitrate_plain_lmb(context, event, target)
        if outcome == _NATIVE_POINTER.SCULPT:
            _trace("blender_native_sculpt", context, event, pointer_owner=outcome)
            return True
        if outcome == _NATIVE_POINTER.ROTATE:
            _trace("blender_native_rotate", context, event, pointer_owner=outcome)
            return True
        _trace("blender_native_pointer_fallback", context, event, pointer_owner=outcome)
        return False

    navigation = getattr(base, "_native_navigation_handoff", None)
    if callable(navigation):
        nav_result = navigation(context, event, target, host=host)
        if nav_result is not None:
            _trace(
                "native_navigation_handoff" if nav_result else "native_navigation_failed",
                context,
                event,
                operator="VIEW3D_OT_rotate",
            )
            return bool(nav_result)

    # Legacy transient remains only for modifier RMB and other not-yet-migrated
    # gestures. Ctrl LMB no longer falls through here.
    operator_name = (
        "sculpt_z_left_runtime_v4"
        if event_type == "LEFTMOUSE"
        else "sculpt_z_right_runtime_v4"
    )
    ok = base._invoke_transient(operator_name, target)
    _trace(
        "transient_started" if ok else "transient_invoke_failed",
        context,
        event,
        operator=operator_name,
    )
    return bool(ok)


def install(
    sculpt_input_core,
    real_machine_trace=None,
    native_pointer=None,
    alt_gesture=None,
    mask_gesture=None,
):
    global _INSTALLED, _BASE, _TRACE, _NATIVE_POINTER, _ALT_GESTURE, _MASK_GESTURE
    if _INSTALLED:
        return
    setter = getattr(sculpt_input_core, "set_route_handler", None)
    if not callable(setter):
        raise RuntimeError("Sculpt route handler slot is unavailable")
    if native_pointer is None:
        raise RuntimeError("Blender-native pointer arbiter is unavailable")
    if alt_gesture is None or mask_gesture is None:
        raise RuntimeError("ZBrush gesture dependencies are incomplete")
    _BASE = sculpt_input_core
    _TRACE = real_machine_trace
    _NATIVE_POINTER = native_pointer
    _ALT_GESTURE = alt_gesture
    _MASK_GESTURE = mask_gesture
    setter(_route_event_context_authority)
    _INSTALLED = True


def uninstall():
    global _INSTALLED, _BASE, _TRACE, _NATIVE_POINTER, _ALT_GESTURE, _MASK_GESTURE
    if not _INSTALLED:
        return
    if _BASE is not None:
        setter = getattr(_BASE, "set_route_handler", None)
        if callable(setter):
            setter(None)
    _BASE = None
    _TRACE = None
    _NATIVE_POINTER = None
    _ALT_GESTURE = None
    _MASK_GESTURE = None
    _INSTALLED = False
