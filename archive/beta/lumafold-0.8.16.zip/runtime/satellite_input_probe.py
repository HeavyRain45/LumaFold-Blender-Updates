from __future__ import annotations

"""Diagnostic-only observer for the persistent Sculpt input session.

The probe receives broker events through an explicit observer slot. It never
wraps Blender operator methods, decides ownership, or changes modal results.
Optional tablet-locality diagnostics are fan-out observation only.
"""

import ctypes
from ctypes import wintypes

import bpy

from ..core.host_control import HOST_CONTROL
from ..core.state import STATE
from . import real_machine_trace

_INSTALLED = False
_BASE = None
_UNSUBSCRIBE = None
_CYCLE = 0
_PENDING_BEFORE = {}
_TABLET_LOCALITY = None

_POINTERS = {"LEFTMOUSE", "RIGHTMOUSE", "MIDDLEMOUSE"}


def _operator_ids(window):
    if window is None:
        return []
    try:
        operators = tuple(window.modal_operators)
    except Exception:
        return []
    result = []
    for op in operators[:24]:
        text = ""
        for owner_name in ("bl_rna", "rna_type"):
            try:
                owner = getattr(op, owner_name, None)
                ident = str(getattr(owner, "identifier", "") or "")
                if ident:
                    text = ident
                    break
            except Exception:
                pass
        if not text:
            try:
                text = str(op)
            except Exception:
                text = "?"
        result.append(text[:120])
    return result


def _win32_state():
    try:
        user32 = ctypes.WinDLL("user32", use_last_error=True)
        user32.GetForegroundWindow.restype = wintypes.HWND
        user32.GetCapture.restype = wintypes.HWND
        return {
            "foreground_hwnd": int(user32.GetForegroundWindow() or 0),
            "capture_hwnd": int(user32.GetCapture() or 0),
        }
    except Exception as exc:
        return {"win32_error": f"{type(exc).__name__}: {exc}"}


def _snapshot(context):
    window = getattr(context, "window", None)
    area = getattr(context, "area", None)
    region = getattr(context, "region", None)
    payload = {
        "cycle": int(_CYCLE),
        "host_mode": str(getattr(STATE, "host_mode", "") or ""),
        "lease": HOST_CONTROL.snapshot(),
        "window_ptr": int(window.as_pointer()) if window is not None else 0,
        "area_type": str(getattr(area, "type", "") or ""),
        "region_type": str(getattr(region, "type", "") or ""),
        "modal_ops": _operator_ids(window),
    }
    payload.update(_win32_state())
    return payload


def _deferred_probe(window_ptr: int, cycle: int):
    if not _INSTALLED:
        return None
    try:
        window = next(
            (
                w
                for w in tuple(bpy.context.window_manager.windows)
                if int(w.as_pointer()) == int(window_ptr or 0)
            ),
            None,
        )
        payload = {
            "cycle": int(cycle),
            "host_mode": str(getattr(STATE, "host_mode", "") or ""),
            "lease": HOST_CONTROL.snapshot(),
            "window_ptr": int(window_ptr or 0),
            "modal_ops": _operator_ids(window),
        }
        payload.update(_win32_state())
        real_machine_trace.trace("SCULPT_INPUT_AFTER_PRESS", **payload)
    except Exception as exc:
        real_machine_trace.trace(
            "SCULPT_INPUT_PROBE_ERROR",
            error=f"{type(exc).__name__}: {exc}",
        )
    return None


def _event_key(context, event):
    window = getattr(context, "window", None)
    ptr = int(window.as_pointer()) if window is not None else 0
    return (
        ptr,
        str(getattr(event, "type", "") or "").upper(),
        str(getattr(event, "value", "") or "").upper(),
    )


def _observe(phase: str, context, event, *, result=None):
    # Locality probe receives only the pre-route event and is strictly read-only.
    if phase == "before" and _TABLET_LOCALITY is not None:
        try:
            _TABLET_LOCALITY.observe(context, event, real_machine_trace)
        except Exception:
            pass

    event_type = str(getattr(event, "type", "") or "").upper()
    event_value = str(getattr(event, "value", "") or "").upper()
    if event_type not in _POINTERS or event_value not in {"PRESS", "RELEASE"}:
        return
    key = _event_key(context, event)
    if phase == "before":
        _PENDING_BEFORE[key] = _snapshot(context)
        return
    if phase != "after":
        return
    before = _PENDING_BEFORE.pop(key, None)
    after = _snapshot(context)
    real_machine_trace.trace(
        "SCULPT_INPUT_EDGE",
        event=event_type,
        value=event_value,
        result=list(result or ()),
        before=before,
        after=after,
    )
    if event_type == "LEFTMOUSE" and event_value == "PRESS":
        try:
            window = getattr(context, "window", None)
            ptr = int(window.as_pointer()) if window is not None else 0
            bpy.app.timers.register(
                lambda p=ptr, c=int(_CYCLE): _deferred_probe(p, c),
                first_interval=0.03,
            )
        except Exception:
            pass


def _host_transition(snapshot):
    global _CYCLE
    state = str((snapshot or {}).get("state") or "")
    owner = str((snapshot or {}).get("owner") or "")
    if state == "SATELLITE" and owner == "satellite":
        _CYCLE += 1
    real_machine_trace.trace(
        "SCULPT_INPUT_HOST_TRANSITION",
        cycle=int(_CYCLE),
        lease=dict(snapshot or {}),
        host_mode=str(getattr(STATE, "host_mode", "") or ""),
        **_win32_state(),
    )


def install(sculpt_input_core, tablet_locality=None):
    global _INSTALLED, _BASE, _UNSUBSCRIBE, _TABLET_LOCALITY
    if _INSTALLED:
        return
    setter = getattr(sculpt_input_core, "set_input_observer", None)
    if not callable(setter):
        raise RuntimeError("Universal input observer slot is unavailable")
    _BASE = sculpt_input_core
    _TABLET_LOCALITY = tablet_locality
    setter(_observe)
    try:
        _UNSUBSCRIBE = HOST_CONTROL.subscribe(_host_transition)
    except Exception:
        _UNSUBSCRIBE = None
    real_machine_trace.trace("SCULPT_INPUT_PROBE_INSTALLED")
    _INSTALLED = True


def uninstall():
    global _INSTALLED, _BASE, _UNSUBSCRIBE, _TABLET_LOCALITY
    if not _INSTALLED:
        return
    if callable(_UNSUBSCRIBE):
        try:
            _UNSUBSCRIBE()
        except Exception:
            pass
    _UNSUBSCRIBE = None
    _PENDING_BEFORE.clear()
    if _BASE is not None:
        setter = getattr(_BASE, "set_input_observer", None)
        if callable(setter):
            setter(None)
    _BASE = None
    _TABLET_LOCALITY = None
    _INSTALLED = False
