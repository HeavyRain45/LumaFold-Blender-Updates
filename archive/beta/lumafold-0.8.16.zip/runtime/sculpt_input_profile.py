from __future__ import annotations

"""Sculpt-only ZBrush-style input profile for LumaFold.

Blender profile stays a pure pass-through. Z profile only owns Sculpt-mode
pointer gestures and delegates sculpt/mask work to Blender public operators.

Dev15 refinements:
- background Ctrl-drag follows ZBrush Clear Mask semantics;
- Mask rectangle has a light gray translucent fill plus outline;
- ZBrush Alt pen-zoom remains owned by LumaFold until pen-up, so tablet hover
  can never keep zooming after contact is lost;
- Shift + blank LMB uses Blender's native view-pan behavior (the same action as
  Blender Shift+MMB) instead of the dev14 axis-snap experiment;
- interaction timestamps remain available to the preview scheduler.
"""

import math
import time

import bpy
import gpu
from bpy_extras import view3d_utils
from gpu_extras.batch import batch_for_shader

from ..core.app import APP

_LEFT_ID = "lumafold.sculpt_z_left_mouse"
_RIGHT_ID = "lumafold.sculpt_z_right_mouse"
_KEYMAP_NAME = "Sculpt"
_ADDON_KEYMAPS = []
_LAST_INTERACTION = 0.0

_GESTURE_TOOL_MARKERS = (
    "box_", "lasso_", "line_", "polyline_",
    "trim", "filter", "face_set", "annotate",
    "move", "rotate", "scale", "transform",
)


def note_interaction():
    global _LAST_INTERACTION
    _LAST_INTERACTION = time.monotonic()


def seconds_since_interaction() -> float:
    if _LAST_INTERACTION <= 0.0:
        return 9999.0
    return max(0.0, time.monotonic() - _LAST_INTERACTION)


def _profile() -> str:
    try:
        value = str(
            APP.store.namespace("sculpt").get("input_profile", "blender") or "blender"
        ).strip().lower()
    except Exception:
        value = "blender"
    return "zbrush" if value == "zbrush" else "blender"


def _view3d_window(context) -> bool:
    area = getattr(context, "area", None)
    region = getattr(context, "region", None)
    return bool(
        area is not None and getattr(area, "type", "") == "VIEW_3D"
        and region is not None and getattr(region, "type", "") == "WINDOW"
    )


def _active_sculpt_mesh(context):
    obj = getattr(context, "sculpt_object", None)
    if obj is None:
        view_layer = getattr(context, "view_layer", None)
        objects = getattr(view_layer, "objects", None) if view_layer is not None else None
        obj = getattr(objects, "active", None) if objects is not None else None
    if obj is None or getattr(obj, "type", "") != "MESH":
        return None
    return obj


def _z_profile_active(context) -> bool:
    return bool(
        str(getattr(context, "mode", "") or "").upper() == "SCULPT"
        and _view3d_window(context)
        and _active_sculpt_mesh(context) is not None
        and _profile() == "zbrush"
    )


def _active_tool_id(context) -> str:
    try:
        tool = context.workspace.tools.from_space_view3d_mode("SCULPT", create=False)
        return str(getattr(tool, "idname", "") or "")
    except Exception:
        return ""


def _should_pass_special_tool(context) -> bool:
    tool_id = _active_tool_id(context).lower()
    if not tool_id:
        return False
    if tool_id in {"builtin.brush", "builtin_brush.draw"}:
        return False
    if tool_id.startswith("builtin_brush."):
        return False
    return any(marker in tool_id for marker in _GESTURE_TOOL_MARKERS)


def _ray_vectors(context, event):
    region = getattr(context, "region", None)
    rv3d = getattr(context, "region_data", None)
    if region is None or rv3d is None:
        return None, None
    try:
        coord = (float(event.mouse_region_x), float(event.mouse_region_y))
        origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
        direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
        return origin, direction
    except Exception:
        return None, None


def _ray_hit_active(context, event, obj) -> bool:
    """Fast path: only test the active Sculpt mesh, not the whole scene."""
    if obj is None:
        return False
    origin, direction = _ray_vectors(context, event)
    if origin is None:
        return False
    try:
        inv = obj.matrix_world.inverted_safe()
        ray_origin = inv @ origin
        ray_direction = inv.to_3x3() @ direction
        depsgraph = context.evaluated_depsgraph_get()
        result, _location, _normal, _index = obj.ray_cast(
            ray_origin, ray_direction, depsgraph=depsgraph
        )
        return bool(result)
    except Exception:
        return False


def _scene_hit_object(context, event):
    """Whole-scene ray cast is intentionally reserved for Alt tap transfer."""
    origin, direction = _ray_vectors(context, event)
    scene = getattr(context, "scene", None)
    if origin is None or scene is None:
        return None
    try:
        depsgraph = context.evaluated_depsgraph_get()
        result, _location, _normal, _index, obj, _matrix = scene.ray_cast(
            depsgraph, origin, direction
        )
        return obj if result else None
    except Exception:
        return None


def _same_object(a, b) -> bool:
    if a is None or b is None:
        return False
    if a == b:
        return True
    try:
        return getattr(a, "original", None) == b or getattr(b, "original", None) == a
    except Exception:
        return False


def _drag_threshold(context) -> float:
    try:
        inputs = context.preferences.inputs
        values = []
        for name in ("drag_threshold_tablet", "drag_threshold_mouse", "drag_threshold"):
            value = getattr(inputs, name, None)
            if value is not None:
                value = float(value)
                if value > 0:
                    values.append(value)
        if values:
            return max(2.0, min(values))
    except Exception:
        pass
    return 4.0


def _brush_stroke_call(**kwargs):
    try:
        return bpy.ops.sculpt.brush_stroke("INVOKE_DEFAULT", **kwargs)
    except (RuntimeError, TypeError):
        kwargs.pop("ignore_background_click", None)
        try:
            return bpy.ops.sculpt.brush_stroke("INVOKE_DEFAULT", **kwargs)
        except (RuntimeError, TypeError):
            return {"CANCELLED"}


def _invoke_brush_stroke(*, invert=False, smooth=False, mask=False):
    if bpy.app.version >= (5, 1, 0):
        mode = "INVERT" if invert else "NORMAL"
        toggle = "MASK" if mask else ("SMOOTH" if smooth and not invert else "None")
        return _brush_stroke_call(
            mode=mode,
            brush_toggle=toggle,
            ignore_background_click=True,
        )
    if mask:
        return _brush_stroke_call(mode="MASK", ignore_background_click=True)
    mode = "INVERT" if invert else ("SMOOTH" if smooth else "NORMAL")
    return _brush_stroke_call(mode=mode, ignore_background_click=True)


def _invoke_view(op_name: str):
    try:
        return getattr(bpy.ops.view3d, op_name)("INVOKE_DEFAULT")
    except (AttributeError, RuntimeError):
        return {"CANCELLED"}


def _mask_filter(sharpen: bool):
    kwargs = {
        "filter_type": "SHARPEN" if sharpen else "SMOOTH",
        "auto_iteration_count": True,
    }
    try:
        return bpy.ops.sculpt.mask_filter("EXEC_DEFAULT", **kwargs)
    except (RuntimeError, TypeError):
        kwargs.pop("auto_iteration_count", None)
        try:
            return bpy.ops.sculpt.mask_filter("EXEC_DEFAULT", **kwargs)
        except (RuntimeError, TypeError):
            return {"CANCELLED"}


def _invert_mask():
    try:
        return bpy.ops.paint.mask_flood_fill("EXEC_DEFAULT", mode="INVERT")
    except RuntimeError:
        return {"CANCELLED"}


def _set_mask(value: float):
    try:
        return bpy.ops.paint.mask_flood_fill(
            "EXEC_DEFAULT", mode="VALUE", value=max(0.0, min(1.0, float(value)))
        )
    except (RuntimeError, TypeError):
        return {"CANCELLED"}


def _clear_mask():
    return _set_mask(0.0)


def _box_mask(x0: int, y0: int, x1: int, y1: int, *, erase: bool):
    xmin, xmax = sorted((int(x0), int(x1)))
    ymin, ymax = sorted((int(y0), int(y1)))
    if xmax - xmin < 2 or ymax - ymin < 2:
        return {"CANCELLED"}
    kwargs = {
        "xmin": xmin,
        "xmax": xmax,
        "ymin": ymin,
        "ymax": ymax,
        "mode": "VALUE",
        "value": 0.0 if erase else 1.0,
        "use_front_faces_only": False,
    }
    try:
        return bpy.ops.paint.mask_box_gesture("EXEC_DEFAULT", True, **kwargs)
    except (RuntimeError, TypeError):
        kwargs.pop("use_front_faces_only", None)
        try:
            return bpy.ops.paint.mask_box_gesture("EXEC_DEFAULT", True, **kwargs)
        except (RuntimeError, TypeError):
            return {"CANCELLED"}


def _transfer_sculpt_object():
    try:
        return bpy.ops.object.transfer_mode("INVOKE_DEFAULT")
    except (AttributeError, RuntimeError):
        return {"CANCELLED"}


def _tablet_contact_lost(event) -> bool:
    """True only for an actual tablet hover/no-pressure motion sample."""
    try:
        return bool(event.is_tablet) and float(event.pressure) <= 0.001
    except Exception:
        return False


def _zoom_step(context, current_y: float, previous_y: float):
    """Apply one smooth ZBrush-style zoom step without spawning a second modal."""
    rv3d = getattr(context, "region_data", None)
    if rv3d is None:
        return
    dy = float(current_y) - float(previous_y)
    if abs(dy) < 0.01:
        return
    try:
        distance = max(1.0e-7, float(rv3d.view_distance))
        # Pen upward = zoom in, downward = zoom out. Exponential scaling keeps
        # the feel proportional across very close and very distant views.
        factor = math.exp(-dy * 0.012)
        rv3d.view_distance = max(1.0e-7, min(1.0e12, distance * factor))
        area = getattr(context, "area", None)
        if area is not None:
            area.tag_redraw()
    except Exception:
        pass


class _GestureMixin:
    _start_x = 0
    _start_y = 0
    _threshold_sq = 16.0
    _moved = False

    def _begin(self, context, event):
        note_interaction()
        self._start_x = int(event.mouse_region_x)
        self._start_y = int(event.mouse_region_y)
        threshold = _drag_threshold(context)
        self._threshold_sq = threshold * threshold
        self._moved = False

    def _distance_sq(self, event) -> float:
        dx = float(event.mouse_region_x) - float(self._start_x)
        dy = float(event.mouse_region_y) - float(self._start_y)
        return dx * dx + dy * dy

    def _crossed_drag(self, event) -> bool:
        if self._moved:
            return True
        if self._distance_sq(event) >= self._threshold_sq:
            self._moved = True
        return self._moved


class LUMAFOLD_OT_sculpt_z_left_mouse(bpy.types.Operator, _GestureMixin):
    bl_idname = _LEFT_ID
    bl_label = "LumaFold Z Sculpt Left Mouse"
    bl_description = "ZBrush-style sculpt, navigation and mask routing in LumaFold Z profile"
    bl_options = {"INTERNAL"}

    _box_handle = None

    @classmethod
    def poll(cls, context):
        return _z_profile_active(context)

    def _tag_redraw(self, context):
        try:
            context.area.tag_redraw()
        except Exception:
            pass

    def _draw_box_preview(self):
        if not getattr(self, "_box_preview", False):
            return
        x0, y0 = float(self._start_x), float(self._start_y)
        x1, y1 = self._box_end
        if abs(x1 - x0) < 1.0 and abs(y1 - y0) < 1.0:
            return

        fill = (
            (x0, y0), (x1, y0), (x1, y1),
            (x0, y0), (x1, y1), (x0, y1),
        )
        outline = ((x0, y0), (x1, y0), (x1, y1), (x0, y1), (x0, y0))
        try:
            shader = gpu.shader.from_builtin("UNIFORM_COLOR")
            gpu.state.blend_set("ALPHA")

            fill_batch = batch_for_shader(shader, "TRIS", {"pos": fill})
            shader.bind()
            shader.uniform_float("color", (0.72, 0.72, 0.72, 0.18))
            fill_batch.draw(shader)

            line_batch = batch_for_shader(shader, "LINE_STRIP", {"pos": outline})
            gpu.state.line_width_set(1.4)
            shader.uniform_float("color", (0.92, 0.92, 0.92, 0.90))
            line_batch.draw(shader)
        except Exception:
            pass
        finally:
            try:
                gpu.state.line_width_set(1.0)
            except Exception:
                pass
            try:
                gpu.state.blend_set("NONE")
            except Exception:
                pass

    def _start_box_preview(self, context):
        self._box_preview = True
        self._box_end = (float(self._start_x), float(self._start_y))
        try:
            self._box_handle = bpy.types.SpaceView3D.draw_handler_add(
                self._draw_box_preview, (), "WINDOW", "POST_PIXEL"
            )
        except Exception:
            self._box_handle = None
        self._tag_redraw(context)

    def _stop_box_preview(self, context):
        self._box_preview = False
        handle = getattr(self, "_box_handle", None)
        if handle is not None:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(handle, "WINDOW")
            except Exception:
                pass
            self._box_handle = None
        self._tag_redraw(context)

    def invoke(self, context, event):
        if _should_pass_special_tool(context):
            return {"PASS_THROUGH"}

        self._begin(context, event)
        self._ctrl = bool(event.ctrl)
        self._alt = bool(event.alt)
        self._shift = bool(event.shift)
        self._zoom_armed = bool(self._alt and not self._ctrl and not self._shift)
        self._zoom_ready = False
        self._zoom_tablet = bool(getattr(event, "is_tablet", False))
        self._zoom_last_y = float(event.mouse_region_y)
        self._box_preview = False
        self._box_handle = None

        sculpt_obj = _active_sculpt_mesh(context)
        self._hit_current = _ray_hit_active(context, event, sculpt_obj)

        # Current-mesh stroke stays immediate for pressure/latency quality.
        if self._hit_current and not self._ctrl:
            _invoke_brush_stroke(
                invert=self._alt,
                smooth=(self._shift and not self._alt),
                mask=False,
            )
            return {"FINISHED"}

        if self._ctrl and not self._hit_current:
            self._start_box_preview(context)

        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        note_interaction()
        if not _z_profile_active(context):
            self._stop_box_preview(context)
            return {"CANCELLED"}
        if event.type == "ESC":
            self._stop_box_preview(context)
            return {"CANCELLED"}

        # Exact ZBrush tablet zoom chord: Alt down -> pen-down on blank canvas ->
        # release Alt while keeping pen contact -> move pen. Once armed, LumaFold
        # keeps ownership until contact/release so tablet hover cannot continue it.
        if self._zoom_armed and event.type in {"LEFT_ALT", "RIGHT_ALT"} and event.value == "RELEASE":
            if not self._moved:
                self._zoom_ready = True
                self._zoom_last_y = float(event.mouse_region_y)
            return {"RUNNING_MODAL"}

        if self._zoom_ready and self._zoom_tablet and _tablet_contact_lost(event):
            self._stop_box_preview(context)
            return {"FINISHED"}

        if event.type in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}:
            if self._zoom_ready:
                current_y = float(event.mouse_region_y)
                _zoom_step(context, current_y, self._zoom_last_y)
                self._zoom_last_y = current_y
                self._moved = True
                return {"RUNNING_MODAL"}

            if self._ctrl and not self._hit_current:
                self._box_end = (float(event.mouse_region_x), float(event.mouse_region_y))
                self._tag_redraw(context)

            if self._crossed_drag(event):
                if self._ctrl:
                    if self._hit_current:
                        self._stop_box_preview(context)
                        _invoke_brush_stroke(
                            invert=bool(event.alt or self._alt), smooth=False, mask=True
                        )
                        return {"FINISHED"}
                    return {"RUNNING_MODAL"}

                self._stop_box_preview(context)
                # Shift + blank LMB is deliberately mapped to the exact Blender
                # navigation action normally reached through Shift+MMB: View Pan.
                if bool(event.shift or self._shift):
                    _invoke_view("move")
                elif bool(event.alt):
                    _invoke_view("move")
                else:
                    _invoke_view("rotate")
                return {"FINISHED"}

        if event.type == "LEFTMOUSE" and event.value == "RELEASE":
            self._stop_box_preview(context)

            if self._moved:
                if self._ctrl and not self._hit_current:
                    if self._alt:
                        # Keep Ctrl+Alt as a subtractive rectangle for the
                        # common reverse-mask workflow.
                        _box_mask(
                            self._start_x,
                            self._start_y,
                            int(event.mouse_region_x),
                            int(event.mouse_region_y),
                            erase=True,
                        )
                    else:
                        # ZBrush truth: Ctrl-dragging available empty canvas
                        # clears the visible mask; the rectangle is feedback,
                        # not a region that becomes newly masked.
                        _clear_mask()
                return {"FINISHED"}

            if self._ctrl:
                if self._hit_current:
                    _mask_filter(sharpen=self._alt)
                else:
                    _invert_mask()
                return {"FINISHED"}

            # Shift + blank tap has no separate action. Its actual ZBrush-style
            # navigation mapping is Shift + blank drag -> Blender View Pan.
            if self._shift and not self._hit_current:
                return {"FINISHED"}

            # Only now pay for a whole-scene hit test; normal sculpt/navigation
            # never needs it.
            if self._alt and not self._hit_current:
                sculpt_obj = _active_sculpt_mesh(context)
                hit_obj = _scene_hit_object(context, event)
                if (
                    hit_obj is not None
                    and getattr(hit_obj, "type", "") == "MESH"
                    and not _same_object(hit_obj, sculpt_obj)
                ):
                    _transfer_sculpt_object()
                return {"FINISHED"}

            return {"FINISHED"}

        return {"RUNNING_MODAL"}


class LUMAFOLD_OT_sculpt_z_right_mouse(bpy.types.Operator, _GestureMixin):
    bl_idname = _RIGHT_ID
    bl_label = "LumaFold Z Sculpt Right Mouse"
    bl_description = "ZBrush-style view navigation and Sculpt context menu in LumaFold Z profile"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        return _z_profile_active(context)

    def invoke(self, context, event):
        if _should_pass_special_tool(context):
            return {"PASS_THROUGH"}
        self._begin(context, event)
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        note_interaction()
        if not _z_profile_active(context):
            return {"CANCELLED"}
        if event.type == "ESC":
            return {"CANCELLED"}

        if event.type in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"} and self._crossed_drag(event):
            if bool(event.alt):
                _invoke_view("move")
            elif bool(event.ctrl):
                _invoke_view("zoom")
            else:
                _invoke_view("rotate")
            return {"FINISHED"}

        if event.type == "RIGHTMOUSE" and event.value == "RELEASE":
            try:
                bpy.ops.wm.call_panel("INVOKE_DEFAULT", name="VIEW3D_PT_sculpt_context_menu")
            except RuntimeError:
                pass
            return {"FINISHED"}

        return {"RUNNING_MODAL"}


_CLASSES = (
    LUMAFOLD_OT_sculpt_z_left_mouse,
    LUMAFOLD_OT_sculpt_z_right_mouse,
)


def _remove_stale_items(km):
    try:
        for item in tuple(km.keymap_items):
            if str(getattr(item, "idname", "") or "") in {_LEFT_ID, _RIGHT_ID}:
                km.keymap_items.remove(item)
    except Exception:
        pass


def _register_keymaps():
    wm = getattr(bpy.context, "window_manager", None)
    keyconfigs = getattr(wm, "keyconfigs", None) if wm is not None else None
    kc = getattr(keyconfigs, "addon", None) if keyconfigs is not None else None
    if kc is None:
        return
    km = kc.keymaps.get(_KEYMAP_NAME)
    if km is None:
        km = kc.keymaps.new(name=_KEYMAP_NAME, space_type="EMPTY", region_type="WINDOW")
    _remove_stale_items(km)
    for op_id, event_type in ((_LEFT_ID, "LEFTMOUSE"), (_RIGHT_ID, "RIGHTMOUSE")):
        item = km.keymap_items.new(op_id, event_type, "PRESS", any=True)
        _ADDON_KEYMAPS.append((km, item))


def _unregister_keymaps():
    while _ADDON_KEYMAPS:
        km, item = _ADDON_KEYMAPS.pop()
        try:
            km.keymap_items.remove(item)
        except Exception:
            pass
    try:
        wm = getattr(bpy.context, "window_manager", None)
        kc = getattr(getattr(wm, "keyconfigs", None), "addon", None) if wm is not None else None
        km = kc.keymaps.get(_KEYMAP_NAME) if kc is not None else None
        if km is not None:
            _remove_stale_items(km)
    except Exception:
        pass


def register():
    for cls in _CLASSES:
        try:
            bpy.utils.register_class(cls)
        except RuntimeError:
            try:
                bpy.utils.unregister_class(cls)
            except Exception:
                pass
            bpy.utils.register_class(cls)
    _register_keymaps()


def unregister():
    _unregister_keymaps()
    for cls in reversed(_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
