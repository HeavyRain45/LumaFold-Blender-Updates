from __future__ import annotations

"""Small persistent cache for Blender-owned Brush/Alpha preview payloads.

Preview extraction itself must happen on Blender's main thread. Persisting the
already validated RGBA payloads avoids paying that extraction cost again on the
first Brush Library open after every Blender restart or LumaFold hot reload.

The cache is intentionally disposable: it lives under bpy.app.cachedir, is
versioned by Blender major/minor plus LumaFold preview-format revision, and is
never part of user project/persistence state.
"""

import json
from pathlib import Path

import bpy

from ..core.app import APP

_FORMAT = 1
_BRUSH_LIMIT = 160
_ALPHA_LIMIT = 128
_INSTALLED = False
_LAST_SIGNATURE = None
_TIMER_ACTIVE = False


def _cache_path() -> Path:
    raw = str(getattr(bpy.app, "cachedir", "") or "").strip()
    base = Path(raw).expanduser() if raw else (Path.home() / ".cache" / "blender")
    folder = base / "lumafold"
    folder.mkdir(parents=True, exist_ok=True)
    return folder / "preview_payloads_v1.json"


def _preview_format_revision(state) -> int:
    try:
        return int(state.get("brush_preview_format_revision", 0) or 0)
    except Exception:
        return 0


def _valid_payloads(raw, limit: int) -> dict:
    result = {}
    for identity, value in list(dict(raw or {}).items())[-max(1, int(limit)):]:
        payload = dict(value or {})
        if not payload.get("rgba_b64"):
            continue
        payload["key"] = str(identity)
        result[str(identity)] = payload
    return result


def _merge_cache(state, key: str, values: dict, limit: int):
    target = state.setdefault(key, {})
    for identity, payload in dict(values or {}).items():
        target[str(identity)] = dict(payload or {})
    while len(target) > limit:
        target.pop(next(iter(target)), None)


def _signature(state):
    brush = dict(state.get("primary_brush_preview_cache") or state.get("brush_library_preview_cache") or {})
    alpha = dict(state.get("primary_alpha_preview_cache") or state.get("alpha_library_preview_cache") or {})
    # Identity sets are cheap at this scale (64 Brush assets today) and make a
    # library refresh with the same item count persist correctly.
    return (
        tuple(sorted(str(key) for key in brush.keys())),
        tuple(sorted(str(key) for key in alpha.keys())),
        _preview_format_revision(state),
    )


def _load():
    global _LAST_SIGNATURE
    state = APP.store.namespace("sculpt")
    path = _cache_path()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        _LAST_SIGNATURE = _signature(state)
        return

    expected_mm = [int(bpy.app.version[0]), int(bpy.app.version[1])]
    if int(data.get("format", -1)) != _FORMAT:
        _LAST_SIGNATURE = _signature(state)
        return
    if list(data.get("blender_mm") or ()) != expected_mm:
        _LAST_SIGNATURE = _signature(state)
        return
    if int(data.get("preview_revision", -1)) != _preview_format_revision(state):
        _LAST_SIGNATURE = _signature(state)
        return

    brush = _valid_payloads(data.get("brush"), _BRUSH_LIMIT)
    alpha = _valid_payloads(data.get("alpha"), _ALPHA_LIMIT)
    for key in ("primary_brush_preview_cache", "brush_library_preview_cache"):
        _merge_cache(state, key, brush, _BRUSH_LIMIT)
    for key in ("primary_alpha_preview_cache", "alpha_library_preview_cache"):
        _merge_cache(state, key, alpha, _ALPHA_LIMIT)
    _LAST_SIGNATURE = _signature(state)


def _flush(force: bool = False):
    global _LAST_SIGNATURE
    state = APP.store.namespace("sculpt")
    sig = _signature(state)
    if not force and sig == _LAST_SIGNATURE:
        return

    brush = _valid_payloads(
        state.get("primary_brush_preview_cache") or state.get("brush_library_preview_cache"),
        _BRUSH_LIMIT,
    )
    alpha = _valid_payloads(
        state.get("primary_alpha_preview_cache") or state.get("alpha_library_preview_cache"),
        _ALPHA_LIMIT,
    )
    payload = {
        "format": _FORMAT,
        "blender_mm": [int(bpy.app.version[0]), int(bpy.app.version[1])],
        "preview_revision": _preview_format_revision(state),
        "brush": brush,
        "alpha": alpha,
    }
    try:
        path = _cache_path()
        temp = path.with_suffix(path.suffix + ".tmp")
        temp.write_text(json.dumps(payload, separators=(",", ":")), encoding="utf-8")
        temp.replace(path)
        _LAST_SIGNATURE = sig
    except Exception:
        pass


def _tick():
    global _TIMER_ACTIVE
    if not _INSTALLED:
        _TIMER_ACTIVE = False
        return None
    _flush(force=False)
    return 2.50


def install():
    global _INSTALLED, _TIMER_ACTIVE
    if _INSTALLED:
        return
    _INSTALLED = True
    _load()
    if not _TIMER_ACTIVE:
        _TIMER_ACTIVE = True
        try:
            bpy.app.timers.register(_tick, first_interval=2.50)
        except Exception:
            _TIMER_ACTIVE = False


def uninstall():
    global _INSTALLED
    if not _INSTALLED:
        return
    _flush(force=True)
    _INSTALLED = False
