from __future__ import annotations

"""Primary Brush/Alpha visual cache bridge.

The underlying images remain Blender-owned Brush ImagePreview / Alpha image
previews. This layer keeps enough JSON-ready preview payloads alive for the
compact Primary grid and Secondary browsers while also keeping each host's
bridge snapshot below its transport budget.
"""

from ..core.app import APP
from ..desktop.bridge_server import BRIDGE


_BRUSH_CMD = "sculpt.brush.library_preview"
_ALPHA_CMD = "sculpt.alpha.library_preview"
_BRUSH_PREVIEW_FORMAT_REVISION = 3
_BRUSH_CACHE_ITEMS = 48
_ALPHA_CACHE_ITEMS = 32
_ORIGINALS = {}
_ORIGINAL_SNAPSHOT = None


def _extend_sculpt_persistence_excludes():
    schema = APP.persistence.schemas.get("sculpt")
    if schema is None:
        return
    excluded = list(schema.exclude_keys)
    for key in ("primary_brush_preview_cache", "primary_alpha_preview_cache", "quick_shortcuts", "quick_shortcuts_status"):
        if key not in excluded:
            excluded.append(key)
    APP.register_state_schema(
        "sculpt",
        schema.version,
        migrations=dict(schema.migrations),
        exclude_keys=tuple(excluded),
    )


def _invalidate_stale_brush_preview_payloads():
    """Drop old orientation/alpha/color-space payloads once when the wire format changes."""
    state = APP.store.namespace("sculpt")
    revision = int(state.get("brush_preview_format_revision", 0) or 0)
    if revision == _BRUSH_PREVIEW_FORMAT_REVISION:
        return
    for key in (
        "current_brush_preview",
        "brush_preview_cache",
        "brush_library_preview_cache",
        "primary_brush_preview_cache",
    ):
        value = state.get(key)
        if isinstance(value, dict):
            value.clear()
        else:
            state[key] = {}
    state["brush_preview_format_revision"] = _BRUSH_PREVIEW_FORMAT_REVISION


def _copy_preview_payloads(source_key: str, target_key: str, *, max_items: int):
    state = APP.store.namespace("sculpt")
    source = dict(state.get(source_key) or {})
    target = state.setdefault(target_key, {})
    for identity, raw in source.items():
        payload = dict(raw or {})
        if payload.get("rgba_b64"):
            payload["key"] = str(identity)
            target[str(identity)] = payload
    if len(target) > max_items:
        for old in tuple(target.keys())[:-max_items]:
            target.pop(old, None)


def _requested_ids(identities=None, identity=""):
    values = [str(item) for item in list(identities or ()) if str(item or "")]
    if identity:
        values.append(str(identity))
    return list(dict.fromkeys(values))


def _chunks(values, size=8):
    values = list(values or ())
    step = max(1, int(size))
    for start in range(0, len(values), step):
        yield values[start:start + step]


def _asset_identity(slot) -> str:
    slot = dict(slot or {})
    rel = str(slot.get("relative_asset_identifier") or "").replace("\\", "/").strip()
    if not rel:
        return ""
    return "asset|{}|{}|{}".format(
        str(slot.get("asset_library_type") or "").casefold(),
        str(slot.get("asset_library_identifier") or "").casefold(),
        rel.casefold(),
    )


def _satellite_quick_preview_cache(sculpt) -> dict:
    """Return only preview payloads the compact Satellite can actually draw.

    Satellite's socket reader has a deliberately small response budget. Sending
    the whole accumulated product cache after opening Brush Library can exceed
    that budget even though Satellite Primary only needs up to four rows / 16
    slots. Map those exact identities back into the legacy ``brush_preview_cache``
    key already consumed by ``satellite_host_runtime.local_sculpt``.
    """
    primary = dict(sculpt.get("primary_brush_preview_cache") or {})
    legacy = dict(sculpt.get("brush_preview_cache") or {})
    slots = list(sculpt.get("quick_brush_slots") or ())
    try:
        rows = max(2, min(4, int(sculpt.get("quick_rows", 2) or 2)))
    except Exception:
        rows = 2
    identities = []
    for slot in slots[: rows * 4]:
        identity = _asset_identity(slot)
        if identity and identity not in identities:
            identities.append(identity)

    compact = {}
    for identity in identities[:16]:
        payload = dict(primary.get(identity) or legacy.get(identity) or {})
        if payload.get("rgba_b64"):
            payload["key"] = identity
            compact[identity] = payload
    return compact


def _install_snapshot_filter():
    global _ORIGINAL_SNAPSHOT
    if _ORIGINAL_SNAPSHOT is not None:
        return
    original = BRIDGE._snapshot
    _ORIGINAL_SNAPSHOT = original

    def filtered_snapshot(client_name: str = ""):
        snapshot = original(client_name)
        client = str(client_name or "")
        try:
            module_state = snapshot.get("module_state") or {}
            sculpt = module_state.get("sculpt") or {}
            if client.startswith("LumaFold Satellite"):
                # Satellite Primary consumes brush_preview_cache, not the product
                # accumulation key. Send only the <=16 quick-slot previews it can
                # actually draw so ready/get_state remains below 512 KiB even
                # after a large Brush Library session.
                sculpt["brush_preview_cache"] = _satellite_quick_preview_cache(sculpt)
                sculpt.pop("primary_brush_preview_cache", None)
                sculpt.pop("primary_alpha_preview_cache", None)
            elif client.startswith("LumaFold Secondary"):
                # Secondary already consumes the mirrored legacy library caches.
                # Do not send product caches as a duplicate Base64 copy. Brush 48
                # + Alpha 32 keeps a generous visible/scrolling working set while
                # keeping the shared Secondary snapshot below its 2 MiB budget.
                sculpt.pop("primary_brush_preview_cache", None)
                sculpt.pop("primary_alpha_preview_cache", None)
            module_state["sculpt"] = sculpt
            snapshot["module_state"] = module_state
        except Exception:
            pass
        return snapshot

    BRIDGE._snapshot = filtered_snapshot


def install():
    _extend_sculpt_persistence_excludes()
    _invalidate_stale_brush_preview_payloads()
    _install_snapshot_filter()
    commands = getattr(APP.commands, "_commands", {})

    if _BRUSH_CMD in commands and _BRUSH_CMD not in _ORIGINALS:
        original_brush = commands[_BRUSH_CMD]
        _ORIGINALS[_BRUSH_CMD] = original_brush

        def brush_preview_wrapper(*, identities=None, identity=""):
            requested = _requested_ids(identities, identity)
            if not requested:
                return original_brush(identities=identities, identity=identity)
            messages = []
            # The legacy command trims brush_library_preview_cache to ten items.
            # Accumulate every <=8 batch first, then mirror the stable product
            # cache back into the legacy key consumed by the independent
            # Secondary Surface. Without this mirror an 8-column viewport keeps
            # losing older visible previews and immediately re-requests them.
            for batch in _chunks(requested, 8):
                messages.append(str(original_brush(identities=batch)))
                _copy_preview_payloads(
                    "brush_library_preview_cache", "primary_brush_preview_cache", max_items=_BRUSH_CACHE_ITEMS
                )
                _copy_preview_payloads(
                    "primary_brush_preview_cache", "brush_library_preview_cache", max_items=_BRUSH_CACHE_ITEMS
                )
            return " · ".join(messages)

        APP.commands.register(_BRUSH_CMD, brush_preview_wrapper)

    if _ALPHA_CMD in commands and _ALPHA_CMD not in _ORIGINALS:
        original_alpha = commands[_ALPHA_CMD]
        _ORIGINALS[_ALPHA_CMD] = original_alpha

        def alpha_preview_wrapper(*, identities=None, identity=""):
            requested = _requested_ids(identities, identity)
            if not requested:
                return original_alpha(identities=identities, identity=identity)
            messages = []
            # Alpha has the same independent-Secondary lifetime problem. Keep
            # the accumulated product cache mirrored into the key the browser
            # already consumes so a loaded tile stays loaded while scrolling.
            for batch in _chunks(requested, 8):
                messages.append(str(original_alpha(identities=batch)))
                _copy_preview_payloads(
                    "alpha_library_preview_cache", "primary_alpha_preview_cache", max_items=_ALPHA_CACHE_ITEMS
                )
                _copy_preview_payloads(
                    "primary_alpha_preview_cache", "alpha_library_preview_cache", max_items=_ALPHA_CACHE_ITEMS
                )
            return " · ".join(messages)

        APP.commands.register(_ALPHA_CMD, alpha_preview_wrapper)


def uninstall():
    global _ORIGINAL_SNAPSHOT
    for command_id, original in tuple(_ORIGINALS.items()):
        APP.commands.register(command_id, original)
    _ORIGINALS.clear()
    if _ORIGINAL_SNAPSHOT is not None:
        BRIDGE._snapshot = _ORIGINAL_SNAPSHOT
        _ORIGINAL_SNAPSHOT = None
