from __future__ import annotations

"""Authoritative ZBrush-style Ctrl/Ctrl+Alt mask gesture owner.

Ownership:
- Ctrl tap on sculpt surface -> Blender native Smooth Mask filter;
- Ctrl+Alt tap on sculpt surface -> Blender native Sharpen Mask filter;
- Ctrl tap on background -> Blender native Invert Mask;
- Ctrl drag from sculpt surface -> Blender native Mask brush stroke;
- Ctrl drag from background -> Blender native box-mask gesture;
- Ctrl background drag that never reaches the model -> Blender native Clear Mask.

Surface/background classification is strictly mask-local and never participates
in ordinary Sculpt-vs-Rotate ownership.
"""

import bpy
import gpu
from bpy_extras import view3d_utils
from gpu_extras.batch import batch_for_shader
from mathutils import Vector

MASK_GESTURE_ID = "lumafold.sculpt_mask_gesture_v2"

_INSTALLED = False
_TRACE = None
_MOVE_EVENTS = {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}


def _trace(reason: str, context=None, event=None, **extra):
    if _TRACE is None:
        return
    try:
        payload = {
            "reason": str(reason),
            "event": str(getattr(event, "type", "") or "") if event is not None else "",
            "value": str(getattr(event, "value", "") or "") if event is not None else "",
        }
        payload.update(extra)
        _TRACE.trace("ZBRUSH_MASK_GESTURE", **payload)
    except Exception:
        pass


def _region_xy(event):
    try:
        return float(event.mouse_region_x), float(event.mouse_region_y)
    except Exception:
        return 0.0, 0.0


def _drag_threshold(context) -> float:
    try:
        inputs = context.preferences.inputs
        values = []
        for name in ("drag_threshold_tablet", "drag_threshold_mouse", "drag_threshold"):
            value = getattr(inputs, name, None)
            if value is not None and float(value) > 0.0:
                values.append(float(value))
        if values:
            return max(2.0, min(values))
    except Exception:
        pass
    return 4.0


def _active_sculpt_mesh(context):
    obj = getattr(context, "sculpt_object", None)
    if obj is None:
        objects = getattr(getattr(context, "view_layer", None), "objects", None)
        obj = getattr(objects, "active", None) if objects is not None else None
    if obj is None or getattr(obj, "type", "") != "MESH":
        return None
    return obj


def _surface_hit_xy(context, x: float, y: float) -> bool:
    """Mask-local double-path surface classifier at region coordinates."""
    obj = _active_sculpt_mesh(context)
    region = getattr(context, "region", None)
    rv3d = getattr(context, "region_data", None)
    scene = getattr(context, "scene", None)
    if obj is None or region is None or rv3d is None:
        return False
    try:
        origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, (float(x), float(y)))
        direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, (float(x), float(y)))
        depsgraph = context.evaluated_depsgraph_get()
        if scene is not None:
            hit, _loc, _normal, _index, hit_obj, _matrix = scene.ray_cast(
                depsgraph, origin, direction
            )
            if hit and hit_obj is not None:
                original = getattr(hit_obj, "original", hit_obj)
                if hit_obj == obj or original == obj:
                    return True
        eval_obj = obj.evaluated_get(depsgraph)
        inv = eval_obj.matrix_world.inverted_safe()
        hit, _loc, _normal, _index = eval_obj.ray_cast(
            inv @ origin, inv.to_3x3() @ direction
        )
        return bool(hit)
    except Exception:
        return False


def _drag_hits_active_surface(context, event) -> bool:
    x, y = _region_xy(event)
    return _surface_hit_xy(context, x, y)


def _projected_bbox_intersects(context, obj, xmin, ymin, xmax, ymax) -> bool:
    region = getattr(context, "region", None)
    rv3d = getattr(context, "region_data", None)
    if region is None or rv3d is None or obj is None:
        return False
    points = []
    try:
        matrix = obj.matrix_world
        for corner in tuple(getattr(obj, "bound_box", ()) or ()):
            point = view3d_utils.location_3d_to_region_2d(
                region, rv3d, matrix @ Vector(corner)
            )
            if point is not None:
                points.append((float(point.x), float(point.y)))
    except Exception:
        return False
    if not points:
        return False
    bx0 = min(p[0] for p in points)
    bx1 = max(p[0] for p in points)
    by0 = min(p[1] for p in points)
    by1 = max(p[1] for p in points)
    return not (xmax < bx0 or xmin > bx1 or ymax < by0 or ymin > by1)


def _rect_hits_active(context, x0, y0, x1, y1) -> bool:
    xmin, xmax = sorted((float(x0), float(x1)))
    ymin, ymax = sorted((float(y0), float(y1)))
    for iy in range(5):
        y = ymin + (ymax - ymin) * (iy / 4.0)
        for ix in range(5):
            x = xmin + (xmax - xmin) * (ix / 4.0)
            if _surface_hit_xy(context, x, y):
                return True
    return _projected_bbox_intersects(
        context, _active_sculpt_mesh(context), xmin, ymin, xmax, ymax
    )


def _run_mask_filter(context, sharpen: bool):
    kwargs = {
        "filter_type": "SHARPEN" if sharpen else "SMOOTH",
        "iterations": 1,
        "auto_iteration_count": True,
    }
    window = getattr(context, "window", None)
    area = getattr(context, "area", None)
    region = getattr(context, "region", None)
    try:
        if window is not None and area is not None and region is not None:
            with bpy.context.temp_override(window=window, area=area, region=region):
                result = set(bpy.ops.sculpt.mask_filter("EXEC_DEFAULT", **kwargs) or ())
        else:
            result = set(bpy.ops.sculpt.mask_filter("EXEC_DEFAULT", **kwargs) or ())
        if area is not None:
            area.tag_redraw()
        _trace("mask_filter_finished", context, None, sharpen=bool(sharpen), result=sorted(result))
        return result
    except (RuntimeError, TypeError, AttributeError) as exc:
        _trace("mask_filter_exception", context, None, sharpen=bool(sharpen), error=f"{type(exc).__name__}: {exc}")
        return {"CANCELLED"}


def _run_mask_flood(context, mode: str, value: float = 0.0):
    window = getattr(context, "window", None)
    area = getattr(context, "area", None)
    region = getattr(context, "region", None)
    kwargs = {"mode": str(mode), "value": float(value)}
    try:
        if window is not None and area is not None and region is not None:
            with bpy.context.temp_override(window=window, area=area, region=region):
                result = set(bpy.ops.paint.mask_flood_fill("EXEC_DEFAULT", **kwargs) or ())
        else:
            result = set(bpy.ops.paint.mask_flood_fill("EXEC_DEFAULT", **kwargs) or ())
        if area is not None:
            area.tag_redraw()
        _trace("mask_flood_finished", context, None, mode=str(mode), result=sorted(result))
        return result
    except (RuntimeError, TypeError, AttributeError) as exc:
        _trace("mask_flood_exception", context, None, mode=str(mode), error=f"{type(exc).__name__}: {exc}")
        return {"CANCELLED"}


def _native_mask_stroke(context, invert: bool):
    window = getattr(context, "window", None)
    area = getattr(context, "area", None)
    region = getattr(context, "region", None)
    try:
        if window is not None and area is not None and region is not None:
            with bpy.context.temp_override(window=window, area=area, region=region):
                return set(bpy.ops.sculpt.brush_stroke(
                    "INVOKE_DEFAULT",
                    mode="INVERT" if invert else "NORMAL",
                    brush_toggle="MASK",
                    ignore_background_click=True,
                ) or ())
        return {"CANCELLED"}
    except (RuntimeError, TypeError, AttributeError):
        return {"CANCELLED"}


def _execute_box_mask(x0, y0, x1, y1, *, erase: bool):
    xmin, xmax = sorted((int(x0), int(x1)))
    ymin, ymax = sorted((int(y0), int(y1)))
    if xmax - xmin < 2 or ymax - ymin < 2:
        return {"CANCELLED"}
    kwargs = {
        "xmin": xmin,
        "xmax": xmax,
        "ymin": ymin,
        "ymax": ymax,
        "wait_for_input": False,
        "use_front_faces_only": False,
        "mode": "VALUE",
        "value": 0.0 if erase else 1.0,
    }
    try:
        return set(bpy.ops.paint.mask_box_gesture("EXEC_REGION_WIN", **kwargs) or ())
    except (RuntimeError, TypeError):
        kwargs.pop("use_front_faces_only", None)
        try:
            return set(bpy.ops.paint.mask_box_gesture("EXEC_REGION_WIN", **kwargs) or ())
        except (RuntimeError, TypeError):
            return {"CANCELLED"}


def _draw_box(self):
    if not bool(getattr(self, "_box_preview", False)):
        return
    x0, y0 = self._start_x, self._start_y
    x1, y1 = self._last_x, self._last_y
    fill = ((x0, y0), (x1, y0), (x1, y1), (x0, y0), (x1, y1), (x0, y1))
    outline = ((x0, y0), (x1, y0), (x1, y1), (x0, y1), (x0, y0))
    try:
        shader = gpu.shader.from_builtin("UNIFORM_COLOR")
        gpu.state.blend_set("ALPHA")
        fill_batch = batch_for_shader(shader, "TRIS", {"pos": fill})
        shader.bind()
        shader.uniform_float("color", (0.20, 0.20, 0.20, 0.30))
        fill_batch.draw(shader)
        line_batch = batch_for_shader(shader, "LINE_STRIP", {"pos": outline})
        shader.uniform_float("color", (0.70, 0.70, 0.70, 0.95))
        line_batch.draw(shader)
    except Exception:
        pass
    finally:
        try:
            gpu.state.blend_set("NONE")
        except Exception:
            pass


class LUMAFOLD_OT_sculpt_mask_gesture_v2(bpy.types.Operator):
    bl_idname = MASK_GESTURE_ID
    bl_label = "LumaFold ZBrush Mask Gesture"
    bl_options = {"INTERNAL"}
    _draw_box = _draw_box

    @classmethod
    def poll(cls, context):
        return bool(
            str(getattr(context, "mode", "") or "").upper() == "SCULPT"
            and getattr(getattr(context, "area", None), "type", "") == "VIEW_3D"
            and getattr(getattr(context, "region", None), "type", "") == "WINDOW"
        )

    def invoke(self, context, event):
        if not bool(getattr(event, "ctrl", False)) or bool(getattr(event, "shift", False)):
            return {"CANCELLED"}
        self._sharpen = bool(getattr(event, "alt", False))
        self._start_x, self._start_y = _region_xy(event)
        self._last_x, self._last_y = self._start_x, self._start_y
        self._start_on_surface = bool(_drag_hits_active_surface(context, event))
        self._dragging = False
        self._box_preview = False
        self._box_handle = None
        threshold = _drag_threshold(context)
        self._threshold_sq = threshold * threshold
        context.window_manager.modal_handler_add(self)
        _trace(
            "started",
            context,
            event,
            sharpen=bool(self._sharpen),
            start_on_surface=bool(self._start_on_surface),
        )
        return {"RUNNING_MODAL"}

    def _stop_box(self, context):
        handle = getattr(self, "_box_handle", None)
        if handle is not None:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(handle, "WINDOW")
            except Exception:
                pass
            self._box_handle = None
        self._box_preview = False
        try:
            context.area.tag_redraw()
        except Exception:
            pass

    def modal(self, context, event):
        event_type = str(getattr(event, "type", "") or "").upper()
        event_value = str(getattr(event, "value", "") or "").upper()

        if event_type in {"ESC", "WINDOW_DEACTIVATE"}:
            self._stop_box(context)
            return {"CANCELLED"}

        if event_type in _MOVE_EVENTS:
            x, y = _region_xy(event)
            self._last_x, self._last_y = x, y
            dx = x - self._start_x
            dy = y - self._start_y
            if not self._dragging and dx * dx + dy * dy >= self._threshold_sq:
                self._dragging = True
                if self._start_on_surface:
                    result = _native_mask_stroke(context, bool(self._sharpen))
                    _trace("surface_mask_drag", context, event, result=sorted(result))
                    return {"FINISHED"}
                self._box_preview = True
                try:
                    self._box_handle = bpy.types.SpaceView3D.draw_handler_add(
                        self._draw_box, (), "WINDOW", "POST_PIXEL"
                    )
                except Exception:
                    self._box_handle = None
            if self._box_preview:
                try:
                    context.area.tag_redraw()
                except Exception:
                    pass
            return {"RUNNING_MODAL"}

        if event_type == "LEFTMOUSE" and event_value == "RELEASE":
            if not self._dragging:
                if self._start_on_surface:
                    result = _run_mask_filter(context, bool(self._sharpen))
                    reason = "mask_sharpen_tap" if self._sharpen else "mask_smooth_tap"
                elif not self._sharpen:
                    result = _run_mask_flood(context, "INVERT")
                    reason = "background_invert_tap"
                else:
                    result = {"CANCELLED"}
                    reason = "background_alt_tap_noop"
                _trace(reason, context, event, result=sorted(result))
                return {"FINISHED"}

            if self._box_preview:
                self._stop_box(context)
                hits_model = _rect_hits_active(
                    context,
                    self._start_x,
                    self._start_y,
                    self._last_x,
                    self._last_y,
                )
                if hits_model:
                    result = _execute_box_mask(
                        self._start_x,
                        self._start_y,
                        self._last_x,
                        self._last_y,
                        erase=bool(self._sharpen),
                    )
                    reason = "background_box_mask"
                elif not self._sharpen:
                    result = _run_mask_flood(context, "VALUE", value=0.0)
                    reason = "background_clear_drag"
                else:
                    result = {"CANCELLED"}
                    reason = "background_alt_drag_noop"
                _trace(
                    reason,
                    context,
                    event,
                    result=sorted(result),
                    hits_model=bool(hits_model),
                    erase=bool(self._sharpen),
                )
                return {"FINISHED"}
            return {"FINISHED"}

        return {"RUNNING_MODAL", "PASS_THROUGH"}


_CLASSES = (LUMAFOLD_OT_sculpt_mask_gesture_v2,)


def handle_pointer_press(context, event, target):
    if str(getattr(event, "type", "") or "").upper() != "LEFTMOUSE":
        return None
    if str(getattr(event, "value", "") or "").upper() != "PRESS":
        return None
    if not bool(getattr(event, "ctrl", False)) or bool(getattr(event, "shift", False)):
        return None
    if target is None:
        return False
    window, area, region = target
    try:
        with bpy.context.temp_override(window=window, area=area, region=region):
            result = bpy.ops.lumafold.sculpt_mask_gesture_v2("INVOKE_DEFAULT")
        ok = "RUNNING_MODAL" in set(result or ())
        _trace("mask_owner_started" if ok else "mask_owner_failed", context, event, result=list(result or ()))
        return ok
    except (RuntimeError, TypeError, AttributeError) as exc:
        _trace("mask_owner_exception", context, event, error=f"{type(exc).__name__}: {exc}")
        return False


def install(real_machine_trace=None):
    global _INSTALLED, _TRACE
    if _INSTALLED:
        return
    _TRACE = real_machine_trace
    for cls in _CLASSES:
        bpy.utils.register_class(cls)
    _INSTALLED = True


def uninstall():
    global _INSTALLED, _TRACE
    if not _INSTALLED:
        return
    for cls in reversed(_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    _TRACE = None
    _INSTALLED = False
