from __future__ import annotations

"""Low-frequency Embedded idle pulse policy.

Mouse/keyboard events already redraw the owning View3D immediately. The modal TIMER
therefore only needs to keep low-frequency context/status synchronization alive.
Keeping that TIMER path from forcing a 60 Hz View3D redraw prevents LumaFold from
competing with Blender while another native window (notably Preferences) is moved.
"""

import time


_INSTALLED = False
_ORIGINAL = None
_OPERATORS = None
_IDLE_INTERVAL = 0.10


def install(operators_module) -> None:
    global _INSTALLED, _ORIGINAL, _OPERATORS
    if _INSTALLED:
        return
    original = getattr(operators_module, "_context_pulse", None)
    if not callable(original):
        return
    _OPERATORS = operators_module
    _ORIGINAL = original

    def idle_context_pulse(operator, host, host_id):
        now = time.perf_counter()
        last = float(getattr(operator, "_lumafold_idle_pulse_at", 0.0) or 0.0)
        if now - last < _IDLE_INTERVAL:
            return None
        operator._lumafold_idle_pulse_at = now
        return original(operator, host, host_id)

    operators_module._context_pulse = idle_context_pulse
    _INSTALLED = True


def uninstall() -> None:
    global _INSTALLED, _ORIGINAL, _OPERATORS
    if _INSTALLED and _OPERATORS is not None and callable(_ORIGINAL):
        _OPERATORS._context_pulse = _ORIGINAL
    _INSTALLED = False
    _ORIGINAL = None
    _OPERATORS = None


def snapshot():
    return {
        "installed": bool(_INSTALLED),
        "idle_interval": float(_IDLE_INTERVAL),
    }
