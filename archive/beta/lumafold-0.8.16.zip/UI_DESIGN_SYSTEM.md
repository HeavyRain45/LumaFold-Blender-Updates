# LumaFold UI Design System v1 — S0.6.10 Secondary Background Contract

> 目标：后续 Sculpt / Model / Light / Render / Asset 等产品界面不得再各自猜边距、图标尺寸、按钮行高或字体层级。
> Host 只负责承载/定位；产品 View 统一消费本文件对应的 `ui/layout_system.py` 与公共 Components。

## 1. 两类产品 Surface

### Primary Surface（一级菜单：浮台 / 卫星主工作台）
- 外边距：12 design units，四边一致。
- 常规间距：6。
- 小间距：4。
- 常规操作行高：28。
- Action icon glyph：14。
- Action icon box：24。
- Sculpt 基准宽度：264（已由实机确认）。
- 不允许模块自行修改 Host 视觉语言。

### Secondary Surface（二级菜单：Brush / Alpha Library / Settings / More）
- 外边距：12，四边一致。
- 常规间距：6；小间距：4。
- 常规行高：24。
- Action icon glyph：14；Action icon box：24。
- 标题：section 字号；导航/主要动作：body；元数据/资源短标签：small。
- 二级菜单不得新增独立系统标题栏；使用现有无边框 Secondary Host。
- ESC / 原入口二次点击 / 与一级真实交互的关闭规则保持统一。

## 2. 图标规则

- 所有产品 Action Icon 必须来自统一 atlas；业务模块不得自行 GPU 画基础图标。
- 标准操作图标：14 glyph 放入 24 box；同一工具栏所有图标中心线、外框尺寸一致。
- `image_button` 的参数代表“图像尺寸”，并会额外叠加 FramePadding；因此资源 Preview 必须通过公共 `image_square_button()`，保证 Preview 与文字 Placeholder 的**外框尺寸完全相同**。
- 不允许直接把图片尺寸当作按钮格尺寸，否则加载 Preview 前后 Grid 会位移。

## 3. 字体层级

- `title`：极少使用，仅品牌/大标题。
- `section`：一级/二级 Surface 标题。
- `body`：导航、主要按钮、普通内容。
- `small`：元数据、资源卡短标签、辅助状态。
- `value`：数值。
- 产品代码不得依赖 ImGui 当前默认字体大小；所有裸 `imgui.button/combo/input_text` 必须放入明确的 `font_scope`，或使用公共 Component。

## 4. Brush Library v1 Grid

- Surface：462 × 286。
- 左导航：78。
- 左右分栏 Gap：6。
- 左上固定：全部 / 收藏。
- 左下：真实 Asset Library 文件夹列表。
- `+ / −`：固定在左下底部工具栏，不随文件夹数量移动；两单元等宽，二者总宽度（含中间 Gap）必须严格等于文件夹导航按钮宽度，glyph 居中。
- 右上：搜索框 + 24×24 Refresh action。
- Refresh 含义：重新扫描 Blender Brush / Asset Library；不表示重置。
- 搜索行后分隔；`范围名 · 数量` 属于资源内容层，位于 Brush Grid 上方。
- Brush Grid：8 列；Tile 外框 38；Gap 4。
- Scrollbar：10；Brush Grid scroll child 必须填满右侧 Content Safe Rect。第 8 列 → scrollbar 的剩余空间目标为 12；scrollbar → Secondary Surface 外轮廓只保留统一的 12-unit Surface Inset，不允许再叠加 nested gutter。
- Brush Grid 不再额外增加 bottom compensation；底部只保留 Surface 自身 12-unit inset。Scrollbar track 背景透明，只显示圆角 grab。
- Scrollbar 位置属于 Grid 几何 contract，不允许业务 View 用 overlay/肉眼 margin 修正。

## 5. Primary Sculpt Grid

- 四列 Quick Brush 共用一个 Grid 起点和左右边界。
- Quick Brush Preview 与 Placeholder 外框完全一致。
- Size / Strength 使用同一固定 Label Column，Slider 起点/终点完全一致。
- Current Brush / Alpha 卡、Quick Brush、底部按钮均使用同一内容边界。

## 6. 代码约束

- 产品布局 token：`ui/layout_system.py`。
- 基础颜色/字体 token：`ui/theme.py`。
- Style：`ui/design.py`。
- 基础控件：`ui/components.py`。
- 图标：`ui/icons.py`。
- View 不得新增散落的“看起来差不多”的 margin / icon box / row height 常量；新增规格应先进入 layout contract。
- Embedded 与 Satellite 必须消费同一 View 和同一 layout contract。

## 7. Context Menu v1

- Context Menu 是轻量操作层，视觉权重必须低于 Primary / Secondary Surface。
- 基准宽度：136 design units。
- 操作行高：22。
- 标题使用 `body`，当前对象/状态使用 `small`，不得使用 Secondary 大标题规格。
- 操作按钮填满 Context Menu 内容宽度；同一菜单内按钮宽度、高度、左右边界一致。
- Quick Brush、未来 Alpha Slot 等右键菜单必须复用 `CONTEXT_MENU` contract，不得自行写 150+ 的固定大按钮。

## 8. Alignment Contract v1（S0.6.7 冻结）

这组规则用于消灭“看起来差一点”的低级布局错误，适用于 Primary / Secondary / Context Menu。

- **同一 Surface 只允许一个内容基准网格。** 标题、导航、工具栏、资源 Grid 不得各自发明局部 X/Y 偏移。
- **Primary / Secondary 四边外边距固定相等。** 任何业务 View 不得通过额外 dummy/空白补偿某一边。
- **Secondary Header 是一条共享 24-unit 基准行。** 左侧标题与右侧 Search/Action 从同一 Y 起点布局；右侧 Search 的 X 起点必须与下方资源内容列完全一致。
- **Secondary 标题的左边界必须与左侧导航列一致。** 标题不是“漂在窗口左上”的装饰文字。
- **Search 与右侧 Action Icon 同高、同中心线。** Action Icon 使用标准 14 glyph / 24 box；Surface 宽度变化只重新计算 Search 宽度，不改变 icon box。
- **左右分栏使用单一 split X。** Header 与 Body 共享同一个 `nav_w + split_gap`，不得出现标题/搜索一套分栏、资源区另一套分栏。
- **Brush Library v1 宽度冻结为 462。** 8 列 Tile 尺寸不变；通过收窄左导航/外框减少右侧多余视觉空白，不压缩资源 Tile。
- **Scrollbar 服从 Surface Inset Contract。** 第 8 列→scrollbar 与 scrollbar→Surface 外轮廓都以统一 12-unit inset 为目标；scroll child 不得再额外留下 child 外侧 gutter。
- **左下 Folder Toolbar 与右侧 Grid 共用 Content Safe Rect 底边。** 不额外叠加 footer/bottom compensation；底部只保留统一 Surface inset。
- **`+ / −` 总宽度必须等于文件夹导航按钮宽度。** 两格等宽、glyph 居中；不得因为禁用态、字体或 FramePadding 改变外框。
- **Context Menu 同样遵守内容边界与行高 contract。** 不允许某个右键菜单临时使用不同 padding / title offset / button width。
- 如果发现某控件不齐，优先检查它是否违反本 Alignment Contract；禁止先加局部 magic number 修视觉。


## 9. Surface Inset Contract v1（S0.6.7 冻结）

这是所有 LumaFold 产品 Surface 的外框几何基础，优先级高于局部 Grid/Toolbar 规则。

- **Outer Surface**：实际可见的一级/二级/右键菜单外轮廓。
- **Content Safe Rect**：所有标题、搜索、导航、资源 Grid、工具栏所在的统一内容矩形。
- **四边 inset 必须一致。** `Outer Surface → Content Safe Rect` 的 Top / Bottom / Left / Right 默认统一使用 `outer_padding = 12` design units；禁止某一边再叠加 dummy spacing、footer gap、child gutter 来“看起来差不多”。
- **Scrollbar 是 Content Safe Rect 内的最后一个控件。** 对滚动资源区，scrollbar 的可见右边缘到 Outer Surface 右边缘只允许一个 Surface Inset；不能同时存在“scroll child 外留白 + Surface padding”两层间距。
- **Scrollbar 左右做视觉闭合。** 固定资源 Grid 后，最后一列到 scrollbar 的剩余空间应与 scrollbar 到 Outer Surface 的 Surface Inset 形成同一视觉尺度；如果不闭合，应优先调整 Surface / Nav 几何，而不是单独挪 scrollbar。
- **Header / Body / Footer 共用同一个 Content Safe Rect。** 顶部 Search/Action、主体 Grid、底部 `+ / −` 都必须落在同一左右边界和上下安全边界内。
- **Primary / Secondary / Context Menu 一律适用。** 只有业务内容尺寸不同，不允许分别发明一套外框 padding。
- 实机发现“某边看起来更宽/更窄”时，首先检查 Surface Inset Contract；禁止先新增局部 magic offset。


## 10. Container-Centered Toolbar Contract v1（S0.6.9 冻结）

用于 `+ / −`、双 Action、底部小工具栏等“按钮组置于某个列/容器内部”的场景。

- **实际 Content Rect 优先于理论列宽。** 排版前必须读取所在容器的实际可用宽度；不得假设 `nav_w` 就等于 child 的可用宽度。
- **按钮组作为一个整体居中。** `side = (container_width - group_width) / 2`，必须满足 `left remainder == right remainder`。
- **两单元工具栏等宽。** `cell = (group_width - gap) / 2`；中间 Gap 只使用 Design System token。
- **禁止局部 X offset。** 如果组偏左/偏右，修容器几何或公共 centering helper，不允许给某一个菜单添加 magic number。
- **Primary / Secondary / Context Menu 通用。** 以后 Alpha Library、文件夹工具栏、成对操作按钮都复用 `centered_group_geometry()`。
- **DPI/Host 无关。** Embedded 与 Satellite 都以运行时实际 Content Rect 计算，因此缩放或 Host 切换不得改变左右对称关系。


## 11. Nav Column Symmetry Contract v1（S0.6.9 冻结）

左侧导航栏中，按钮/底部工具栏的可见左右留白必须以**外层 Surface 的视觉边界**为参照，而不是以内部 Child Content Rect 为参照。

- 左侧可见留白 = `SECONDARY.outer_padding`。
- 左栏到右侧内容区的 `split_gap` 对资源库类 Secondary Surface 也必须等于 `SECONDARY.outer_padding`。
- Brush Library 当前固定为：`nav_w=72`、`split_gap=12`；二者总跨度仍为 84，因此右侧搜索、资源 Grid 与 scrollbar 的 X 起点不改变。
- 禁止使用“按钮组内部居中”去补偿列级不对称；如果左右视觉留白不一致，应先修 Nav Column / split 几何。
- 一级菜单、二级菜单、Context Menu 若使用左右分区布局，都必须明确各自的 Visual Rect 边界，再做控件对齐。


## 12. Secondary Surface Background Contract v1（S0.6.10 冻结）

- Embedded Popup 与 Native Satellite Secondary Surface 必须使用同一个根背景 token：`T.SECONDARY_SURFACE_BG`。
- `T.SECONDARY_SURFACE_BG` 当前等于 `SURFACE_1`，与 ImGui `POPUP_BG` 保持一致。
- Native Secondary Host 禁止直接继承普通 `WINDOW_BG / SURFACE_0`，否则会在 `CHILD_BG / SURFACE_1` 外产生额外灰色层。
- Native WGL framebuffer clear color 必须与 Secondary Surface 根背景一致，避免圆角抗锯齿边缘露出另一层灰阶。
- Embedded / Satellite 的 Secondary Surface 只允许一个可见背景层级；Child 仅用于布局/裁剪，不得形成 Host 特有的额外 Panel 背景。
- Brush / Alpha Library、Settings、More 等所有 Secondary kind 都复用该规则。


## 13. Alpha Library Reuse Contract v1（S0.7.2）

Alpha Library **不得重新发明二级菜单布局**。它直接复用 Brush Library 已冻结的：

- Secondary Surface 外边距 / Content Safe Rect；
- 左侧 `全部 / 收藏 + 文件夹 + 底部工具栏`；
- 右侧 `搜索 + 刷新 + scope/count + 8 列 Grid`；
- Scrollbar geometry / Surface Inset / Background Contract；
- Preview tile 外框与加载前后不变的几何；
- Context Menu 轻量字体/行高规范。

后续 Material / Asset / Alpha 等资源浏览器优先复用同一 Asset Browser Layout Contract，只允许业务内容不同。


## 14. Alpha Import Contract v1（S0.7.2）

- Alpha 左下 `+` 是导入入口：只负责把用户选择的真实图片加载到当前 Blender 文件，不复制第二份 LumaFold 资产数据库。
- `−` 继续禁用，直到删除/移除行为能映射到明确的 Blender/文件系统资产语义。
- 内置 `LumaFold 测试 Alpha` 为只读测试种子，使用与用户图片完全相同的 Image → Texture → Brush 激活路径。
- 测试种子只用于链路验证，不定义用户正式 Alpha 资产组织方式。


## 15. Workspace Presence Contract v1（S0.7.2）

LumaFold 产品 Surface 的**可见状态属于 Blender Window / Host Lease，不属于某一个 Workspace Area**。

- Embedded 浮台以 Blender Window 为稳定所有权边界；Workspace 切换导致 Screen / Area / Region 指针变化时，必须迁移同一个 live Host 到新 Workspace 的主 View3D，而不是让 Header 保持激活但 Surface 消失。
- Workspace / Mode 身份只决定当前显示哪个 LumaFold 产品 Surface，不决定 LumaFold 是否“运行”。例如 Modeling → Model 占位，Sculpting → Sculpt。
- Workspace / Mode 转换属于输入生命周期边界。转换时必须释放 LumaFold 持有的鼠标/键盘/文本捕获，禁止旧 Area 的 PRESS/RELEASE 状态泄漏到新 Area。
- Header 的激活态只表示有效 Host Lease 是否存在，不能表示某个旧 Area 是否还存在。
- 业务 View 不得保存 Area/Region 作为持久身份；这些属于 Host 层运行时定位信息。
- 当前 Embedded 技术路径仍需要目标 Workspace 存在 View3D；无 View3D Workspace 的 Window-level fallback 属于后续 Host 能力，不允许业务模块自行伪造。


## 16. Window-Level Input Routing Contract v1（S0.7.3）

- Embedded LumaFold 的产品存在性和输入所有权以 Blender Window 为边界，不以启动时的 Area/Region 为边界。
- Workspace 可以替换 Screen/Area/Region；UIHost 必须重绑到当前 Workspace 的目标 View3D，而 Modal 输入不能再使用 `context.area == host.area` 作为硬门禁。
- 所有同一 Window 的事件都可进入 LumaFold 输入路由；只有 ImGui 明确声明 capture 的输入才归 LumaFold 所有。
- 鼠标 PRESS 还必须位于当前绑定 View3D Region 内；LumaFold 已拥有的手势 RELEASE 必须无条件完成，避免 Workspace/编辑器切换造成 stuck input。
- Workspace/Mode/Rebind 都是 transient-input reset 边界。
- “Draw Host 已迁移但 Input Host 未迁移”属于违反本 Contract 的架构错误，禁止通过用户手动重新开关插件规避。
