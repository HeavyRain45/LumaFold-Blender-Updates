from __future__ import annotations

"""Pure product policy for the long-lived LumaFold update contract.

This module deliberately knows nothing about Blender operators. It owns the
stable product identity, channels and persisted update metadata so the UI and
Blender adapter cannot invent their own update rules.
"""

from dataclasses import dataclass
import json
import os
from pathlib import Path
import tomllib
from typing import Any

EXTENSION_ID = "lumafold"
REPOSITORY_NAME = "LumaFold"
UPDATE_STATE_SCHEMA = 1

# Public distribution identity is separate from the private source repository.
# Beta is active for controlled internal rehearsal. Stable remains intentionally
# closed until the first real online upgrade rehearsal succeeds end-to-end.
PUBLIC_UPDATES_REPOSITORY = "HeavyRain45/LumaFold-Blender-Updates"
PUBLIC_PAGES_BASE = "https://heavyrain45.github.io/LumaFold-Blender-Updates"
TARGET_STABLE_URL = f"{PUBLIC_PAGES_BASE}/stable/"
TARGET_BETA_URL = f"{PUBLIC_PAGES_BASE}/beta/"

_STABLE_URL = ""
_BETA_URL = TARGET_BETA_URL


@dataclass(frozen=True)
class UpdateChannel:
    id: str
    label: str
    repository_url: str


@dataclass(frozen=True)
class ProductVersion:
    version: str
    blender_min: str
    blender_max: str
    platforms: tuple[str, ...]


def _root() -> Path:
    return Path(__file__).resolve().parent.parent


def product_version() -> ProductVersion:
    data = tomllib.loads((_root() / "blender_manifest.toml").read_text(encoding="utf-8"))
    return ProductVersion(
        version=str(data.get("version", "0.0.0") or "0.0.0"),
        blender_min=str(data.get("blender_version_min", "") or ""),
        blender_max=str(data.get("blender_version_max", "") or ""),
        platforms=tuple(str(v) for v in (data.get("platforms") or ())),
    )


def channels() -> dict[str, UpdateChannel]:
    stable = os.environ.get("LUMAFOLD_STABLE_REPOSITORY_URL", _STABLE_URL).strip()
    beta = os.environ.get("LUMAFOLD_BETA_REPOSITORY_URL", _BETA_URL).strip()
    return {
        "stable": UpdateChannel("stable", "稳定版 Stable", stable),
        "beta": UpdateChannel("beta", "测试版 Beta", beta),
    }


def channel(channel_id: str) -> UpdateChannel:
    return channels().get(str(channel_id or "stable").lower(), channels()["stable"])


def default_state() -> dict[str, Any]:
    return {
        "schema": UPDATE_STATE_SCHEMA,
        "channel": "stable",
        "repository_url": "",
        "last_sync_ok": False,
        "last_sync_error": "",
    }


def load_state(path: Path) -> dict[str, Any]:
    state = default_state()
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(raw, dict):
            state.update(raw)
    except FileNotFoundError:
        pass
    except Exception:
        # Corrupt update metadata must never stop LumaFold from loading.
        pass
    state["schema"] = UPDATE_STATE_SCHEMA
    if str(state.get("channel", "stable")) not in channels():
        state["channel"] = "stable"
    return state


def save_state(path: Path, state: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = default_state()
    payload.update(dict(state or {}))
    payload["schema"] = UPDATE_STATE_SCHEMA
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def repository_contract(channel_id: str, state: dict[str, Any] | None = None) -> UpdateChannel:
    """Return the repository truth for this install.

    A deployed channel URL wins over persisted legacy metadata. This permits a
    future release to migrate known old URLs while keeping user preferences and
    extension identity stable. Before deployment, an empty URL makes update UI
    explicitly report 'repository not published' instead of guessing.
    """
    selected = channel(channel_id)
    if selected.repository_url:
        return selected
    persisted = str((state or {}).get("repository_url", "") or "").strip()
    if persisted:
        return UpdateChannel(selected.id, selected.label, persisted)
    return selected
