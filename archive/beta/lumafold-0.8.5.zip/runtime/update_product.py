from __future__ import annotations

"""Product controller for LumaFold online updates.

UI/menus talk only to this module.  Repository mutation and package installation
stay inside extension_repository; product identity/channel rules stay inside
services.update_service.  This prevents the updater from leaking into Host,
Sculpt input or other runtime domains.
"""

from pathlib import Path
import traceback

import bpy

from ..core.state import STATE
from ..services import update_service
from . import extension_repository

_STATE_FILENAME = "update_state.json"
_REGISTERED = False


def _state_path() -> Path:
    root = Path(bpy.utils.user_resource('CONFIG', path="lumafold", create=True))
    return root / _STATE_FILENAME


def load_state() -> dict:
    return update_service.load_state(_state_path())


def save_state(state: dict) -> None:
    update_service.save_state(_state_path(), state)


def selected_channel() -> str:
    return str(load_state().get("channel", "stable") or "stable")


def menu_snapshot() -> dict:
    state = load_state()
    channel_id = str(state.get("channel", "stable") or "stable")
    status = extension_repository.status(channel_id, state)
    version = update_service.product_version()
    return {
        "version": version.version,
        "channel": channel_id,
        "channel_label": update_service.channel(channel_id).label,
        "configured": status.configured,
        "online_allowed": status.online_allowed,
        "message": status.message,
        "remote_url": status.remote_url,
    }


def _record_failure(state: dict, exc: Exception) -> None:
    state["last_sync_ok"] = False
    state["last_sync_error"] = f"{type(exc).__name__}: {exc}"
    save_state(state)
    STATE.last_error = traceback.format_exc()


def _ensure_selected_repository(state: dict):
    channel_id = str(state.get("channel", "stable") or "stable")
    repo = extension_repository.ensure_repository(channel_id, state)
    contract = update_service.repository_contract(channel_id, state)
    state["repository_url"] = contract.repository_url
    save_state(state)
    return repo


class LUMAFOLD_OT_update_setup_repository(bpy.types.Operator):
    bl_idname = "lumafold.update_setup_repository"
    bl_label = "配置 LumaFold 在线更新"
    bl_description = "使用 Blender 原生 Extensions Repository 配置 LumaFold 更新源；只需配置一次"

    def execute(self, context):
        state = load_state()
        try:
            repo = _ensure_selected_repository(state)
            self.report({'INFO'}, f"LumaFold {update_service.channel(state['channel']).label} 更新源已配置")
            return {'FINISHED'}
        except Exception as exc:
            _record_failure(state, exc)
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}


class LUMAFOLD_OT_update_check(bpy.types.Operator):
    bl_idname = "lumafold.update_check"
    bl_label = "检查 LumaFold 更新"
    bl_description = "同步 LumaFold 远程仓库；下载与版本判断交给 Blender Extensions 系统"

    def execute(self, context):
        state = load_state()
        try:
            repo = _ensure_selected_repository(state)
            result = extension_repository.sync_repository(repo)
            if 'CANCELLED' in result:
                raise RuntimeError("Blender 取消了仓库同步")
            state["last_sync_ok"] = True
            state["last_sync_error"] = ""
            save_state(state)
            self.report({'INFO'}, "LumaFold 更新信息已同步")
            return {'FINISHED'}
        except Exception as exc:
            _record_failure(state, exc)
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}


class LUMAFOLD_OT_update_install(bpy.types.Operator):
    bl_idname = "lumafold.update_install"
    bl_label = "安装 LumaFold 更新"
    bl_description = "仅从 LumaFold 仓库安装/升级 lumafold 包，不会更新其他 Blender 扩展"

    def execute(self, context):
        state = load_state()
        try:
            repo = _ensure_selected_repository(state)
            sync_result = extension_repository.sync_repository(repo)
            if 'CANCELLED' in sync_result:
                raise RuntimeError("Blender 取消了仓库同步")
            result = extension_repository.install_or_upgrade(repo)
            if 'CANCELLED' in result:
                raise RuntimeError("Blender 取消了 LumaFold 更新")
            state["last_sync_ok"] = True
            state["last_sync_error"] = ""
            save_state(state)
            self.report({'INFO'}, "LumaFold 更新已交给 Blender 安装；如有提示请重启 Blender")
            return {'FINISHED'}
        except Exception as exc:
            _record_failure(state, exc)
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}


class LUMAFOLD_OT_update_set_channel(bpy.types.Operator):
    bl_idname = "lumafold.update_set_channel"
    bl_label = "切换 LumaFold 更新通道"
    bl_description = "Stable 用于同事日常使用；Beta 用于内部测试"

    channel: bpy.props.EnumProperty(
        items=(
            ('stable', "稳定版 Stable", "推荐给普通用户"),
            ('beta', "测试版 Beta", "用于内部测试新功能"),
        ),
        default='stable',
    )

    def execute(self, context):
        state = load_state()
        state["channel"] = str(self.channel)
        # Do not silently re-point an existing Blender repo to an unpublished
        # endpoint.  ensure_repository() applies the channel contract on demand.
        state["last_sync_ok"] = False
        state["last_sync_error"] = ""
        save_state(state)
        self.report({'INFO'}, f"LumaFold 更新通道：{update_service.channel(self.channel).label}")
        return {'FINISHED'}


class LUMAFOLD_OT_update_open_native(bpy.types.Operator):
    bl_idname = "lumafold.update_open_native"
    bl_label = "打开 Blender 更新管理"
    bl_description = "打开 Blender 原生 Extensions 更新界面"

    def execute(self, context):
        try:
            extension_repository.open_native_update_ui()
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}


CLASSES = (
    LUMAFOLD_OT_update_setup_repository,
    LUMAFOLD_OT_update_check,
    LUMAFOLD_OT_update_install,
    LUMAFOLD_OT_update_set_channel,
    LUMAFOLD_OT_update_open_native,
)


def register():
    global _REGISTERED
    if _REGISTERED:
        return
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    # Create/update metadata lazily. It lives outside the extension install
    # directory, so replacing the package cannot erase user update preferences.
    state = load_state()
    save_state(state)
    _REGISTERED = True


def unregister():
    global _REGISTERED
    if not _REGISTERED:
        return
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    _REGISTERED = False
