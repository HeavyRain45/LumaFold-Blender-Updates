from __future__ import annotations

"""Blender-native adapter for LumaFold extension repository operations.

Only this module is allowed to mutate Blender Extension repositories or invoke
extension sync/install operators. Product/UI layers express intent through this
adapter and never implement their own network/download/update mechanism.
"""

from dataclasses import dataclass
from typing import Any

import bpy

from ..services import update_service


@dataclass(frozen=True)
class RepositoryStatus:
    configured: bool
    online_allowed: bool
    index: int
    name: str
    module: str
    remote_url: str
    channel: str
    message: str = ""


def online_allowed() -> bool:
    return bool(getattr(bpy.app, "online_access", False))


def _repos():
    extensions = getattr(getattr(bpy.context, "preferences", None), "extensions", None)
    return getattr(extensions, "repos", None)


def _repo_index(repo) -> int:
    repos = _repos()
    if repos is None:
        return -1
    try:
        for index, item in enumerate(repos):
            if item == repo:
                return index
    except Exception:
        pass
    return -1


def find_repository(*, remote_url: str = "", name: str = update_service.REPOSITORY_NAME):
    repos = _repos()
    if repos is None:
        return None
    target_url = str(remote_url or "").rstrip("/")
    try:
        for repo in repos:
            repo_url = str(getattr(repo, "remote_url", "") or "").rstrip("/")
            if target_url and repo_url == target_url:
                return repo
            if str(getattr(repo, "name", "") or "") == str(name):
                return repo
    except Exception:
        return None
    return None


def status(channel_id: str, state: dict[str, Any] | None = None) -> RepositoryStatus:
    contract = update_service.repository_contract(channel_id, state)
    if not contract.repository_url:
        return RepositoryStatus(
            configured=False,
            online_allowed=online_allowed(),
            index=-1,
            name=update_service.REPOSITORY_NAME,
            module="",
            remote_url="",
            channel=contract.id,
            message="在线仓库尚未发布",
        )
    repo = find_repository(remote_url=contract.repository_url)
    if repo is None:
        return RepositoryStatus(
            configured=False,
            online_allowed=online_allowed(),
            index=-1,
            name=update_service.REPOSITORY_NAME,
            module="",
            remote_url=contract.repository_url,
            channel=contract.id,
            message="LumaFold 在线仓库尚未添加到 Blender",
        )
    return RepositoryStatus(
        configured=True,
        online_allowed=online_allowed(),
        index=_repo_index(repo),
        name=str(getattr(repo, "name", "") or update_service.REPOSITORY_NAME),
        module=str(getattr(repo, "module", "") or ""),
        remote_url=str(getattr(repo, "remote_url", "") or ""),
        channel=contract.id,
        message="就绪",
    )


def ensure_repository(channel_id: str, state: dict[str, Any] | None = None):
    contract = update_service.repository_contract(channel_id, state)
    if not contract.repository_url:
        raise RuntimeError("LumaFold 在线仓库尚未发布，当前开发版不会写入临时更新地址")
    repos = _repos()
    if repos is None:
        raise RuntimeError("当前 Blender 没有 Extensions Repository API")

    repo = find_repository(remote_url=contract.repository_url)
    if repo is None:
        repo = repos.new(
            name=update_service.REPOSITORY_NAME,
            module="lumafold_remote",
            remote_url=contract.repository_url,
            source='USER',
        )
    try:
        repo.enabled = True
    except Exception:
        pass
    try:
        repo.use_remote_url = True
    except Exception:
        pass
    try:
        repo.use_sync_on_startup = True
    except Exception:
        pass
    try:
        repo.remote_url = contract.repository_url
    except Exception:
        pass
    try:
        bpy.ops.wm.save_userpref()
    except Exception:
        pass
    return repo


def sync_repository(repo) -> set[str]:
    if not online_allowed():
        raise RuntimeError("Blender 当前禁止联网，请先在系统设置中允许 Online Access")
    index = _repo_index(repo)
    if index < 0:
        raise RuntimeError("无法定位 LumaFold Extension Repository")
    result = bpy.ops.extensions.repo_sync(repo_index=index)
    return set(result or ())


def install_or_upgrade(repo) -> set[str]:
    """Install/upgrade only the LumaFold package from its own repository.

    Do not use package_upgrade_all here: LumaFold's product button must never
    upgrade unrelated third-party extensions as a side effect.
    """
    if not online_allowed():
        raise RuntimeError("Blender 当前禁止联网，请先在系统设置中允许 Online Access")
    index = _repo_index(repo)
    if index < 0:
        raise RuntimeError("无法定位 LumaFold Extension Repository")
    result = bpy.ops.extensions.package_install(
        repo_index=index,
        pkg_id=update_service.EXTENSION_ID,
        enable_on_install=True,
    )
    return set(result or ())


def open_native_update_ui() -> set[str]:
    try:
        result = bpy.ops.extensions.userpref_show_for_update()
    except Exception:
        result = bpy.ops.screen.userpref_show('INVOKE_DEFAULT')
    return set(result or ())
