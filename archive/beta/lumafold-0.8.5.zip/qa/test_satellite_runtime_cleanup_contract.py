from __future__ import annotations

"""Static contract for Satellite runtime/module boundaries."""

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ADDON_INIT = (ROOT / "__init__.py").read_text(encoding="utf-8")
SECONDARY = (ROOT / "desktop" / "secondary_surface_host.py").read_text(encoding="utf-8")
TRANSPORT = (ROOT / "desktop" / "secondary_transport_policy.py").read_text(encoding="utf-8")
PRIMARY = (ROOT / "desktop" / "satellite_host.py").read_text(encoding="utf-8")
PRIMARY_RUNTIME = (ROOT / "desktop" / "satellite_host_runtime.py").read_text(encoding="utf-8")
PRIMARY_GEOMETRY = (ROOT / "ui" / "primary_surface_geometry.py").read_text(encoding="utf-8")
AUTHORITY = (ROOT / "runtime" / "satellite_bridge_authority.py").read_text(encoding="utf-8")
RUNTIME_CORE = (ROOT / "runtime" / "runtime_core.py").read_text(encoding="utf-8")
SCULPT_INPUT = (ROOT / "runtime" / "sculpt_input_core.py").read_text(encoding="utf-8")
ROUTE_TRUTH = (ROOT / "runtime" / "sculpt_route_truth.py").read_text(encoding="utf-8")
INPUT_PROBE = (ROOT / "runtime" / "satellite_input_probe.py").read_text(encoding="utf-8")
TABLET_LOCALITY = (ROOT / "runtime" / "tablet_pointer_locality.py").read_text(encoding="utf-8")
ALPHA_REVISION = (ROOT / "runtime" / "alpha_library_revision.py").read_text(encoding="utf-8")
PANELS = (ROOT / "panels.py").read_text(encoding="utf-8")
HOST_SESSION = (ROOT / "runtime" / "host_session_persistence.py").read_text(encoding="utf-8")
IDLE_POLICY = (ROOT / "runtime" / "embedded_idle_policy.py").read_text(encoding="utf-8")
MANIFEST = (ROOT / "blender_manifest.toml").read_text(encoding="utf-8")


def require(text, token, label):
    if token not in text:
        raise AssertionError(f"{label} missing contract token: {token}")


def main():
    require(SECONDARY, "def _queue_command(command_id, **kwargs):", "Secondary __main__ command adapter")
    require(SECONDARY, "return _runtime._queue_command(command_id, **kwargs)", "Secondary runtime command forwarding")
    if "sculpt.alpha.library_import_dialog" in SECONDARY:
        raise AssertionError("Satellite Secondary still routes Alpha add through legacy dialog command")
    if SECONDARY.count("sculpt.alpha.source_add_dialog") < 2:
        raise AssertionError("Satellite Alpha and More are not both routed to product Alpha-add command")
    require(SECONDARY, "WM_MOUSEACTIVATE = 0x0021", "Secondary mouse activation policy")
    require(SECONDARY, "return MA_NOACTIVATE", "Secondary no-activate policy")
    require(SECONDARY, "timeout = 0.12 if visible else 0.75", "Secondary watchdog cadence")
    require(SECONDARY, "payload = _runtime.actions.get(timeout=timeout)", "Secondary event-driven command wake")
    require(SECONDARY, "_transport_policy.install(_runtime)", "Secondary transport policy wiring")
    require(TRANSPORT, 'fresh = original({"action": "get_state"}, timeout=timeout)', "post-command snapshot refresh")

    require(PRIMARY, "def _lazy_secondary_prewarm():", "lazy Secondary policy")
    if "time.sleep(0.45)" in PRIMARY:
        raise AssertionError("historical 0.45s Secondary prewarm returned")
    require(PRIMARY, "_runtime.actions.get(timeout=0.10)", "Primary watchdog cadence")

    require(PRIMARY_GEOMETRY, "def primary_surface_geometry", "shared Primary geometry authority")
    require(PRIMARY_GEOMETRY, "SCULPT_PRIMARY.grid_gap", "shared Quick-row spacing token")
    require(PRIMARY_GEOMETRY, "SCULPT_PRIMARY.quick_tile_min", "shared Quick tile token")
    require(PRIMARY_RUNTIME, "from ui.primary_surface_geometry import", "Satellite consumes UI geometry authority")
    require(PRIMARY_RUNTIME, "def _calibrate_primary_surface_from_view", "hidden shared-View calibration")
    require(PRIMARY_RUNTIME, 'surface_state.get("sculpt_brush_library_anchor")', "shared View bottom-action anchor truth")
    require(PRIMARY_RUNTIME, 'anchor.get("button_bottom"', "real final-control bottom truth")
    require(PRIMARY_RUNTIME, "imgui.get_window_pos()", "Primary root origin truth")
    require(PRIMARY_RUNTIME, "if visible:", "calibration forbidden after user-visible")
    require(PRIMARY_RUNTIME, "normalize_base_height_design", "content-base normalization")
    require(PRIMARY_RUNTIME, "def _apply_primary_surface_contract", "one native Primary geometry adapter")
    require(PRIMARY_RUNTIME, "_commit_pending_primary_surface()", "geometry commit before ImGui frame")
    require(PRIMARY_RUNTIME, "primary_surface_geometry(", "deterministic row geometry")
    for forbidden in (
        "imgui.get_cursor_screen_pos()",
        "def _calibrate_primary_surface_contract",
        "measured_height_design = float(ch) / scale",
        "row_delta =",
        "slot_w = max(px(54.0",
    ):
        if forbidden in PRIMARY_RUNTIME:
            raise AssertionError("Satellite restored Host-owned Primary geometry heuristic: " + forbidden)
    for forbidden in (
        "_autofit_primary_after_layout",
        "_primary_autofit_pending",
        "imgui.get_content_region_avail()[1]",
        "_runtime._queue_quick_rows =",
        "_resize_primary_for_remote_quick_rows",
    ):
        if forbidden in PRIMARY:
            raise AssertionError("Satellite wrapper owns Primary geometry again: " + forbidden)

    if "sync_brush_state" in AUTHORITY or "sync_alpha_state" in AUTHORITY:
        raise AssertionError("Satellite snapshot authority still performs resource sync")
    require(AUTHORITY, "def _secondary_snapshot", "Secondary Store snapshot")
    require(AUTHORITY, "APP.store.snapshot()", "Secondary Store read")
    require(AUTHORITY, "def _bounded_preview_cache", "Secondary preview wire budget helper")

    if (ROOT / "runtime" / "sculpt_input_activity.py").exists():
        raise AssertionError("legacy activity monkey-patch module returned")
    if (ROOT / "runtime" / "satellite_input_session.py").exists():
        raise AssertionError("legacy broker monkey-patch module returned")
    require(SCULPT_INPUT, "HOST_CONTROL.snapshot()", "HostControl lease activity truth")
    require(SCULPT_INPUT, 'if state == SATELLITE and owner == "satellite":', "Satellite lease activity")
    require(SCULPT_INPUT, "def _ensure_satellite_brokers", "universal broker owner")
    require(SCULPT_INPUT, "for window in windows:", "one broker per Blender Window")
    require(SCULPT_INPUT, "def set_route_handler", "explicit route dependency slot")
    require(SCULPT_INPUT, "def set_navigation_handler", "explicit navigation dependency slot")
    require(SCULPT_INPUT, "def set_input_observer", "explicit diagnostic observer slot")
    require(SCULPT_INPUT, 'result = {"RUNNING_MODAL"} if _route_event', "single broker event route")
    if "_patch_embedded_host_modal" in SCULPT_INPUT:
        raise AssertionError("Embedded Host modal patch returned to input core")

    require(ADDON_INIT, "sculpt_route_truth.install(", "route authority wiring")
    require(ADDON_INIT, "sculpt_alt_gesture,", "Alt gesture dependency wiring")
    require(ADDON_INIT, "sculpt_mask_gesture,", "mask gesture dependency wiring")
    require(ROUTE_TRUTH, "set_route_handler", "route authority explicit injection")
    if "sculpt_input_core._route_event =" in ROUTE_TRUTH:
        raise AssertionError("route authority reverted to monkey patching")
    for forbidden in ("getattr(bpy.context", "bpy.context.mode", "bpy.context.sculpt_object", "bpy.context.view_layer"):
        if forbidden in ROUTE_TRUTH:
            raise AssertionError("event-context route authority reads global bpy.context: " + forbidden)

    if "core._bump_generation()" in RUNTIME_CORE or "core._RUNNING_SAT_WINDOWS.clear()" in RUNTIME_CORE or "core._ensure_satellite_brokers()" in RUNTIME_CORE:
        raise AssertionError("Runtime Core still owns broker lifecycle")

    require(ADDON_INIT, "satellite_input_probe.install(sculpt_input_core, tablet_pointer_locality)", "input probe + tablet locality wiring")
    require(INPUT_PROBE, "set_input_observer", "diagnostic observer hook")
    require(INPUT_PROBE, "_TABLET_LOCALITY.observe(context, event, real_machine_trace)", "tablet observer fan-out")
    if ".modal =" in INPUT_PROBE:
        raise AssertionError("diagnostic probe reverted to modal monkey patching")
    require(INPUT_PROBE, "GetForegroundWindow", "foreground HWND evidence")
    require(INPUT_PROBE, "GetCapture", "capture HWND evidence")
    require(TABLET_LOCALITY, "GetCursorPos", "Windows cursor locality evidence")
    require(TABLET_LOCALITY, "WindowFromPoint", "Windows window locality evidence")
    require(TABLET_LOCALITY, "MonitorFromPoint", "Windows monitor locality evidence")
    for forbidden in ("SetCursorPos", "ClipCursor", "SetCapture", "ReleaseCapture"):
        if forbidden in TABLET_LOCALITY:
            raise AssertionError("tablet locality diagnostics mutate Windows pointer state: " + forbidden)

    require(ADDON_INIT, "alpha_library_revision.install(operators, alpha_import_product)", "Alpha revision publisher wiring")
    require(ALPHA_REVISION, 'service.list_sculpt_alphas()', "authoritative Alpha rescan")

    # Productization: no developer N-panel in the shipping registration path.
    if "bpy.types.Panel" in PANELS or "bl_region_type = 'UI'" in PANELS:
        raise AssertionError("shipping panels.py still exposes a developer N-panel")
    require(PANELS, "LUMAFOLD_MT_product_maintenance", "native maintenance menu")
    require(PANELS, "lumafold.write_diagnostics", "maintenance report entry")
    require(PANELS, "lumafold.update_check", "update check entry")
    require(PANELS, "lumafold.update_install", "update install entry")
    require(PANELS, "lumafold.update_open_native", "native Blender update entry")
    if "real_machine_trace.register_ui()" in ADDON_INIT:
        raise AssertionError("real-machine developer trace UI is still registered in product mode")

    # Session ownership is isolated from HostControl/input/rendering. It supplies
    # startup intent and one-shot placement only.
    require(ADDON_INIT, "host_session_persistence.install(operators)", "host session owner wiring")
    require(ADDON_INIT, "host_session_persistence.prepare_for_shutdown()", "pre-shutdown session capture")
    require(ADDON_INIT, "host_session_persistence.schedule_startup_restore()", "startup host restoration")
    require(HOST_SESSION, '"host_mode": "embedded"', "persisted host mode")
    require(HOST_SESSION, '"satellite_restore_once"', "one-shot Satellite placement")
    require(HOST_SESSION, "embedded_last_valid_pos_x", "Embedded last-position restore")
    require(HOST_SESSION, "_DEFAULT_X_DESIGN = 52.0", "first-run X placement")
    require(HOST_SESSION, "_DEFAULT_Y_DESIGN = 68.0", "first-run Y placement")
    require(HOST_SESSION, "_capture_satellite_client_rect", "Satellite native placement capture")
    for forbidden in ("grant_satellite", "grant_embedded", "recover_embedded", "begin_detach", "begin_attach"):
        if forbidden in HOST_SESSION:
            raise AssertionError("session persistence mutated HostControl authority: " + forbidden)

    # Idle timer may keep context/status warm but must not force the old 60 Hz
    # View3D redraw path while Blender Preferences/native windows are moving.
    require(ADDON_INIT, "embedded_idle_policy.install(operators)", "Embedded idle policy wiring")
    require(IDLE_POLICY, "_IDLE_INTERVAL = 0.10", "10 Hz idle pulse")
    require(IDLE_POLICY, "operators_module._context_pulse = idle_context_pulse", "single timer-pulse adapter")
    if "event_timer_add" in IDLE_POLICY or "tag_redraw" in IDLE_POLICY:
        raise AssertionError("idle policy should throttle existing pulse, not own Blender timers/redraw")

    require(MANIFEST, 'version = "0.8.4"', "Extension semantic version")
    require(MANIFEST, 'name = "LumaFold Blender"', "product extension name")

    print("Satellite/Product-session/maintenance/idle-performance contract: PASS")


if __name__ == "__main__":
    main()
