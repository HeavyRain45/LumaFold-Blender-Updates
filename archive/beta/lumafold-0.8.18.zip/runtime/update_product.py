from __future__ import annotations

"""Product controller for LumaFold online updates.

UI/menus talk only to this module. Repository configuration/sync stays inside
extension_repository; product identity/channel rules stay inside
services.update_service; package replacement is owned by update_restart_transaction.
The running LumaFold process must never overwrite its own extension package.
"""

from pathlib import Path
import traceback

import bpy

from ..core.state import STATE
from ..services import update_service
from . import extension_repository, update_restart_transaction

_STATE_FILENAME = "update_state.json"
_REGISTERED = False


def _state_path() -> Path:
    root = Path(bpy.utils.user_resource('CONFIG', path="lumafold", create=True))
    return root / _STATE_FILENAME


def load_state() -> dict:
    return update_service.load_state(_state_path())


def save_state(state: dict) -> None:
    update_service.save_state(_state_path(), state)


def selected_channel() -> str:
    return str(load_state().get("channel", "stable") or "stable")


def menu_snapshot() -> dict:
    state = load_state()
    channel_id = str(state.get("channel", "stable") or "stable")
    status = extension_repository.status(channel_id, state)
    version = update_service.product_version()
    transaction = update_restart_transaction.reconcile_loaded_version(version.version)
    return {
        "version": version.version,
        "channel": channel_id,
        "channel_label": update_service.channel(channel_id).label,
        "configured": status.configured,
        "online_allowed": status.online_allowed,
        "message": status.message,
        "remote_url": status.remote_url,
        "update_transaction": str(transaction.get("state", "") or ""),
        "update_error": str(transaction.get("error", "") or ""),
        "update_summary": update_restart_transaction.transaction_summary(transaction),
        "update_source_version": str(transaction.get("source_version", "") or ""),
        "update_loaded_version": str(transaction.get("loaded_version", "") or ""),
        "update_channel": str(transaction.get("channel", "") or ""),
        "update_attempt_id": str(transaction.get("attempt_id", "") or ""),
    }


def _record_failure(state: dict, exc: Exception) -> None:
    state["last_sync_ok"] = False
    state["last_sync_error"] = f"{type(exc).__name__}: {exc}"
    save_state(state)
    STATE.last_error = traceback.format_exc()


def _ensure_selected_repository(state: dict):
    channel_id = str(state.get("channel", "stable") or "stable")
    repo = extension_repository.ensure_repository(channel_id, state)
    contract = update_service.repository_contract(channel_id, state)
    state["repository_url"] = contract.repository_url
    save_state(state)
    return repo


def _project_has_unsaved_changes() -> bool:
    return bool(getattr(bpy.data, "is_dirty", False))


def _project_filepath() -> str:
    return str(getattr(bpy.data, "filepath", "") or "")


def _save_project_before_update() -> None:
    """Guarantee project persistence before arming the restart transaction.

    New/never-saved projects are intentionally blocked because there is no safe
    implicit destination. Existing .blend files are saved synchronously and the
    update continues only after Blender reports a clean project state.
    """
    if not _project_has_unsaved_changes():
        return

    filepath = _project_filepath()
    if not filepath:
        raise RuntimeError("当前项目尚未保存。请先另存为 .blend 文件，再安装 LumaFold 更新。")

    result = bpy.ops.wm.save_as_mainfile(filepath=filepath)
    if 'CANCELLED' in result or _project_has_unsaved_changes():
        raise RuntimeError("当前 .blend 文件保存失败，已取消更新。")


class LUMAFOLD_OT_update_setup_repository(bpy.types.Operator):
    bl_idname = "lumafold.update_setup_repository"
    bl_label = "配置 LumaFold 在线更新"
    bl_description = "使用 Blender 原生 Extensions Repository 配置 LumaFold 更新源；只需配置一次"

    def execute(self, context):
        state = load_state()
        try:
            _ensure_selected_repository(state)
            self.report({'INFO'}, f"LumaFold {update_service.channel(state['channel']).label} 更新源已配置")
            return {'FINISHED'}
        except Exception as exc:
            _record_failure(state, exc)
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}


class LUMAFOLD_OT_update_check(bpy.types.Operator):
    bl_idname = "lumafold.update_check"
    bl_label = "检查 LumaFold 更新"
    bl_description = "同步 LumaFold 远程仓库；下载与版本判断交给 Blender Extensions 系统"

    def execute(self, context):
        state = load_state()
        try:
            repo = _ensure_selected_repository(state)
            result = extension_repository.sync_repository(repo)
            if 'CANCELLED' in result:
                raise RuntimeError("Blender 取消了仓库同步")
            state["last_sync_ok"] = True
            state["last_sync_error"] = ""
            save_state(state)
            self.report({'INFO'}, "LumaFold 更新信息已同步")
            return {'FINISHED'}
        except Exception as exc:
            _record_failure(state, exc)
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}


class LUMAFOLD_OT_update_install(bpy.types.Operator):
    bl_idname = "lumafold.update_install"
    bl_label = "安装 LumaFold 更新"
    bl_description = "保存当前项目后安全退出 Blender，由隔离 Helper 安装 LumaFold 更新并重新启动 Blender"

    def invoke(self, context, event):
        dirty = _project_has_unsaved_changes()
        if dirty and not _project_filepath():
            self.report({'ERROR'}, "当前项目尚未保存。请先另存为 .blend 文件，再安装 LumaFold 更新。")
            return {'CANCELLED'}
        if not dirty:
            return self.execute(context)
        return context.window_manager.invoke_props_dialog(self, width=360)

    def draw(self, context):
        self.layout.label(
            text="检测到未保存修改，将先保存项目，再更新并重启 Blender。",
            icon='ERROR',
        )

    def execute(self, context):
        state = load_state()
        try:
            # Project persistence is a hard precondition for process-isolated
            # replacement. Never arm the helper or quit Blender while the current
            # .blend still contains unsaved work.
            _save_project_before_update()

            repo = _ensure_selected_repository(state)
            sync_result = extension_repository.sync_repository(repo)
            if 'CANCELLED' in sync_result:
                raise RuntimeError("Blender 取消了仓库同步")
            version = update_service.product_version()
            channel_id = str(state.get("channel", "stable") or "stable")
            update_restart_transaction.arm(
                repo=repo,
                extension_id=update_service.EXTENSION_ID,
                source_version=version.version,
                channel=channel_id,
            )
            state["last_sync_ok"] = True
            state["last_sync_error"] = ""
            save_state(state)
            # No package mutation occurs here. The factory-startup helper is
            # already waiting on this PID and will only install after Blender is
            # fully gone, so native WGL/modal modules cannot overlap replacement.
            bpy.ops.wm.quit_blender()
            return {'FINISHED'}
        except Exception as exc:
            _record_failure(state, exc)
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}


class LUMAFOLD_OT_update_set_channel(bpy.types.Operator):
    bl_idname = "lumafold.update_set_channel"
    bl_label = "切换 LumaFold 更新通道"
    bl_description = "Stable 用于同事日常使用；Beta 用于内部测试"

    channel: bpy.props.EnumProperty(
        items=(
            ('stable', "稳定版 Stable", "推荐给普通用户"),
            ('beta', "测试版 Beta", "用于内部测试新功能"),
        ),
        default='stable',
    )

    def execute(self, context):
        state = load_state()
        state["channel"] = str(self.channel)
        state["last_sync_ok"] = False
        state["last_sync_error"] = ""
        save_state(state)
        self.report({'INFO'}, f"LumaFold 更新通道：{update_service.channel(self.channel).label}")
        return {'FINISHED'}


class LUMAFOLD_OT_update_open_native(bpy.types.Operator):
    bl_idname = "lumafold.update_open_native"
    bl_label = "打开 Blender 更新管理"
    bl_description = "打开 Blender 原生 Extensions 更新界面"

    def execute(self, context):
        try:
            extension_repository.open_native_update_ui()
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}


CLASSES = (
    LUMAFOLD_OT_update_setup_repository,
    LUMAFOLD_OT_update_check,
    LUMAFOLD_OT_update_install,
    LUMAFOLD_OT_update_set_channel,
    LUMAFOLD_OT_update_open_native,
)


def register():
    global _REGISTERED
    if _REGISTERED:
        return
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    state = load_state()
    save_state(state)
    try:
        update_restart_transaction.reconcile_loaded_version(update_service.product_version().version)
    except Exception:
        # A corrupt/legacy receipt must never stop LumaFold from registering.
        pass
    _REGISTERED = True


def unregister():
    global _REGISTERED
    if not _REGISTERED:
        return
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    _REGISTERED = False
