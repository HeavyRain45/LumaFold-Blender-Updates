from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

service = (ROOT / "services" / "update_service.py").read_text(encoding="utf-8")
adapter = (ROOT / "runtime" / "extension_repository.py").read_text(encoding="utf-8")
product = (ROOT / "runtime" / "update_product.py").read_text(encoding="utf-8")
transaction = (ROOT / "runtime" / "update_restart_transaction.py").read_text(encoding="utf-8")
panels = (ROOT / "panels.py").read_text(encoding="utf-8")
manifest = (ROOT / "blender_manifest.toml").read_text(encoding="utf-8")
workflow = (ROOT / ".github" / "workflows" / "release-extension.yml").read_text(encoding="utf-8")

assert 'EXTENSION_ID = "lumafold"' in service
assert 'id = "lumafold"' in manifest
assert 'name = "LumaFold Blender"' in manifest
assert 'REPOSITORY_NAME = "LumaFold"' in service

assert 'PUBLIC_UPDATES_REPOSITORY = "HeavyRain45/LumaFold-Blender-Updates"' in service
assert 'TARGET_STABLE_URL = f"{PUBLIC_PAGES_BASE}/stable/"' in service
assert 'TARGET_BETA_URL = f"{PUBLIC_PAGES_BASE}/beta/"' in service
assert '_STABLE_URL = ""' in service
assert '_BETA_URL = TARGET_BETA_URL' in service

# Running-product process may configure/sync the repository but must never
# replace its own loaded package. Native/WGL modules make in-process self-update
# an invalid lifetime boundary.
assert "bpy.ops.extensions.repo_sync" in adapter
assert "repo_directory=directory" in adapter
assert "bpy.ops.extensions.package_install" not in adapter
assert "bpy.ops.extensions.package_upgrade_all" not in adapter
assert "install_or_upgrade" not in adapter
assert "update_restart_transaction.arm" in product
assert "bpy.ops.wm.quit_blender()" in product
assert "bpy.ops.extensions.package_install" not in product
assert "bpy.ops.extensions.package_upgrade_all" not in product

# Package replacement is owned by a clean factory-startup helper process that
# waits for the product Blender PID to exit before touching the extension.
assert '"--factory-startup"' in transaction
assert '"--background"' in transaction
assert '"--online-mode"' in transaction
assert "_wait_for_process_exit" in transaction
assert "WaitForSingleObject" in transaction

# Blender's extension repo_index is resolved from a filtered effective list and
# must not be derived from preferences.extensions.repos. Directory identity is
# the stable operator contract for the exact LumaFold repository.
assert "bpy.ops.extensions.repo_sync(repo_directory=repo_directory)" in transaction
assert "def _repo_index" not in transaction
assert "enumerate(bpy.context.preferences.extensions.repos)" not in transaction

# Updating an installed package must use Blender's upgrade owner rather than the
# install operator. The exact repository is injected through operator context so
# package_upgrade_all only acts on the LumaFold repository.
assert "bpy.ops.extensions.package_upgrade_all(use_active_only=True)" in transaction
assert "bpy.context.temp_override(extension_repo=repo)" in transaction
assert "bpy.ops.extensions.package_install(" not in transaction
assert "installed_version" in transaction
assert "blender_manifest.toml" in transaction
assert "subprocess.Popen([args.blender_exe]" in transaction

for text in (adapter, product, transaction):
    assert "urllib" not in text
    assert "requests" not in text
    assert "urlopen" not in text

assert "bpy.utils.user_resource('CONFIG'" in product
assert '_STATE_FILENAME = "update_state.json"' in product
assert "update_transaction.json" in transaction

assert '"stable"' in service and '"beta"' in service
assert 'lumafold.update_set_channel' in product
assert 'stable.channel = \'stable\'' in panels
assert 'beta.channel = \'beta\'' in panels

assert "extension build" in workflow
assert "extension validate" in workflow
assert "extension server-generate" in workflow
assert "LUMAFOLD_RELEASE_CHANNEL" in workflow
assert "HeavyRain45/LumaFold-Blender-Updates" in workflow
assert "LUMAFOLD_UPDATES_TOKEN" in workflow
assert "Copy-Item -Path $env:LUMAFOLD_PACKAGE -Destination $channelDir" in workflow
assert "Remove-Item $channelDir" not in workflow
assert "git push origin HEAD:main" in workflow

for operator_id in (
    "lumafold.update_check",
    "lumafold.update_install",
    "lumafold.update_setup_repository",
    "lumafold.update_open_native",
):
    assert operator_id in panels

print("online update architecture contract: PASS")
