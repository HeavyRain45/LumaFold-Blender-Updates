from __future__ import annotations

# One source of truth for the development build shown in diagnostics.
# Product modules must not carry their own hand-written version labels.
BUILD_ID = "S0.8.7-beta1"
BUILD_TITLE = "Explicit Extension Upgrade Ownership"
BUILD_LABEL = f"{BUILD_ID} · {BUILD_TITLE}"
