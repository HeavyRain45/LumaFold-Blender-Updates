from __future__ import annotations

"""Explicit Satellite close policy.

The native Satellite X is a user request to close LumaFold, not a Host migration
request. Unexpected Satellite process loss still delegates to the existing
watchdog recovery path so Blender can recover the Embedded host after a crash.
"""

_INSTALLED = False
_ORIGINAL_WATCHDOG = None


def install(operators):
    global _INSTALLED, _ORIGINAL_WATCHDOG
    if _INSTALLED:
        return
    _ORIGINAL_WATCHDOG = operators._external_satellite_watchdog

    def satellite_watchdog_with_explicit_close():
        if not bool(getattr(operators, "_EXTERNAL_SATELLITE_WATCHDOG_RUNNING", False)):
            return None

        closing = bool(getattr(operators.BRIDGE, "satellite_closing", False))
        if closing:
            # WM_CLOSE has already reported `satellite_closing` through the
            # bridge. Retire the Satellite process and lease, but do not create
            # another Embedded renderer. The next toolbar toggle starts fresh.
            try:
                operators.BRIDGE.satellite_active = False
                operators.BRIDGE.stop_satellite_process()
            except Exception:
                pass

            operators.STATE.running = False
            operators.STATE.host = None
            operators.STATE.host_mode = "embedded"
            operators.STATE.status = "LumaFold closed from Satellite"
            operators._RETURN_EMBEDDED_TARGET = None
            operators._EXTERNAL_SATELLITE_WATCHDOG_RUNNING = False
            operators._MIGRATION_IN_PROGRESS = False

            try:
                lease = operators.HOST_CONTROL.lease
                if lease.state != operators.EMBEDDED or lease.owner != "embedded":
                    operators.HOST_CONTROL.recover_embedded()
            except Exception:
                try:
                    operators.HOST_CONTROL.recover_embedded()
                except Exception:
                    pass
            return None

        # No explicit close intent: preserve the accepted watchdog behavior for
        # unexpected process death / crash recovery back to Embedded.
        return _ORIGINAL_WATCHDOG()

    operators._external_satellite_watchdog = satellite_watchdog_with_explicit_close
    _INSTALLED = True


def uninstall(operators):
    global _INSTALLED, _ORIGINAL_WATCHDOG
    if not _INSTALLED:
        return
    if _ORIGINAL_WATCHDOG is not None:
        operators._external_satellite_watchdog = _ORIGINAL_WATCHDOG
    _ORIGINAL_WATCHDOG = None
    _INSTALLED = False
