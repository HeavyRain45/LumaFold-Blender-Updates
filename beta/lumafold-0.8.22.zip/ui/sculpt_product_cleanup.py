from __future__ import annotations

"""Small product-presentation cleanup shared by Floating and Satellite hosts.

This module deliberately stays above the frozen Sculpt foundation. It owns only
presentation policy requested by the product surface: concise Alpha add actions,
user-owned managed-folder labels, temporary hiding of the unfinished More action,
and the product intent emitted by the Satellite Host switch. It does not own
Alpha filesystem data, Host input, or Host migration mechanics.
"""

_INSTALLED = False
_ORIGINAL_ALPHA_DRAW = None
_ORIGINAL_ADD_CONTEXT = None
_ORIGINAL_FOUNDATION_DRAW = None
_MANAGED_FOLDER_PREFIX = "alpha|lumafold_user|"
_SATELLITE_RETURN_SERIAL = 0


def _managed_folder_label(folder: dict) -> str:
    folder = dict(folder or {})
    folder_id = str(folder.get("id") or "")
    if not folder_id.startswith(_MANAGED_FOLDER_PREFIX):
        return str(folder.get("label") or "文件夹")
    relative = folder_id[len(_MANAGED_FOLDER_PREFIX):].replace("\\", "/").strip("/")
    if not relative or relative == "根目录":
        return str(folder.get("label") or "文件夹")
    return relative


def _present_alpha_sculpt(sculpt):
    presented = dict(sculpt or {})
    folders = []
    for raw in list(presented.get("alpha_library_folders") or ()):
        folder = dict(raw or {})
        if str(folder.get("id") or "").startswith(_MANAGED_FOLDER_PREFIX):
            folder["label"] = _managed_folder_label(folder)
        folders.append(folder)
    presented["alpha_library_folders"] = folders
    return presented


def _draw_add_context_compact(alpha_product, imgui, scale: float):
    """Two self-sizing actions; no explanatory footer competes with the menu."""
    foundation = alpha_product.foundation
    popup_name = "Alpha Add##product_context"
    labels = ("添加 Alpha 图片 / 本地文件夹", "新建文件夹")

    try:
        with foundation.font_scope(imgui, "small", scale):
            text_w = max(float(imgui.calc_text_size(label)[0]) for label in labels)
        popup_w = max(foundation.px(156.0, scale), text_w + foundation.px(30.0, scale))
        if hasattr(imgui, "set_next_window_size_constraints"):
            imgui.set_next_window_size_constraints(
                (popup_w, 0.0),
                (popup_w, foundation.px(180.0, scale)),
            )
    except Exception:
        popup_w = foundation.px(176.0, scale)

    if not imgui.begin_popup(popup_name):
        return
    try:
        width = max(1.0, float(imgui.get_content_region_avail()[0]))
        if foundation.button(
            imgui, labels[0], scale, width / scale,
            kind="small", height=foundation.CONTEXT_MENU.row_h,
        ):
            alpha_product._dispatch_product_action("add_alpha")
            try:
                imgui.close_current_popup()
            except Exception:
                pass

        width = max(1.0, float(imgui.get_content_region_avail()[0]))
        if foundation.button(
            imgui, labels[1], scale, width / scale,
            kind="small", height=foundation.CONTEXT_MENU.row_h,
        ):
            alpha_product._dispatch_product_action("create_folder")
            try:
                imgui.close_current_popup()
            except Exception:
                pass
    finally:
        imgui.end_popup()


def install(alpha_product, sculpt_view):
    global _INSTALLED, _ORIGINAL_ALPHA_DRAW, _ORIGINAL_ADD_CONTEXT, _ORIGINAL_FOUNDATION_DRAW
    if _INSTALLED:
        return

    foundation = alpha_product.foundation
    _ORIGINAL_ALPHA_DRAW = alpha_product.draw_alpha_library_product
    _ORIGINAL_ADD_CONTEXT = alpha_product._draw_add_context
    _ORIGINAL_FOUNDATION_DRAW = foundation.draw_sculpt_compact

    def draw_alpha_library_product_compact(imgui, sculpt, scale, **kwargs):
        return _ORIGINAL_ALPHA_DRAW(imgui, _present_alpha_sculpt(sculpt), scale, **kwargs)

    def draw_add_context_compact(imgui, scale):
        return _draw_add_context_compact(alpha_product, imgui, scale)

    def draw_sculpt_compact_product(*args, **kwargs):
        # The Satellite Host switch is a Host migration request, while the native
        # window X is a product-close request. Never route both through WM_CLOSE.
        # Publish the switch intent over the existing sculpt state bridge; Blender
        # remains the sole owner of the actual Satellite -> Embedded migration.
        host_label = str(kwargs.get("host_label") or "").strip()
        on_state_changed = kwargs.get("on_state_changed")
        if host_label == "卫星" and callable(on_state_changed):
            def request_return_to_floating():
                global _SATELLITE_RETURN_SERIAL
                _SATELLITE_RETURN_SERIAL += 1
                on_state_changed({
                    "satellite_return_request_serial": int(_SATELLITE_RETURN_SERIAL),
                })

            kwargs["on_toggle_host"] = request_return_to_floating

        # sculpt_view installs its own per-frame button composition immediately
        # before calling the foundation. Capture that composed button here so the
        # cleanup stays presentation-only and does not bypass existing behavior.
        active_button = foundation.button

        def product_button(imgui_arg, label, scale_arg=1.0, width=0.0, **button_kwargs):
            text_label = str(label or "")
            if text_label == "更多":
                return False
            if text_label == "笔刷库":
                try:
                    available_px = max(1.0, float(imgui_arg.get_content_region_avail()[0]))
                    width = max(float(width or 0.0), available_px / max(0.01, float(scale_arg)))
                except Exception:
                    pass
            return active_button(imgui_arg, label, scale_arg, width, **button_kwargs)

        foundation.button = product_button
        try:
            return _ORIGINAL_FOUNDATION_DRAW(*args, **kwargs)
        finally:
            foundation.button = active_button

    alpha_product._draw_add_context = draw_add_context_compact
    alpha_product.draw_alpha_library_product = draw_alpha_library_product_compact
    foundation.draw_alpha_library_foundation = draw_alpha_library_product_compact
    sculpt_view.draw_alpha_library_foundation = draw_alpha_library_product_compact
    foundation.draw_sculpt_compact = draw_sculpt_compact_product
    _INSTALLED = True


def uninstall(alpha_product, sculpt_view):
    global _INSTALLED, _ORIGINAL_ALPHA_DRAW, _ORIGINAL_ADD_CONTEXT, _ORIGINAL_FOUNDATION_DRAW
    global _SATELLITE_RETURN_SERIAL
    if not _INSTALLED:
        return
    foundation = alpha_product.foundation
    if _ORIGINAL_ADD_CONTEXT is not None:
        alpha_product._draw_add_context = _ORIGINAL_ADD_CONTEXT
    if _ORIGINAL_ALPHA_DRAW is not None:
        alpha_product.draw_alpha_library_product = _ORIGINAL_ALPHA_DRAW
        foundation.draw_alpha_library_foundation = _ORIGINAL_ALPHA_DRAW
        sculpt_view.draw_alpha_library_foundation = _ORIGINAL_ALPHA_DRAW
    if _ORIGINAL_FOUNDATION_DRAW is not None:
        foundation.draw_sculpt_compact = _ORIGINAL_FOUNDATION_DRAW
    _ORIGINAL_ALPHA_DRAW = None
    _ORIGINAL_ADD_CONTEXT = None
    _ORIGINAL_FOUNDATION_DRAW = None
    _SATELLITE_RETURN_SERIAL = 0
    _INSTALLED = False
