# Shared UI product composition hooks.
#
# Importing the ui package happens in both Blender Embedded and the standalone
# Native Secondary Surface process. Installing Alpha Library product behavior
# here keeps one implementation for both hosts without teaching Host/Input code
# about Alpha source management.
from . import alpha_library_product as _alpha_library_product

_alpha_library_product.install()

# `ui.sculpt_view` re-exports the foundation functions by value.  A standalone
# Secondary process can therefore keep a stale reference if that module was
# imported before/while the product hook was installed.  Rebind the public
# composition symbol explicitly so Embedded and Native Secondary always draw
# the same Alpha product surface (unified add/delete/folder semantics).
from . import sculpt_view as _sculpt_view

_sculpt_view.draw_alpha_library_foundation = _alpha_library_product.draw_alpha_library_product

# Product-only presentation cleanup is installed after both shared view modules
# exist. It stays above the frozen foundation and therefore applies identically
# to Floating, Satellite, and Secondary surfaces without touching Host/Input.
from . import sculpt_product_cleanup as _sculpt_product_cleanup

_sculpt_product_cleanup.install(_alpha_library_product, _sculpt_view)
