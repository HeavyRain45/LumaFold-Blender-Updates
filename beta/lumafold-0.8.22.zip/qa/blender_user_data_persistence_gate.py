from __future__ import annotations

"""Real Blender 5.2.1 gate for LumaFold user-owned state durability.

The extension package is replaceable. User state must not live inside that package.
This gate verifies the current product contracts with Blender itself:
- Core state.json lives under Blender user CONFIG and round-trips product state;
- Host/session state survives the same persistence round-trip;
- linked Alpha registry metadata survives a fresh service instance;
- managed Alpha storage lives under Blender user DATAFILES, outside the add-on tree;
- preview cache remains disposable and outside the add-on tree.
"""

import bpy
import importlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import traceback

ROOT = Path(__file__).resolve().parents[1]
RESULT_PATH = ROOT / "blender_user_data_persistence_result.json"
if "--" in sys.argv:
    rest = sys.argv[sys.argv.index("--") + 1:]
    for idx, value in enumerate(rest):
        if value == "--result-path" and idx + 1 < len(rest):
            RESULT_PATH = Path(rest[idx + 1]).resolve()


def write_result(ok: bool, *, stage: str, detail: str = "", extra=None):
    payload = {
        "ok": bool(ok),
        "stage": str(stage),
        "detail": str(detail),
        "blender_version": bpy.app.version_string,
        "background": bool(bpy.app.background),
        "extra": dict(extra or {}),
    }
    RESULT_PATH.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print("LUMAFOLD_USER_DATA_GATE", json.dumps(payload, ensure_ascii=False), flush=True)
    return payload


def load_addon():
    name = "lumafold_persistence_ci"
    for key in tuple(sys.modules):
        if key == name or key.startswith(name + "."):
            sys.modules.pop(key, None)
    spec = importlib.util.spec_from_file_location(
        name,
        ROOT / "__init__.py",
        submodule_search_locations=[str(ROOT)],
    )
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    sys.modules[name] = module
    spec.loader.exec_module(module)
    module.register()
    return name, module


def outside_package(path: Path) -> bool:
    path = path.resolve()
    root = ROOT.resolve()
    try:
        path.relative_to(root)
        return False
    except ValueError:
        return True


def main():
    addon = None
    linked_source_id = ""
    managed_folder_id = ""
    try:
        if tuple(bpy.app.version[:3]) != (5, 2, 1):
            raise RuntimeError(f"expected Blender 5.2.1, got {bpy.app.version_string}")
        if not bpy.app.background:
            raise RuntimeError("this gate must run in Blender background mode")

        package_name, addon = load_addon()
        app = addon.APP

        state_path = app.persistence.default_path().resolve()
        if not outside_package(state_path):
            raise RuntimeError(f"state.json is inside replaceable add-on package: {state_path}")
        if "lumafold" not in {part.casefold() for part in state_path.parts}:
            raise RuntimeError(f"state path is not namespaced for LumaFold: {state_path}")

        sculpt = app.store.namespace("sculpt")
        host = app.store.namespace("__host_session__")
        sculpt["persistence_gate_quick_slot"] = "slot-survives-update"
        sculpt["persistence_gate_alpha_mapping"] = "alpha-survives-update"
        host["host_mode"] = "satellite"
        host["satellite_x"] = 321.0
        host["satellite_y"] = 654.0
        report = app.persistence.save(force=True)
        if not report.ok or not state_path.exists():
            raise RuntimeError(f"core persistence save failed: {report.status} {report.message}")

        # Overwrite live mirrors, then restore from the durable user-profile file.
        sculpt["persistence_gate_quick_slot"] = "mutated"
        sculpt["persistence_gate_alpha_mapping"] = "mutated"
        host["host_mode"] = "embedded"
        host["satellite_x"] = 0.0
        host["satellite_y"] = 0.0
        loaded = app.persistence.load(apply=True)
        if not loaded.ok:
            raise RuntimeError(f"core persistence load failed: {loaded.status} {loaded.message}")
        if sculpt.get("persistence_gate_quick_slot") != "slot-survives-update":
            raise RuntimeError("sculpt/Quick Slot durable state did not round-trip")
        if sculpt.get("persistence_gate_alpha_mapping") != "alpha-survives-update":
            raise RuntimeError("sculpt/Alpha mapping durable state did not round-trip")
        if host.get("host_mode") != "satellite" or float(host.get("satellite_x", 0.0)) != 321.0:
            raise RuntimeError("Host session durable state did not round-trip")

        source_module = importlib.import_module(package_name + ".services.alpha_source_store")
        managed_module = importlib.import_module(package_name + ".services.alpha_managed_store")
        preview_module = importlib.import_module(package_name + ".runtime.preview_disk_cache")

        source_store = source_module.AlphaSourceStore()
        source_path = source_store._storage_path().resolve()
        if not outside_package(source_path):
            raise RuntimeError(f"Alpha source registry is inside add-on package: {source_path}")

        with tempfile.TemporaryDirectory(prefix="lumafold-linked-alpha-") as temp_dir:
            added = source_store.add_folder(temp_dir)
            linked_source_id = str((added.get("source") or {}).get("id") or "")
            fresh_store = source_module.AlphaSourceStore()
            records = fresh_store.list_sources()
            if not linked_source_id or not any(str(item.get("id") or "") == linked_source_id for item in records):
                raise RuntimeError("linked Alpha registry did not survive a fresh service instance")
            fresh_store.remove_folder(linked_source_id)
            linked_source_id = ""

        managed_store = managed_module.AlphaManagedStore()
        managed_root = managed_store._root(create=True).resolve()
        if not outside_package(managed_root):
            raise RuntimeError(f"managed Alpha root is inside add-on package: {managed_root}")
        created = managed_store.create_folder("__persistence_gate__")
        managed_folder_id = str(created.get("folder_id") or "")
        if not managed_folder_id:
            raise RuntimeError("managed Alpha folder was not created")
        managed_store.remove_folder(managed_folder_id)
        managed_folder_id = ""

        cache_path = preview_module._cache_path().resolve()
        if not outside_package(cache_path):
            raise RuntimeError(f"preview cache is inside add-on package: {cache_path}")

        write_result(
            True,
            stage="PASS",
            extra={
                "state_path": str(state_path),
                "alpha_source_path": str(source_path),
                "managed_alpha_root": str(managed_root),
                "preview_cache_path": str(cache_path),
            },
        )
    except Exception as exc:
        write_result(False, stage="FAILED", detail=f"{type(exc).__name__}: {exc}", extra={"traceback": traceback.format_exc()})
        raise
    finally:
        try:
            if addon is not None:
                addon.unregister()
        except Exception:
            pass


if __name__ == "__main__":
    main()
