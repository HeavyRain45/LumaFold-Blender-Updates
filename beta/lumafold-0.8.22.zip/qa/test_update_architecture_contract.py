from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

service = (ROOT / "services" / "update_service.py").read_text(encoding="utf-8")
adapter = (ROOT / "runtime" / "extension_repository.py").read_text(encoding="utf-8")
product = (ROOT / "runtime" / "update_product.py").read_text(encoding="utf-8")
transaction = (ROOT / "runtime" / "update_restart_transaction.py").read_text(encoding="utf-8")
panels = (ROOT / "panels.py").read_text(encoding="utf-8")
manifest = (ROOT / "blender_manifest.toml").read_text(encoding="utf-8")
workflow = (ROOT / ".github" / "workflows" / "release-extension.yml").read_text(encoding="utf-8")

assert 'EXTENSION_ID = "lumafold"' in service
assert 'id = "lumafold"' in manifest
assert 'name = "LumaFold Blender"' in manifest
assert 'REPOSITORY_NAME = "LumaFold"' in service

assert 'PUBLIC_UPDATES_REPOSITORY = "HeavyRain45/LumaFold-Blender-Updates"' in service
assert 'PUBLIC_RAW_BASE = "https://raw.githubusercontent.com/HeavyRain45/LumaFold-Blender-Updates/main"' in service
assert 'TARGET_STABLE_URL = f"{PUBLIC_RAW_BASE}/stable/index.json"' in service
assert 'TARGET_BETA_URL = f"{PUBLIC_RAW_BASE}/beta/index.json"' in service
assert 'PUBLIC_PAGES_BASE' not in service
assert '_STABLE_URL = ""' in service
assert '_BETA_URL = TARGET_BETA_URL' in service

# Running-product process may configure/sync the repository but must never
# replace its own loaded package. Native/WGL modules make in-process self-update
# an invalid lifetime boundary.
assert "bpy.ops.extensions.repo_sync" in adapter
assert "repo_directory=directory" in adapter
assert "bpy.ops.extensions.package_install" not in adapter
assert "bpy.ops.extensions.package_upgrade_all" not in adapter
assert "install_or_upgrade" not in adapter
assert "update_restart_transaction.arm" in product
assert "bpy.ops.wm.quit_blender()" in product
assert "bpy.ops.extensions.package_install" not in product
assert "bpy.ops.extensions.package_upgrade_all" not in product

# Project persistence is a hard precondition for a restart update. Dirty files
# with an existing path must be saved synchronously; dirty never-saved projects
# must be blocked instead of inventing a destination or quitting Blender.
assert "def _project_has_unsaved_changes" in product
assert "bpy.data" in product
assert "is_dirty" in product
assert "def _project_filepath" in product
assert "def _save_project_before_update" in product
assert "bpy.ops.wm.save_as_mainfile(filepath=filepath)" in product
assert "当前项目尚未保存" in product
assert "当前 .blend 文件保存失败，已取消更新" in product
assert product.index("_save_project_before_update()") < product.index("update_restart_transaction.arm(")
assert product.index("_save_project_before_update()") < product.index("bpy.ops.wm.quit_blender()")

# Checked update state must expose the exact target version as a dedicated
# status line, not hide the result inside action labels or tooltips. Network
# sync remains Blender-owned; LumaFold only reads Blender's local index.
assert '"remote_version": ""' in service
assert "def available_version" in adapter
assert 'Path(directory) / ".blender_ext" / "index.json"' in adapter
assert "extension_repository.available_version(repo)" in product
assert '"remote_version": remote_version' in product
assert '"update_available": checked and _update_available' in product
assert 'f"发现新版本：v{remote_version}"' in panels
assert '"已是最新版本"' in panels
assert 'actions.operator("lumafold.update_check", text="检查更新"' in panels
assert 'actions.operator("lumafold.update_install", text="安装更新"' in panels
assert '检查更新 ·' not in panels

# Installing always presents a compact, explicit restart confirmation. The
# dialog identifies the current version and project-safety state without
# exposing helper/repository implementation details.
assert "invoke_props_dialog(self, width=360)" in product
assert 'text=f"当前：v{version}"' in product
assert '"LumaFold 更新完成后将自动重启 Blender。"' in product
assert '"请确认当前项目已保存。"' in product
assert '"检测到未保存修改，将先保存当前项目。"' in product
assert "更新期间不会在当前进程覆盖" not in product

# Package replacement is owned by a clean factory-startup helper process that
# waits for the product Blender PID to exit before touching the extension.
assert '"--factory-startup"' in transaction
assert '"--background"' in transaction
assert '"--online-mode"' in transaction
assert "_wait_for_process_exit" in transaction
assert "WaitForSingleObject" in transaction

# A factory-startup helper does not inherit the user's repository preferences.
# The running product must pass the exact repository directory that owns the
# installed LumaFold package, and the helper must re-attach that directory via
# Blender's native custom_directory repository API before attempting upgrade.
assert '"--repo-directory"' in transaction
assert "repo_directory = str(getattr(repo, \"directory\"" in transaction
assert "custom_directory=args.repo_directory" in transaction
assert "target_directory = _norm_dir(args.repo_directory)" in transaction
assert "installed_before_sync = _installed_version(repo, args.pkg_id)" in transaction
assert "Helper could not find installed package" in transaction

# repo_sync accepts directory identity directly, so it must not be routed
# through Blender's filtered operator repo_index contract.
assert "bpy.ops.extensions.repo_sync(repo_directory=repo_directory)" in transaction
assert "def _repo_index" not in transaction
assert "enumerate(bpy.context.preferences.extensions.repos)" not in transaction

# package_upgrade_all(use_active_only=True) resolves its target from
# preferences.extensions.active_repo. The isolated helper must explicitly set
# that raw repository collection index to LumaFold before invoking the native
# upgrade owner; context override alone is not sufficient in Blender 5.2.
assert "repo_raw_index" in transaction
assert "extensions.active_repo = int(repo_raw_index)" in transaction
assert "bpy.ops.extensions.package_upgrade_all(use_active_only=True)" in transaction
assert "bpy.context.temp_override(extension_repo=repo)" in transaction
assert "bpy.ops.extensions.package_install(" not in transaction
assert "installed_version" in transaction
assert "blender_manifest.toml" in transaction
assert "subprocess.Popen([args.blender_exe]" in transaction

for text in (adapter, product, transaction):
    assert "urllib" not in text
    assert "requests" not in text
    assert "urlopen" not in text

assert "bpy.utils.user_resource('CONFIG'" in product
assert '_STATE_FILENAME = "update_state.json"' in product
assert "update_transaction.json" in transaction

# Stable/Beta switching and native repository setup remain low-frequency
# product capabilities, but the high-frequency header menu intentionally hides
# them. The compact menu exposes only direct update actions.
assert '"stable"' in service and '"beta"' in service
assert 'lumafold.update_set_channel' in product
assert 'lumafold.update_setup_repository' in product
assert 'lumafold.update_open_native' in product
assert 'lumafold.update_set_channel' not in panels
assert 'lumafold.update_setup_repository' not in panels
assert 'lumafold.update_open_native' not in panels
assert 'lumafold.write_diagnostics' not in panels
assert 'lumafold.update_check' in panels
assert 'lumafold.update_install' in panels

assert "extension build" in workflow
assert "extension validate" in workflow
assert "extension server-generate" in workflow
assert "LUMAFOLD_RELEASE_CHANNEL" in workflow
assert "HeavyRain45/LumaFold-Blender-Updates" in workflow
assert "LUMAFOLD_UPDATES_TOKEN" in workflow
assert "Copy-Item -Path $env:LUMAFOLD_PACKAGE -Destination $channelDir" in workflow
assert 'archive/' in workflow
assert "Move-Item -Path $_.FullName" in workflow
assert "public index must contain exactly one lumafold entry" in workflow
assert "Remove-Item $channelDir" not in workflow
assert "git push origin HEAD:main" in workflow

print("online update architecture contract: PASS")
