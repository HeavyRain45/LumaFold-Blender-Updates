from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
product = (ROOT / "runtime" / "update_product.py").read_text(encoding="utf-8")

# Clean projects should not be interrupted by a redundant confirmation dialog.
assert "if not dirty:" in product
assert "return self.execute(context)" in product

# Never-saved dirty projects remain blocked before any restart transaction.
assert "if dirty and not _project_filepath():" in product
assert "当前项目尚未保存" in product

# Only dirty saved projects reach the dialog, and its user-facing copy stays
# compact instead of exposing updater implementation details.
assert "invoke_props_dialog(self, width=360)" in product
assert "检测到未保存修改，将先保存项目，再更新并重启 Blender。" in product
assert "当前项目没有未保存修改" not in product
assert "更新期间不会在当前进程覆盖正在运行的插件文件" not in product
assert "安装完成后 Blender 将自动重新启动" not in product

# Persistence still precedes helper arm and Blender exit.
assert product.index("_save_project_before_update()") < product.index("update_restart_transaction.arm(")
assert product.index("_save_project_before_update()") < product.index("bpy.ops.wm.quit_blender()")

print("update restart prompt contract: PASS")
