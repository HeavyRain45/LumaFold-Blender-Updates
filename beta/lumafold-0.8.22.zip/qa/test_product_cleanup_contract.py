from __future__ import annotations

"""Static contract for product cleanup and Satellite close/return separation."""

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
UI = (ROOT / "ui" / "sculpt_product_cleanup.py").read_text(encoding="utf-8")
UI_INIT = (ROOT / "ui" / "__init__.py").read_text(encoding="utf-8")
CLOSE = (ROOT / "runtime" / "satellite_close_policy.py").read_text(encoding="utf-8")
ROOT_INIT = (ROOT / "__init__.py").read_text(encoding="utf-8")
SAT_RUNTIME = (ROOT / "desktop" / "satellite_host_runtime.py").read_text(encoding="utf-8")


def require(text: str, token: str, label: str):
    if token not in text:
        raise AssertionError(f"{label} missing contract token: {token}")


def forbid(text: str, token: str, label: str):
    if token in text:
        raise AssertionError(f"{label} contains forbidden token: {token}")


def main():
    # Alpha folder rows present user-owned names, while provenance remains in the
    # underlying Alpha service snapshot.
    require(UI, '_MANAGED_FOLDER_PREFIX = "alpha|lumafold_user|"', "managed folder presentation")
    require(UI, 'relative = folder_id[len(_MANAGED_FOLDER_PREFIX):]', "managed folder custom label")
    require(UI, 'folder["label"] = _managed_folder_label(folder)', "managed folder label composition")

    # Plus popup is exactly two concise, content-sized actions.
    require(UI, '("添加 Alpha 图片 / 本地文件夹", "新建文件夹")', "Alpha add actions")
    require(UI, "calc_text_size(label)", "Alpha add auto width")
    require(UI, "set_next_window_size_constraints", "Alpha add adaptive popup")
    forbid(UI, "图片进入“全部”；整个文件夹会显示在左侧", "Alpha add footer")
    forbid(UI, "新建 LumaFold 文件夹", "Alpha create wording")

    # More stays hidden in the shared View composition, so Floating and Satellite
    # cannot drift into different product controls.
    require(UI, 'if text_label == "更多":', "shared More suppression")
    require(UI, 'if text_label == "笔刷库":', "Brush Library expansion")
    require(UI, "get_content_region_avail", "Brush Library adaptive width")
    require(UI_INIT, "_sculpt_product_cleanup.install(_alpha_library_product, _sculpt_view)", "shared UI install")

    # Satellite Host-switch intent must never reuse the native WM_CLOSE route.
    # The UI publishes intent over the existing sculpt state bridge; Blender owns
    # the actual migration back to Embedded.
    require(UI, 'host_label == "卫星"', "Satellite switch specialization")
    require(UI, '"satellite_return_request_serial"', "Satellite return intent")
    require(UI, 'kwargs["on_toggle_host"] = request_return_to_floating', "Satellite switch callback")
    require(CLOSE, 'operators.APP.events.subscribe(', "Satellite return subscription")
    require(CLOSE, '"sculpt.state.changed", _on_sculpt_state_changed', "Satellite return event")
    require(CLOSE, "operators._request_return_from_external_satellite()", "Satellite Embedded migration")
    require(CLOSE, "_UNSUBSCRIBE_STATE", "Satellite return subscription cleanup")

    # Explicit native Satellite close remains product shutdown. Unexpected process
    # death still delegates to the accepted Embedded recovery watchdog.
    require(SAT_RUNTIME, 'request({"action": "satellite_closing"', "native X close transport")
    require(CLOSE, "if closing:", "explicit Satellite close branch")
    require(CLOSE, 'operators.STATE.status = "LumaFold closed from Satellite"', "explicit close status")
    require(CLOSE, "operators._RETURN_EMBEDDED_TARGET = None", "explicit close clears return target")
    require(CLOSE, "operators.HOST_CONTROL.recover_embedded()", "explicit close lease cleanup")
    require(CLOSE, "return _ORIGINAL_WATCHDOG()", "unexpected Satellite death recovery")
    forbid(CLOSE, "_restore_embedded_after_satellite", "explicit close policy")
    require(ROOT_INIT, 'satellite_close_policy = _importlib.import_module(__name__ + ".runtime.satellite_close_policy")', "close policy import")
    require(ROOT_INIT, "satellite_close_policy.install(operators)", "close policy install")
    require(ROOT_INIT, "satellite_close_policy.uninstall(operators)", "close policy uninstall")

    print("Product cleanup and Satellite close/return contract: PASS")


if __name__ == "__main__":
    main()
