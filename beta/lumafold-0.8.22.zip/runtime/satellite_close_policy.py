from __future__ import annotations

"""Satellite close versus Host-return policy.

The native Satellite X is a user request to close LumaFold. The Satellite Host
switch is a separate migration request that is published through the existing
``sculpt.state.changed`` bridge and handled here on Blender's main thread.
Unexpected Satellite process loss still delegates to the accepted watchdog
recovery path.
"""

_INSTALLED = False
_ORIGINAL_WATCHDOG = None
_UNSUBSCRIBE_STATE = None
_LAST_RETURN_SERIAL = 0
_OPERATORS = None


def _coerce_serial(value) -> int:
    try:
        return int(value)
    except Exception:
        return 0


def _on_sculpt_state_changed(payload):
    global _LAST_RETURN_SERIAL
    operators = _OPERATORS
    if operators is None:
        return

    fields = dict((payload or {}).get("fields") or {})
    if "satellite_return_request_serial" not in fields:
        return

    serial = _coerce_serial(fields.get("satellite_return_request_serial"))
    if serial <= 0 or serial <= int(_LAST_RETURN_SERIAL):
        return
    _LAST_RETURN_SERIAL = serial

    # This event is emitted by the Bridge pump on Blender's main thread. Keep
    # migration ownership in operators/HostControl; the Satellite UI only emits
    # intent and never closes its own HWND for a Host switch.
    try:
        lease_state = str(getattr(operators.HOST_CONTROL.lease, "state", ""))
        satellite_runtime = bool(
            getattr(operators.STATE, "host_mode", "") == "satellite"
            or lease_state in {operators.SATELLITE, operators.DETACHING}
            or operators._external_satellite_alive()
        )
    except Exception:
        satellite_runtime = False
    if not satellite_runtime:
        return

    operators._request_return_from_external_satellite()


def install(operators):
    global _INSTALLED, _ORIGINAL_WATCHDOG, _UNSUBSCRIBE_STATE
    global _LAST_RETURN_SERIAL, _OPERATORS
    if _INSTALLED:
        return
    _OPERATORS = operators
    _LAST_RETURN_SERIAL = 0
    _ORIGINAL_WATCHDOG = operators._external_satellite_watchdog
    _UNSUBSCRIBE_STATE = operators.APP.events.subscribe(
        "sculpt.state.changed", _on_sculpt_state_changed,
    )

    def satellite_watchdog_with_explicit_close():
        if not bool(getattr(operators, "_EXTERNAL_SATELLITE_WATCHDOG_RUNNING", False)):
            return None

        closing = bool(getattr(operators.BRIDGE, "satellite_closing", False))
        if closing:
            # Only the native window X reports `satellite_closing`. The Host
            # switch now uses `satellite_return_request_serial`, so these two
            # product intents can no longer collapse into the same WM_CLOSE path.
            try:
                operators.BRIDGE.satellite_active = False
                operators.BRIDGE.stop_satellite_process()
            except Exception:
                pass

            operators.STATE.running = False
            operators.STATE.host = None
            operators.STATE.host_mode = "embedded"
            operators.STATE.status = "LumaFold closed from Satellite"
            operators._RETURN_EMBEDDED_TARGET = None
            operators._EXTERNAL_SATELLITE_WATCHDOG_RUNNING = False
            operators._MIGRATION_IN_PROGRESS = False

            try:
                lease = operators.HOST_CONTROL.lease
                if lease.state != operators.EMBEDDED or lease.owner != "embedded":
                    operators.HOST_CONTROL.recover_embedded()
            except Exception:
                try:
                    operators.HOST_CONTROL.recover_embedded()
                except Exception:
                    pass
            return None

        # No explicit close intent: preserve the accepted watchdog behavior for
        # unexpected process death / crash recovery back to Embedded.
        return _ORIGINAL_WATCHDOG()

    operators._external_satellite_watchdog = satellite_watchdog_with_explicit_close
    _INSTALLED = True


def uninstall(operators):
    global _INSTALLED, _ORIGINAL_WATCHDOG, _UNSUBSCRIBE_STATE
    global _LAST_RETURN_SERIAL, _OPERATORS
    if not _INSTALLED:
        return
    if callable(_UNSUBSCRIBE_STATE):
        try:
            _UNSUBSCRIBE_STATE()
        except Exception:
            pass
    _UNSUBSCRIBE_STATE = None
    if _ORIGINAL_WATCHDOG is not None:
        operators._external_satellite_watchdog = _ORIGINAL_WATCHDOG
    _ORIGINAL_WATCHDOG = None
    _LAST_RETURN_SERIAL = 0
    _OPERATORS = None
    _INSTALLED = False
