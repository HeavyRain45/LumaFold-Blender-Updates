from __future__ import annotations

# One source of truth for the development build shown in diagnostics.
# Product modules must not carry their own hand-written version labels.
BUILD_ID = "S0.8.6-beta1"
BUILD_TITLE = "Safe Restart Update Rehearsal"
BUILD_LABEL = f"{BUILD_ID} · {BUILD_TITLE}"
