from __future__ import annotations

"""Process-isolated LumaFold update transaction.

Never replace the running LumaFold extension in the Blender process that owns
its modal handlers, ImGui/WGL hosts or native modules.  The product process only
arms a clean helper Blender.  The helper starts with --factory-startup, waits
for the product Blender PID to exit, installs the package, then relaunches
Blender normally.
"""

import json
import os
from pathlib import Path
import subprocess
import tempfile

import bpy

_HELPER_NAME = "lumafold_update_helper.py"
_STATUS_NAME = "update_transaction.json"
_LOG_NAME = "update_transaction.log"


def _transaction_root() -> Path:
    root = Path(tempfile.gettempdir()) / "LumaFold" / "update"
    root.mkdir(parents=True, exist_ok=True)
    return root


def _status_path() -> Path:
    root = Path(bpy.utils.user_resource('CONFIG', path="lumafold", create=True))
    return root / _STATUS_NAME


def _write_status(payload: dict) -> None:
    path = _status_path()
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def read_status() -> dict:
    try:
        raw = json.loads(_status_path().read_text(encoding="utf-8"))
        return raw if isinstance(raw, dict) else {}
    except Exception:
        return {}


def _helper_source() -> str:
    # Deliberately standalone: this file is executed by a factory-startup Blender
    # and must never import the LumaFold package that is being replaced.
    return r'''from __future__ import annotations
import argparse
import ctypes
import json
from pathlib import Path
import subprocess
import sys
import time
import traceback
import bpy


def _write(path: Path, payload: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def _wait_for_process_exit(pid: int, timeout_s: float = 300.0):
    PROCESS_SYNCHRONIZE = 0x00100000
    kernel32 = ctypes.windll.kernel32
    handle = kernel32.OpenProcess(PROCESS_SYNCHRONIZE, False, int(pid))
    if not handle:
        return
    try:
        WAIT_OBJECT_0 = 0x00000000
        WAIT_TIMEOUT = 0x00000102
        deadline = time.monotonic() + timeout_s
        while time.monotonic() < deadline:
            result = kernel32.WaitForSingleObject(handle, 500)
            if result == WAIT_OBJECT_0:
                return
            if result != WAIT_TIMEOUT:
                raise RuntimeError(f"WaitForSingleObject failed: {result}")
        raise TimeoutError("Timed out waiting for Blender to exit")
    finally:
        kernel32.CloseHandle(handle)


def _repo_index(repo):
    for index, item in enumerate(bpy.context.preferences.extensions.repos):
        if item == repo:
            return index
    return -1


def main():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--wait-pid", type=int, required=True)
    parser.add_argument("--repo-url", required=True)
    parser.add_argument("--repo-module", default="lumafold_remote")
    parser.add_argument("--pkg-id", default="lumafold")
    parser.add_argument("--status-path", required=True)
    parser.add_argument("--log-path", required=True)
    parser.add_argument("--blender-exe", required=True)
    args = parser.parse_args(sys.argv[sys.argv.index("--") + 1:])
    status_path = Path(args.status_path)
    log_path = Path(args.log_path)
    try:
        _write(status_path, {"state": "waiting_for_exit", "target": args.pkg_id})
        _wait_for_process_exit(args.wait_pid)
        _write(status_path, {"state": "installing", "target": args.pkg_id})

        repos = bpy.context.preferences.extensions.repos
        repo = None
        target = args.repo_url.rstrip("/")
        for item in repos:
            if str(getattr(item, "remote_url", "") or "").rstrip("/") == target:
                repo = item
                break
        if repo is None:
            repo = repos.new(
                name="LumaFold Update Helper",
                module=args.repo_module,
                remote_url=args.repo_url,
                source='USER',
            )
        repo.enabled = True
        try:
            repo.use_remote_url = True
            repo.remote_url = args.repo_url
        except Exception:
            pass
        index = _repo_index(repo)
        if index < 0:
            raise RuntimeError("Helper could not resolve LumaFold repository")

        sync_result = set(bpy.ops.extensions.repo_sync(repo_index=index) or ())
        if "CANCELLED" in sync_result:
            raise RuntimeError("Helper repository sync was cancelled")
        install_result = set(bpy.ops.extensions.package_install(
            repo_index=index,
            pkg_id=args.pkg_id,
            enable_on_install=False,
        ) or ())
        if "CANCELLED" in install_result:
            raise RuntimeError("Helper package installation was cancelled")

        _write(status_path, {"state": "installed", "target": args.pkg_id})
        subprocess.Popen([args.blender_exe], close_fds=True)
    except Exception as exc:
        text = traceback.format_exc()
        log_path.parent.mkdir(parents=True, exist_ok=True)
        log_path.write_text(text, encoding="utf-8")
        _write(status_path, {
            "state": "failed",
            "target": args.pkg_id,
            "error": f"{type(exc).__name__}: {exc}",
            "log": str(log_path),
        })
        subprocess.Popen([args.blender_exe], close_fds=True)
        raise


if __name__ == "__main__":
    main()
'''


def arm(*, repo, extension_id: str) -> dict:
    """Launch the isolated helper and return transaction metadata.

    This function never mutates the installed extension.  The helper is already
    running in a separate factory-startup Blender before the product process is
    asked to quit, and it waits for this process to fully exit before touching
    the package directory.
    """
    blender_exe = str(getattr(bpy.app, "binary_path", "") or "")
    if not blender_exe or not Path(blender_exe).is_file():
        raise RuntimeError("无法定位当前 Blender 可执行文件")

    repo_url = str(getattr(repo, "remote_url", "") or "").strip()
    if not repo_url:
        raise RuntimeError("LumaFold 更新仓库 URL 为空")
    repo_module = str(getattr(repo, "module", "") or "lumafold_remote")

    root = _transaction_root()
    helper_path = root / _HELPER_NAME
    log_path = root / _LOG_NAME
    helper_path.write_text(_helper_source(), encoding="utf-8")
    try:
        log_path.unlink(missing_ok=True)
    except Exception:
        pass

    status_path = _status_path()
    _write_status({"state": "armed", "target": extension_id})
    command = [
        blender_exe,
        "--factory-startup",
        "--background",
        "--online-mode",
        "--python",
        str(helper_path),
        "--",
        "--wait-pid",
        str(os.getpid()),
        "--repo-url",
        repo_url,
        "--repo-module",
        repo_module,
        "--pkg-id",
        str(extension_id),
        "--status-path",
        str(status_path),
        "--log-path",
        str(log_path),
        "--blender-exe",
        blender_exe,
    ]
    creationflags = 0
    if os.name == "nt":
        creationflags = int(getattr(subprocess, "CREATE_NO_WINDOW", 0)) | int(getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
    proc = subprocess.Popen(
        command,
        cwd=str(root),
        close_fds=True,
        creationflags=creationflags,
    )
    return {
        "pid": int(proc.pid),
        "status_path": str(status_path),
        "log_path": str(log_path),
    }
