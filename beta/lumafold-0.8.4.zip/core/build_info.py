from __future__ import annotations

# One source of truth for the development build shown in diagnostics.
# Product modules must not carry their own hand-written version labels.
BUILD_ID = "S0.8.4-dev87"
BUILD_TITLE = "Release Manifest Compatibility"
BUILD_LABEL = f"{BUILD_ID} · {BUILD_TITLE}"
