import bpy

from .core.state import STATE
from .runtime import update_product


class LUMAFOLD_MT_product_maintenance(bpy.types.Menu):
    bl_label = "LumaFold"
    bl_idname = "LUMAFOLD_MT_product_maintenance"

    def draw(self, context):
        layout = self.layout
        status = layout.column(align=True)
        if STATE.last_error:
            status.label(text="检测到需要查看的问题", icon='ERROR')
        else:
            status.label(text="LumaFold 运行正常", icon='CHECKMARK')

        try:
            update = update_product.menu_snapshot()
            version = str(update.get("version", "") or "")
            channel_label = str(update.get("channel_label", "稳定版 Stable") or "稳定版 Stable")
            status.label(text=f"v{version} · {channel_label}", icon='FILE_REFRESH')
            transaction_state = str(update.get("update_transaction", "") or "")
            transaction_summary = str(update.get("update_summary", "") or "")
            if transaction_summary:
                icon = 'ERROR' if transaction_state == 'failed' else ('CHECKMARK' if transaction_state == 'installed' else 'INFO')
                status.label(text=transaction_summary, icon=icon)
            update_error = str(update.get("update_error", "") or "")
            if transaction_state == 'failed' and update_error:
                status.label(text=update_error[:96], icon='ERROR')
            if not bool(update.get("online_allowed", False)):
                status.label(text="Blender 当前未允许联网", icon='INFO')
            elif not bool(update.get("configured", False)):
                status.label(text=str(update.get("message", "更新源未配置")), icon='INFO')
        except Exception:
            pass

        layout.separator()
        update_col = layout.column(align=True)
        update_col.operator("lumafold.update_check", text="检查更新", icon='FILE_REFRESH')
        update_col.operator("lumafold.update_install", text="安装 LumaFold 更新", icon='IMPORT')
        update_col.operator("lumafold.update_setup_repository", text="配置在线更新", icon='URL')
        update_col.operator("lumafold.update_open_native", text="打开 Blender 更新管理", icon='PREFERENCES')

        channel_row = layout.row(align=True)
        stable = channel_row.operator("lumafold.update_set_channel", text="Stable")
        stable.channel = 'stable'
        beta = channel_row.operator("lumafold.update_set_channel", text="Beta")
        beta.channel = 'beta'

        layout.separator()
        layout.operator("lumafold.write_diagnostics", text="生成检测报告", icon='FILE_TICK')


def _draw_lumafold_header(self, context):
    """Product launch + low-frequency maintenance entry; no N-panel required."""
    row = self.layout.row(align=True)
    row.separator(factor=0.35)
    embedded_running = bool(
        getattr(STATE, "running", False)
        and str(getattr(STATE, "host_mode", "embedded") or "embedded").lower() == "embedded"
    )
    operator_id = "lumafold.close_embedded_host" if embedded_running else "lumafold.toggle_p0"
    row.operator(
        operator_id,
        text="LumaFold",
        icon='BRUSH_DATA',
        depress=bool(getattr(STATE, "running", False)),
    )
    row.menu("LUMAFOLD_MT_product_maintenance", text="", icon='DOWNARROW_HLT')


def _tag_view3d_headers_redraw():
    try:
        wm = bpy.context.window_manager
        for window in wm.windows:
            screen = window.screen
            if screen is None:
                continue
            for area in screen.areas:
                if area.type != 'VIEW_3D':
                    continue
                for region in area.regions:
                    if region.type == 'HEADER':
                        region.tag_redraw()
    except Exception:
        pass


CLASSES = (LUMAFOLD_MT_product_maintenance,)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    try:
        bpy.types.VIEW3D_HT_header.remove(_draw_lumafold_header)
    except Exception:
        pass
    try:
        bpy.types.VIEW3D_HT_header.append(_draw_lumafold_header)
    except Exception:
        pass
    _tag_view3d_headers_redraw()


def unregister():
    try:
        bpy.types.VIEW3D_HT_header.remove(_draw_lumafold_header)
    except Exception:
        pass
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
